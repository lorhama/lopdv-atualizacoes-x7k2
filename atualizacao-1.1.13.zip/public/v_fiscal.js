// Integração fiscal: notas da SEFAZ (painel pendentes/importadas) e configuração do certificado, agendamento e serviço pago.
const UFS = [['11', 'RO'], ['12', 'AC'], ['13', 'AM'], ['14', 'RR'], ['15', 'PA'], ['16', 'AP'], ['17', 'TO'], ['21', 'MA'], ['22', 'PI'], ['23', 'CE'], ['24', 'RN'], ['25', 'PB'], ['26', 'PE'], ['27', 'AL'], ['28', 'SE'], ['29', 'BA'], ['31', 'MG'], ['32', 'ES'], ['33', 'RJ'], ['35', 'SP'], ['41', 'PR'], ['42', 'SC'], ['43', 'RS'], ['50', 'MS'], ['51', 'MT'], ['52', 'GO'], ['53', 'DF']];
const fmtChave = c => String(c || '').replace(/(\d{4})(?=\d)/g, '$1 ').trim();
// Busca por chave pelo SITE de consulta da SEFAZ (grátis). O site exige a digitação do código de segurança (captcha) por uma pessoa,
// então o sistema abre o site certo, deixa a chave copiada e recebe de volta o XML baixado (ou o PDF/foto da consulta).
const UF_COD = { 11: 'RO', 12: 'AC', 13: 'AM', 14: 'RR', 15: 'PA', 16: 'AP', 17: 'TO', 21: 'MA', 22: 'PI', 23: 'CE', 24: 'RN', 25: 'PB', 26: 'PE', 27: 'AL', 28: 'SE', 29: 'BA', 31: 'MG', 32: 'ES', 33: 'RJ', 35: 'SP', 41: 'PR', 42: 'SC', 43: 'RS', 50: 'MS', 51: 'MT', 52: 'GO', 53: 'DF' };
const NFCE_URL = { AC: 'https://www.sefaznet.ac.gov.br/nfce/consulta', AL: 'http://nfce.sefaz.al.gov.br/consultaNFCe.htm', AP: 'https://www.sefaz.ap.gov.br/sate/seg/SEGf_AcessarFuncao.jsp?cdFuncao=FIS_1261', AM: 'https://sistemas.sefaz.am.gov.br/nfceweb/formConsulta.do',
  BA: 'http://nfe.sefaz.ba.gov.br/servicos/nfce/Modulos/Geral/NFCEC_consulta_chave_acesso.aspx', DF: 'https://ww1.receita.fazenda.df.gov.br/documentosfiscais/consultar', ES: 'http://app.sefaz.es.gov.br/ConsultaNFCe', GO: 'http://www.nfce.go.gov.br/post/ver/214344/consulta-nfce',
  MA: 'http://www.nfce.sefaz.ma.gov.br/portal/consultaNFe.do?method=preFilterCupom&', MT: 'http://www.sefaz.mt.gov.br/nfce/consultanfce', MS: 'http://www.dfe.ms.gov.br/nfce', MG: 'http://nfce.fazenda.mg.gov.br/portalnfce/sistema/consultaarg.xhtml',
  PA: 'https://appnfc.sefa.pa.gov.br/portal/view/consultas/nfce/consultanfce.seam', PB: 'https://www.sefaz.pb.gov.br/servirtual/documentos-fiscais/nfc-e/consultar-nfc-e', PR: 'https://sped.fazenda.pr.gov.br/NFCe/webservices/sped/nfce/completa',
  PE: 'http://nfce.sefaz.pe.gov.br/nfce/consulta', PI: 'https://www.sefaz.pi.gov.br/nfce/index.jsf', RJ: 'http://www.nfce.fazenda.rj.gov.br/consulta', RN: 'http://nfce.set.rn.gov.br/portalDFE/NFCe/ConsultaNFCe.aspx', RS: 'https://www.sefaz.rs.gov.br/NFCE/NFCE-COM.aspx',
  RO: 'https://www.nfce.sefin.ro.gov.br', RR: 'https://portalapp.sefaz.rr.gov.br/nfce/consulta', SC: 'https://sat.sef.sc.gov.br/nfce/consulta', SP: 'https://www.nfce.fazenda.sp.gov.br/NFCeConsultaPublica/Paginas/ConsultaPublica.aspx',
  SE: 'http://www.nfce.se.gov.br/portal/portalNoticias.jsp', TO: 'http://www.sefaz.to.gov.br/nfce/consulta.jsf' };
const NFE_URL = 'https://www.nfe.fazenda.gov.br/portal/consultaRecaptcha.aspx?tipoConsulta=resumo&tipoConteudo=7PhJ+gAVw2g=';
function buscaSiteSefaz() {
  const corpo = document.createElement('div');
  corpo.innerHTML = `<p class="muted">Consulta <b>gratuita</b> no site oficial da SEFAZ. O site pede o código de segurança (captcha), que precisa ser digitado por você; por isso o sistema não consegue buscar sozinho.</p>
    <label>Chave de acesso (44 números)<input id="csc" inputmode="numeric" placeholder="cole a chave de acesso" autocomplete="off"></label><div id="csi" class="muted" style="margin:6px 0"></div>
    <button class="btn primary" type="button" id="cso" disabled>Abrir o site de consulta da SEFAZ</button>
    <ol style="margin:12px 0 0 18px;line-height:1.5"><li>Clique no botão acima (a chave já fica copiada: é só colar).</li><li>Digite o código de segurança e consulte a nota.</li>
      <li><b>Se o site oferecer baixar o XML:</b> baixe e escolha o arquivo abaixo.</li><li><b>Se só mostrar a nota na tela:</b> salve a página como <b>PDF</b> (Ctrl+P → Salvar como PDF) ou tire um print e use a aba <b>📷 Foto / PDF da nota</b> em Estoque → Entrada de mercadoria.</li></ol>
    <label style="margin-top:8px">Já baixei o XML da nota<input type="file" id="csx" accept=".xml,text/xml"></label>`;
  const m = modal({ titulo: 'Buscar por chave no site da SEFAZ', tam: 'md', corpo, botoes: [{ txt: 'Fechar' }] });
  const info = () => { const ch = $('#csc', corpo).value.replace(/\D/g, ''); let t = '', ok = false;
    if (ch.length === 44) { const uf = UF_COD[+ch.slice(0, 2)], mod = ch.slice(20, 22); ok = !!uf; t = ok ? `UF ${uf} · ${mod === '65' ? 'NFC-e (cupom de consumidor)' : mod === '55' ? 'NF-e' : 'modelo ' + mod} · nº ${Number(ch.slice(25, 34))}` : 'Chave inválida (UF desconhecida).'; }
    else if (ch.length) t = `${ch.length} de 44 números`;
    $('#csi', corpo).textContent = t; $('#cso', corpo).disabled = !ok; };
  $('#csc', corpo).oninput = info;
  $('#cso', corpo).onclick = () => { const ch = $('#csc', corpo).value.replace(/\D/g, ''), uf = UF_COD[+ch.slice(0, 2)], mod = ch.slice(20, 22);
    try { navigator.clipboard.writeText(ch).catch(() => { /* sem permissão: cole a chave manualmente */ }); } catch { /* sem área de transferência */ }
    const url = mod === '65' ? NFCE_URL[uf] : NFE_URL;
    if (!url) { aviso('Não tenho o endereço de consulta de NFC-e do seu estado. Use o endereço impresso no próprio cupom (perto do QR Code). A chave já foi copiada.'); return; }
    window.open(url, '_blank', 'noopener'); toast('Chave copiada. Cole no site e digite o código de segurança.'); };
  $('#csx', corpo).onchange = seguro(async e => { const f = e.target.files[0]; if (!f) return; const t = await f.text();
    if (!/<(infNFe|infCFe|NFe|CFe|nfeProc)\b/.test(t)) throw new Error('Esse arquivo não parece ser o XML de uma nota fiscal.');
    sessionStorage.setItem('xmlTexto', t); m.fechar(); location.hash = '#/entrada'; });
}


registrar({ id: 'notas-sefaz', titulo: 'Entrada de mercadoria (Automática)', grupo: 'Estoque', perm: 'estoque.entrada', render: async el => {
  if (await semEmpresa(el, 'dar entrada de mercadoria')) return;
  let aba = 'pendentes';
  const carregar = async () => {
    const [p, cfg] = await Promise.all([api('/fiscal/painel'), api('/fiscal/config')]);
    const rs = p.resumo, hr2 = x => (x ? dt(x) : '—');
    const abaBtn = (k, t) => `<button class="${aba === k ? 'on' : ''}" data-ab="${k}">${t}</button>`;
    const linhaNota = r => `<b>${esc(r.emitente_nome || '(sem nome)')}</b><br><small class="muted">${esc(r.emitente_doc || '')} · NF ${esc(r.numero || '—')} · ${r.emissao ? dia(r.emissao) : 'sem data'}</small>`;
    let corpo = '';
    if (aba === 'pendentes') corpo = tabela([{ l: 'Nota', f: linhaNota }, { l: 'Valor', n: 1, f: r => R(r.valor) },
      { l: 'XML', f: r => (r.tem_xml ? chip('completo', 'retirado') : chip(r.manifestado_em ? 'aguardando SEFAZ' : 'só resumo', 'novo')) }, { l: 'Origem', f: r => (r.origem === 'servico' ? 'Serviço pago' : 'SEFAZ') }, { l: 'Chave', f: r => `<small class="muted">${esc(fmtChave(r.chave))}</small>` }],
      p.pendentes, { vazio: 'Nada pendente. Use "Buscar XMLs na SEFAZ".', acoes: r => (r.tem_xml ? `<button class="btn sm primary" data-imp="${r.chave}">Importar para o estoque</button> ` : (r.manifestado_em ? '' : `<button class="btn sm" data-ci="${r.chave}" title="Dar ciência da operação para a SEFAZ liberar o XML completo">Dar ciência</button> `)) + `<button class="btn sm" data-ig="${r.chave}">Ignorar</button>` });
    else if (aba === 'importadas') corpo = tabela([{ l: 'Nota', f: linhaNota }, { l: 'Valor', n: 1, f: r => R(r.valor) }, { l: 'Entrada no estoque', f: r => `#${r.entrada_id} · ${dt(r.importada_em)}` }, { l: 'Chave', f: r => `<small class="muted">${esc(fmtChave(r.chave))}</small>` }], p.importadas, { vazio: 'Nenhuma nota importada ainda.' });
    else if (aba === 'ignoradas') corpo = tabela([{ l: 'Nota', f: linhaNota }, { l: 'Valor', n: 1, f: r => R(r.valor) }], p.ignoradas, { vazio: 'Nenhuma nota ignorada.', acoes: r => `<button class="btn sm" data-re="${r.chave}">Voltar para pendentes</button>` });
    else corpo = tabela([{ l: 'Data', f: r => dt(r.criado_em) }, { l: 'Origem', k: 'origem' }, { l: 'Novas', n: 1, k: 'novos' }, { l: 'XML completos', n: 1, k: 'completos' }, { l: 'Só resumo', n: 1, k: 'resumos' }, { l: 'Ciências', n: 1, k: 'ciencias' }, { l: 'Resultado', f: r => (r.erro ? `<span class="erro">${esc(r.erro)}</span>` : esc(r.resultado || 'ok')) }], p.buscas, { vazio: 'Nenhuma busca feita ainda.' });
    el.innerHTML = `<div class="cards">
        <div class="stat">Pendentes de entrada<b>${rs.pendentes}</b><small class="muted">${rs.pendentes_com_xml} com XML pronto · ${R(rs.valor_pendente)}</small></div>
        <div class="stat">Já importadas para o estoque<b>${rs.importadas}</b></div>
        <div class="stat">Última busca<b style="font-size:16px">${cfg.ultima_busca ? dt(cfg.ultima_busca) : '—'}</b><small class="muted">${cfg.proxima_consulta && new Date(cfg.proxima_consulta) > new Date() ? 'Próxima consulta liberada às ' + hr(cfg.proxima_consulta) : 'Agenda: ' + ({ desligado: 'desligada', intervalo: 'a cada ' + cfg.intervalo_min + ' min', diario: 'diária às ' + cfg.hora }[cfg.agenda] || '')}</small></div></div>
      <div class="bar"><button class="btn primary" id="buscar" ${cfg.cert ? '' : 'disabled title="Cadastre o certificado em Integração fiscal"'}>Buscar XMLs na SEFAZ</button>
        <button class="btn" id="chave" ${cfg.svc.url ? '' : 'disabled title="Configure o serviço em Integração fiscal"'}>Buscar por chave (serviço pago)</button><button class="btn" id="chavesite" title="Grátis: abre o site de consulta da SEFAZ com a chave pronta para colar">Buscar por chave no site da SEFAZ</button><div class="grow"></div><button class="btn" id="atu">↻ Atualizar</button></div>
      ${!cfg.cert && !cfg.svc.url ? '<div class="card"><b>Nenhuma integração configurada.</b> Cadastre o certificado digital ou o serviço pago em <a href="#/integracao-fiscal">Integração fiscal</a>.</div>' : ''}
      <div class="tabs">${abaBtn('pendentes', 'Pendentes de entrada (' + rs.pendentes + ')')}${abaBtn('importadas', 'Já importadas (' + rs.importadas + ')')}${abaBtn('ignoradas', 'Ignoradas (' + p.ignoradas.length + ')')}${abaBtn('buscas', 'Buscas recentes')}</div>${corpo}`;
  };
  el.onclick = seguro(async e => {
    const d = e.target.dataset || {};
    if (d.ab) { aba = d.ab; return carregar(); }
    if (e.target.id === 'atu') return carregar();
    if (d.imp) { sessionStorage.setItem('xmlChave', d.imp); location.hash = '#/entrada'; return; }
    if (d.ig) { await api('/fiscal/ignorar', { method: 'POST', body: { chaves: [d.ig] } }); return carregar(); }
    if (d.re) { await api('/fiscal/ignorar', { method: 'POST', body: { chaves: [d.re], ignorar: false } }); return carregar(); }
    if (d.ci) { const r = await api('/fiscal/ciencia', { method: 'POST', body: { chaves: [d.ci] } }); if (r.erros.length) throw new Error(r.erros[0]); toast('Ciência registrada. O XML completo costuma chegar na próxima busca (aguarde alguns minutos).'); return carregar(); }
    if (e.target.id === 'buscar') {
      e.target.disabled = true; toast('Buscando na SEFAZ... pode levar alguns instantes.');
      try { const r = await api('/fiscal/buscar', { method: 'POST' });
        if (r.erro) toast('Busca terminou com aviso: ' + r.erro, 'aviso'); else toast(r.novos ? `${r.novos} nota(s) nova(s): ${r.completos} com XML, ${r.resumos} só resumo.` : 'Nenhuma nota nova (SEFAZ: ' + (r.motivo || 'ok') + ').'); }
      finally { e.target.disabled = false; }
      return carregar();
    }
    if (e.target.id === 'chavesite') return buscaSiteSefaz();
    if (e.target.id === 'chave') formModal({ titulo: 'Buscar notas por chave de acesso (serviço pago)', tam: 'md', campos: [{ k: 'chaves', l: 'Chaves de acesso (44 números; uma por linha — pode colar várias)', t: 'textarea', full: true, req: true }],
      extra: '<p class="muted">Cada consulta pode ser cobrada pelo serviço contratado. A nota buscada aparece em "Pendentes de entrada".</p>',
      onSave: async o => { const r = await api('/fiscal/chave', { method: 'POST', body: { chaves: o.chaves } }); const ok = r.filter(x => x.ok).length;
        toast(`${ok} de ${r.length} nota(s) encontrada(s).`, ok === r.length ? undefined : 'aviso'); r.filter(x => !x.ok).slice(0, 3).forEach(x => toast(fmtChave(x.chave).slice(0, 20) + '…: ' + x.erro, 'aviso')); carregar(); } });
  });
  await carregar();
} });

registrar({ id: 'integracao-fiscal', titulo: 'Integração fiscal (SEFAZ)', grupo: 'Sistema', perm: 'config.gerenciar', render: async el => {
  const c = await api('/fiscal/config');
  const op = (l, sel) => l.map(([v, t]) => `<option value="${v}" ${String(v) === String(sel) ? 'selected' : ''}>${t}</option>`).join('');
  el.innerHTML = `<div class="card"><h3>1. Certificado digital A1 e busca na SEFAZ</h3>
      <p class="muted">Com o certificado A1 (arquivo .pfx), o sistema consulta a SEFAZ e traz as notas emitidas contra o CNPJ da empresa. Cupom de consumidor (NFC-e) em geral não aparece aqui — use o serviço pago abaixo. O certificado e a senha ficam guardados só neste computador (senha cifrada).</p>
      ${c.cert ? `<p>✅ Certificado cadastrado: <b>${esc(c.cert.nome)}</b><br><small class="muted">${esc(c.cert.titular)} · válido até ${esc(c.cert.validade)}</small> <button class="btn sm danger" id="rmcert">Remover</button></p>` : '<p class="erro">Nenhum certificado cadastrado.</p>'}
      <div class="row"><label style="flex:2">Arquivo do certificado (.pfx ou .p12)<input type="file" id="pfx" accept=".pfx,.p12"></label><label>Senha do certificado<input id="pfxs" type="password" autocomplete="off"></label><button class="btn primary auto" id="envcert">Enviar certificado</button></div>
      <div class="row"><label>CNPJ da empresa<input id="cnpj" value="${esc(c.cnpj)}" inputmode="numeric" placeholder="só números"></label><label>Estado (UF)<select id="uf">${op(UFS.map(([v, t]) => [v, t]), c.uf)}</select></label>
        <label>Ambiente<select id="amb">${op([['1', 'Produção (notas reais)'], ['2', 'Homologação (teste)']], c.ambiente)}</select></label></div>
      <h4 style="margin-top:14px">Agendamento da busca</h4>
      <div class="row"><label>Quando buscar<select id="ag">${op([['desligado', 'Desligado (só pelo botão)'], ['intervalo', 'A cada intervalo de tempo'], ['diario', 'Uma vez por dia']], c.agenda)}</select></label>
        <label id="lbint">Intervalo (minutos, mínimo 61)<input id="int" value="${esc(c.intervalo_min)}" inputmode="numeric"></label><label id="lbhr">Horário<input id="hr" type="time" value="${esc(c.hora)}"></label></div>
      <label class="chk"><input type="checkbox" id="aci" ${c.auto_ciencia ? 'checked' : ''}> Dar ciência da operação automaticamente nas notas que vierem só com resumo (a SEFAZ então libera o XML completo na busca seguinte)</label>
      <p class="muted">A SEFAZ bloqueia consultas muito frequentes: após não haver notas novas, só aceita nova consulta depois de 1 hora. O sistema respeita isso sozinho: nunca faz duas consultas com menos de 1h00min02s entre elas (nem pelo agendamento, nem pelo botão). O agendamento só roda enquanto o sistema estiver aberto no computador servidor.</p>
      <button class="btn primary" id="sfis">Salvar</button></div>
    <div class="card"><h3>2. Serviço pago de busca por chave</h3>
      <p class="muted">Funciona também para cupom de consumidor, conforme o serviço contratado. Preencha com os dados da documentação do serviço (endereço, nome do cabeçalho da chave de acesso etc.). Use <b>{chave}</b> no endereço onde vai a chave de 44 números.</p>
      <div class="row"><label style="flex:3">Endereço (https://...)<input id="su" value="${esc(c.svc.url)}" placeholder="https://servico.exemplo.com/nfe/{chave}"></label><label>Método<select id="sm">${op([['GET', 'GET'], ['POST', 'POST (envia {"chave": ...})']], c.svc.metodo)}</select></label></div>
      <div class="row"><label>Nome do cabeçalho de acesso<input id="sh" value="${esc(c.svc.header_nome)}" placeholder="ex: Api-Key"></label><label>Prefixo (se houver)<input id="sp" value="${esc(c.svc.header_prefixo)}" placeholder="ex: Bearer "></label>
        <label>Chave de acesso (Api-Key)<input id="sk" type="password" autocomplete="off" placeholder="${c.svc.tem_chave ? '•••••••• (deixe vazio para manter)' : 'cole a chave do serviço'}"></label></div>
      <div class="row"><label>A resposta vem como<select id="sr">${op([['xml', 'XML direto (ou em base64)'], ['json', 'JSON com o XML dentro de um campo']], c.svc.resposta)}</select></label><label id="lbcampo">Campo do JSON com o XML<input id="sc" value="${esc(c.svc.campo)}" placeholder="xml"></label></div>
      <div class="row"><label style="flex:2">Testar com uma chave de acesso<input id="st" inputmode="numeric" placeholder="44 números"></label><button class="btn auto" id="ssv">Salvar</button><button class="btn primary auto" id="stest">Salvar e testar</button></div></div>`;
  const vis = () => { $('#lbint', el).style.display = $('#ag', el).value === 'intervalo' ? '' : 'none'; $('#lbhr', el).style.display = $('#ag', el).value === 'diario' ? '' : 'none'; $('#lbcampo', el).style.display = $('#sr', el).value === 'json' ? '' : 'none'; };
  vis(); el.onchange = vis;
  const salvarFiscal = async () => api('/fiscal/config', { method: 'PUT', body: { cnpj: $('#cnpj', el).value, uf: $('#uf', el).value, ambiente: $('#amb', el).value, agenda: $('#ag', el).value, intervalo_min: $('#int', el).value, hora: $('#hr', el).value, auto_ciencia: $('#aci', el).checked } });
  const salvarSvc = async () => api('/fiscal/config', { method: 'PUT', body: { svc: { url: $('#su', el).value, metodo: $('#sm', el).value, header_nome: $('#sh', el).value, header_prefixo: $('#sp', el).value, header_valor: $('#sk', el).value, resposta: $('#sr', el).value, campo: $('#sc', el).value } } });
  el.onclick = seguro(async e => {
    const id = e.target.id;
    if (id === 'sfis') { await salvarFiscal(); toast('Configuração salva.'); return rotear(); }
    if (id === 'ssv') { await salvarSvc(); toast('Serviço salvo.'); return rotear(); }
    if (id === 'stest') { await salvarSvc(); const r = await api('/fiscal/servico/testar', { method: 'POST', body: { chave: $('#st', el).value } }); toast(`Serviço funcionando: ${r.emitente || 'nota'} · ${R(r.valor)}.`); return; }
    if (id === 'rmcert') { if (await confirmar('Remover o certificado digital deste sistema? A busca agendada será desligada.')) { await api('/fiscal/certificado', { method: 'DELETE' }); return rotear(); } return; }
    if (id === 'envcert') {
      const f = $('#pfx', el).files[0], senha = $('#pfxs', el).value; if (!f) throw new Error('Escolha o arquivo do certificado.'); if (!senha) throw new Error('Informe a senha do certificado.');
      const b64 = await new Promise((ok, no) => { const rd = new FileReader(); rd.onload = () => ok(String(rd.result).split(',')[1]); rd.onerror = no; rd.readAsDataURL(f); });
      toast('Conferindo o certificado...'); const r = await api('/fiscal/certificado', { method: 'POST', body: { pfx_base64: b64, senha, nome: f.name } });
      toast('Certificado aceito. Válido até ' + r.validade + '.'); return rotear();
    }
  });
} });
