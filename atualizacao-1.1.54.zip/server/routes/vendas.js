// Vendas diretas: itens, envio para cozinha/bar (ao receber), controle de retirada, pagamento.
const express = require('express');
const { precoVigente, reaplicarCombos } = require('../promocoes');
const db = require('../db');
const { auth, can, verificarAutorizacao, auditar } = require('../auth');
const { HttpError, wrap, num, r2, hoje } = require('../util');
const est = require('../estoque_lib');
const prn = require('../printer');
const r = express.Router();

const tef = require('../tef');

async function pedidoCompleto(id) {
  const p = (await db.q(`select p.*, u.nome usuario, coalesce(vd.nome,u.nome) vendedor, coalesce(vd.codigo,u.codigo) vendedor_codigo, c.nome cliente, v.numero venda_numero, cx.numero caixa_numero
    from pedidos p left join usuarios u on u.id=p.usuario_id left join usuarios vd on vd.id=p.vendedor_id left join clientes c on c.id=p.cliente_id
    left join vendas v on v.pedido_id=p.id left join caixas cx on cx.id=coalesce(p.caixa_id, v.caixa_id, (select id from caixas where usuario_id=p.usuario_id and status='aberto' order by id desc limit 1)) where p.id=$1`, [id])).rows[0];
  if (!p) throw new HttpError(404, 'Venda não encontrada.');
  const run = (s, a) => db.q(s, a);
  p.itens = (await run(`select i.*, u.nome usuario, rp.nome retirado_por_nome from pedido_itens i
    left join usuarios u on u.id=i.usuario_id left join usuarios rp on rp.id=i.retirado_por where i.pedido_id=$1 order by i.id`, [id])).rows;
  p.pagamentos = (await run('select * from pagamentos where pedido_id=$1 order by id', [id])).rows;
  p.devolucoes = (await run('select d.*, u.nome usuario from devolucoes d left join usuarios u on u.id=d.usuario_id where d.pedido_id=$1 order by d.id', [id])).rows;
  p.subtotal = r2(p.itens.filter(i => i.status !== 'cancelado').reduce((s, i) => s + Number(i.quantidade) * Number(i.preco_unit), 0));
  if (p.status === 'aberto') p.total = r2(p.subtotal - Number(p.desconto || 0));
  return p;
}

// O que sai do estoque por um item vendido (o próprio produto ou, se preparado, os insumos da ficha técnica)
async function linhasDoItem(c, prod, qtd) {
  const linhas = []; let custo = 0;
  if (prod.tipo === 'preparado' && prod.controla_estoque) {
    // preparado com estoque próprio (ex.: pipoca feita antes na Produção): a venda baixa só o produto, não os insumos
    const pp = (await c.query('select * from produtos where id=$1 for update', [prod.id])).rows[0];
    custo = Number(pp.custo_medio); linhas.push({ p: pp, q: qtd });
  } else if (prod.tipo === 'preparado') {
    const rec = await c.query(`select p.*, r.quantidade rq from receitas r join produtos p on p.id=r.insumo_id
      where r.produto_id=$1 order by p.id for update of p`, [prod.id]);
    for (const i of rec.rows) { custo += Number(i.rq) * Number(i.custo_medio); if (i.controla_estoque) linhas.push({ p: i, q: Number(i.rq) * qtd }); }
  } else {
    const pp = (await c.query('select * from produtos where id=$1 for update', [prod.id])).rows[0];
    custo = Number(pp.custo_medio);
    if (pp.controla_estoque) linhas.push({ p: pp, q: qtd });
  }
  return { linhas, custo };
}

// Baixa o estoque da venda SOMENTE quando ela foi finalizada (paga) e todos os itens foram entregues (retirados) na cozinha/bar.
async function baixarEstoqueVenda(pedidoId, userId) {
  return db.tx(async c => {
    const ped = (await c.query('select * from pedidos where id=$1 for update', [pedidoId])).rows[0];
    if (!ped || ped.status !== 'fechado' || ped.estoque_baixado_em) return false;
    const itens = (await c.query("select * from pedido_itens where pedido_id=$1 and status<>'cancelado' order by id", [ped.id])).rows;
    if (!itens.length || itens.some(i => i.status !== 'retirado')) return false;
    for (const it of itens) {
      if ((await c.query("select 1 from mov_estoque where origem='pedido_item' and ref_id=$1 and tipo='venda'", [it.id])).rowCount) continue; // já baixado (vendas antigas)
      const prod = (await c.query('select * from produtos where id=$1', [it.produto_id])).rows[0];
      if (!prod) continue;
      // item genérico (ex.: "Refrigerante"): baixa as bebidas que o bar informou na retirada
      const esc = (await c.query('select produto_id, quantidade from item_escolhas where item_id=$1 order by id', [it.id])).rows;
      let linhas = [];
      if (esc.length) {
        let custoTot = 0, qTot = 0;
        for (const e of esc) {
          const pe = (await c.query('select * from produtos where id=$1', [e.produto_id])).rows[0]; if (!pe) continue;
          const r = await linhasDoItem(c, pe, Number(e.quantidade)); linhas = linhas.concat(r.linhas); custoTot += r.custo * Number(e.quantidade); qTot += Number(e.quantidade);
        }
        if (qTot > 0) await c.query('update pedido_itens set custo_unit=$1 where id=$2', [Math.round(custoTot / qTot * 1e4) / 1e4, it.id]);
      } else linhas = (await linhasDoItem(c, prod, Number(it.quantidade))).linhas;
      for (const l of linhas)
        await est.mover(c, { produto_id: l.p.id, tipo: 'venda', quantidade: -l.q, custo_unit: l.p.custo_medio, origem: 'pedido_item', ref_id: it.id, motivo: `Venda #${ped.id}`, usuario_id: userId });
    }
    await c.query('update pedidos set estoque_baixado_em=now() where id=$1', [ped.id]);
    return true;
  });
}

// Devolve ao estoque tudo que foi baixado por um item (inclusive insumos da ficha técnica)
async function devolverEstoque(c, itemId, userId, motivo) {
  // devolve o que ainda está "fora" (venda menos o que já foi estornado antes, p.ex. em devolução parcial)
  const m = await c.query("select produto_id, sum(quantidade) q, max(custo_unit) custo from mov_estoque where origem='pedido_item' and ref_id=$1 and tipo in ('venda','estorno') group by produto_id", [itemId]);
  for (const x of m.rows) {
    const q = Math.round(-Number(x.q) * 1000) / 1000; if (Math.abs(q) < 0.0004) continue;
    await est.mover(c, { produto_id: x.produto_id, tipo: 'estorno', quantidade: q, custo_unit: x.custo, origem: 'pedido_item', ref_id: itemId, motivo, usuario_id: userId });
  }
}

// ---- Lista de vendas
r.get('/pedidos', auth('vendas.acessar'), wrap(async (req, res) => {
  const status = ['aberto', 'fechado', 'cancelado'].includes(req.query.status) ? req.query.status : 'aberto';
  const x = await db.q(`select p.*, v.numero venda_numero, u.nome usuario, coalesce(s.sub,0) subtotal, coalesce(s.n,0) itens, coalesce(s.novos,0) novos, coalesce(s.pend,0) pendentes
    from pedidos p left join usuarios u on u.id=p.usuario_id left join vendas v on v.pedido_id=p.id
    left join lateral (select sum(quantidade*preco_unit) sub, count(*)::int n,
      count(*) filter (where status='novo')::int novos, count(*) filter (where status='enviado')::int pend
      from pedido_itens where pedido_id=p.id and status<>'cancelado') s on true
    where p.status=$1 order by p.id desc limit 200`, [status]);
  res.json(x.rows);
}));

async function exigirCaixa(user) {
  if (!(await db.q("select 1 from caixas where usuario_id=$1 and status='aberto'", [user.id])).rowCount)
    throw new HttpError(400, 'Você precisa ter um caixa aberto para vender. Abra o caixa no menu Caixa.', { sem_caixa: true });
}

// Venda direta: abre uma nova venda (sem mesa/identificação). Se o usuário já tem uma venda aberta e vazia, reaproveita.
const exigeEmpresa = require('../exige_empresa');
r.post('/pedidos', auth('vendas.acessar'), wrap(async (req, res) => {
  await exigeEmpresa();
  await exigirCaixa(req.user);
  const vazia = await db.q(`select id from pedidos p where status='aberto' and usuario_id=$1 and not exists (select 1 from pedido_itens i where i.pedido_id=p.id and i.status<>'cancelado') and p.id <> all($2::int[]) order by id limit 1`, [req.user.id, (Array.isArray((req.body || {}).excluir) ? req.body.excluir : []).map(Number).filter(Number.isInteger)]);
  // empresa do terminal (cabeçalho X-Empresa-Id, definido no instalador do atalho); se não houver/for inválida, a empresa em uso
  const eid = +req.get('x-empresa-id') || 0;
  const emp = (eid ? (await db.q('select id from empresas where id=$1 and ativo', [eid])).rows[0] : null) || (await db.q('select id from empresas where em_uso limit 1')).rows[0];
  if (vazia.rowCount) { await db.q('update pedidos set empresa_id=$2 where id=$1', [vazia.rows[0].id, emp ? emp.id : null]); return res.json(await pedidoCompleto(vazia.rows[0].id)); }
  const x = await db.q("insert into pedidos(tipo,usuario_id,empresa_id) values('balcao',$1,$2) returning id", [req.user.id, emp ? emp.id : null]);
  res.json(await pedidoCompleto(x.rows[0].id));
}));

// Troca o cliente da venda em andamento
r.put('/pedidos/:id/cliente', auth('vendas.acessar'), wrap(async (req, res) => {
  const ped = (await db.q('select status from pedidos where id=$1', [req.params.id])).rows[0];
  if (!ped) throw new HttpError(404, 'Venda não encontrada.');
  if (ped.status !== 'aberto') throw new HttpError(400, 'Só é possível trocar o cliente de uma venda aberta.');
  const cid = req.body?.cliente_id ? Number(req.body.cliente_id) : null;
  if (cid && !(await db.q('select 1 from clientes where id=$1', [cid])).rowCount) throw new HttpError(400, 'Cliente não encontrado.');
  await db.q('update pedidos set cliente_id=$1 where id=$2', [cid, req.params.id]);
  res.json(await pedidoCompleto(req.params.id));
}));

r.get('/pedidos/:id', auth('vendas.acessar'), wrap(async (req, res) => res.json(await pedidoCompleto(req.params.id))));

// ---- Lançar item (confere o estoque e bloqueia estoque negativo; a baixa é feita só após a entrega de tudo)
r.post('/pedidos/:id/itens', auth('vendas.acessar'), wrap(async (req, res) => {
  await exigirCaixa(req.user);
  const b = req.body || {};
  const qtd = num(b.quantidade, 1);
  if (qtd <= 0) throw new HttpError(400, 'Quantidade inválida.');
  await db.tx(async c => {
    const ped = (await c.query('select * from pedidos where id=$1 for update', [req.params.id])).rows[0];
    if (!ped) throw new HttpError(404, 'Venda não encontrada.');
    if (ped.status !== 'aberto') throw new HttpError(400, 'Esta venda não está aberta.');
    const prod = (await c.query('select * from produtos where id=$1', [b.produto_id])).rows[0];
    if (!prod || !prod.ativo || !prod.vendavel) throw new HttpError(400, 'Produto indisponível para venda.');

    // o que vai sair do estoque (a baixa só acontece depois que a venda for paga e todos os itens entregues)
    const { linhas, custo } = await linhasDoItem(c, prod, qtd);
    // como a baixa só ocorre na entrega, desconta do saldo o que já está vendido/lançado e ainda não baixado
    for (const l of linhas) {
      const rs = (await c.query(`select coalesce(sum(x.q),0) q from (
          select i.quantidade q from pedido_itens i join pedidos pd on pd.id=i.pedido_id
            where i.produto_id=$1 and i.status<>'cancelado' and pd.estoque_baixado_em is null and pd.status in ('aberto','fechado')
              and not exists (select 1 from mov_estoque m where m.origem='pedido_item' and m.ref_id=i.id and m.tipo='venda')
          union all
          select i.quantidade*r.quantidade from pedido_itens i join pedidos pd on pd.id=i.pedido_id join receitas r on r.produto_id=i.produto_id join produtos pr on pr.id=i.produto_id
            where pr.controla_estoque=false and r.insumo_id=$1 and i.status<>'cancelado' and pd.estoque_baixado_em is null and pd.status in ('aberto','fechado')
              and not exists (select 1 from mov_estoque m where m.origem='pedido_item' and m.ref_id=i.id and m.tipo='venda')) x`, [l.p.id])).rows[0].q;
      l.reservado = Number(rs); l.disp = Number(l.p.estoque_atual) - l.reservado;
    }
    const faltas = linhas.filter(l => l.disp - l.q < -0.0005)
      .map(l => ({ produto: l.p.nome, unidade: l.p.unidade, atual: l.disp, necessario: l.q }));

    let autorizado = null;
    if (faltas.length) {
      const neg = (await c.query("select valor from config where chave='estoque_negativo'")).rows[0]?.valor;
      if (neg === 'nao') throw new HttpError(400, 'Estoque insuficiente (o sistema não permite vender com estoque negativo): ' + faltas.map(f => `${f.produto}: disponível ${Number(f.atual).toLocaleString('pt-BR')} ${f.unidade}, necessário ${Number(f.necessario).toLocaleString('pt-BR')}`).join('; ') + '.');
      if (!b.autorizacao && !(req.user.perms || []).includes('*')) throw new HttpError(409, 'Estoque insuficiente: a venda deixaria o estoque negativo.', { codigo: 'ESTOQUE_NEGATIVO', faltas });
      autorizado = await verificarAutorizacao(c, b.autorizacao, 'vendas.estoque_negativo', req.user);
      await auditar(c, { id: autorizado.id, nome: autorizado.nome }, 'venda_estoque_negativo', { pedido: ped.id, produto: prod.nome, quantidade: qtd, faltas, lancado_por: req.user.nome });
    }

    const it = await c.query(`insert into pedido_itens(pedido_id,produto_id,nome,quantidade,preco_unit,custo_unit,destino,observacao,usuario_id,autorizado_por)
      values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) returning id`,
      [ped.id, prod.id, prod.nome, qtd, await precoVigente(c, prod.id), custo, prod.destino, b.observacao || null, req.user.id, autorizado?.id || null]);
    await reaplicarCombos(c, ped.id);   // promoção "leve N por R$ X"
  });
  res.json(await pedidoCompleto(req.params.id));
}));

// ---- Cancelar item
r.delete('/pedidos/:id/itens/:itemId', auth('vendas.acessar'), wrap(async (req, res) => {
  const motivo = (req.body || {}).motivo || null;
  let aviso = null;
  await db.tx(async c => {
    const ped = (await c.query('select * from pedidos where id=$1 for update', [req.params.id])).rows[0];
    if (!ped || ped.status !== 'aberto') throw new HttpError(400, 'Venda não está aberta.');
    const it = (await c.query('select * from pedido_itens where id=$1 and pedido_id=$2 for update', [req.params.itemId, ped.id])).rows[0];
    if (!it || it.status === 'cancelado') throw new HttpError(404, 'Item não encontrado.');
    const autIt = await verificarAutorizacao(c, (req.body || {}).autorizacao, 'vendas.cancelar', req.user);   // qualquer cancelamento exige usuário e senha de quem pode cancelar
    if (it.status !== 'novo') {
      if (false && !can(req.user, 'vendas.cancelar')) throw new HttpError(403, 'Item já enviado: apenas quem tem permissão de cancelamento pode cancelar.');
      if (!motivo) throw new HttpError(400, 'Informe o motivo do cancelamento.');
    }
    await devolverEstoque(c, it.id, req.user.id, 'Cancelamento item venda #' + ped.id);
    await c.query(`update pedido_itens set status='cancelado', cancelado_em=now(), cancelado_por=$1, motivo_cancelamento=$2, autorizado_por=$4 where id=$3`, [req.user.id, motivo, it.id, autIt.id]);
    await reaplicarCombos(c, ped.id);
    await auditar(c, req.user, 'item_cancelado', { pedido: ped.id, item: it.nome, status: it.status, motivo, autorizado_por: autIt.id }); if (it.status !== 'novo') { if (it.impresso_em) aviso = { ped, it }; }
  });
  if (aviso && aviso.it.destino !== 'nenhum') { // avisa a cozinha/bar do cancelamento
    prn.imprimirDestino(db, aviso.it.destino, { pedido: aviso.ped, usuario: req.user.nome, itens: [aviso.it], cancelado: true }).catch(() => { });
  }
  res.json(await pedidoCompleto(req.params.id));
}));

// ---- Alterar a quantidade de um item já lançado (venda aberta, antes do pagamento)
r.put('/pedidos/:id/itens/:itemId', auth('vendas.acessar'), wrap(async (req, res) => {
  const b = req.body || {}; const qtd = num(b.quantidade, 0);
  if (!(qtd > 0)) throw new HttpError(400, 'Informe uma quantidade maior que zero (para tirar o item, cancele-o).');
  await db.tx(async c => {
    const ped = (await c.query('select * from pedidos where id=$1 for update', [req.params.id])).rows[0];
    if (!ped || ped.status !== 'aberto') throw new HttpError(400, 'Venda não está aberta.');
    const it = (await c.query('select * from pedido_itens where id=$1 and pedido_id=$2 for update', [req.params.itemId, ped.id])).rows[0];
    if (!it || it.status === 'cancelado') throw new HttpError(404, 'Item não encontrado.');
    if (it.impresso_em || (await c.query("select 1 from mov_estoque where origem='pedido_item' and ref_id=$1 and tipo='venda'", [it.id])).rowCount)
      throw new HttpError(400, 'Este item já foi impresso/baixado do estoque: cancele-o e lance novamente, ou lance a diferença como novo item.');
    const ant = Number(it.quantidade);
    if (Math.abs(qtd - ant) < 0.0005) return;
    let aut = null;
    if (qtd < ant && it.status !== 'novo') {   // diminuir item já enviado = cancelamento parcial: exige motivo e senha de quem pode cancelar
      if (!b.motivo) throw new HttpError(400, 'Informe o motivo da redução.');
      aut = await verificarAutorizacao(c, b.autorizacao, 'vendas.cancelar', req.user);
    }
    await c.query('update pedido_itens set quantidade=$1 where id=$2', [qtd, it.id]);
    await reaplicarCombos(c, ped.id);
    await auditar(c, req.user, 'item_quantidade_alterada', { pedido: ped.id, item: it.nome, de: ant, para: qtd, status: it.status, motivo: b.motivo || null, autorizado_por: aut ? aut.id : null });
  });
  res.json(await pedidoCompleto(req.params.id));
}));

// ---- Enviar itens novos para cozinha/bar (libera na tela de produção; imprime só ao receber)
r.post('/pedidos/:id/enviar', auth('vendas.acessar'), wrap(async (req, res) => {
  const { ped, itens } = await db.tx(async c => {
    const ped = (await c.query('select * from pedidos where id=$1 for update', [req.params.id])).rows[0];
    if (!ped || ped.status !== 'aberto') throw new HttpError(400, 'Venda não está aberta.');
    const novos = (await c.query("select * from pedido_itens where pedido_id=$1 and status='novo' order by id", [ped.id])).rows;
    if (!novos.length) throw new HttpError(400, 'Não há itens novos para enviar.');
    await c.query(`update pedido_itens set status = case when destino='nenhum' then 'retirado' else 'enviado' end,
      enviado_em=now(), retirado_em = case when destino='nenhum' then now() end where pedido_id=$1 and status='novo'`, [ped.id]);
    return { ped, itens: novos };
  });
  // o pedido NÃO é impresso aqui: a impressão sai somente ao receber o pagamento
  const impressao = [];
  res.json({ pedido: await pedidoCompleto(ped.id), impressao });
}));

r.post('/pedidos/:id/reimprimir', auth('vendas.reimprimir'), wrap(async (req, res) => {
  const ped = (await db.q('select p.*, v.numero venda_numero from pedidos p left join vendas v on v.pedido_id=p.id where p.id=$1', [req.params.id])).rows[0];
  if (!ped) throw new HttpError(404, 'Venda não encontrada.');
  const dest = req.body?.destino;
  const itens = (await db.q("select * from pedido_itens where pedido_id=$1 and status in ('enviado','retirado') and destino = any($2) order by id",
    [ped.id, dest ? [dest] : ['cozinha', 'bar', 'brincadeira']])).rows;
  const impressao = [];
  for (const d of ['cozinha', 'bar', 'brincadeira']) {
    const lote = itens.filter(i => i.destino === d);
    if (lote.length) impressao.push(await prn.imprimirDestino(db, d, { pedido: ped, usuario: req.user.nome, itens: lote, reimpressao: true }));
  }
  await auditar(null, req.user, 'reimpressao', { pedido: ped.id, destino: dest || 'todos' });
  res.json({ impressao });
}));

// ---- Painel de produção (cozinha/bar) e controle de retirada
r.get('/producao', auth('producao.acessar'), wrap(async (req, res) => {
  const dest = ['cozinha', 'bar', 'brincadeira'].includes(req.query.destino) ? [req.query.destino] : ['cozinha', 'bar', 'brincadeira'];
  const base = `select i.id, i.pedido_id, i.nome, i.quantidade, i.observacao, i.destino, i.status, i.enviado_em, i.retirado_em,
    v.numero venda_numero, ua.nome atendente, ur.nome retirado_por_nome,
    (select coalesce(json_agg(json_build_object('id',o.id,'nome',o.nome,'unidade',o.unidade) order by o.nome),'[]'::json) from produto_opcoes po join produtos o on o.id=po.opcao_id where po.produto_id=i.produto_id and o.ativo) opcoes,
    (select coalesce(json_agg(json_build_object('nome',o.nome,'quantidade',e.quantidade) order by e.id),'[]'::json) from item_escolhas e join produtos o on o.id=e.produto_id where e.item_id=i.id) escolhas
    from pedido_itens i join pedidos p on p.id=i.pedido_id left join vendas v on v.pedido_id=p.id left join usuarios ua on ua.id=i.usuario_id left join usuarios ur on ur.id=i.retirado_por`;
  const pendentes = (await db.q(`${base} where i.status='enviado' and p.status<>'cancelado' and i.destino = any($1) order by i.enviado_em`, [dest])).rows;
  const retirados = (await db.q(`${base} where i.status='retirado' and p.status<>'cancelado' and i.destino = any($1) and i.retirado_em >= current_date and i.enviado_em is not null
    and i.destino<>'nenhum' order by i.retirado_em desc limit 150`, [dest])).rows;
  res.json({ pendentes, retirados });
}));

r.post('/producao/retirar', auth('producao.retirar'), wrap(async (req, res) => {
  const ids = (req.body?.ids || []).map(Number).filter(Boolean);
  if (!ids.length) throw new HttpError(400, 'Nenhum item selecionado.');
  const esc = req.body?.escolhas || {};   // { itemId: [{ produto_id, quantidade }] } — para itens genéricos, o que o bar entregou de verdade
  const x = await db.tx(async c => {
    const its = (await c.query("select * from pedido_itens where id = any($1) and status='enviado' order by id for update", [ids])).rows;
    for (const it of its) {
      const ops = (await c.query('select o.id, o.nome from produto_opcoes po join produtos o on o.id=po.opcao_id where po.produto_id=$1 and o.ativo', [it.produto_id])).rows;
      if (!ops.length) continue;
      const lista = (esc[it.id] || []).map(e => ({ produto_id: Number(e.produto_id), quantidade: Number(String(e.quantidade).replace(',', '.')) })).filter(e => e.quantidade > 0);
      if (!lista.length) throw new HttpError(400, `Informe qual ${it.nome} saiu (e a quantidade de cada um) antes de marcar como retirado.`);
      if (lista.some(e => !ops.some(o => o.id === e.produto_id))) throw new HttpError(400, `Opção inválida para "${it.nome}".`);
      const soma = lista.reduce((t, e) => t + e.quantidade, 0);
      if (Math.abs(soma - Number(it.quantidade)) > 0.0005) throw new HttpError(400, `"${it.nome}": o caixa vendeu ${Number(it.quantidade).toLocaleString('pt-BR')} e você informou ${soma.toLocaleString('pt-BR')}. A soma precisa fechar com o que foi vendido.`);
      await c.query('delete from item_escolhas where item_id=$1', [it.id]);
      for (const e of lista) await c.query('insert into item_escolhas(item_id, produto_id, quantidade) values($1,$2,$3)', [it.id, e.produto_id, e.quantidade]);
    }
    return c.query(`update pedido_itens set status='retirado', retirado_em=now(), retirado_por=$1
      where id = any($2) and status='enviado' returning id, pedido_id`, [req.user.id, its.map(i => i.id)]);
  });
  // se com isso todos os itens da venda foram entregues (cozinha e bar), baixa o estoque
  const baixadas = [];
  for (const pid of [...new Set(x.rows.map(i => i.pedido_id))]) if (await baixarEstoqueVenda(pid, req.user.id)) baixadas.push(pid);
  res.json({ retirados: x.rowCount, estoque_baixado_vendas: baixadas });
}));

// ---- Pagamento / fechamento
// Doação do troco: depois de recebida a venda em dinheiro, o cliente pode deixar as moedinhas (ou o troco) para um dos destinos cadastrados nas configurações.
// Vendedor da venda: o operador informa o NÚMERO (código) do vendedor; por padrão é quem abriu a venda
r.put('/pedidos/:id/vendedor', auth('vendas.receber'), wrap(async (req, res) => {
  const p = (await db.q('select id, status from pedidos where id=$1', [req.params.id])).rows[0];
  if (!p) throw new HttpError(404, 'Venda não encontrada.');
  if (p.status !== 'aberto') throw new HttpError(400, 'Só é possível trocar o vendedor de uma venda em andamento.');
  const cod = Number(String(req.body?.codigo || '').replace(/\D/g, ''));
  const u = cod ? (await db.q('select id, nome, codigo from usuarios where codigo=$1 and ativo', [cod])).rows[0] : null;
  if (!u) throw new HttpError(400, 'Vendedor não encontrado ou inativo. Confira o número do usuário.');
  await db.q('update pedidos set vendedor_id=$1 where id=$2', [u.id, p.id]);
  await auditar(null, req.user, 'venda_vendedor', { pedido: p.id, vendedor: u.nome, codigo: u.codigo });
  res.json(await pedidoCompleto(p.id));
}));

r.post('/pedidos/:id/doacao', auth('vendas.receber'), wrap(async (req, res) => {
  const cfg = {}; (await db.q("select chave, valor from config where chave in ('doacao_ativa','doacao_destinos')")).rows.forEach(x => { cfg[x.chave] = x.valor; });
  const destinos = String(cfg.doacao_destinos || '').split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  if (cfg.doacao_ativa !== '1' || !destinos.length) throw new HttpError(400, 'Doações não estão ativas nas configurações.');
  const destino = String(req.body?.destino || '').trim(), valor = r2(Number(String(req.body?.valor).replace(',', '.')));
  if (!destinos.includes(destino)) throw new HttpError(400, 'Local de doação inválido.');
  if (!(valor > 0) || valor > 500) throw new HttpError(400, 'Valor da doação inválido.');
  const p = (await db.q("select id, caixa_id, status from pedidos where id=$1", [req.params.id])).rows[0];
  if (!p || p.status !== 'fechado' || !p.caixa_id) throw new HttpError(400, 'A doação só vale para uma venda já finalizada.');
  if ((await db.q('select 1 from doacoes where pedido_id=$1', [p.id])).rowCount) throw new HttpError(400, 'Esta venda já tem uma doação registrada.');
  await db.q('insert into doacoes(pedido_id,caixa_id,destino,valor,usuario_id) values($1,$2,$3,$4,$5)', [p.id, p.caixa_id, destino, valor, req.user.id]);
  await auditar(null, req.user, 'doacao', { pedido: p.id, destino, valor });
  res.json({ ok: true });
}));

r.post('/pedidos/:id/pagar', auth('vendas.receber'), wrap(async (req, res) => {
  const b = req.body || {};
  const formas = new Map((await db.q('select codigo, descricao, tipo, tef_ativo, tef_vias, max_parcelas from formas_pagamento where ativo')).rows.map(f => [f.codigo, f]));
  const refs = (b.pagamentos || []).map(p => p.tef_ref).filter(Boolean);
  let comprovantes = [];
  try {
  await db.tx(async c => {
    const cx = (await c.query("select id from caixas where usuario_id=$1 and status='aberto' order by id desc limit 1", [req.user.id])).rows[0];
    if (!cx) throw new HttpError(400, 'Abra o seu caixa antes de receber pagamentos.');
    const ped = (await c.query('select * from pedidos where id=$1 for update', [req.params.id])).rows[0];
    if (!ped || ped.status !== 'aberto') throw new HttpError(400, 'Venda não está aberta.');
    const itens = (await c.query("select * from pedido_itens where pedido_id=$1 and status<>'cancelado'", [ped.id])).rows;
    if (!itens.length) throw new HttpError(400, 'Venda sem itens. Cancele-a se não for usada.');
    // venda direta: ao receber, os itens vão para a cozinha/bar (aparecem na tela de produção e imprimem o pedido)
    if (itens.some(i => i.status === 'novo')) await c.query(`update pedido_itens set status = case when destino='nenhum' then 'retirado' else 'enviado' end,
      enviado_em=now(), retirado_em = case when destino='nenhum' then now() end where pedido_id=$1 and status='novo'`, [ped.id]);
    const subtotal = r2(itens.reduce((s, i) => s + Number(i.quantidade) * Number(i.preco_unit), 0));
    const desconto = r2(num(b.desconto));
    if (desconto < 0 || desconto > subtotal) throw new HttpError(400, 'Desconto inválido.');
    if (desconto > 0 && !can(req.user, 'vendas.desconto')) throw new HttpError(403, 'Você não tem permissão para dar desconto.');
    // arredondamento: valor em R$ (+ acrescenta, - reduz); exige permissão (ou usuário/senha de quem tenha) e respeita o limite configurado
    let arred = r2(num(b.arredondamento)), arredPor = null;
    if (arred !== 0) {
      const cfg = {}; (await c.query("select chave, valor from config where chave in ('arred_max_mais','arred_max_menos')")).rows.forEach(x => { cfg[x.chave] = Number(String(x.valor).replace(',', '.')) || 0; });
      const maxMais = cfg.arred_max_mais ?? 1, maxMenos = cfg.arred_max_menos ?? 1;
      if (arred > 0 && arred > maxMais + 0.001) throw new HttpError(400, `Arredondamento para mais acima do limite configurado (máximo R$ ${maxMais.toFixed(2).replace('.', ',')}).`);
      if (arred < 0 && -arred > maxMenos + 0.001) throw new HttpError(400, `Arredondamento para menos acima do limite configurado (máximo R$ ${maxMenos.toFixed(2).replace('.', ',')}).`);
      if (can(req.user, 'vendas.arredondar')) arredPor = req.user.id;
      else arredPor = (await verificarAutorizacao(c, b.autorizacao, 'vendas.arredondar', req.user)).id;
      if (subtotal - desconto + arred < 0) throw new HttpError(400, 'Arredondamento maior que o total da venda.');
    }
    const total = r2(subtotal - desconto + arred);
    const pgs = (b.pagamentos || []).map(p => ({ forma: p.forma, valor: r2(num(p.valor)), parcelas: Math.max(1, Math.round(num(p.parcelas) || 1)), tef_ref: p.tef_ref })).filter(p => p.valor > 0);
    if (pgs.some(p => !formas.has(p.forma))) throw new HttpError(400, 'Forma de pagamento inválida ou inativa.');
    const tipoDe = p => formas.get(p.forma).tipo;
    for (const p of pgs) {
      const f = formas.get(p.forma);
      if (f.tef_ativo) { const t = tef.reservar(p.tef_ref, p.forma, p.valor, req.user.id); p.tef = t; }
      else if (p.tef_ref) throw new HttpError(400, 'Forma sem TEF recebeu uma transação TEF.');
      if (p.parcelas > (f.max_parcelas || 1)) p.parcelas = f.max_parcelas || 1;
    }
    const soma = r2(pgs.reduce((s, p) => s + p.valor, 0));
    if (soma + 0.001 < total) throw new HttpError(400, `Pagamento insuficiente: faltam ${r2(total - soma).toFixed(2)}.`);
    const troco = r2(soma - total);
    const dinheiro = r2(pgs.filter(p => tipoDe(p) === 'dinheiro').reduce((s, p) => s + p.valor, 0));
    if (troco > 0.001 && troco > dinheiro + 0.001) throw new HttpError(400, 'Valor pago excede o total; só é possível dar troco em dinheiro.');
    if (troco > 0.001 && pgs.some(p => p.tef)) { /* troco só sai do dinheiro; cartão TEF sempre no valor exato */ }
    let clienteId = b.cliente_id || ped.cliente_id || null;
    const fiado = r2(pgs.filter(p => tipoDe(p) === 'fiado').reduce((s, p) => s + p.valor, 0));
    if (fiado > 0 && !clienteId) throw new HttpError(400, 'Venda crediário só pode ser feita com um cliente cadastrado. Selecione ou cadastre o cliente.');
    if (fiado > 0 && !(await c.query('select 1 from clientes where id=$1 and ativo', [clienteId])).rowCount) throw new HttpError(400, 'Cliente não encontrado ou inativo.');
    if (fiado > 0) {   // funcionário (cliente ligado a um usuário) só retira no crediário se a opção estiver ligada no cadastro dele
      const fu = (await c.query('select u.nome, u.pode_fiado from clientes cl join usuarios u on u.id=cl.usuario_id where cl.id=$1', [clienteId])).rows[0];
      if (fu && !fu.pode_fiado) throw new HttpError(400, `${fu.nome} não está autorizado(a) a retirar no crediário. Ligue a opção "Pode retirar no crediário" no cadastro do usuário (Equipe > Usuários).`);
    }
    let trocoRest = troco;
    for (const p of pgs) {
      let v = p.valor;
      if (tipoDe(p) === 'dinheiro' && trocoRest > 0) { const d = Math.min(v, trocoRest); v = r2(v - d); trocoRest = r2(trocoRest - d); }
      if (v > 0) await c.query('insert into pagamentos(pedido_id,caixa_id,forma,valor,parcelas,tef_nsu,tef_autorizacao,tef_rede) values($1,$2,$3,$4,$5,$6,$7,$8)',
        [ped.id, cx.id, p.forma, v, p.parcelas > 1 ? p.parcelas : null, p.tef?.nsu || null, p.tef?.autorizacao || null, p.tef?.rede || null]);
      if (p.tef) comprovantes.push({ vias: formas.get(p.forma).tef_vias || 1, linhas: p.tef.comprovante, forma: formas.get(p.forma).descricao });
    }
    if (fiado > 0) {
      const venc = b.vencimento_fiado || new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10);
      await c.query(`insert into titulos(tipo,descricao,categoria,cliente_id,pedido_id,valor,vencimento) values('receber',$1,'Venda fiado',$2,$3,$4,$5)`,
        [`Crediário venda #${ped.id}`, clienteId, ped.id, fiado, venc]);
    }
    await c.query("update pedidos set status='fechado', total=$1, desconto=$2, caixa_id=$3, cliente_id=$4, fechado_em=now(), arredondamento=$6, arredondamento_por=$7 where id=$5", [total, desconto, cx.id, clienteId, ped.id, arred, arredPor]);
    if (arred !== 0) await auditar(c, req.user, 'arredondamento', { pedido: ped.id, valor: arred, autorizado_por: arredPor, subtotal, total });
    if (desconto > 0) await auditar(c, req.user, 'desconto', { pedido: ped.id, desconto, subtotal });
    if (b.observacao && String(b.observacao).trim()) await c.query('update pedidos set observacao=$1 where id=$2', [String(b.observacao).trim().slice(0, 500), ped.id]);
    res.locals.troco = troco;
  });
  } catch (e) { for (const ref of refs) await tef.finalizar(ref, false); throw e; }
  // venda gravada: confirma as transações TEF e imprime os comprovantes
  for (const ref of refs) await tef.finalizar(ref, true);
  const imp = [];
  for (const cp of comprovantes) {
    if (!cp.linhas.length) continue;
    for (let i = 0; i < cp.vias; i++) imp.push(await prn.imprimirTexto(db, 'caixa', '', cp.linhas.join('\n') + (cp.vias > 1 ? `\n\n(via ${i + 1}/${cp.vias})` : '')));
  }
  // venda fiado: comprovante do cliente (opcional) com SOMENTE os itens desta venda, valor no crediário e vencimento, com campo de assinatura
  let impFiado = null;
  try {
    const cli = (await db.q('select p.cliente_id, p.desconto, c.nome, c.telefone from pedidos p join clientes c on c.id=p.cliente_id where p.id=$1', [req.params.id])).rows[0];
    const tit = (await db.q("select valor, vencimento from titulos where pedido_id=$1 and tipo='receber' and categoria='Venda fiado' and status<>'cancelado' order by id limit 1", [req.params.id])).rows[0];
    if (cli && tit && (req.body || {}).imprimir_fiado !== false) {
      const its = (await db.q("select nome, quantidade, preco_unit, observacao from pedido_itens where pedido_id=$1 and status<>'cancelado' order by id", [req.params.id])).rows;
      const vnum = (await db.q('select numero from vendas where pedido_id=$1', [req.params.id])).rows[0];
      const emp = ((await db.q("select valor from config where chave='empresa'")).rows[0] || {}).valor || '';
      const W = 42, d2 = x => { const d = new Date(x); return String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0') + '/' + d.getFullYear(); };
      const brl = n => Number(n).toFixed(2).replace('.', ',');
      const lin = (esq, dir) => String(esq).slice(0, W - dir.length - 1).padEnd(W - dir.length) + dir;
      const L = [];
      if (emp) L.push(String(emp).toUpperCase().slice(0, W));
      L.push('COMPROVANTE DE FIADO', prn.linha(W), 'Cliente: ' + String(cli.nome).slice(0, W - 9), 'Venda ' + String(vnum ? vnum.numero : req.params.id).padStart(6, '0') + ' - ' + d2(Date.now()) + ' - ' + String(req.user.nome).split(' ')[0], prn.linha(W), 'ITENS DESTA VENDA', prn.linha(W));
      let bruto = 0;
      for (const i of its) {
        const q = Number(i.quantidade), tot = r2(q * Number(i.preco_unit)); bruto = r2(bruto + tot);
        L.push(lin((Number.isInteger(q) ? q : String(q).replace('.', ',')) + 'x ' + i.nome, brl(tot)));
        if (i.observacao) L.push('   obs: ' + String(i.observacao).slice(0, W - 8));
      }
      L.push(prn.linha(W));
      if (Number(cli.desconto) > 0) L.push(lin('Desconto', '-' + brl(cli.desconto)));
      L.push(lin('TOTAL NO FIADO', brl(tit.valor)), lin('Vencimento', d2(tit.vencimento)), '', '', '________________________________', 'Assinatura do cliente', '', 'Comprovante sem valor fiscal');
      impFiado = await prn.imprimirTexto(db, 'caixa', 'FIADO', L.join('\n'));
      impFiado.total = Number(tit.valor);
    }
  } catch (e) { impFiado = { ok: false, erro: e.message }; }
  // itens sem cozinha/bar (entregues na hora): se a venda já está toda entregue, baixa o estoque
  try { await baixarEstoqueVenda(Number(req.params.id), req.user.id); } catch (e) { console.error('baixa de estoque:', e.message); }
  // pagamento recebido: agora sim imprime os pedidos da cozinha e do bar (itens ainda não impressos)
  const impressoes = [];
  try {
    const ped = (await db.q('select p.*, v.numero venda_numero from pedidos p left join vendas v on v.pedido_id=p.id where p.id=$1', [req.params.id])).rows[0];
    const its = (await db.q("select * from pedido_itens where pedido_id=$1 and status in ('enviado','retirado') and impresso_em is null and destino in ('cozinha','bar','brincadeira') order by id", [ped.id])).rows;
    const querImprimir = Array.isArray((req.body || {}).imprimir_tickets) ? req.body.imprimir_tickets : ['cozinha', 'bar', 'brincadeira'];   // padrão: imprime todos
    for (const dest of ['cozinha', 'bar', 'brincadeira']) {
      const lote = its.filter(i => i.destino === dest);
      if (!lote.length || !querImprimir.includes(dest)) continue;
      const rs = await prn.imprimirDestino(db, dest, { pedido: ped, usuario: req.user.nome, itens: lote });
      impressoes.push(rs);
      if (rs && rs.ok) await db.q('update pedido_itens set impresso_em=now() where id = any($1)', [lote.map(i => i.id)]);
    }
  } catch (e) { impressoes.push({ ok: false, destino: 'pedido', erro: e.message }); }
  const p = await pedidoCompleto(req.params.id);
  // resumo de tudo que a finalização fez (mostrado ao operador numa janela)
  let resumo = null;
  try {
    const ped2 = (await db.q(`select p.estoque_baixado_em, p.cliente_id, cl.nome cliente, coalesce(cx.numero, cx.id) caixa_num from pedidos p left join clientes cl on cl.id=p.cliente_id left join caixas cx on cx.id=p.caixa_id where p.id=$1`, [req.params.id])).rows[0] || {};
    const itv = p.itens.filter(i => i.status !== 'cancelado');
    const fx = new Map([...formas.values()].map(f => [f.codigo, f]));
    const fi = (await db.q("select valor, vencimento from titulos where pedido_id=$1 and tipo='receber' order by id desc limit 1", [req.params.id])).rows[0];
    const subtotal = r2(itv.reduce((s2, i) => s2 + Number(i.quantidade) * Number(i.preco_unit), 0));
    const baixaProd = itv.filter(i => i.destino === 'nenhum').length, volta = itv.filter(i => i.destino !== 'nenhum');
    resumo = {
      venda_numero: p.venda_numero || p.id, caixa: ped2.caixa_num, operador: req.user.nome, cliente: ped2.cliente || null,
      itens: itv.map(i => ({ nome: i.nome, qtd: Number(i.quantidade), total: r2(Number(i.quantidade) * Number(i.preco_unit)), destino: i.destino })),
      subtotal, desconto: Number(p.desconto) || 0, arredondamento: Number(p.arredondamento) || 0, total: Number(p.total),
      pagamentos: p.pagamentos.map(g => ({ forma: (fx.get(g.forma) || {}).descricao || g.forma, valor: Number(g.valor), parcelas: g.parcelas, nsu: g.tef_nsu, autorizacao: g.tef_autorizacao })),
      troco: res.locals.troco || 0,
      fiado: fi ? { valor: Number(fi.valor), vencimento: fi.vencimento } : null,
      producao: ['cozinha', 'bar', 'brincadeira'].map(d => { const n = volta.filter(i => i.destino === d).length; const im = impressoes.find(x => x && x.destino === d); return n ? { destino: d, itens: n, impresso: !!(im && im.ok), erro: im && !im.ok ? im.erro : null } : null; }).filter(Boolean),
      entregues_na_hora: baixaProd,
      estoque_baixado: !!ped2.estoque_baixado_em,
      tef_impresso: imp.length ? imp.every(x => x.ok) : null,
      fiado_impresso: impFiado ? { ok: !!impFiado.ok, erro: impFiado.erro || null, total: impFiado.total ?? null } : null,
      empresa_id: p.empresa_id || null,
    };
  } catch (e) { console.error('resumo da venda:', e.message); }
  res.json({ pedido: p, resumo, impressoes, troco: res.locals.troco, comprovantes: comprovantes.map(c => ({ forma: c.forma, linhas: c.linhas })), impressao: imp });
}));

// ---- Conta para conferência (imprime no caixa)
r.post('/pedidos/:id/conta', auth('vendas.acessar'), wrap(async (req, res) => {
  const p = await pedidoCompleto(req.params.id);
  const L = [`Venda: ${String(p.venda_numero || p.id).padStart(6, '0')}`, prn.linha(42)];
  p.itens.filter(i => i.status !== 'cancelado').forEach(i => {
    const t = (Number(i.quantidade) * Number(i.preco_unit)).toFixed(2);
    L.push(`${Number(i.quantidade)}x ${i.nome}`.slice(0, 32).padEnd(32) + t.padStart(10));
  });
  L.push(prn.linha(42), 'TOTAL'.padEnd(32) + p.subtotal.toFixed(2).padStart(10), '', 'Conferencia - nao e documento fiscal');
  res.json(await prn.imprimirTexto(db, 'caixa', 'CONTA', L.join('\n')));
}));

// ---- Devolução parcial de produtos de uma venda finalizada (cliente devolve só alguns itens)
r.post('/pedidos/:id/devolucao', auth('vendas.acessar'), wrap(async (req, res) => {
  const b = req.body || {};
  const motivo = String(b.motivo || '').trim();
  if (motivo.length < 5) throw new HttpError(400, 'Informe o motivo da devolução (mínimo 5 letras).');
  const pedidos = (Array.isArray(b.itens) ? b.itens : []).map(x => ({ id: Number(x.item_id), q: Math.round(Number(x.quantidade) * 1000) / 1000 })).filter(x => x.q > 0);
  if (!pedidos.length) throw new HttpError(400, 'Informe a quantidade a devolver de pelo menos um produto.');
  const out = await db.tx(async c => {
    const aut = await verificarAutorizacao(c, b.autorizacao, 'vendas.cancelar', req.user);
    const ped = (await c.query('select * from pedidos where id=$1 for update', [req.params.id])).rows[0];
    if (!ped) throw new HttpError(404, 'Venda não encontrada.');
    if (ped.status !== 'fechado') throw new HttpError(400, ped.status === 'cancelado' ? 'Esta venda está cancelada.' : 'Devolução só vale para venda finalizada.');
    const cx = ped.caixa_id ? (await c.query('select numero, status from caixas where id=$1', [ped.caixa_id])).rows[0] : null;
    if (cx && cx.status !== 'aberto') throw new HttpError(400, `O caixa ${cx.numero} desta venda já foi fechado. Reabra o caixa (Caixa > Reabrir) para fazer a devolução.`);
    const itens = (await c.query("select * from pedido_itens where pedido_id=$1 and status<>'cancelado' order by id for update", [ped.id])).rows;
    const bruto = itens.reduce((t, i) => t + Number(i.quantidade) * Number(i.preco_unit), 0);
    const ratio = bruto > 0 ? Math.min(1, Number(ped.total) / bruto) : 1;
    let brutoDev = 0; const dev = [];
    for (const d of pedidos) {
      const it = itens.find(i => i.id === d.id);
      if (!it) throw new HttpError(400, 'Produto não pertence a esta venda (ou já foi totalmente devolvido).');
      if (d.q > Number(it.quantidade) + 0.0004) throw new HttpError(400, `Quantidade maior que a vendida de ${it.nome} (vendido: ${Number(it.quantidade)}).`);
      brutoDev += d.q * Number(it.preco_unit); dev.push({ it, q: d.q });
    }
    if (dev.every(d => Math.abs(d.q - Number(d.it.quantidade)) < 0.0004) && dev.length === itens.length) throw new HttpError(400, 'Todos os produtos estão sendo devolvidos: use "Cancelar venda".');
    const valor = r2(brutoDev * ratio);
    // forma da devolução do dinheiro: uma das formas usadas na própria venda
    const pg = (await c.query("select forma, sum(valor) v, bool_or(tef_nsu is not null) tef from pagamentos where pedido_id=$1 group by forma", [ped.id])).rows;
    const fp = pg.find(x => x.forma === b.forma);
    if (!fp) throw new HttpError(400, 'Escolha a forma de pagamento da devolução entre as usadas nesta venda.');
    if (Number(fp.v) + 0.004 < valor) throw new HttpError(400, `O valor a devolver (${valor.toFixed(2)}) é maior que o pago em ${fp.forma} (${Number(fp.v).toFixed(2)}). Escolha outra forma.`);
    if (fp.tef && b.tef_estornado !== true) throw new HttpError(400, 'Esta forma foi paga por TEF/cartão integrado. Estorne/cancele na operadora e confirme que isso foi feito.', { codigo: 'TEF_PENDENTE' });
    const tp = (await c.query('select tipo from formas_pagamento where codigo=$1', [fp.forma])).rows[0];
    if (tp && tp.tipo === 'fiado') {
      const t = (await c.query("select id, valor from titulos where pedido_id=$1 and tipo='receber' and categoria='Venda fiado' and status<>'cancelado' for update", [ped.id])).rows[0];
      if (!t) throw new HttpError(400, 'Título do crediário não encontrado.');
      const rec = Number((await c.query('select coalesce(sum(valor),0) s from pagamentos where titulo_id=$1', [t.id])).rows[0].s);
      if (Number(t.valor) - rec + 0.004 < valor) throw new HttpError(400, 'O crediário desta venda já foi parcialmente recebido; o saldo em aberto é menor que a devolução. Devolva em outra forma.');
      await c.query('update titulos set valor=valor-$1 where id=$2', [valor, t.id]);
    }
    await c.query("insert into pagamentos(pedido_id, caixa_id, forma, valor, origem) values($1,$2,$3,$4,'devolucao')", [ped.id, ped.caixa_id, fp.forma, -valor]);
    for (const { it, q } of dev) {
      const frac = q / Number(it.quantidade);
      const m = (await c.query("select produto_id, sum(quantidade) q, max(custo_unit) custo from mov_estoque where origem='pedido_item' and ref_id=$1 and tipo in ('venda','estorno') group by produto_id", [it.id])).rows;
      for (const x of m) {
        const qq = Math.round(-Number(x.q) * frac * 1000) / 1000; if (Math.abs(qq) < 0.0004) continue;
        await est.mover(c, { produto_id: x.produto_id, tipo: 'estorno', quantidade: qq, custo_unit: x.custo, origem: 'pedido_item', ref_id: it.id, motivo: `Devolução venda #${ped.id}: ${motivo}`, usuario_id: req.user.id });
      }
      const resta = Math.round((Number(it.quantidade) - q) * 1000) / 1000;
      if (resta < 0.0004) await c.query("update pedido_itens set quantidade=0, status='cancelado', cancelado_em=now(), cancelado_por=$1, motivo_cancelamento=$2, autorizado_por=$3 where id=$4", [req.user.id, 'Devolvido: ' + motivo, aut.id, it.id]);
      else await c.query('update pedido_itens set quantidade=$1 where id=$2', [resta, it.id]);
      await c.query('insert into devolucoes(pedido_id,item_id,produto_id,nome,quantidade,valor,forma,motivo,usuario_id,autorizado_por) values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',
        [ped.id, it.id, it.produto_id, it.nome, q, r2(q * Number(it.preco_unit) * ratio), fp.forma, motivo, req.user.id, aut.id]);
    }
    const descDev = bruto > 0 ? r2(Number(ped.desconto || 0) * (brutoDev / bruto)) : 0;
    await c.query('update pedidos set total=total-$1, desconto=greatest(0, desconto-$2) where id=$3', [valor, descDev, ped.id]);
    await auditar(c, req.user, 'venda_devolucao', { pedido: ped.id, valor, forma: fp.forma, motivo, itens: dev.map(d => ({ item: d.it.nome, quantidade: d.q })), autorizado_por: aut.id });
    return { ok: true, valor };
  });
  res.json(out);
}));

// ---- Cancelar uma venda JÁ FINALIZADA (paga): devolve o estoque, estorna pagamentos/fiado/doação no caixa. Fica tudo registrado.
r.post('/pedidos/:id/cancelar-finalizada', auth('vendas.acessar'), wrap(async (req, res) => {
  const b = req.body || {};
  const motivo = String(b.motivo || '').trim();
  if (motivo.length < 5) throw new HttpError(400, 'Informe o motivo do cancelamento (mínimo 5 letras).');
  let avisosProd = [];
  const out = await db.tx(async c => {
    const aut = await verificarAutorizacao(c, b.autorizacao, 'vendas.cancelar', req.user);
    const ped = (await c.query('select * from pedidos where id=$1 for update', [req.params.id])).rows[0];
    if (!ped) throw new HttpError(404, 'Venda não encontrada.');
    if (ped.status === 'cancelado') throw new HttpError(400, 'Esta venda já está cancelada.');
    if (ped.status !== 'fechado') throw new HttpError(400, 'Esta venda ainda está aberta: use o botão Cancelar da própria venda.');
    const cx = ped.caixa_id ? (await c.query('select numero, status from caixas where id=$1', [ped.caixa_id])).rows[0] : null;
    if (cx && cx.status !== 'aberto') throw new HttpError(400, `O caixa ${cx.numero} desta venda já foi fechado. Reabra o caixa (Caixa > Reabrir) para cancelar a venda.`);
    const pg = (await c.query("select forma, caixa_id, sum(valor) valor, bool_or(tef_nsu is not null) tef_nsu from pagamentos where pedido_id=$1 and coalesce(origem,'venda') in ('venda','devolucao') group by forma, caixa_id having sum(valor)>0", [ped.id])).rows;   // saldo líquido (já descontadas devoluções)
    if (pg.some(x => x.tef_nsu) && b.tef_estornado !== true) throw new HttpError(400, 'Há pagamento por TEF/cartão integrado nesta venda. Cancele a transação na operadora/TEF e confirme que isso foi feito.', { codigo: 'TEF_PENDENTE' });
    const tit = (await c.query("select id from titulos where pedido_id=$1 and tipo='receber' and categoria='Venda fiado' and status<>'cancelado'", [ped.id])).rows;
    for (const t of tit) {
      const rec = (await c.query('select count(*)::int n from pagamentos where titulo_id=$1', [t.id])).rows[0].n;
      if (rec) throw new HttpError(400, 'O crediário desta venda já teve recebimento. Estorne o recebimento antes de cancelar a venda.');
      await c.query("update titulos set status='cancelado' where id=$1", [t.id]);
    }
    for (const x of pg)
      await c.query("insert into pagamentos(pedido_id, caixa_id, forma, valor, origem) values($1,$2,$3,$4,'estorno_cancelamento')", [ped.id, x.caixa_id, x.forma, -Number(x.valor)]);
    await c.query('delete from doacoes where pedido_id=$1', [ped.id]);
    const itens = (await c.query("select id from pedido_itens where pedido_id=$1 and status<>'cancelado'", [ped.id])).rows;
    for (const i of itens) await devolverEstoque(c, i.id, req.user.id, 'Cancelamento venda finalizada #' + ped.id);
    avisosProd = (await c.query("select * from pedido_itens where pedido_id=$1 and status='enviado' and destino in ('cozinha','bar','brincadeira') and impresso_em is not null", [ped.id])).rows;
    await c.query("update pedido_itens set status='cancelado', cancelado_em=now(), cancelado_por=$1, motivo_cancelamento=$2, autorizado_por=$3 where pedido_id=$4 and status<>'cancelado'", [req.user.id, 'Venda cancelada: ' + motivo, aut.id, ped.id]);   // some da tela da cozinha/bar
    await c.query("update pedidos set status='cancelado', motivo_cancelamento=$1, cancelado_em=now(), cancelado_por=$3, cancelado_autorizado_por=$4 where id=$2", [motivo, ped.id, req.user.id, aut.id]);
    await c.query("update vendas set status='cancelada' where pedido_id=$1", [ped.id]);
    await auditar(c, req.user, 'venda_cancelada_finalizada', { pedido: ped.id, total: Number(ped.total), motivo, autorizado_por: aut.id, estornos: pg.length, itens: itens.length });
    return { ok: true, pedido: ped.id, total: Number(ped.total) };
  });
  for (const d of ['cozinha', 'bar', 'brincadeira']) {   // avisa a cozinha/bar que o pedido foi cancelado
    const l = avisosProd.filter(x => x.destino === d); if (!l.length) continue;
    prn.imprimirDestino(db, d, { pedido: { id: out.pedido }, usuario: req.user.nome, itens: l, cancelado: true }).catch(() => { });
  }
  res.json(out);
}));

// ---- Cancelar a venda inteira
r.post('/pedidos/:id/cancelar', auth('vendas.acessar'), wrap(async (req, res) => {
  const motivo = (req.body || {}).motivo || null;
  await db.tx(async c => {
    const ped = (await c.query('select * from pedidos where id=$1 for update', [req.params.id])).rows[0];
    if (!ped || ped.status !== 'aberto') throw new HttpError(400, 'Venda não está aberta.');
    if ((req.body || {}).pendente) {   // exclusão de venda pendente: pede usuário e senha (do próprio operador ou de quem pode cancelar)
      const aut = req.body.autorizacao;
      const admin = (req.user.perms || []).includes('*');
      const meu = !admin && aut && aut.login && String(aut.login).toLowerCase() === String(req.user.login || '').toLowerCase();
      if (meu) { const u = (await c.query('select senha_hash from usuarios where id=$1', [req.user.id])).rows[0]; if (!u || !require('./../auth').bcrypt.compareSync(String(aut.senha || ''), u.senha_hash)) throw new HttpError(403, 'Usuário ou senha inválidos.', { codigo: 'AUTORIZACAO_INVALIDA' }); }
      else await verificarAutorizacao(c, aut, 'vendas.cancelar', req.user);
    }
    let autV = null;
    if (!(req.body || {}).pendente) autV = await verificarAutorizacao(c, (req.body || {}).autorizacao, 'vendas.cancelar', req.user);   // cancelar venda: sempre usuário e senha
    const itens = (await c.query("select * from pedido_itens where pedido_id=$1 and status<>'cancelado' for update", [ped.id])).rows;
    if (itens.some(i => i.status !== 'novo')) {
      if (false && !can(req.user, 'vendas.cancelar')) throw new HttpError(403, 'Há itens já enviados: apenas quem tem permissão de cancelamento pode cancelar a venda.');
      if (!motivo) throw new HttpError(400, 'Informe o motivo do cancelamento.');
    }
    for (const i of itens) {
      await devolverEstoque(c, i.id, req.user.id, 'Cancelamento venda #' + ped.id);
      await c.query("update pedido_itens set status='cancelado', cancelado_em=now(), cancelado_por=$1, motivo_cancelamento=$2 where id=$3", [req.user.id, motivo, i.id]);
    }
    await c.query("update pedidos set status='cancelado', motivo_cancelamento=$1, fechado_em=now(), cancelado_em=now(), cancelado_por=$3, cancelado_autorizado_por=$4 where id=$2", [motivo, ped.id, req.user.id, autV ? autV.id : req.user.id]);
    if (itens.length) await auditar(c, req.user, 'venda_cancelada', { pedido: ped.id, itens: itens.length, motivo });
  });
  res.json({ ok: true });
}));

module.exports = r;
