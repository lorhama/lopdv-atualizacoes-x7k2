// Financeiro (contas a pagar/receber) e relatórios.
// Itens por cliente (contas a receber): títulos de um ou mais clientes com os itens de cada venda
function itensClienteHtml(titulos) {
  const nomes = [...new Set(titulos.map(x => x.cliente))];
  return nomes.map(n => {
    const ts = titulos.filter(x => x.cliente === n), tot = ts.reduce((a, x) => a + Number(x.saldo), 0);
    return `<div class="card" style="margin-bottom:12px"><h4 style="margin:0 0 6px">${esc(n)} <span class="muted">— saldo ${R(tot)}</span></h4>` + ts.map(x => `<div style="margin:8px 0 4px"><b>${esc(x.descricao)}</b> · venc. ${dia(x.vencimento)}${x.vencido ? ' ' + chip('vencido', 'err') : ''} · valor ${R(x.valor)}${x.recebido ? ' · recebido ' + R(x.recebido) : ''} · <b>saldo ${R(x.saldo)}</b></div>` +
      ((x.itens || []).length ? tabela([{ l: 'Item', k: 'nome' }, { l: 'Qtd', n: 1, f: i => N(i.qtd) }, { l: 'Unitário', n: 1, f: i => R(i.unit) }, { l: 'Total', n: 1, f: i => R(i.qtd * i.unit) }], x.itens, { rodape: ['<b>Total dos itens</b>', '', '', R(x.itens.reduce((t2, i) => t2 + i.qtd * i.unit, 0))] }) : '<p class="muted" style="margin:0 0 4px">Sem itens (lançamento manual).</p>')).join('') + `<p style="text-align:right;margin:8px 0 0"><b>Total do cliente: ${R(tot)}</b></p></div>`;
  }).join('');
}
function tituloView(tipo) {
  const pagar = tipo === 'pagar';
  registrar({ id: 'contas-' + tipo, titulo: pagar ? 'Contas a pagar' : 'Contas a receber', grupo: 'Financeiro', perm: 'financeiro.ver', render: async el => {
    const [forn, cli, FP] = await Promise.all([pagar ? api('/fornecedores?ativos=1') : [], pagar ? [] : api('/clientes'), pagar ? api('/formas-pagamento?uso=pagar') : []]);
    const nomeForma = c => (FP.find(f => f.codigo === c) || {}).descricao || '';
    let lista = [];
    el.innerHTML = `<div class="bar"><select id="st"><option value="aberto">Em aberto</option><option value="pago">${pagar ? 'Pagas' : 'Recebidas'}</option><option value="cancelado">Canceladas</option><option value="">Todas</option></select>
      <input id="q" list="dl-q" placeholder="🔎 Buscar por ${pagar ? 'fornecedor' : 'cliente'}" autocomplete="off" style="min-width:200px"><datalist id="dl-q">${(pagar ? forn : cli).map(x => `<option value="${esc(x.nome)}">`).join('')}</datalist>
      <label class="chk" style="margin:0">Vencimento de <input type="date" id="de"></label><label class="chk" style="margin:0">até <input type="date" id="ate"></label><button class="btn" id="f">Filtrar</button><div class="grow"></div>
      ${tem('financeiro.editar') ? '<button class="btn primary" id="novo">+ Novo lançamento</button>' : ''}</div><div id="res"></div>`;
    const porCliente = ls => {   // total por cliente + botão para ver os itens
      const m = new Map(); ls.filter(t => t.status === 'aberto').forEach(t => { const k = t.cliente_id || 0; if (!m.has(k)) m.set(k, { id: k, nome: t.cliente || 'Sem cliente', n: 0, valor: 0, saldo: 0 }); const g = m.get(k); g.n++; g.valor += Number(t.valor); g.saldo += Number(t.saldo); });
      const gs = [...m.values()].sort((a, b) => b.saldo - a.saldo); if (!gs.length) return '';
      return '<h3 style="margin:6px 0">Total por cliente (em aberto)</h3>' + tabela([{ l: 'Cliente', k: 'nome' }, { l: 'Títulos', n: 1, k: 'n' }, { l: 'Valor original', n: 1, f: g => R(g.valor) }, { l: 'Saldo em aberto', n: 1, f: g => `<b>${R(g.saldo)}</b>` }], gs,
        { acoes: g => (g.id ? `<button class="btn sm" data-ci="${g.id}">Ver itens</button>` : '') + (tem('vendas.receber') ? ` <button class="btn sm ok" data-ct="${g.id}">Receber tudo</button>` : ''), rodape: ['<b>TOTAL GERAL</b>', gs.reduce((a, g) => a + g.n, 0), R(gs.reduce((a, g) => a + g.valor, 0)), `<b>${R(gs.reduce((a, g) => a + g.saldo, 0))}</b>`] }) + '<h3 style="margin:16px 0 6px">Títulos</h3>';
    };
    const carregar = seguro(async () => {
      const r = await api('/financeiro/titulos?' + qs({ tipo, status: $('#st', el).value, de: $('#de', el).value, ate: $('#ate', el).value, q: $('#q', el).value.trim() })); lista = r.titulos;
      $('#res', el).innerHTML = `<div class="cards"><div class="stat">Em aberto<b>${R(r.totais.aberto)}</b></div><div class="stat ${r.totais.vencido ? 'err' : ''}">Vencido<b>${R(r.totais.vencido)}</b></div><div class="stat">${pagar ? 'Pago' : 'Recebido'}<b>${R(r.totais.pago)}</b></div></div>` + (pagar ? '' : porCliente(lista)) + (pagar || !tem('vendas.receber') || !lista.some(t => t.status === 'aberto') ? '' : '<div class="bar" id="lote"><label class="chk" style="display:flex;align-items:center;gap:6px;margin:0;cursor:pointer"><input type="checkbox" id="selall" style="width:auto;flex:none;margin:0"><b>Selecionar todas</b></label><button class="btn ok" id="recsel" disabled>Receber selecionadas</button><span class="muted" id="selinfo"></span></div>') +
        tabela([...(pagar || !tem('vendas.receber') ? [] : [{ l: '✓', f: t => (t.status === 'aberto' ? `<input type="checkbox" class="sel" data-s="${t.id}" style="width:auto">` : '') }]), { l: 'Vencimento', f: t => dia(t.vencimento) + (t.vencido ? ' ' + chip('vencido', 'err') : '') }, { l: 'Descrição', k: 'descricao' }, { l: pagar ? 'Fornecedor' : 'Cliente', f: t => esc(pagar ? t.fornecedor : t.cliente) }, { l: 'Categoria', k: 'categoria' }, ...(pagar ? [{ l: 'Forma prevista', f: t => esc(nomeForma(t.forma_prevista)) || '<span class="muted">—</span>' }] : []),
          { l: 'Valor', n: 1, f: t => R(t.valor) + (t.status === 'aberto' && Number(t.saldo) < Number(t.valor) - 0.004 ? `<br><small class="muted">saldo ${R(t.saldo)}</small>` : '') }, { l: 'Situação', f: t => chip(t.status === 'pago' ? (pagar ? 'pago ' : 'recebido ') + dia(t.pago_em) : t.status, t.status === 'pago' ? 'ok' : t.status === 'cancelado' ? 'cancelado' : '') }], lista,
          { acoes: t => (t.pedido_id && !pagar ? `<button class="btn sm" data-vi="${t.pedido_id}">Ver itens</button> ` : '') + (t.status !== 'aberto' ? '' : ((pagar ? tem('financeiro.baixar') : tem('vendas.receber')) ? `<button class="btn sm ok" data-b="${t.id}">${pagar ? 'Pagar' : 'Receber'}</button> ` : '') + (tem('financeiro.editar') ? `<button class="btn sm" data-e="${t.id}">Editar</button> <button class="btn sm danger" data-c="${t.id}">Cancelar</button>` : '')) });
    });
    const campos = [{ k: 'descricao', l: 'Descrição', req: true, full: true }, pagar ? { k: 'fornecedor_id', l: 'Fornecedor', t: 'select', op: [['', '—']].concat(forn.map(f => [f.id, f.nome])) } : { k: 'cliente_id', l: 'Cliente', t: 'select', op: [['', '—']].concat(cli.map(c => [c.id, c.nome])) },
      { k: 'categoria', l: 'Categoria', ph: pagar ? 'Aluguel, energia, salários...' : 'Eventos, crediário...' }, { k: 'valor', l: 'Valor (R$)', t: 'number', step: '0.01', req: true }, { k: 'vencimento', l: 'Vencimento', t: 'date', req: true }];
    const form = reg => formModal({ titulo: reg ? 'Editar título' : 'Novo lançamento', campos: reg ? campos : campos.concat([{ k: 'parcelas', l: 'Parcelas mensais', t: 'number', padrao: 1 }]), valores: reg ? { ...reg, vencimento: String(reg.vencimento).slice(0, 10) } : { parcelas: 1 },
      onSave: async o => { await api('/financeiro/titulos' + (reg ? '/' + reg.id : ''), { method: reg ? 'PUT' : 'POST', body: { ...o, tipo } }); toast('Salvo.'); carregar(); } });
    $('#f', el).onclick = carregar; $('#st', el).onchange = carregar; $('#q', el).onchange = carregar;
    if ($('#novo', el)) $('#novo', el).onclick = () => form(null);
    el.onclick = seguro(async e => {
      const d = e.target.dataset, t = id => lista.find(x => x.id == id);
      const marcadas = () => $$('.sel', el).filter(c => c.checked && c.closest('tr').style.display !== 'none').map(c => lista.find(x => x.id == c.dataset.s)).filter(Boolean);
      const atualizaSel = () => { const m = marcadas(), bt = $('#recsel', el); if (!bt) return; bt.disabled = !m.length; bt.textContent = m.length ? `Receber selecionadas (${m.length})` : 'Receber selecionadas'; $('#selinfo', el).textContent = m.length ? 'Total: ' + R(m.reduce((a, x) => a + Number(x.saldo), 0)) : ''; };
      if (e.target.id === 'selall') { $$('.sel', el).forEach(c => { if (c.closest('tr').style.display !== 'none') c.checked = e.target.checked; }); return atualizaSel(); }
      if (e.target.classList.contains('sel')) return atualizaSel();
      if (e.target.id === 'recsel') {
        const m = marcadas(); if (!m.length) return;
        const dd = await api('/fiado/pendentes');
        if (!dd.caixas.length) return aviso('Para receber é necessário ter um caixa aberto.\nAbra o seu caixa no menu Caixa.', 'Caixa fechado');
        return baixarLote(m, dd, carregar);
      }
      if (d.ct) { const m = lista.filter(x => x.status === 'aberto' && String(x.cliente_id || 0) === d.ct); const dd = await api('/fiado/pendentes'); if (!dd.caixas.length) return aviso('Para receber é necessário ter um caixa aberto.\nAbra o seu caixa no menu Caixa.', 'Caixa fechado'); return baixarLote(m, dd, carregar); }
      if (d.vi) return verItensVenda(+d.vi);
      if (d.ci) { const rr = await api('/relatorios/contas-receber?' + qs({ itens: 1, situacao: 'aberto', cliente_id: d.ci })); return modal({ titulo: 'Itens em aberto — ' + (rr.titulos[0] ? rr.titulos[0].cliente : 'cliente'), tam: 'lg', corpo: rr.titulos.length ? itensClienteHtml(rr.titulos) : '<p class="muted">Nada em aberto.</p>', botoes: [{ txt: 'Fechar', cls: 'primary' }] }); }
      if (d.e) form(t(d.e));
      if (d.c && await confirmar('Cancelar este título?')) { await api(`/financeiro/titulos/${d.c}/cancelar`, { method: 'POST' }); carregar(); }
      if (d.b && !pagar && tem('vendas.receber')) {   // todo recebimento entra no caixa aberto, com forma de pagamento/TEF e comprovante
        const x = t(d.b), dd = await api('/fiado/pendentes'), tt = dd.titulos.find(z => z.id == x.id) || x;
        if (!dd.caixas.length) return aviso('Para receber crediário é necessário ter um caixa aberto.\nAbra o seu caixa no menu Caixa.', 'Caixa fechado');
        return baixarFiado(tt, dd, carregar);
      }
      if (d.b) { const x = t(d.b); formModal({ titulo: (pagar ? 'Pagar: ' : 'Receber: ') + x.descricao, campos: [{ k: 'valor', l: 'Valor (R$)', t: 'number', step: '0.01', req: true }, { k: 'data', l: 'Data', t: 'date', req: true }, { k: 'forma', l: 'Forma', t: 'select', op: pagar ? FP.map(f => [f.codigo, f.descricao]) : [['dinheiro', 'Dinheiro'], ['pix', 'PIX'], ['transferencia', 'Transferência'], ['boleto', 'Boleto'], ['cartao', 'Cartão']], full: true }], valores: { valor: x.valor, data: hojeISO(), forma: x.forma_prevista || undefined },
        onSave: async o => { await api(`/financeiro/titulos/${x.id}/baixar`, { method: 'POST', body: o }); toast('Baixado.'); carregar(); } }); }
    });
    await carregar();
  } });
}
tituloView('pagar'); tituloView('receber');

// ---------------- Relatórios
registrar({ id: 'relatorios', titulo: 'Relatórios', grupo: 'Relatórios', perm: ['relatorios.financeiro', 'relatorios.estoque'], render: async el => {
  const fin = tem('relatorios.financeiro'), est = tem('relatorios.estoque');
  const abas = [fin && ['caixa', 'Fechamento de caixa'], fin && ['ticket', 'Ticket médio'], fin && ['lucro', 'Lucratividade'], fin && ['vendas', 'Vendas'], (est || fin) && ['top', 'Mais vendidos'], fin && ['areceber', 'Contas a receber']].filter(Boolean);
  let aba = abas[0][0], ultimo = null, semDatas = false;
  const hojeISO = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  el.innerHTML = `<div class="tabs" id="tb">${abas.map(a => `<button data-a="${a[0]}" class="${a[0] === aba ? 'on' : ''}">${a[1]}</button>`).join('')}${est ? '<a class="btn" href="#/movimentos" style="border-radius:99px">Movimentação de estoque →</a>' : ''}</div>
    <div class="bar" id="filtros"><label class="chk hidden" id="fcrw" style="margin:0">Cliente <select id="fcr"><option value="">Todos</option></select></label><label class="chk hidden" id="fcmw" style="margin:0">Relatório <select id="fcm"><option value="total">Total geral</option><option value="itens">Total geral imprimindo os itens</option></select></label><label class="chk hidden" id="fcsw" style="margin:0">Situação <select id="fcs"><option value="aberto">Em aberto</option><option value="pago">Recebidas</option><option value="todas">Todas</option></select></label><label class="chk hidden" id="fsitw" style="margin:0">Situação <select id="fsit"><option value="todas">Todas</option><option value="finalizadas">Só finalizadas</option><option value="canceladas">Só canceladas</option></select></label><label class="chk" style="margin:0" id="ffpw">Forma de pagamento <select id="ffp"><option value="">Todas</option></select></label><label class="chk" style="margin:0">De <input type="date" id="de" value="${iniMes()}"></label><label class="chk" style="margin:0">Até <input type="date" id="ate" value="${hojeISO()}"></label><button class="btn primary" id="ok">Gerar</button><div class="grow"></div><button class="btn" id="csv">CSV</button><button class="btn" onclick="window.print()">Imprimir</button></div><div id="res"></div>`;
  const per = () => qs({ de: $('#de', el).value, ate: $('#ate', el).value, forma: $('#ffp', el).value });
  try { const cs = await api('/clientes'); $('#fcr', el).innerHTML += cs.map(c => `<option value="${c.id}">${esc(c.nome)}${c.ativo ? '' : ' (INATIVO)'}</option>`).join(''); } catch { /* sem lista */ }
  try { const fs = await api('/formas-pagamento'); $('#ffp', el).innerHTML += fs.map(f => `<option value="${esc(f.codigo)}">${esc(f.descricao || f.codigo)}</option>`).join(''); } catch { /* sem lista: fica só Todas */ }
  const gerar = seguro(async () => {
    const res = $('#res', el);
    $('#filtros', el).classList.toggle('hidden', aba === 'caixa' && false);
    $('#fsitw', el).classList.toggle('hidden', aba !== 'vendas');
    $('#ffpw', el).classList.toggle('hidden', aba === 'caixa' || aba === 'areceber');
    $('#fcrw', el).classList.toggle('hidden', aba !== 'areceber'); $('#fcsw', el).classList.toggle('hidden', aba !== 'areceber'); $('#fcmw', el).classList.toggle('hidden', aba !== 'areceber');
    if (aba === 'areceber' && !semDatas) { semDatas = true; $('#de', el).value = ''; $('#ate', el).value = ''; }   // dívidas antigas também precisam aparecer
    if (aba !== 'areceber' && semDatas) { semDatas = false; $('#de', el).value = iniMes(); $('#ate', el).value = hojeISO(); }
    if (aba === 'caixa') {
      const l = (await api('/caixa')).filter(c => c.status === 'fechado' || true);
      res.innerHTML = '<p class="muted">Escolha um caixa para ver o fechamento completo (por forma de pagamento, sangrias, diferença).</p>' + tabela([{ l: '#', k: 'id' }, { l: 'Usuário', k: 'usuario' }, { l: 'Abertura', f: r => dt(r.aberto_em) }, { l: 'Fechamento', f: r => dt(r.fechado_em) }, { l: 'Status', f: r => chip(r.status, r.status === 'aberto' ? 'ok' : '') }, { l: 'Esperado', n: 1, f: r => (r.valor_esperado != null ? R(r.valor_esperado) : '') }, { l: 'Contado', n: 1, f: r => (r.valor_informado != null ? R(r.valor_informado) : '') },
        { l: 'Diferença', n: 1, f: r => (r.valor_informado != null ? `<b class="${r.valor_informado - r.valor_esperado ? 'erro' : ''}">${R(r.valor_informado - r.valor_esperado)}</b>` : '') }], l, { acoes: r => `<button class="btn sm" data-cx="${r.id}">Abrir</button>` });
      ultimo = { nome: 'caixas', cols: [{ l: '#', k: 'id' }, { l: 'Usuário', k: 'usuario' }, { l: 'Abertura', k: 'aberto_em' }, { l: 'Fechamento', k: 'fechado_em' }, { l: 'Esperado', k: 'valor_esperado' }, { l: 'Contado', k: 'valor_informado' }], rows: l };
    } else if (aba === 'vendas') {
      const r = await api('/relatorios/vendas?' + per() + '&situacao=' + $('#fsit', el).value), s = r.resumo;
      const somaV = (k, so) => r.vendas.filter(x => !so || x.status !== 'cancelado').reduce((t, x) => t + Number(x[k] || 0), 0);
      const cols = [{ l: 'Nº', k: 'numero' }, { l: 'Data', f: x => dt(x.data) }, { l: 'Situação', f: x => (x.status === 'cancelado' ? chip('CANCELADA', 'err') : chip('FINALIZADA', 'ok')) }, { l: 'Operador', k: 'operador' }, { l: 'Pagamento', k: 'formas' },
        { l: 'Valor bruto', n: 1, f: x => R(x.bruto) }, { l: 'Desconto', n: 1, f: x => (x.status === 'cancelado' ? '' : (x.bruto - x.total > 0.004 ? R(x.bruto - x.total) : '')) }, { l: 'Valor líquido', n: 1, f: x => (x.status === 'cancelado' ? '<span class="muted">—</span>' : `<b>${R(x.total)}</b>`) }, { l: 'Devolvido', n: 1, f: x => (x.devolvido ? `<b class="erro">${R(x.devolvido)}</b>` : '') }, { l: 'Cancelada por', f: x => (x.status === 'cancelado' ? esc(x.cancelado_por || '') + (x.autorizado_por && x.autorizado_por !== x.cancelado_por ? ` <small class="muted">(autorizou: ${esc(x.autorizado_por)})</small>` : '') + (x.cancelado_em ? `<br><small class="muted">${dt(x.cancelado_em)}</small>` : '') : '') }, { l: 'Motivo', k: 'motivo' }];
      res.innerHTML = `<div class="cards"><div class="stat">Finalizadas<b>${s.finalizadas}</b><small>${R(s.valor_finalizadas)} líquido</small></div><div class="stat">Valor bruto<b>${R(s.bruto_finalizadas)}</b></div><div class="stat">Descontos<b>${R(s.desconto_finalizadas)}</b></div><div class="stat">Valor líquido<b>${R(s.valor_finalizadas)}</b></div><div class="stat ${s.canceladas ? 'err' : ''}">Canceladas<b>${s.canceladas}</b><small>${R(s.valor_canceladas)}</small></div></div>` + tabela(cols, r.vendas, { vazio: 'Nenhuma venda no período.', rodape: cols.map(c => ({ 'Nº': '<b>TOTAL</b>', 'Valor bruto': R(somaV('bruto', 1)), 'Desconto': R(r.vendas.filter(x => x.status !== 'cancelado').reduce((t, x) => t + Math.max(x.bruto - x.total, 0), 0)), 'Valor líquido': R(somaV('total', 1)), 'Devolvido': R(somaV('devolvido')) }[c.l] || '')) });
      ultimo = { nome: 'vendas', cols: [{ l: 'Nº', k: 'numero' }, { l: 'Data', k: 'data' }, { l: 'Situação', k: 'status' }, { l: 'Operador', k: 'operador' }, { l: 'Pagamento', k: 'formas' }, { l: 'Valor bruto', k: 'bruto' }, { l: 'Valor líquido', k: 'total' }, { l: 'Devolvido', k: 'devolvido' }, { l: 'Cancelada por', k: 'cancelado_por' }, { l: 'Autorizado por', k: 'autorizado_por' }, { l: 'Motivo', k: 'motivo' }], rows: r.vendas };
    } else if (aba === 'areceber') {
      const r = await api('/relatorios/contas-receber?' + qs({ itens: $('#fcm', el).value === 'itens' ? 1 : '', situacao: $('#fcs', el).value, cliente_id: $('#fcr', el).value, de: $('#de', el).value, ate: $('#ate', el).value })), t = r.total;
      res.innerHTML = `<div class="cards"><div class="stat">Total geral em aberto<b>${R(t.saldo)}</b><small>${t.n} título(s)</small></div><div class="stat ${t.vencido ? 'err' : ''}">Vencido<b>${R(t.vencido)}</b></div><div class="stat">Já recebido<b>${R(t.recebido)}</b></div><div class="stat">Valor original<b>${R(t.valor)}</b></div></div>
        <h3 style="margin:6px 0">Total por cliente</h3>` + tabela([{ l: 'Cliente', k: 'cliente' }, { l: 'Títulos', n: 1, k: 'n' }, { l: 'Valor original', n: 1, f: x => R(x.valor) }, { l: 'Recebido', n: 1, f: x => R(x.recebido) }, { l: 'Vencido', n: 1, f: x => (x.vencido ? `<b class="erro">${R(x.vencido)}</b>` : '') }, { l: 'Saldo em aberto', n: 1, f: x => `<b>${R(x.saldo)}</b>` }], r.por_cliente,
        { vazio: 'Nenhuma conta a receber.', rodape: ['<b>TOTAL GERAL</b>', t.n, R(t.valor), R(t.recebido), R(t.vencido), `<b>${R(t.saldo)}</b>`] }) +
        ($('#fcm', el).value === 'itens' ? `<h3 style="margin:16px 0 6px">Detalhe por cliente, com os itens</h3>` + r.por_cliente.map(g => {
          const ts = r.titulos.filter(x => x.cliente === g.cliente);
          return `<div class="card" style="margin-bottom:12px;break-inside:avoid"><h4 style="margin:0 0 6px">${esc(g.cliente)} <span class="muted">— saldo ${R(g.saldo)}</span></h4>` + ts.map(x => `<div style="margin:8px 0 4px"><b>${esc(x.descricao)}</b> · venc. ${dia(x.vencimento)}${x.vencido ? ' ' + chip('vencido', 'err') : ''} · valor ${R(x.valor)}${x.recebido ? ' · recebido ' + R(x.recebido) : ''} · <b>saldo ${R(x.saldo)}</b></div>` +
            ((x.itens || []).length ? tabela([{ l: 'Item', k: 'nome' }, { l: 'Qtd', n: 1, f: i => N(i.qtd) }, { l: 'Unitário', n: 1, f: i => R(i.unit) }, { l: 'Total', n: 1, f: i => R(i.qtd * i.unit) }], x.itens, { rodape: ['<b>Total dos itens</b>', '', '', R(x.itens.reduce((t2, i) => t2 + i.qtd * i.unit, 0))] }) : '<p class="muted" style="margin:0 0 4px">Sem itens (lançamento manual).</p>')).join('') + `<p style="text-align:right;margin:8px 0 0"><b>Total do cliente: ${R(g.saldo)}</b></p></div>`;
        }).join('') + `<p style="text-align:right;font-size:17px"><b>TOTAL GERAL: ${R(t.saldo)}</b></p>` : '');
      ultimo = { nome: 'contas-a-receber', cols: [{ l: 'Cliente', k: 'cliente' }, { l: 'Descrição', k: 'descricao' }, { l: 'Vencimento', k: 'vencimento' }, { l: 'Valor', k: 'valor' }, { l: 'Recebido', k: 'recebido' }, { l: 'Saldo', k: 'saldo' }], rows: r.titulos };
    } else if (aba === 'ticket') {
      const r = await api('/relatorios/ticket-medio?' + per());
      res.innerHTML = `<div class="cards"><div class="stat">Valor bruto<b>${R(r.total.bruto)}</b></div><div class="stat">Valor líquido<b>${R(r.total.faturamento)}</b></div><div class="stat">Vendas<b>${r.total.vendas}</b></div><div class="stat">Ticket médio<b>${R(r.total.ticket)}</b></div></div><h3 style="margin:6px 0">Por dia</h3>` +
        tabela([{ l: 'Dia', f: x => dia(x.dia) }, { l: 'Vendas', n: 1, k: 'vendas' }, { l: 'Valor bruto', n: 1, f: x => R(x.bruto) }, { l: 'Valor líquido', n: 1, f: x => R(x.faturamento) }, { l: 'Ticket médio (líq.)', n: 1, f: x => R(x.ticket) }], r.por_dia, { rodape: ['<b>TOTAL</b>', r.total.vendas, R(r.total.bruto), R(r.total.faturamento), R(r.total.ticket)] }) + `<h3 style="margin:16px 0 6px">Por atendente</h3>` + tabela([{ l: 'Atendente', k: 'usuario' }, { l: 'Vendas', n: 1, k: 'vendas' }, { l: 'Valor bruto', n: 1, f: x => R(x.bruto) }, { l: 'Valor líquido', n: 1, f: x => R(x.faturamento) }, { l: 'Ticket médio (líq.)', n: 1, f: x => R(x.ticket) }], r.por_atendente, { rodape: ['<b>TOTAL</b>', r.total.vendas, R(r.total.bruto), R(r.total.faturamento), R(r.total.ticket)] });
      ultimo = { nome: 'ticket-medio', cols: [{ l: 'Dia', k: 'dia' }, { l: 'Vendas', k: 'vendas' }, { l: 'Valor bruto', k: 'bruto' }, { l: 'Valor líquido', k: 'faturamento' }, { l: 'Ticket médio', k: 'ticket' }], rows: r.por_dia };
    } else if (aba === 'lucro') {
      const r = await api('/relatorios/lucratividade?' + per()), s = r.resumo;
      res.innerHTML = `<div class="cards"><div class="stat">Receita bruta<b>${R(s.receita_bruta)}</b></div><div class="stat">Descontos<b>${R(s.descontos)}</b></div><div class="stat">Custo das mercadorias<b>${R(s.custo_mercadoria)}</b></div><div class="stat"><span>Lucro bruto (${N(s.margem_pct, 1)}%)</span><b>${R(s.lucro_bruto)}</b></div>
        <div class="stat">Despesas pagas no período<b>${R(s.despesas_operacionais_pagas)}</b></div><div class="stat ${s.resultado < 0 ? 'err' : ''}">Resultado<b>${R(s.resultado)}</b></div></div><p class="muted">Custo pelo custo médio vigente no momento da venda. Despesas = contas a pagar baixadas no período (exceto compras de mercadoria, que já entram no custo).</p>` +
        tabela([{ l: 'Produto', k: 'nome' }, { l: 'Qtd', n: 1, f: x => N(x.quantidade) }, { l: 'Receita', n: 1, f: x => R(x.receita) }, { l: 'Custo', n: 1, f: x => R(x.custo) }, { l: 'Lucro', n: 1, f: x => `<b class="${x.lucro < 0 ? 'erro' : ''}">${R(x.lucro)}</b>` }, { l: 'Margem', n: 1, f: x => N(x.margem, 1) + '%' }], r.produtos, { rodape: ['<b>TOTAL</b>', N(r.produtos.reduce((t, x) => t + Number(x.quantidade), 0)), R(s.receita_bruta), R(s.custo_mercadoria), `<b>${R(r.produtos.reduce((t, x) => t + Number(x.lucro), 0))}</b>`, N(s.margem_pct, 1) + '%'] });
      ultimo = { nome: 'lucratividade', cols: [{ l: 'Produto', k: 'nome' }, { l: 'Qtd', k: 'quantidade' }, { l: 'Receita', k: 'receita' }, { l: 'Custo', k: 'custo' }, { l: 'Lucro', k: 'lucro' }, { l: 'Margem %', k: 'margem' }], rows: r.produtos };
    } else {
      const r = await api('/relatorios/mais-vendidos?' + per() + '&limite=50');
      res.innerHTML = tabela([{ l: '#', f: x => r.produtos.indexOf(x) + 1 }, { l: 'Produto', k: 'nome' }, { l: 'Quantidade', n: 1, f: x => N(x.quantidade) }, { l: 'Vendas', n: 1, k: 'comandas' }, { l: 'Receita', n: 1, f: x => R(x.receita) }], r.produtos, { vazio: 'Sem vendas no período.', rodape: ['', '<b>TOTAL</b>', N(r.produtos.reduce((t, x) => t + Number(x.quantidade), 0)), '', R(r.produtos.reduce((t, x) => t + Number(x.receita), 0))] });
      ultimo = { nome: 'mais-vendidos', cols: [{ l: 'Produto', k: 'nome' }, { l: 'Quantidade', k: 'quantidade' }, { l: 'Vendas', k: 'comandas' }, { l: 'Receita', k: 'receita' }], rows: r.produtos };
    }
  });
  el.onclick = seguro(async e => {
    const a = e.target.dataset.a; if (a) { aba = a; $$('#tb button', el).forEach(b => b.classList.toggle('on', b.dataset.a === a)); return gerar(); }
    if (e.target.dataset.cx) { const r = await api('/caixa/' + e.target.dataset.cx); modal({ titulo: 'Relatório do fechamento — Caixa #' + r.caixa.id, tam: 'md', corpo: resumoCaixaHtml(r), botoes: [{ txt: 'Gerar PDF', fn: async () => { await caixaPdf(r.caixa.id); return false; } }, { txt: 'Imprimir', fn: () => { window.print(); return false; } }, { txt: 'Fechar', cls: 'primary' }] }); }
  });
  $('#ok', el).onclick = gerar; $('#csv', el).onclick = () => ultimo && csv(ultimo.nome, ultimo.cols, ultimo.rows);
  await gerar();
} });

// ---- Extrato do produto (relatório): toda entrada e saída, com saldo linha a linha
registrar({ id: 'extrato-produto', titulo: 'Extrato do produto', grupo: 'Relatórios', perm: ['relatorios.estoque', 'estoque.ver'], render: async el => {
  const prods = await api('/produtos');
  const { dl, achar } = seletorProduto(prods, 'dl-ex');
  const TIPO = { entrada: 'Entrada', venda: 'Saída (venda)', estorno: 'Estorno de venda', ajuste: 'Ajuste', producao_saida: 'Saída (produção)', producao_entrada: 'Entrada (produção)' };
  el.innerHTML = `<div class="bar">${dl}<input id="pp" list="dl-ex" style="min-width:280px" placeholder="Produto (nome, código ou código de barras)" autocomplete="off"><label class="chk" style="margin:0">De <input type="date" id="de" value="${iniMes()}"></label><label class="chk" style="margin:0">Até <input type="date" id="ate" value="${hojeISO()}"></label>
    <button class="btn primary" id="ok">Ver extrato</button><div class="grow"></div><button class="btn" id="csv">CSV</button><button class="btn" onclick="window.print()">Imprimir</button></div><div id="res"><p class="muted">Escolha um produto para ver toda a movimentação de entrada e saída.</p></div>`;
  let ultimo = null;
  const buscar = seguro(async () => {
    const p = achar($('#pp', el).value); if (!p) throw new Error('Escolha um produto na lista (ou leia o código de barras).');
    $('#pp', el).value = rotuloProd(p);
    const r = await api('/estoque/extrato?' + qs({ produto_id: p.id, de: $('#de', el).value, ate: $('#ate', el).value })); ultimo = r; const un = r.produto.unidade;
    $('#res', el).innerHTML = `<h3 style="margin:6px 0">${esc(r.produto.nome)} <small class="muted">cód. ${esc(r.produto.codigo || '')}</small></h3>
      <div class="cards"><div class="stat">Saldo inicial<b>${N(r.saldo_inicial)} ${un}</b></div><div class="stat">Entradas<b>${N(r.entradas)} ${un}</b></div><div class="stat">Saídas<b>${N(r.saidas)} ${un}</b></div><div class="stat">Saldo final<b>${N(r.saldo_final)} ${un}</b></div><div class="stat">Estoque hoje<b>${N(r.produto.estoque_atual)} ${un}</b></div></div>` +
      tabela([{ l: 'Data', f: x => dt(x.criado_em) }, { l: 'Tipo', f: x => chip(TIPO[x.tipo] || x.tipo, x.quantidade > 0 ? 'ok' : 'warn') }, { l: 'Documento', k: 'documento' },
        { l: 'Entrada', n: 1, f: x => (x.quantidade > 0 ? N(x.quantidade) : '') }, { l: 'Saída', n: 1, f: x => (x.quantidade < 0 ? N(-x.quantidade) : '') }, { l: 'Saldo', n: 1, f: x => `<b>${N(x.saldo_apos)}</b>` },
        { l: 'Custo un.', n: 1, f: x => (x.custo_unit != null ? R(x.custo_unit) : '') }, { l: 'Usuário', k: 'usuario' }, { l: 'Motivo / obs.', k: 'motivo' }], r.linhas, { vazio: 'Nenhuma movimentação no período.' });
  });
  $('#ok', el).onclick = buscar; $('#pp', el).onchange = () => { if (achar($('#pp', el).value)) buscar(); };
  $('#csv', el).onclick = () => ultimo && csv('extrato-' + (ultimo.produto.codigo || ultimo.produto.id), [{ l: 'Data', k: 'criado_em' }, { l: 'Tipo', k: 'tipo' }, { l: 'Documento', k: 'documento' }, { l: 'Quantidade', k: 'quantidade' }, { l: 'Saldo', k: 'saldo_apos' }, { l: 'Custo', k: 'custo_unit' }, { l: 'Usuário', k: 'usuario' }, { l: 'Motivo', k: 'motivo' }], ultimo.linhas);
} });

// ---- Relatório de entradas de mercadoria: filtros por período, tipo e fornecedor; colunas ordenáveis (clique no título)
registrar({ id: 'rel-entradas', titulo: 'Entradas de mercadoria', grupo: 'Relatórios', perm: ['relatorios.estoque', 'estoque.ver'], render: async el => {
  const forn = await api('/fornecedores').catch(() => []);
  const TIPO = { xml: 'Entrada XML', consignado: 'Consignado', manual: 'Manual', doacao: 'Doação' };
  el.innerHTML = `<div class="bar"><label class="chk" style="margin:0">De <input type="date" id="de" value="${iniMes()}"></label><label class="chk" style="margin:0">Até <input type="date" id="ate" value="${hojeISO()}"></label>
    <label class="chk" style="margin:0">Tipo <select id="tp"><option value="">Todos</option><option value="xml">Entrada XML</option><option value="consignado">Entrada consignado</option><option value="manual">Entrada manual</option><option value="doacao">Doação</option></select></label>
    <label class="chk" style="margin:0">Fornecedor <select id="fo"><option value="">Todos</option>${forn.map(f => `<option value="${f.id}">${esc(f.nome)}</option>`).join('')}</select></label>
    <label class="chk" style="margin:0"><input type="checkbox" id="it"> Mostrar itens</label>
    <button class="btn primary" id="ok">Gerar</button><div class="grow"></div><button class="btn" id="csv">CSV</button><button class="btn" onclick="window.print()">Imprimir</button></div><div id="res"></div>`;
  let ultimo = null;
  const gerar = seguro(async () => {
    const d = await api('/estoque/relatorio-entradas?' + qs({ de: $('#de', el).value, ate: $('#ate', el).value, tipo: $('#tp', el).value, fornecedor_id: $('#fo', el).value }));
    const itens = $('#it', el).checked; ultimo = d;
    const pt = Object.entries(d.por_tipo).map(([k, v]) => `<div class="stat">${esc(TIPO[k] || k)}<b>${R(v.valor)}</b><small>${v.entradas} entrada(s)</small></div>`).join('');
    const tipoChip = t => chip(TIPO[t] || t, t === 'consignado' ? 'warn' : t === 'xml' ? 'ok' : '');
    const cols = [{ l: 'Data', f: x => dt(x.criado_em) }, { l: 'Tipo', f: x => tipoChip(x.tipo) + (x.tipo === 'consignado' && x.consig_status ? ` <span class="muted">${x.consig_status === 'acertada' ? 'acertada' : 'em aberto'}</span>` : '') }, { l: 'Fornecedor', f: x => esc(x.fornecedor || '—') }, { l: 'Série', f: x => esc(x.serie || '') }, { l: 'Nº nota', f: x => esc(x.numero || '') },
      { l: 'Itens', n: 1, k: 'qtd_itens' }, { l: 'Qtd. total', n: 1, f: x => N(x.qtd_total) }, { l: 'Valor', n: 1, f: x => R(x.total) }, { l: 'Usuário', f: x => esc(x.usuario || '') }];
    $('#res', el).innerHTML = `<div class="cards"><div class="stat">Entradas no período<b>${d.total.entradas}</b></div><div class="stat">Valor total<b>${R(d.total.valor)}</b></div>${pt}</div>
      <p class="muted">Clique no título de uma coluna para ordenar (como no Excel); use a caixa de filtro para achar uma nota ou fornecedor.</p>` +
      tabela(cols, d.entradas, { vazio: 'Nenhuma entrada nesse filtro.', acoes: itens ? null : x => (x.itens.length ? `<button class="btn sm" data-ver="${x.id}">Itens</button>` : '') }) +
      (itens && d.entradas.length ? `<h3 style="margin:16px 0 6px">Itens das entradas</h3>` + tabela([{ l: 'Data', f: x => dt(x.criado_em) }, { l: 'Tipo', f: x => esc(TIPO[x.tipo] || x.tipo) }, { l: 'Fornecedor', f: x => esc(x.fornecedor || '—') }, { l: 'Série', f: x => esc(x.serie || '') }, { l: 'Nº nota', f: x => esc(x.numero || '') }, { l: 'Produto', f: x => esc(x.produto || '') + (x.doacao ? ' <span class="muted">(doação)</span>' : '') }, { l: 'Qtd.', n: 1, f: x => N(x.quantidade) + ' ' + esc(x.unidade || '') }, { l: 'Custo un.', n: 1, f: x => R(x.custo_unit) }, { l: 'Total', n: 1, f: x => R(x.total) }],
        d.entradas.flatMap(e => e.itens.map(i => ({ ...i, criado_em: e.criado_em, tipo: e.tipo, fornecedor: e.fornecedor, numero: e.numero, serie: e.serie })))) : '');
  });
  el.onclick = seguro(async e => {
    const v = e.target.dataset.ver; if (!v || !ultimo) return;
    const en = ultimo.entradas.find(x => String(x.id) === v); if (!en) return;
    modal({ titulo: `Itens da entrada ${en.numero ? 'NF ' + (en.serie ? 'série ' + en.serie + ' nº ' : '') + en.numero : '#' + en.id}`, tam: 'lg', corpo: `<p class="muted">${esc(TIPO[en.tipo] || en.tipo)} · ${esc(en.fornecedor || 'sem fornecedor')} · ${dt(en.criado_em)}</p>` + tabela([{ l: 'Produto', f: x => esc(x.produto || '') + (x.doacao ? ' <span class="muted">(doação)</span>' : '') }, { l: 'Qtd.', n: 1, f: x => N(x.quantidade) + ' ' + esc(x.unidade || '') }, { l: 'Custo un.', n: 1, f: x => R(x.custo_unit) }, { l: 'Total', n: 1, f: x => R(x.total) }], en.itens), botoes: [{ txt: 'Fechar', cls: 'primary' }] });
  });
  $('#ok', el).onclick = gerar; $('#it', el).onchange = gerar;
  $('#csv', el).onclick = () => ultimo && csv('entradas', [{ l: 'Data', csv: x => x.criado_em }, { l: 'Tipo', csv: x => TIPO[x.tipo] }, { l: 'Fornecedor', k: 'fornecedor' }, { l: 'Série', k: 'serie' }, { l: 'Nº nota', k: 'numero' }, { l: 'Itens', k: 'qtd_itens' }, { l: 'Qtd total', k: 'qtd_total' }, { l: 'Valor', k: 'total' }, { l: 'Usuário', k: 'usuario' }], ultimo.entradas);
  gerar();
} });
