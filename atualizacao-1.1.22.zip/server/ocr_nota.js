// Leitura OFFLINE de foto de nota de compra (OCR) e interpretação dos itens. Nada sai do computador.
// Motor 1: programa "tesseract" instalado na máquina (se houver). Motor 2: biblioteca tesseract.js (instalada com o sistema), usando o
// idioma português que acompanha o sistema em server/ocr/por.traineddata.
const fs = require('fs'), os = require('os'), path = require('path'), cp = require('child_process');
const DIR = path.join(__dirname, 'ocr');

function acharExe() {
  const cand = [process.env.LOPDV_TESSERACT, 'tesseract', 'C:\\Program Files\\Tesseract-OCR\\tesseract.exe', 'C:\\Program Files (x86)\\Tesseract-OCR\\tesseract.exe'].filter(Boolean);
  for (const c of cand) {
    try { const r = cp.spawnSync(c, ['--version'], { timeout: 8000, windowsHide: true }); if (r.status === 0) return c; } catch { /* próximo */ }
  }
  return null;
}

function rodarExe(exe, arq, psm) {
  return new Promise((ok, err) => cp.execFile(exe, [arq, 'stdout', '-l', 'por', '--tessdata-dir', DIR, '--psm', String(psm)], { timeout: 120000, maxBuffer: 20e6, windowsHide: true }, (e, out) => (e ? err(e) : ok(String(out)))));
}

async function viaTesseractJs(buf) {
  let T; try { T = require('tesseract.js'); } catch { return null; }
  const w = await T.createWorker('por', 1, { langPath: DIR, gzip: false, cacheMethod: 'none' });
  try { await w.setParameters({ tessedit_pageseg_mode: '6', preserve_interword_spaces: '1' }); } catch { /* opcional */ }
  try { const r = await w.recognize(buf); return r.data.text; } finally { try { await w.terminate(); } catch { /* */ } }
}

// Devolve { texto, motor }. Lança erro com mensagem clara se nenhum motor estiver disponível.
async function lerImagem(buf) {
  const exe = acharExe();
  if (exe) {
    const arq = path.join(os.tmpdir(), 'lopdv-ocr-' + process.pid + '-' + Date.now() + '.img');
    fs.writeFileSync(arq, buf);
    try {
      let melhor = '', n = -1;
      for (const psm of [6, 4]) { const t = await rodarExe(exe, arq, psm); const k = interpretar(t).length; if (k > n || (k === n && t.length > melhor.length)) { melhor = t; n = k; } if (n >= 3) break; }
      return { texto: melhor, motor: 'tesseract' };
    } finally { try { fs.unlinkSync(arq); } catch { /* */ } }
  }
  const t = await viaTesseractJs(buf);
  if (t !== null) return { texto: t, motor: 'tesseract.js' };
  const e = new Error('O leitor offline (OCR) ainda não está instalado neste computador. Atualize o sistema (a atualização instala o leitor) ou instale o Tesseract.'); e.status = 501; throw e;
}


// ---------- PDF da nota (DANFE salvo/recebido por e-mail): lê o TEXTO do PDF, sem internet ----------
function acharPdftotext() {
  for (const c of [process.env.LOPDV_PDFTOTEXT, 'pdftotext'].filter(Boolean)) { try { const r = cp.spawnSync(c, ['-v'], { timeout: 5000, windowsHide: true }); if (r.status === 0 || r.status === 99 || (r.stderr && /pdftotext/i.test(String(r.stderr)))) return c; } catch { /* próximo */ } }
  return null;
}
async function viaPdfJs(buf) {
  let pdfjs; try { pdfjs = await import('pdfjs-dist/legacy/build/pdf.mjs'); } catch { return null; }
  const doc = await pdfjs.getDocument({ data: new Uint8Array(buf), useSystemFonts: true, isEvalSupported: false, verbosity: 0 }).promise;
  let out = '';
  for (let n = 1; n <= Math.min(doc.numPages, 30); n++) {
    const tc = await (await doc.getPage(n)).getTextContent(), linhas = [];
    for (const it of tc.items) { if (!it.str || !it.str.trim()) continue; const y = it.transform[5], x = it.transform[4]; let l = linhas.find(k => Math.abs(k.y - y) < 3); if (!l) { l = { y, p: [] }; linhas.push(l); } l.p.push({ x, w: it.width || 0, t: it.str }); }
    linhas.sort((a, b) => b.y - a.y);
    for (const l of linhas) { l.p.sort((a, b) => a.x - b.x); let ln = '', fim = null; for (const q of l.p) { ln += (fim !== null && q.x - fim > 1.5 ? ' ' : '') + q.t; fim = q.x + q.w; } out += ln.replace(/\s+/g, ' ') + '\n'; }
  }
  try { await doc.destroy(); } catch { /* */ }
  return out;
}
async function lerPdf(buf) {
  let texto = '', motor = '';
  const exe = acharPdftotext();
  if (exe) {
    const arq = path.join(os.tmpdir(), 'lopdv-pdf-' + process.pid + '-' + Date.now() + '.pdf'); fs.writeFileSync(arq, buf);
    try { texto = await new Promise((ok, err) => cp.execFile(exe, ['-layout', '-enc', 'UTF-8', arq, '-'], { timeout: 60000, maxBuffer: 30e6, windowsHide: true }, (e, out) => (e ? err(e) : ok(out)))); motor = 'pdf (pdftotext)'; }
    catch { texto = ''; } finally { try { fs.unlinkSync(arq); } catch { /* */ } }
  }
  if (!texto || texto.trim().length < 80) { const t = await viaPdfJs(buf); if (t !== null) { texto = t; motor = 'pdf'; } else if (!texto) { const e = new Error('O leitor de PDF ainda não está instalado neste computador. Atualize o sistema (a atualização instala o leitor).'); e.status = 501; throw e; } }
  if (texto.trim().length < 80) { const e = new Error('Este PDF é uma imagem (nota escaneada) e não tem texto para ler. Tire uma foto da nota ou salve a página como imagem (JPG/PNG) e use a foto.'); e.status = 400; throw e; }
  return { texto, motor };
}
// chave de acesso de 44 dígitos impressa na DANFE
function acharChave(texto) {
  const m = /(?<!\d)\d{4}(?:[ .]?\d{4}){10}(?!\d)/.exec(String(texto || '')); return m ? m[0].replace(/\D/g, '') : null;
}


// dados do cabeçalho da nota: número, CNPJ do emitente e data. A chave de 44 dígitos é a fonte mais segura:
// UF(2) AAMM(4) CNPJ(14) modelo(2) série(3) número(9) ...
function cnpjValido(d) {
  d = String(d || '').replace(/\D/g, ''); if (d.length !== 14 || /^(\d)\1+$/.test(d)) return false;
  const dv = n => { let soma = 0, p = n - 7; for (let i = 0; i < n; i++) { soma += Number(d[i]) * p--; if (p < 2) p = 9; } const r = soma % 11; return r < 2 ? 0 : 11 - r; };
  return dv(12) === Number(d[12]) && dv(13) === Number(d[13]);
}
// todos os CNPJs válidos que aparecem no texto, na ordem, sem os de 'excluir' (CNPJ da própria empresa = comprador, não é fornecedor)
function acharCnpjs(texto, excluir = []) {
  const ex = new Set(excluir.map(x => String(x || '').replace(/\D/g, ''))), out = [];
  for (const m of String(texto || '').matchAll(/\b(\d{2})[.]?(\d{3})[.]?(\d{3})[\/]?(\d{4})[-]?(\d{2})\b/g)) { const d = m.slice(1).join(''); if (cnpjValido(d) && !ex.has(d) && !out.includes(d)) out.push(d); }
  return out;
}
function cabecalho(texto, chave, excluir = []) {
  const o = { numero: '', serie: '', cnpj: '', data: '' };
  if (chave && /^\d{44}$/.test(chave)) { o.cnpj = chave.slice(6, 20); o.serie = String(Number(chave.slice(22, 25))); o.numero = String(Number(chave.slice(25, 34))); }
  const t = String(texto || '');
  if (!o.numero) { const m = /(?:NFC?-?e|NF-?e|NOTA\s+FISCAL|DANFE)[^\n\d]{0,40}?(?:n[º°o]?\.?\s*:?\s*)(\d[\d.]{2,12})/i.exec(t) || /\bn(?:[º°]\.?|o\.)\s*:?\s*(\d{1,3}(?:\.\d{3})+|\d{3,9})\b/i.exec(t); if (m) o.numero = String(Number(m[1].replace(/\D/g, '')) || ''); }
  if (!o.cnpj) o.cnpj = acharCnpjs(t, excluir)[0] || '';
  if (!o.serie) { const m = /\bs[ée]rie\s*[:.\-\s]{0,6}(\d{1,3})\b/i.exec(t); if (m) o.serie = String(Number(m[1])); }
  const d = /\b(\d{2})\/(\d{2})\/(\d{4})\b/.exec(t); if (d) o.data = `${d[3]}-${d[2]}-${d[1]}`;
  return o;
}

// Totais impressos no rodapé da nota (para conferir se todas as linhas foram lidas)
function rodape(texto) {
  const t = String(texto || ''), o = { total_nota: null, qtd_nota: null };
  const m = /total\s*merc[^\d\n]{0,15}(\d{1,3}(?:[.,]\d{3})*[.,]\d{2})/i.exec(t) || /^\s*total\s*[:.\s]{1,12}(\d{1,3}(?:[.,]\d{3})*[.,]\d{2})\s*$/im.exec(t);
  if (m) { const v = m[1].replace(/[.,](?=\d{3}\b)/g, '').replace(',', '.'); if (parseFloat(v) > 0) o.total_nota = parseFloat(v); }
  const q = /qtd\.?\s*prod\.?[^\d\n]{0,10}(\d{1,7})\b/i.exec(t); if (q) o.qtd_nota = Number(q[1]);
  return o;
}

// ---------- interpretação do texto ----------
const UNS = new Set(['UN', 'UND', 'UNID', 'PC', 'PÇ', 'PCT', 'PT', 'CX', 'FD', 'FARDO', 'KG', 'G', 'GR', 'L', 'LT', 'ML', 'DZ', 'SC', 'PAC', 'GF', 'LA', 'BD', 'TP']);
const IGNORA = /\b(TOTAL|SUBTOTAL|TROCO|ICMS|PIS|COFINS|CNPJ|CPF|CHAVE|PROTOCOLO|FRETE|DESCONTO|PAGAMENTO|EMISS|DANFE|VENCIMENTO|PARCELA|DUPLICATA|TRANSPORTADOR|IMPOSTOS|TRIBUTOS|S[ÉE]RIE|INSCRI)/i;
const numRe = /^\d{1,3}(\.\d{3})*,\d{1,4}$|^\d+,\d{1,4}$|^\d+\.\d{1,4}$|^\d+$/;
const toN = s => { s = String(s).trim(); if (/,/.test(s)) s = s.replace(/\./g, '').replace(',', '.'); return parseFloat(s); };
const r2 = x => Math.round(x * 100) / 100;
const semAcento = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '');

function interpretar(texto) {
  const out = [];
  for (const bruta of String(texto || '').split(/\r?\n/)) {
    const linha = bruta.replace(/[|\[\]{}_~“”"]/g, ' ').replace(/\s+/g, ' ').trim();
    // "Desconto -0,50" logo abaixo de um item: abate do total daquele item (o "Desconto total" do rodapé não conta)
    if (/^desc\w*\s+-?\s*\d/i.test(linha) && !/total/i.test(linha) && out.length) {
      const m = /(\d{1,3}(?:\.\d{3})*,\d{2}|\d+[.,]\d{2})/.exec(linha.replace(/^desc\w*\s+/i, ''));
      if (m) { const it = out[out.length - 1], d = toN(m[1]); if (d > 0 && d < it.total) { it.desconto = r2((it.desconto || 0) + d); it.total = r2(it.total - d); it.valor_unit = Math.round(it.total / it.qtd * 10000) / 10000; } }
      continue;
    }
    if (linha.length < 8 || IGNORA.test(linha)) continue;
    // separa "6,0000/9,9500", tira pontuação solta nas pontas ("12,0000." / "UN:")
    const tk = linha.replace(/(\d)['`´](?=[A-Za-z])/g, '$1 ').replace(/(\d)\/(\d)/g, '$1 $2').split(' ').map(x => x.replace(/^[.:;,'`]+|[.:;'`]+$/g, '')).filter(Boolean);
    const nums = tk.map((t, i) => (numRe.test(t) ? i : -1)).filter(i => i >= 0);
    if (nums.length < 2) continue;
    let q, u, t, ini = -1, conferir = false;
    // 1) três números seguidos em que qtd × unitário = total
    for (let a = 0; a + 2 < nums.length && ini < 0; a++) {
      const [i, j, k] = [nums[a], nums[a + 1], nums[a + 2]];
      if (j !== i + 1 || k !== j + 1) continue;
      const qq = toN(tk[i]), uu = toN(tk[j]), tt = toN(tk[k]);
      if (qq > 0 && uu > 0 && /[,.]/.test(tk[j]) && Math.abs(qq * uu - tt) <= Math.max(0.03, tt * 0.01)) { q = qq; u = uu; t = tt; ini = i; }
    }
    // 2) três números seguidos que quase fecham (OCR errou um dígito): usa quantidade e total e recalcula o unitário — fica marcado "conferir"
    for (let a = 0; a + 2 < nums.length && ini < 0; a++) {
      const [i, j, k] = [nums[a], nums[a + 1], nums[a + 2]];
      if (j !== i + 1 || k !== j + 1 || !/[,.]/.test(tk[j]) || !/[,.]/.test(tk[k])) continue;
      const qq = toN(tk[i]), uu = toN(tk[j]), tt = toN(tk[k]);
      if (qq > 0 && uu > 0 && tt > 0 && Math.abs(qq * uu - tt) <= tt * 0.15) { q = qq; u = tt / qq; t = tt; ini = i; conferir = true; }
    }
    // 3) só unitário e total no fim da linha (quantidade = total ÷ unitário, só se der número inteiro/meio)
    if (ini < 0) {
      const dec = nums.filter(i => /[,.]/.test(tk[i]));
      if (dec.length >= 2) {
        const j = dec[dec.length - 2], k = dec[dec.length - 1]; const uu = toN(tk[j]), tt = toN(tk[k]);
        if (uu > 0 && tt >= uu - 0.005 && k === j + 1) {
          const qq = tt / uu; if (Math.abs(qq - Math.round(qq * 2) / 2) < 0.02) { u = uu; t = tt; q = Math.round(qq * 2) / 2; ini = j; }
        }
      }
    }
    // 4) só o unitário com 4 casas ("4,1000") foi lido; quantidade e total ilegíveis (caneta, rasura, mancha): mantém a linha com quantidade 0 para o operador digitar
    let semQtd = false;
    if (ini < 0) {
      const j = nums.find(i => /^\d{1,4}[.,]\d{4}$/.test(tk[i]) && i >= 2 && toN(tk[i]) > 0);
      if (j !== undefined && tk.slice(0, j).join(' ').replace(/[^A-Za-zÀ-ú]/g, '').length >= 6) { u = toN(tk[j]); q = 0; t = 0; ini = j; semQtd = true; conferir = true; }
    }
    if (ini < 0) continue;
    // descrição = tudo antes dos números, sem códigos fiscais soltos e sem a unidade
    let ds = tk.slice(0, ini);
    let un = '';
    // cupom: "... 1 UN X 24,99 24,99" — o "X" (às vezes lido como K) entre a unidade e o preço não é parte do nome
    if (ds.length > 2 && /^[XxKk×*]$/.test(ds[ds.length - 1]) && UNS.has(semAcento(ds[ds.length - 2]).toUpperCase().replace(/\.$/, ''))) ds.pop();
    while (ds.length && (UNS.has(semAcento(ds[ds.length - 1]).toUpperCase().replace(/\.$/, '')) || /^\d{3,8}$/.test(ds[ds.length - 1]) || /^[0-9]{1,2}[,.]?[0-9]*%?$/.test(ds[ds.length - 1]))) {
      const x = ds.pop(); const up = semAcento(x).toUpperCase().replace(/\.$/, ''); if (UNS.has(up) && !un) un = up;
    }
    let codigo = '';
    if (ds.length > 2 && /^\d{1,3}$/.test(ds[0]) && /^\d{4,14}$/.test(ds[1])) ds.shift();   // cupom: nº do item (001) antes do código
    if (ds.length > 1 && /^\d{4,14}$/.test(ds[0])) codigo = ds.shift();
    if (semQtd) while (ds.length > 1 && !/[A-Za-zÀ-ú]{3}/.test(ds[ds.length - 1])) ds.pop();   // lixo da quantidade rasurada, ex.: "y (280)"
    const desc = ds.join(' ').replace(/^[\d\s.,x*×-]{1,6}(?=[A-Za-zÀ-ú])/, '').trim();
    if ((desc.match(/[A-Za-zÀ-ú]/g) || []).length < 3) continue;
    out.push({ codigo, descricao: desc, un, qtd: Math.round(q * 1000) / 1000, valor_unit: Math.round(u * 10000) / 10000, total: r2(t), conferir, ...(semQtd ? { sem_qtd: true } : {}) });
  }
  return agrupar(out);
}

// Cupom fiscal lista o mesmo produto em várias linhas (uma por unidade bipada): junta as linhas com o mesmo código (ou, sem código,
// com o mesmo nome) em um item só, somando a quantidade e o total.
function agrupar(itens) {
  const g = new Map(), ordem = [];
  for (const it of itens) {
    const k = it.codigo ? 'c:' + it.codigo : 'd:' + semAcento(it.descricao).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
    const a = g.get(k);
    if (!a) { g.set(k, { ...it, linhas: 1 }); ordem.push(k); continue; }
    a.qtd = Math.round((a.qtd + it.qtd) * 1000) / 1000; a.total = r2(a.total + it.total); a.desconto = r2((a.desconto || 0) + (it.desconto || 0)); a.linhas++;
    a.conferir = a.conferir || it.conferir; a.sem_qtd = a.sem_qtd && it.sem_qtd; if (!a.un) a.un = it.un;
  }
  return ordem.map(k => { const a = g.get(k); a.valor_unit = a.qtd > 0 ? Math.round(a.total / a.qtd * 10000) / 10000 : a.valor_unit; if (!a.desconto) delete a.desconto; if (a.linhas === 1) delete a.linhas; return a; });
}

// ---------- casamento com o cadastro de produtos ----------
const norm = s => semAcento(s).toLowerCase().replace(/\b(un|und|unid|pct|cx|kg|g|ml|l|lt|c\/|com)\b/g, ' ').replace(/[^a-z0-9]+/g, ' ').trim();
const toks = s => new Set(norm(s).split(' ').filter(x => x.length > 1));
function similar(a, b) { const A = toks(a), B = toks(b); if (!A.size || !B.size) return 0; let n = 0; A.forEach(x => { if (B.has(x)) n++; }); return 2 * n / (A.size + B.size); }
function casar(itens, produtos) { // produtos: [{id,codigo,nome,codigos_barras:[]}]
  const porCod = new Map(); produtos.forEach(p => { if (p.codigo) porCod.set(String(p.codigo).toLowerCase(), p); (p.codigos_barras || []).forEach(b => porCod.set(String(b), p)); });
  return itens.map(it => {
    let p = it.codigo ? porCod.get(it.codigo.toLowerCase()) : null, conf = p ? 1 : 0;
    if (!p) { let melhor = null, s = 0; for (const x of produtos) { const v = similar(it.descricao, x.nome); if (v > s) { s = v; melhor = x; } } if (melhor && s >= 0.5) { p = melhor; conf = Math.round(s * 100) / 100; } }
    return { ...it, produto_id: p ? p.id : null, produto_nome: p ? p.nome : null, confianca: conf };
  });
}
module.exports = { cnpjValido, acharCnpjs, rodape, cabecalho, agrupar, lerImagem, lerPdf, acharChave, interpretar, casar, acharExe, similar };
