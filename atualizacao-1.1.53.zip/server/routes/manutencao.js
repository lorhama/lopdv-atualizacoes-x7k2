// Manutenção: rotinas em massa — alteração de produtos e fornecedores, importação de tabela de preços e de estoque (arquivos CSV).
const express = require('express');
const db = require('../db');
const { auth, auditar, can } = require('../auth');
const { HttpError, wrap, num, r2, cpfValido } = require('../util');
const est = require('../estoque_lib');
const r = express.Router();
const base = auth('manutencao.acessar');
const exige = (req, perm, msg) => { if (!can(req.user, perm)) throw new HttpError(403, msg); };
const MAX = 20000;
const Q = (c, sql, p) => (c.q ? c.q(sql, p) : c.query(sql, p));   // db (pool) ou cliente de transação

// "000123" e "123" são o mesmo código reduzido; texto fica em maiúsculas
const chaveCod = s => { const t = String(s ?? '').trim(); return /^\d+$/.test(t) ? String(Number(t)) : t.toUpperCase(); };
const soDig = s => String(s ?? '').replace(/\D/g, '');
const numero = v => { // aceita 12,50 | 12.50 | 1.234,50 | R$ 1.234,50
  let t = String(v ?? '').replace(/[R$\s]/gi, ''); if (!t) return NaN;
  if (/,/.test(t)) t = t.replace(/\./g, '').replace(',', '.');
  return /^-?\d+(\.\d+)?$/.test(t) ? Number(t) : NaN;
};
const ids = v => [...new Set((Array.isArray(v) ? v : []).map(Number).filter(n => Number.isInteger(n) && n > 0))].slice(0, MAX);

// ---------- Alteração em massa: produtos ----------
r.post('/produtos-massa', base, wrap(async (req, res) => {
  exige(req, 'cadastros.editar', 'Você não tem permissão para editar cadastros.');
  const b = req.body || {}, lista = ids(b.ids), a = b.alteracoes || {}, sets = [], par = [];
  if (!lista.length) throw new HttpError(400, 'Selecione ao menos um produto.');
  const add = (col, val) => { par.push(val); sets.push(`${col}=$${par.length}`); };
  if (a.categoria_id !== undefined && a.categoria_id !== null) {
    if (a.categoria_id === '' || a.categoria_id === 0) add('categoria_id', null);
    else { if (!(await db.q('select 1 from categorias where id=$1', [Number(a.categoria_id)])).rowCount) throw new HttpError(400, 'Categoria não encontrada.'); add('categoria_id', Number(a.categoria_id)); }
  }
  if (a.destino !== undefined) { if (!['cozinha', 'bar', 'brincadeira', 'nenhum'].includes(a.destino)) throw new HttpError(400, 'Destino inválido.'); add('destino', a.destino); }
  if (a.estoque_minimo !== undefined) { const n = numero(a.estoque_minimo); if (!(n >= 0)) throw new HttpError(400, 'Estoque mínimo inválido.'); add('estoque_minimo', n); }
  if (a.ativo !== undefined) add('ativo', !!a.ativo);
  if (a.vendavel !== undefined) { par.push(!!a.vendavel); sets.push(`vendavel=($${par.length}::boolean and not suspenso)`); }
  if (a.preco) {
    const v = numero(a.preco.valor), modo = a.preco.modo;
    if (!['valor', 'aumentar', 'reduzir'].includes(modo) || !Number.isFinite(v) || v < 0) throw new HttpError(400, 'Informe o preço ou o percentual corretamente.');
    if (modo === 'valor') add('preco_venda', r2(v));
    else { if (modo === 'reduzir' && v > 100) throw new HttpError(400, 'A redução não pode passar de 100%.'); par.push(modo === 'aumentar' ? 1 + v / 100 : 1 - v / 100); sets.push(`preco_venda=round(preco_venda * $${par.length}::numeric, 2)`); }
  }
  if (!sets.length) throw new HttpError(400, 'Escolha ao menos uma alteração.');
  par.push(lista);
  const out = await db.tx(async c => {
    // produto com cadastro pendente (automático) não pode ficar vendável: a confirmação é feita na Entrada de mercadoria
    const x = await c.query(`update produtos set ${sets.join(', ')} where id = any($${par.length}) returning id`, par);
    await auditar(c, req.user, 'manutencao_produtos_massa', { qtd: x.rowCount, alteracoes: a });
    return { alterados: x.rowCount };
  });
  res.json(out);
}));

// ---------- Alteração em massa: fornecedores ----------
r.post('/fornecedores-massa', base, wrap(async (req, res) => {
  exige(req, 'cadastros.editar', 'Você não tem permissão para editar cadastros.');
  const b = req.body || {}, lista = ids(b.ids), a = b.alteracoes || {}, sets = [], par = [];
  if (!lista.length) throw new HttpError(400, 'Selecione ao menos um fornecedor.');
  const add = (col, val) => { par.push(val); sets.push(`${col}=$${par.length}`); };
  if (a.ativo !== undefined) add('ativo', !!a.ativo);
  for (const [k, max] of [['condicao_pagamento', 120], ['cidade', 80], ['observacao', 300]]) if (a[k] !== undefined) add(k, String(a[k]).trim().slice(0, max) || null);
  if (a.uf !== undefined) { const u = String(a.uf).trim().toUpperCase(); if (u && !/^[A-Z]{2}$/.test(u)) throw new HttpError(400, 'UF inválida (use 2 letras).'); add('uf', u || null); }
  if (!sets.length) throw new HttpError(400, 'Escolha ao menos uma alteração.');
  par.push(lista);
  const out = await db.tx(async c => {
    const x = await c.query(`update fornecedores set ${sets.join(', ')} where id = any($${par.length}) returning id`, par);
    await auditar(c, req.user, 'manutencao_fornecedores_massa', { qtd: x.rowCount, alteracoes: a });
    return { alterados: x.rowCount };
  });
  res.json(out);
}));

// ---------- Importação da tabela de preços (código reduzido + preço) ----------
async function analisarPrecos(linhasIn, c = db) {
  const linhas = (Array.isArray(linhasIn) ? linhasIn : []).slice(0, MAX);
  const prods = (await Q(c, 'select id, codigo, nome, preco_venda, suspenso from produtos')).rows, mapa = new Map(prods.map(p => [chaveCod(p.codigo), p]));
  const vistos = new Map(), out = [];
  linhas.forEach((l, i) => {
    const cod = String(l.codigo ?? '').trim(), n = numero(l.preco), item = { linha: Number(l.linha) || i + 2, codigo: cod, preco_arquivo: String(l.preco ?? '') };
    if (!cod) return out.push({ ...item, status: 'erro', motivo: 'Código reduzido em branco' });
    const p = mapa.get(chaveCod(cod));
    if (!p) return out.push({ ...item, status: 'erro', motivo: 'Código não encontrado no cadastro' });
    if (!(n >= 0)) return out.push({ ...item, produto_id: p.id, produto: p.nome, status: 'erro', motivo: 'Preço inválido' });
    if (vistos.has(p.id)) return out.push({ ...item, produto_id: p.id, produto: p.nome, status: 'erro', motivo: 'Código repetido no arquivo (linha ' + vistos.get(p.id) + ')' });
    vistos.set(p.id, item.linha);
    const novo = r2(n), antes = Number(p.preco_venda);
    out.push({ ...item, produto_id: p.id, produto: p.nome, antes, depois: novo, status: Math.abs(novo - antes) < 0.005 ? 'igual' : 'ok', pendente: !!p.suspenso });
  });
  // cadastrados no sistema (com código reduzido) que NÃO vieram no arquivo
  const fora = prods.filter(p => !p.suspenso && !vistos.has(p.id)).map(p => ({ codigo: p.codigo, produto: p.nome, valor: Number(p.preco_venda) }));
  return { linhas: out, fora };
}
r.post('/precos/previa', base, wrap(async (req, res) => {
  exige(req, 'cadastros.editar', 'Você não tem permissão para editar cadastros.');
  const { linhas: l, fora } = await analisarPrecos((req.body || {}).linhas);
  res.json({ linhas: l, fora, resumo: { total: l.length, aplicar: l.filter(x => x.status === 'ok').length, iguais: l.filter(x => x.status === 'igual').length, erros: l.filter(x => x.status === 'erro').length } });
}));
r.post('/precos/aplicar', base, wrap(async (req, res) => {
  exige(req, 'cadastros.editar', 'Você não tem permissão para editar cadastros.');
  const out = await db.tx(async c => {
    const an = await analisarPrecos((req.body || {}).linhas, c), l = an.linhas.filter(x => x.status === 'ok');
    for (const x of l) await c.query('update produtos set preco_venda=$1 where id=$2', [x.depois, x.produto_id]);
    await auditar(c, req.user, 'manutencao_importar_precos', { alterados: l.length, nao_importadas: an.linhas.filter(x => x.status === 'erro').length, amostra: l.slice(0, 20).map(x => ({ id: x.produto_id, de: x.antes, para: x.depois })) });
    return { alterados: l.length, linhas: an.linhas.map(x => (x.status === 'ok' ? { ...x, status: 'importado' } : x)), fora: an.fora };
  });
  res.json(out);
}));

// ---------- Importação de estoque (código de barras + quantidade contada) ----------
async function analisarEstoque(linhasIn, c = db) {
  const linhas = (Array.isArray(linhasIn) ? linhasIn : []).slice(0, MAX);
  const mapa = new Map();
  for (const x of (await Q(c, `select b.codigo_barras cb, p.id, p.codigo, p.nome, p.estoque_atual, p.controla_estoque, p.unidade from produto_codigos_barras b join produtos p on p.codigo=b.produto_codigo`)).rows) mapa.set(soDig(x.cb), x);
  for (const x of (await Q(c, `select codigo_barras cb, id, codigo, nome, estoque_atual, controla_estoque, unidade from produtos where coalesce(codigo_barras,'')<>''`)).rows) if (!mapa.has(soDig(x.cb))) mapa.set(soDig(x.cb), x);
  const todos = (await Q(c, 'select id, codigo, nome, estoque_atual, controla_estoque, unidade from produtos where not suspenso')).rows, porCodigo = new Map(todos.map(p => [chaveCod(p.codigo), p]));
  const porCb = new Map(), porProd = new Map(), out = [];
  linhas.forEach((l, i) => {
    const cb = soDig(l.codigo_barras), n = numero(l.estoque), cr = String(l.codigo_reduzido ?? '').trim(), item = { linha: Number(l.linha) || i + 2, codigo_barras: String(l.codigo_barras ?? '').trim(), codigo: cr, estoque_arquivo: String(l.estoque ?? '') };
    if (/^\s*\d+([.,]\d+)?e[+-]?\d+\s*$/i.test(item.codigo_barras)) return out.push({ ...item, status: 'erro', motivo: 'Código de barras em notação científica (Excel). Formate a coluna como Texto e preencha de novo' });
    if (!cb && !cr) return out.push({ ...item, status: 'erro', motivo: 'Código de barras em branco' });
    const p = (cb ? mapa.get(cb) : null) || (cr ? porCodigo.get(chaveCod(cr)) : null);   // sem código de barras no arquivo (ou não achado), vale o código reduzido
    if (!p) return out.push({ ...item, status: 'erro', motivo: cb ? 'Código de barras não encontrado no cadastro' : 'Código reduzido não encontrado no cadastro' });
    const base = { ...item, produto_id: p.id, produto: p.nome, unidade: p.unidade };
    if (!(n >= 0)) return out.push({ ...base, status: 'erro', motivo: 'Quantidade inválida (use número zero ou maior)' });
    if (!p.controla_estoque) return out.push({ ...base, status: 'erro', motivo: 'Produto não controla estoque' });
    if (cb && porCb.has(cb)) return out.push({ ...base, status: 'erro', motivo: 'Código de barras repetido no arquivo (linha ' + porCb.get(cb) + ')' });
    if (cb) porCb.set(cb, item.linha);
    if (porProd.has(p.id)) return out.push({ ...base, status: 'erro', motivo: 'Outro código de barras do mesmo produto já está na linha ' + porProd.get(p.id) });
    porProd.set(p.id, item.linha);
    const novo = Math.round(n * 1000) / 1000, antes = Number(p.estoque_atual), dif = Math.round((novo - antes) * 1000) / 1000;
    out.push({ ...base, antes, depois: novo, diferenca: dif, status: Math.abs(dif) < 0.0005 ? 'igual' : 'ok' });
  });
  // produtos que controlam estoque e NÃO vieram no arquivo (ficam como estão)
  const fora = todos.filter(p => p.controla_estoque && !porProd.has(p.id)).map(p => ({ codigo: p.codigo, produto: p.nome, valor: Number(p.estoque_atual), unidade: p.unidade }));
  return { linhas: out, fora };
}
const semBalanco = async () => { if ((await db.q("select 1 from balancos where status='andamento' limit 1")).rowCount) throw new HttpError(400, 'Existe um balanço de estoque em andamento. Finalize ou cancele o balanço antes de importar estoque.'); };
r.post('/estoque/previa', base, wrap(async (req, res) => {
  exige(req, 'estoque.ajuste', 'Você não tem permissão para ajustar estoque.');
  const { linhas: l, fora } = await analisarEstoque((req.body || {}).linhas);
  res.json({ linhas: l, fora, resumo: { total: l.length, aplicar: l.filter(x => x.status === 'ok').length, iguais: l.filter(x => x.status === 'igual').length, erros: l.filter(x => x.status === 'erro').length } });
}));
r.post('/estoque/aplicar', base, wrap(async (req, res) => {
  exige(req, 'estoque.ajuste', 'Você não tem permissão para ajustar estoque.');
  await semBalanco();
  const motivo = String((req.body || {}).motivo || '').trim().slice(0, 200) || 'Importação de estoque (arquivo)';
  const out = await db.tx(async c => {
    const an = await analisarEstoque((req.body || {}).linhas, c), l = an.linhas.filter(x => x.status === 'ok');
    for (const x of l) {
      const p = (await c.query('select * from produtos where id=$1 for update', [x.produto_id])).rows[0];
      const antes = Number(p.estoque_atual), delta = Math.round((x.depois - antes) * 1000) / 1000;
      if (Math.abs(delta) < 0.0005) continue;
      const aj = (await c.query(`insert into ajustes_estoque(produto_codigo, estoque_sistema, estoque_informado, diferenca, custo_unit, motivo, usuario_id)
        values($1,$2,$3,$4,$5,$6,$7) returning id`, [p.codigo, antes, x.depois, delta, p.custo_medio, motivo, req.user.id])).rows[0];
      await est.mover(c, { produto_id: p.id, tipo: 'ajuste', quantidade: delta, custo_unit: p.custo_medio, origem: 'ajuste_avulso', ref_id: aj.id, motivo, usuario_id: req.user.id });
    }
    let zerados = 0;
    if ((req.body || {}).zerar === true) {   // opção: zera o estoque dos produtos que não vieram no arquivo
      for (const f of an.fora) {
        const p = (await c.query('select * from produtos where codigo=$1 and controla_estoque for update', [f.codigo])).rows[0];
        if (!p) continue;
        const antes = Number(p.estoque_atual), delta = Math.round(-antes * 1000) / 1000;
        if (Math.abs(delta) < 0.0005) continue;
        const mt = motivo + ' - não estava no arquivo (zerado)';
        const aj = (await c.query(`insert into ajustes_estoque(produto_codigo, estoque_sistema, estoque_informado, diferenca, custo_unit, motivo, usuario_id)
          values($1,$2,0,$3,$4,$5,$6) returning id`, [p.codigo, antes, delta, p.custo_medio, mt, req.user.id])).rows[0];
        await est.mover(c, { produto_id: p.id, tipo: 'ajuste', quantidade: delta, custo_unit: p.custo_medio, origem: 'ajuste_avulso', ref_id: aj.id, motivo: mt, usuario_id: req.user.id });
        zerados++;
      }
    }
    await auditar(c, req.user, 'manutencao_importar_estoque', { alterados: l.length, zerados, zerou_nao_listados: (req.body || {}).zerar === true, nao_importadas: an.linhas.filter(x => x.status === 'erro').length, motivo });
    return { zerados, alterados: l.length, linhas: an.linhas.map(x => (x.status === 'ok' ? { ...x, status: 'importado' } : x)), fora: an.fora };
  });
  res.json(out);
}));

// ---------- Importação de equipe (usuários) ----------
const semAc = t => String(t ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
const lerAtivo = v => { const t = semAc(v); if (!t) return undefined; if (['sim', 's', '1', 'true', 'ativo', 'a', 'x'].includes(t)) return true; if (['nao', 'n', '0', 'false', 'inativo', 'i'].includes(t)) return false; return null; };
async function analisarEquipe(linhasIn, c = db, eu = null) {
  const linhas = (Array.isArray(linhasIn) ? linhasIn : []).slice(0, MAX);
  const perfis = (await Q(c, 'select id, nome from perfis')).rows, pPorNome = new Map(perfis.map(p => [semAc(p.nome), p]));
  const us = (await Q(c, 'select id, codigo, nome, login, email, ativo, perfil_id, telefone, cargo, cpf from usuarios')).rows;
  const porLogin = new Map(us.map(u => [String(u.login).toLowerCase(), u])), porCpf = new Map(us.filter(u => u.cpf).map(u => [u.cpf, u])), cpfsArq = new Set(), porNome = new Map(), vistos = new Set(), tocados = new Set(), out = [];
  us.forEach(u => { const k = semAc(u.nome); porNome.set(k, porNome.has(k) ? null : u); });
  linhas.forEach((l, i) => {
    const t = k => String(l[k] ?? '').trim();
    const item = { linha: Number(l.linha) || i + 2, nome: t('nome'), login: t('login'), perfil: t('perfil'), cpf: t('cpf').replace(/\D/g, ''), cpf_arquivo: t('cpf'), cargo: t('cargo'), telefone: t('telefone'), email: t('email').toLowerCase(), ativo_arquivo: t('ativo'), tem_senha: !!String(l.senha ?? '') };
    const erro = m => out.push({ ...item, status: 'erro', motivo: m });
    if (!item.nome) return erro('Nome em branco');
    if (item.email && !/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(item.email)) return erro('E-mail inválido');
    if (item.cpf && !cpfValido(item.cpf)) return erro('CPF inválido');
    if (l.senha && String(l.senha).length < 4) return erro('Senha com menos de 4 caracteres');
    let perfil = null; if (item.perfil) { perfil = pPorNome.get(semAc(item.perfil)); if (!perfil) return erro('Perfil não encontrado: ' + item.perfil); }
    const at = lerAtivo(item.ativo_arquivo); if (at === null) return erro('Ativo deve ser sim ou não');
    let ex = item.login ? porLogin.get(item.login.toLowerCase()) : (item.cpf && porCpf.get(item.cpf)) || porNome.get(semAc(item.nome));
    if (!item.login && !(item.cpf && porCpf.get(item.cpf)) && ex === null) return erro('Há mais de um usuário com esse nome: informe o login');
    const chave = ex ? 'u' + ex.id : 'n:' + semAc(item.login || item.nome);
    if (vistos.has(chave)) return erro('Usuário repetido no arquivo');
    vistos.add(chave);
    if (item.cpf) { if (cpfsArq.has(item.cpf)) return erro('CPF repetido no arquivo'); cpfsArq.add(item.cpf); const dono = porCpf.get(item.cpf); if (dono && (!ex || dono.id !== ex.id)) return erro('Esse CPF já pertence a outro usuário: ' + dono.nome); }
    if (!ex) {
      if (item.login && /\s/.test(item.login)) return erro('Login não pode ter espaços');
      return out.push({ ...item, novo: true, status: 'ok', perfil_id: perfil ? perfil.id : null, ativo: at === undefined ? true : at, senha: l.senha ? String(l.senha) : '', aviso: l.senha ? '' : 'senha padrão 1234', login_final: item.login || '(automático)' });
    }
    tocados.add(ex.id);
    if (at === false && eu && ex.id === eu) return erro('Você não pode desativar o próprio usuário');
    const ch = []; const dep = {};
    if (item.nome && item.nome !== ex.nome) { ch.push('nome'); dep.nome = item.nome; }
    if (item.cpf && item.cpf !== (ex.cpf || '')) { ch.push('CPF'); dep.cpf = item.cpf; }
    if (perfil && perfil.id !== ex.perfil_id) { ch.push('perfil'); dep.perfil_id = perfil.id; }
    if (item.cargo && item.cargo !== (ex.cargo || '')) { ch.push('cargo'); dep.cargo = item.cargo; }
    if (item.telefone && item.telefone !== (ex.telefone || '')) { ch.push('telefone'); dep.telefone = item.telefone; }
    if (item.email && item.email !== (ex.email || '')) { ch.push('e-mail'); dep.email = item.email; }
    if (at !== undefined && at !== ex.ativo) { ch.push(at ? 'ativar' : 'desativar'); dep.ativo = at; }
    if (l.senha) { ch.push('senha'); dep.senha = String(l.senha); }
    out.push({ ...item, usuario_id: ex.id, login_final: ex.login, codigo: ex.codigo, status: ch.length ? 'ok' : 'igual', mudancas: ch.join(', '), dep });
  });
  const fora = us.filter(u => !tocados.has(u.id)).map(u => ({ codigo: u.codigo, produto: u.nome, valor: u.login, ativo: u.ativo }));
  return { linhas: out, fora };
}
const equipeBase = (req) => exige(req, 'equipe.gerenciar', 'Você não tem permissão para gerenciar a equipe.');
r.post('/equipe/previa', base, wrap(async (req, res) => {
  equipeBase(req);
  const { linhas: l, fora } = await analisarEquipe((req.body || {}).linhas, db, req.user.id);
  res.json({ linhas: l.map(x => ({ ...x, dep: undefined, senha: undefined })), fora, resumo: { total: l.length, aplicar: l.filter(x => x.status === 'ok').length, iguais: l.filter(x => x.status === 'igual').length, erros: l.filter(x => x.status === 'erro').length, novos: l.filter(x => x.novo).length } });
}));
r.post('/equipe/aplicar', base, wrap(async (req, res) => {
  equipeBase(req);
  const { bcrypt } = require('../auth');
  const out = await db.tx(async c => {
    const an = await analisarEquipe((req.body || {}).linhas, c, req.user.id), l = an.linhas.filter(x => x.status === 'ok');
    let novos = 0, alterados = 0;
    for (const x of l) {
      if (x.novo) {
        const hash = bcrypt.hashSync(x.senha || '1234', 10);   // sem senha no arquivo: senha padrão 1234 (só para usuário NOVO; quem já existe mantém a senha)
        const ins = (await c.query('insert into usuarios(nome,login,senha_hash,perfil_id,telefone,cargo,ativo,email,cpf,pode_fiado) values($1,$2,$3,$4,$5,$6,$7,$8,$9,true) returning id, codigo',
          [x.nome, x.login || 'tmp' + require('crypto').randomBytes(6).toString('hex'), hash, x.perfil_id, x.telefone || null, x.cargo || null, x.ativo, x.email || null, x.cpf || null])).rows[0];
        if (!x.login) { const ja = (await c.query('select 1 from usuarios where lower(login)=$1 and id<>$2', [String(ins.codigo), ins.id])).rowCount; await c.query('update usuarios set login=$1 where id=$2', [ja ? 'u' + ins.codigo : String(ins.codigo), ins.id]); }
        x.login_final = x.login || String(ins.codigo); x.uid = ins.id; novos++;
      } else {
        const d = x.dep, sets = [], par = [], add = (col, v) => { par.push(v); sets.push(`${col}=$${par.length}`); };
        if (d.nome !== undefined) add('nome', d.nome); if (d.perfil_id !== undefined) add('perfil_id', d.perfil_id); if (d.cargo !== undefined) add('cargo', d.cargo);
        if (d.telefone !== undefined) add('telefone', d.telefone); if (d.email !== undefined) add('email', d.email); if (d.cpf !== undefined) add('cpf', d.cpf); if (d.ativo !== undefined) add('ativo', d.ativo);
        if (d.senha !== undefined) add('senha_hash', bcrypt.hashSync(d.senha, 10));
        par.push(x.usuario_id); await c.query(`update usuarios set ${sets.join(', ')} where id=$${par.length}`, par);
        if (d.senha !== undefined || d.ativo === false) await c.query('delete from sessoes where usuario_id=$1', [x.usuario_id]);
        alterados++;
      }
    }
    // a equipe nova entra com "pode retirar no crediário" ligado e vira cliente (retira consumo e paga no final); quem já existia mantém a sua opção
    let clientesNovos = 0;
    const fe = require('../fiado_equipe');
    for (const x of l) {
      const uid = x.novo ? x.uid : x.usuario_id;
      const antes = (await c.query('select 1 from clientes where usuario_id=$1', [uid])).rowCount;
      await fe.sincronizar(c, uid);
      if (!antes && (await c.query('select 1 from clientes where usuario_id=$1', [uid])).rowCount) clientesNovos++;
    }
    await auditar(c, req.user, 'manutencao_importar_equipe', { clientes_novos: clientesNovos, novos, alterados, nao_importadas: an.linhas.filter(x => x.status === 'erro').length, amostra: l.slice(0, 20).map(x => ({ nome: x.nome, login: x.login_final, novo: !!x.novo, mudancas: x.mudancas || null })) });
    return { alterados: novos + alterados, novos, clientes_novos: clientesNovos, linhas: an.linhas.map(x => ({ ...x, dep: undefined, senha: undefined, status: x.status === 'ok' ? 'importado' : x.status })), fora: an.fora };
  });
  res.json(out);
}));

module.exports = r;
