// Painel inicial, equipe (usuários e perfis), impressoras, configurações e auditoria.
registrar({ id: 'usuarios', titulo: 'Usuários', grupo: 'Equipe', perm: 'equipe.gerenciar', render: async el => {
  const [us, perfis] = await Promise.all([api('/usuarios'), api('/perfis')]);
  const campos = reg => [{ k: 'codigo', l: 'Código do usuário (automático)', ro: true, ph: 'Gerado ao gravar' }, { k: 'nome', l: 'Nome', req: true }, { k: 'login', l: 'Login (usuário)', req: true }, { k: 'senha', l: reg ? 'Nova senha (deixe vazio para manter)' : 'Senha (mín. 4)', t: 'password', req: !reg }, { k: 'perfil_id', l: 'Perfil de acesso', t: 'select', op: perfis.map(p => [p.id, p.nome]) },
    { k: 'cpf', l: 'CPF', ph: '000.000.000-00' }, { k: 'cargo', l: 'Cargo / função' }, { k: 'telefone', l: 'Telefone' }, { k: 'email', l: 'E-mail (usado para recuperar a senha)', ph: 'nome@email.com' }, { k: 'pode_fiado', l: 'Pode retirar no crediário (paga no final)', t: 'check', padrao: false }, { k: 'ativo', l: 'Ativo', t: 'check', padrao: true }];
  const abrir = reg => formModal({ titulo: reg ? 'Editar usuário' : 'Novo usuário', campos: campos(reg), valores: reg ? { ...reg, cpf: mascaraDoc(reg.cpf) } : {}, tam: 'md',
    onSave: async o => { if (reg && !o.senha) delete o.senha; await api('/usuarios' + (reg ? '/' + reg.id : ''), { method: reg ? 'PUT' : 'POST', body: o }); toast('Salvo.'); rotear(); } });
  el.innerHTML = `<div class="bar"><div class="grow"></div><button class="btn primary" id="novo">+ Novo usuário</button></div>` +
    tabela([{ l: 'Código', f: u => String(u.codigo || '') }, { l: 'Nome', k: 'nome' }, { l: 'Login', k: 'login' }, { l: 'Perfil', k: 'perfil' }, { l: 'Cargo', k: 'cargo' }, { l: 'Situação', f: u => chip(u.ativo ? 'ativo' : 'inativo', u.ativo ? 'ok' : 'cancelado') }], us, { acoes: u => `<button class="btn sm" data-ed="${u.id}">Editar</button> ` + (u.id === S.user.id ? '' : `<button class="btn sm ${u.ativo ? 'danger' : 'primary'}" data-at="${u.id}">${u.ativo ? 'Inativar' : 'Ativar'}</button>`) });
  $('#novo', el).onclick = () => abrir(null);
  el.onclick = seguro(async e => {
    if (e.target.dataset.ed) abrir(us.find(u => u.id == e.target.dataset.ed));
    const at = e.target.dataset.at; if (at) { const u = us.find(x => x.id == at);
      if (!await confirmar(u.ativo ? `Inativar ${u.nome}? Ele perde o acesso ao sistema na hora, mas o histórico dele (vendas, caixas, movimentações) continua nos relatórios. Você pode reativar quando quiser.` : `Reativar ${u.nome}? Ele volta a poder entrar no sistema.`)) return;
      await api('/usuarios/' + at, { method: 'PUT', body: { nome: u.nome, login: u.login, perfil_id: u.perfil_id, telefone: u.telefone, cargo: u.cargo, ativo: !u.ativo } }); toast(u.ativo ? 'Colaborador inativado.' : 'Colaborador reativado.'); rotear(); }
  });
} });

registrar({ id: 'perfis', titulo: 'Perfis e permissões', grupo: 'Equipe', perm: 'equipe.gerenciar', render: async el => {
  const [perfis, grupos, usuarios] = await Promise.all([api('/perfis'), api('/permissoes'), api('/usuarios')]);
  const abrir = reg => {
    const sel = new Set(reg?.permissoes || []); const adm = sel.has('*');
    const corpo = `<label>Nome do perfil<input id="pn" value="${esc(reg?.nome || '')}" ${adm ? 'disabled' : ''}></label>${adm ? '<p class="muted">Administrador tem acesso total e não pode ser alterado.</p>' : ''}
      <div class="perm-g"><h4>Usuários nesta função</h4><input id="pu-f" placeholder="Filtrar usuários..." style="margin-bottom:6px"><div id="pu" style="max-height:170px;overflow:auto">${usuarios.map(u => `<label class="chk" data-n="${esc(u.nome.toLowerCase())}"><input type="checkbox" data-u="${u.id}" ${reg && u.perfil_id === reg.id ? 'checked' : ''} ${adm ? 'disabled' : ''}> ${esc(u.nome)}${u.perfil && !(reg && u.perfil_id === reg.id) ? ` <small class="muted">(hoje: ${esc(u.perfil)})</small>` : ''}</label>`).join('') || '<span class="muted">Nenhum usuário cadastrado.</span>'}</div><p class="muted" style="margin:6px 0 0">Marque quem exerce esta função. Quem estiver em outra função passa para esta; quem for desmarcado fica sem função até ser vinculado a outra.</p></div>
      ${grupos.map(g => `<div class="perm-g"><h4>${esc(g.grupo)}</h4>${g.itens.map(i => `<label class="chk"><input type="checkbox" data-p="${i[0]}" ${sel.has(i[0]) || adm ? 'checked' : ''} ${adm ? 'disabled' : ''}> ${esc(i[1])}</label>`).join('')}</div>`).join('')}`;
    const mm = modal({ titulo: reg ? 'Perfil / função: ' + reg.nome : 'Novo perfil / função', tam: 'md', corpo, botoes: [{ txt: 'Cancelar' }].concat(adm ? [] : [{ txt: 'Salvar', cls: 'primary', fn: async m => {
      const o = { nome: $('#pn', m.body).value.trim(), permissoes: $$('[data-p]', m.body).filter(c => c.checked).map(c => c.dataset.p), usuarios: $$('[data-u]', m.body).filter(c => c.checked).map(c => +c.dataset.u) };
      if (!o.nome) throw new Error('Informe o nome do perfil.');
      await api('/perfis' + (reg ? '/' + reg.id : ''), { method: reg ? 'PUT' : 'POST', body: o }); toast('Perfil salvo.'); rotear(); } }]) });
    const ff = $('#pu-f', mm.body); if (ff) ff.oninput = () => { const t = ff.value.toLowerCase(); $$('#pu label', mm.body).forEach(l => l.classList.toggle('hidden', !!t && !l.dataset.n.includes(t))); };
  };
  el.innerHTML = `<div class="bar"><p class="muted" style="margin:0">Cada perfil define quais telas o usuário acessa e quais funções pode usar dentro delas (descontos, cancelamentos, estoque negativo, fechar caixa...).</p><div class="grow"></div><button class="btn primary" id="novo">+ Novo perfil</button></div>` +
    tabela([{ l: 'Perfil', k: 'nome' }, { l: 'Permissões', n: 1, f: p => (p.permissoes.includes('*') ? 'Acesso total' : p.permissoes.length + ' permissões') }, { l: 'Usuários', n: 1, f: p => usuarios.filter(u => u.perfil_id === p.id).length }], perfis, { acoes: p => `<button class="btn sm" data-ed="${p.id}">${p.permissoes.includes('*') ? 'Ver' : 'Editar'}</button>${p.permissoes.includes('*') ? '' : ` <button class="btn sm danger" data-ex="${p.id}">Excluir</button>`}` });
  $('#novo', el).onclick = () => abrir(null);
  el.onclick = seguro(async e => {
    if (e.target.dataset.ed) abrir(perfis.find(p => p.id == e.target.dataset.ed));
    if (e.target.dataset.ex && await confirmar('Excluir este perfil? (usuários que o usam ficarão sem acesso)')) { await api('/perfis/' + e.target.dataset.ex, { method: 'DELETE' }); rotear(); }
  });
} });

registrar({ id: 'config', titulo: 'Impressoras e configurações', grupo: 'Sistema', perm: 'config.gerenciar', render: async el => {
  const [imp, rede, bk, ver] = await Promise.all([api('/impressoras'), api('/rede').catch(() => ({ enderecos: [] })), api('/backups').catch(() => ({ arquivos: [], pasta: '' })), api('/versao').catch(() => ({ versao: S.versao, historico: [] }))]);
  if (el._upd) el.removeEventListener('click', el._upd);
  el._upd = seguro(async e => {
    if (e.target.id === 'upchk') { const r = await api('/atualizacao/verificar', { method: 'POST' }); toast(r.ok ? (r.nova ? 'Versão ' + r.nova + ' disponível!' : 'Você já está na versão mais recente.') : r.erro, r.ok ? 'ok' : 'erro'); if (r.ok) { rotear(); checarAtualizacao(); } }
    if (e.target.id === 'uplog') verLogAtualizacao();
    if (e.target.id === 'upgo') { const s = await api('/atualizacao'); if (s.disponivel) confirmarAtualizacao(s); }
  }); el.addEventListener('click', el._upd);
  const abrir = async reg => {
    toast('Procurando as impressoras instaladas no Windows...');
    const w = await api('/impressoras/windows').catch(e => ({ ok: false, erro: e.message, impressoras: [] }));
    const nomes = w.impressoras.map(x => x.nome); if (reg && reg.windows_nome && !nomes.includes(reg.windows_nome)) nomes.unshift(reg.windows_nome);
    const campos = [{ k: 'nome', l: 'Nome', req: true, ph: 'Ex.: Impressora da cozinha' },
      { k: 'destino', l: 'Imprime pedidos de', t: 'select', op: [['cozinha', 'Cozinha'], ['bar', 'Bar'], ['brincadeira', 'Brincadeiras (pescaria etc.)'], ['caixa', 'Caixa (conta e comprovantes)'], ['todos', 'Todos os setores (cozinha, bar e caixa)']] },
      { k: 'conexao', l: 'Como a impressora está ligada', t: 'select', op: [['rede', 'Impressora de rede (por IP)'], ['windows', 'Impressora instalada no Windows']], full: true },
      { k: 'windows_nome', l: 'Impressora do Windows', t: 'select', op: [['', nomes.length ? '— escolha —' : 'Nenhuma impressora encontrada']].concat(nomes.map(n => [n, n + (w.impressoras.find(x => x.nome === n)?.padrao ? ' (padrão do Windows)' : '') + (w.impressoras.find(x => x.nome === n)?.virtual ? ' ⚠ VIRTUAL: salva em arquivo, não imprime' : '')])), full: true },
      { k: 'ip', l: 'Endereço IP da impressora', ph: '192.168.0.50' }, { k: 'porta', l: 'Porta', t: 'number', padrao: 9100 }, { k: 'papel', l: 'Bobina (largura do papel)', t: 'select', op: [['80', '80 mm — cupom fiscal padrão'], ['58', '58 mm — bobina de máquina de cartão']] }, { k: 'colunas', l: 'Colunas por linha (80 mm = 42 ou 48 · 58 mm = 32)', t: 'number', padrao: 42 }, { k: 'economia', l: 'Economizar papel (sem linhas em branco sobrando e pedido mais compacto)', t: 'check', padrao: true, full: true }, { k: 'ativo', l: 'Ativa', t: 'check', padrao: true }];
    const m = formModal({ titulo: reg ? 'Editar impressora' : 'Nova impressora', campos, valores: reg || { porta: 9100, colunas: 42, conexao: 'rede', destino: 'cozinha', papel: '80', economia: true },
      extra: `<p class="muted" id="wmsg">${w.ok ? (nomes.length ? 'Impressoras instaladas neste computador (servidor) listadas acima. Para térmicas, prefira o driver da própria impressora ou "Generic / Text Only"; a comanda é enviada direto para ela.' : 'O Windows não listou nenhuma impressora. Instale a impressora no Windows e abra esta tela de novo.') : '<span class="erro">Não foi possível listar as impressoras do Windows: ' + esc(w.erro || '') + '</span>'}<br><b>Todos os setores</b>: esta impressora imprime cozinha, bar e caixa. Se também houver uma impressora só da cozinha (ou do bar), o setor usa a específica e esta fica com o resto.</p>`,
      onSave: async o => { await api('/impressoras' + (reg ? '/' + reg.id : ''), { method: reg ? 'PUT' : 'POST', body: o }); toast('Salvo.'); rotear(); } });
    const cmp = k => $(`[data-k=${k}]`, m.body)?.closest('label');
    const ajusta = () => { const win = $('[data-k=conexao]', m.body).value === 'windows';
      ['windows_nome'].forEach(k => cmp(k)?.classList.toggle('hidden', !win)); ['ip', 'porta'].forEach(k => cmp(k)?.classList.toggle('hidden', win)); };
    $('[data-k=conexao]', m.body).addEventListener('change', ajusta); ajusta();
    $('[data-k=papel]', m.body).addEventListener('change', e => { const c = $('[data-k=colunas]', m.body); if (c) c.value = e.target.value === '58' ? 32 : 42; });   // sugere as colunas da bobina escolhida
  };
  const up = await api('/atualizacao').catch(() => null);
  el.innerHTML = `<div class="card"><h3>Atualização do sistema</h3><p>Versão instalada: <b>${esc(up ? up.versao : S.versao)}</b>. ${up && up.disponivel ? '<b>Versão ' + esc(up.disponivel.versao) + ' disponível.</b>' : 'Nenhuma versão nova encontrada.'}${up && up.checado ? ' <small class="muted">Última verificação: ' + dt(up.checado) + '</small>' : ''}</p>${up && up.erro ? '<p class="erro">' + esc(up.erro) + '</p>' : ''}<div class="row"><label style="flex:3">Endereço de atualização (definido pela versão do sistema; não pode ser alterado aqui)<input id="upurl" value="${esc(up ? up.url : '')}" readonly tabindex="-1" class="ro"></label><button class="btn auto" id="uplog">Ver log da atualização</button> <button class="btn primary auto" id="upchk">Verificar agora</button>${up && up.disponivel ? '<button class="btn primary auto" id="upgo">Atualizar agora</button>' : ''}</div></div>
    <div class="card"><h3>Acesso dos terminais</h3><p>Nos outros computadores da rede, abra o navegador em um destes endereços (e crie um atalho na área de trabalho):</p>
    ${(rede.detalhes || rede.enderecos.map(u => ({ url: u, tipo: 'rede' }))).map(d => d.recomendado ? `<p><b style="font-size:17px"><a href="${esc(d.url)}" target="_blank">${esc(d.url)}</a></b> <span class="chip" style="background:var(--b7);color:var(--t3)">✔ use este nas outras máquinas${d.via ? ' (' + d.via + ')' : ''}</span></p>` : `<p class="muted" style="margin:2px 0">${esc(d.url)} — ${d.tipo === 'vpn' ? 'rede VPN' : d.tipo === 'virtual' ? 'adaptador virtual' : 'outra rede'} (${esc(d.adaptador || '')}): provavelmente não serve para as outras máquinas</p>`).join('') || '<p class="muted">Endereço não detectado.</p>'}<p class="muted">Dica: fixe o IP deste computador no roteador para o endereço não mudar.</p></div>
    <div class="card"><h3>Empresa</h3><p class="muted">Os dados da empresa, o e-mail padrão e o envio de e-mails agora ficam em <a href="#/empresa"><b>Configurações → Empresa</b></a>.</p></div>
    <div class="card"><h3>Arredondamento no recebimento</h3><p class="muted">Valor máximo (em R$) que pode ser arredondado na tela de Receber. Só quem tem a permissão "Arredondamento no recebimento" (ou informa usuário e senha de quem tem) pode usar; cada uso fica registrado na auditoria.</p>
      <div class="row"><label>Máximo para menos (R$)<input id="arrm" value="${esc(String(S.cfg.arred_max_menos ?? '1.00').replace('.', ','))}" inputmode="decimal"></label><label>Máximo para mais (R$)<input id="arrp" value="${esc(String(S.cfg.arred_max_mais ?? '1.00').replace('.', ','))}" inputmode="decimal"></label><button class="btn primary auto" id="sarr">Salvar</button></div></div>
    <div class="card"><h3>Estoque negativo</h3><p class="muted">Define se o estabelecimento aceita vender um item sem saldo em estoque. <b>Sim:</b> a venda só continua com usuário e senha de quem tem a permissão "Autorizar venda com estoque negativo". <b>Não:</b> ninguém consegue vender acima do saldo.</p>
      <div class="row"><label>Usa estoque negativo?<select id="engs"><option value="sim" ${S.cfg.estoque_negativo !== 'nao' ? 'selected' : ''}>Sim (com autorização por usuário e senha)</option><option value="nao" ${S.cfg.estoque_negativo === 'nao' ? 'selected' : ''}>Não (bloqueia a venda)</option></select></label><button class="btn primary auto" id="sneg">Salvar</button></div></div>
    <div class="card"><h3>Doação do troco</h3><p class="muted">Quando o cliente paga em dinheiro e tem troco, o operador pergunta se ele quer deixar as moedinhas como doação. Informe aqui os locais que vão receber as doações deste evento (um por linha). O sistema soma o que foi doado em cada local no fechamento do caixa.</p>
      <label class="chk"><input type="checkbox" id="doaa" ${S.cfg.doacao_ativa === '1' ? 'checked' : ''}> Perguntar sobre doação do troco</label>
      <label>Locais de doação (um por linha)<textarea id="doad" rows="4" placeholder="Ex.:&#10;Abrigo Municipal de Animais&#10;Asilo São Vicente">${esc(S.cfg.doacao_destinos || '')}</textarea></label><button class="btn primary" id="sdoa">Salvar</button></div>
    <div class="card"><h3>Backup do banco de dados</h3><p class="muted">Feito automaticamente <b>ao abrir</b> e <b>ao fechar</b> o sistema. Guarda apenas os últimos <b>3 dias</b> (hoje e os 2 anteriores) em: <b>${esc(bk.pasta || '')}</b>${bk.pg_dump === false ? '<br><span class="erro">pg_dump não encontrado: o backup não funcionará.</span>' : ''}</p>
      <div class="row"><label style="flex:3">Pasta dos backups (só para eles; fora da pasta do sistema, assim não se perde ao reinstalar)<input id="bkp" value="${esc(bk.pasta || '')}" placeholder="${esc(bk.padrao || '')}"></label><button class="btn auto" id="sbkp">Salvar pasta</button><button class="btn auto" id="bkpd" title="Voltar para a pasta padrão">Usar a padrão</button></div>
      <div class="row"><label>Pasta extra para uma cópia (ex.: pen drive, outro disco, pasta do OneDrive)<input id="bkx" value="${esc(S.cfg.backup_pasta_extra || '')}" placeholder="ex: D:\\Backups\\LoPDV"></label><button class="btn auto" id="sbkx">Salvar pasta</button><button class="btn primary auto" id="bkagora">Fazer backup agora</button></div>
      ${bk.arquivos.length ? '<div class="muted" style="margin-top:8px">Últimos: ' + bk.arquivos.slice(0, 5).map(a => esc(a.arquivo) + ' (' + (a.tamanho / 1048576).toFixed(1) + ' MB)').join(' · ') + '</div>' : '<div class="muted" style="margin-top:8px">Nenhum backup feito ainda.</div>'}</div>
    <div class="card"><h3>Sistema</h3><p>Versão instalada: <b>${esc(ver.versao || '')}</b>${(ver.historico || []).length > 1 ? '<br><span class="muted">Histórico: ' + ver.historico.map(h => esc(h.versao) + ' (' + dia(h.aplicado_em) + ')').join(' · ') + '</span>' : ''}</p>
      <button class="btn danger" id="encerrar">Encerrar o sistema (faz backup e desliga o servidor)</button> <span class="muted">Para usar de novo, abra o atalho LoPDV no computador servidor.</span></div>
    <div class="bar"><h3 style="margin:0">Impressoras térmicas (rede)</h3><div class="grow"></div><button class="btn primary" id="novo">+ Impressora</button></div>` +
    tabela([{ l: 'Nome', k: 'nome' }, { l: 'Setor', f: i => esc({ cozinha: 'Cozinha', bar: 'Bar', caixa: 'Caixa', todos: 'Todos os setores' }[i.destino] || i.destino) }, { l: 'Bobina', f: i => (i.papel === '58' ? '58 mm' : '80 mm') + ' · ' + (i.colunas || 42) + ' col.' }, { l: 'Ligação', f: i => (i.conexao === 'windows' ? 'Windows: ' + esc(i.windows_nome || '') : esc((i.ip || '') + ':' + i.porta)) }, { l: 'Situação', f: i => chip(i.ativo ? 'ativa' : 'inativa', i.ativo ? 'ok' : 'cancelado') }], imp, { vazio: 'Nenhuma impressora cadastrada. Sem impressora, os itens aparecem apenas na tela Cozinha/Bar.', acoes: i => `<button class="btn sm" data-t="${i.id}">Testar</button> <button class="btn sm" data-ed="${i.id}">Editar</button> <button class="btn sm danger" data-ex="${i.id}">Excluir</button>` });
  $('#novo', el).onclick = () => abrir(null);
  $('#sbkp', el).onclick = seguro(async () => { const r = await api('/backups/pasta', { method: 'PUT', body: { pasta: $('#bkp', el).value.trim() } }); toast('Pasta dos backups salva' + (r.movidos ? ' — ' + r.movidos + ' backup(s) movido(s) para ela.' : '.')); rotear(); });
  $('#bkpd', el).onclick = seguro(async () => { const r = await api('/backups/pasta', { method: 'PUT', body: { pasta: '' } }); toast('Usando a pasta padrão: ' + r.pasta); rotear(); });
  $('#sbkx', el).onclick = seguro(async () => { await api('/config', { method: 'PUT', body: { backup_pasta_extra: $('#bkx', el).value.trim() } }); S.cfg.backup_pasta_extra = $('#bkx', el).value.trim(); toast('Pasta salva.'); });
  $('#bkagora', el).onclick = seguro(async () => { const r = await api('/backups', { method: 'POST' }); toast('Backup feito: ' + r.arquivo + (r.copia ? (r.copia.startsWith('FALHOU') ? ' — ' + r.copia : ' (copiado)') : '')); rotear(); });
  $('#encerrar', el).onclick = seguro(async () => { if (!await confirmar('Encerrar o sistema? Será feito um backup e o servidor será desligado; todos os terminais perderão o acesso até ele ser aberto de novo no computador servidor.', 'Encerrar sistema')) return; await api('/sistema/encerrar', { method: 'POST' }); document.body.innerHTML = '<div style="padding:40px;font-family:system-ui"><h2>LoPDV encerrado.</h2><p>Para usar de novo, abra o atalho LoPDV no computador servidor.</p></div>'; });
  $('#sarr', el).onclick = seguro(async () => {
    const n = id => { const v = Number(String($(id, el).value).replace(',', '.')); if (!(v >= 0)) throw new Error('Informe um valor válido (zero para não permitir).'); return v.toFixed(2); };
    const body = { arred_max_menos: n('#arrm'), arred_max_mais: n('#arrp') }; await api('/config', { method: 'PUT', body }); Object.assign(S.cfg, body); toast('Limites de arredondamento salvos.'); });
  $('#sneg', el).onclick = seguro(async () => { const v = $('#engs', el).value; await api('/config', { method: 'PUT', body: { estoque_negativo: v } }); S.cfg.estoque_negativo = v; toast('Salvo.'); });
  $('#sdoa', el).onclick = seguro(async () => {
    const body = { doacao_ativa: $('#doaa', el).checked ? '1' : '0', doacao_destinos: $('#doad', el).value.split(/\r?\n/).map(s => s.trim()).filter(Boolean).join('\n') };
    if (body.doacao_ativa === '1' && !body.doacao_destinos) throw new Error('Informe ao menos um local de doação (ou desligue a pergunta).');
    await api('/config', { method: 'PUT', body }); Object.assign(S.cfg, body); toast('Doação do troco salva.'); });
  el.onclick = seguro(async e => {
    const d = e.target.dataset;
    if (d.ed) abrir(imp.find(i => i.id == d.ed));
    if (d.ex && await confirmar('Excluir impressora?')) { await api('/impressoras/' + d.ex, { method: 'DELETE' }); rotear(); }
    if (d.t) { const r = await api(`/impressoras/${d.t}/teste`, { method: 'POST' }); r.ok ? toast('Teste enviado.') : toast(r.erro, 'erro'); }
  });
} });

registrar({ id: 'auditoria', titulo: 'Auditoria', grupo: 'Sistema', perm: 'config.gerenciar', render: async el => {
  const a = await api('/auditoria');
  el.innerHTML = '<p class="muted">Últimas 500 ações sensíveis: logins, descontos, cancelamentos, estoque negativo autorizado, ajustes, caixa...</p>' +
    tabela([{ l: 'Data', f: x => dt(x.criado_em) }, { l: 'Usuário', k: 'usuario_nome' }, { l: 'Ação', f: x => chip(x.acao, /negativo|cancel|desconto|falhou|ajuste/.test(x.acao) ? 'warn' : '') }, { l: 'Detalhe', f: x => `<small>${esc(JSON.stringify(x.detalhe))}</small>` }], a);
} });

registrar({ id: 'empresa', titulo: 'Empresas', grupo: 'Sistema', perm: 'config.gerenciar', render: async el => {
  let lista = await api('/empresa');
  const fmtDoc = d => { d = String(d || '').replace(/\D/g, ''); return d.length === 14 ? d.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5') : d.length === 11 ? d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4') : d; };
  const DICAS = {
    gmail: ['smtp.gmail.com', '587', 'starttls', '<b>Gmail não aceita a senha normal para programas de terceiros (como o LoPDV).</b> Você precisa criar uma <b>"senha de app"</b> de 16 letras: <ol><li>Entre em <b>myaccount.google.com</b> com o e-mail que vai enviar.</li><li>Em <b>Segurança</b>, ative a <b>Verificação em duas etapas</b> (obrigatória).</li><li>Acesse <b>myaccount.google.com/apppasswords</b>, dê o nome <b>LoPDV</b> e clique em Criar.</li><li>Copie as 16 letras (aparecem uma vez só) e cole no campo <b>Senha do e-mail</b> abaixo. O usuário é o e-mail completo.</li></ol>'],
    outlook: ['smtp-mail.outlook.com', '587', 'starttls', 'Use o e-mail completo como usuário. Se a conta tiver verificação em duas etapas, crie uma <b>senha de app</b> em account.microsoft.com → Segurança. A Microsoft vem desligando o envio por senha simples; se falhar, veja o PDF do passo a passo.'],
    yahoo: ['smtp.mail.yahoo.com', '465', 'ssl', 'O Yahoo também exige <b>senha de app</b>: Segurança da conta → <b>Gerar senha de app</b>. Use o e-mail completo como usuário.'],
    outro: ['', '587', 'starttls', 'Peça ao provedor/hospedagem (Locaweb, Hostinger, Registro.br...) o <b>servidor SMTP</b>, a porta e a segurança. Usuário costuma ser o e-mail completo e a senha é a da caixa de e-mail.']
  };
  const form = (c0 = {}) => {
    const c = { ...c0, cnpj: mascaraDoc(c0.cnpj), tel: mascaraTel(c0.tel) };
    const F = (k, l, ph = '', extra = '') => `<label>${l}<input id="e_${k}" value="${esc(c[k] || '')}" placeholder="${esc(ph)}" ${extra}></label>`;
    return `<h4 style="margin:0 0 6px">Dados da empresa</h4>
      <div class="row">${F('nome', 'Nome fantasia *')}${F('razao', 'Razão social')}</div>
      <div class="row">${F('cnpj', 'CNPJ / CPF', '00.000.000/0000-00', 'inputmode="numeric" maxlength="18"')}${F('ie', 'Inscrição estadual')}${F('tel', 'Telefone', '(00) 00000-0000', 'inputmode="tel" maxlength="15"')}</div>
      <div class="row">${F('endereco', 'Endereço')}${F('cidade', 'Cidade / UF')}</div>
      <h4 style="margin:12px 0 6px">E-mail da empresa e envio de e-mails</h4>
      <p class="muted">O <b>e-mail padrão</b> é o remetente das mensagens do sistema (ex.: código de recuperação de senha) <b>quando esta é a empresa em uso</b>. <a href="/guia-email.pdf" target="_blank" rel="noopener">📄 Passo a passo (PDF)</a></p>
      <div class="row">${F('email', 'E-mail padrão (remetente)', 'contato@suaempresa.com.br')}</div>
      <div class="row"><label style="flex:2">Provedor do e-mail (preenche o servidor sozinho)<select id="e_prov"><option value="">Escolha...</option><option value="gmail">Gmail / Google Workspace</option><option value="outlook">Outlook / Hotmail / Live</option><option value="yahoo">Yahoo</option><option value="outro">Outro (e-mail do domínio da empresa)</option></select></label></div>
      <div id="e_dica" class="aviso-box hidden"></div>
      <div class="row">${F('smtp_host', 'Servidor SMTP', 'smtp.gmail.com')}${F('smtp_porta', 'Porta', '587', 'inputmode="numeric"')}
        <label>Segurança<select id="e_smtp_seguranca"><option value="starttls" ${c.smtp_seguranca !== 'ssl' && c.smtp_seguranca !== 'nenhuma' ? 'selected' : ''}>STARTTLS (porta 587)</option><option value="ssl" ${c.smtp_seguranca === 'ssl' ? 'selected' : ''}>SSL/TLS (porta 465)</option><option value="nenhuma" ${c.smtp_seguranca === 'nenhuma' ? 'selected' : ''}>Nenhuma (porta 25)</option></select></label></div>
      <div class="row">${F('smtp_usuario', 'Usuário do e-mail (geralmente o próprio e-mail)')}<label>Senha do e-mail (Gmail/Yahoo: <b>senha de app</b>, não a senha normal)<input id="e_smtp_senha" type="password" autocomplete="new-password" placeholder="${c.smtp_tem_senha ? '•••••••• (deixe vazio para manter)' : 'senha de app (16 letras) ou senha do e-mail'}"></label></div>`;
  };
  const abrir = (c = null) => {
    const m = modal({ titulo: c ? 'Editar empresa' : 'Nova empresa', tam: 'md', corpo: form(c || {}), aoAbrir: mm => { const cj = $('#e_cnpj', mm.body), tl = $('#e_tel', mm.body); cj.oninput = () => { cj.value = mascaraDoc(cj.value); }; tl.oninput = () => { tl.value = mascaraTel(tl.value); }; }, botoes: [{ txt: 'Cancelar' },
      { txt: 'Salvar', cls: 'primary', fn: async mm => {
        const o = {}; ['nome', 'razao', 'cnpj', 'ie', 'tel', 'endereco', 'cidade', 'email', 'smtp_host', 'smtp_porta', 'smtp_seguranca', 'smtp_usuario', 'smtp_senha'].forEach(k => { o[k] = $('#e_' + k, mm.body).value; });
        if (o.cnpj.trim() && !docValido(o.cnpj)) throw new Error('CNPJ/CPF inválido. Confira os números.');
        o.cnpj = soNum(o.cnpj); // grava só os dígitos (o sistema compara com o CNPJ do XML)
        await api('/empresa' + (c ? '/' + c.id : ''), { method: c ? 'PUT' : 'POST', body: o }); toast(c ? 'Empresa salva.' : 'Empresa cadastrada.');
        try { S.cfg = await api('/config'); } catch { /* */ } mostrarEmpresaTerminal(); await carregar();
      } }] });
    const dica = k => { const d = DICAS[k], b = $('#e_dica', m.body); if (!d) { b.classList.add('hidden'); return; } b.innerHTML = d[3]; b.classList.remove('hidden'); };
    $('#e_prov', m.body).onchange = e => { const d = DICAS[e.target.value]; if (!d) return dica(''); if (d[0]) $('#e_smtp_host', m.body).value = d[0]; $('#e_smtp_porta', m.body).value = d[1]; $('#e_smtp_seguranca', m.body).value = d[2]; dica(e.target.value); };
    const h = ((c || {}).smtp_host || '').toLowerCase(), k = /gmail|google/.test(h) ? 'gmail' : /outlook|office365|hotmail/.test(h) ? 'outlook' : /yahoo/.test(h) ? 'yahoo' : h ? 'outro' : ''; $('#e_prov', m.body).value = k; dica(k);
  };
  const carregar = async () => { lista = await api('/empresa'); desenhar(); };
  const desenhar = () => {
    const emUso = lista.find(x => x.em_uso);
    $('#elista', el).innerHTML = (emUso ? '' : '<div class="aviso-box">Nenhuma empresa está <b>em uso</b>. Cadastre uma empresa (ou clique em <b>Usar esta empresa</b>) para liberar Vendas e Entrada de mercadoria.</div>') +
      tabela([{ l: 'Nome fantasia', f: r => `<b>${esc(r.nome)}</b>` }, { l: 'Razão social', k: 'razao' }, { l: 'CNPJ / CPF', f: r => esc(fmtDoc(r.cnpj)) }, { l: 'Cidade', k: 'cidade' }, { l: 'E-mail', k: 'email' },
        { l: 'Situação', f: r => r.em_uso ? chip('EM USO', 'ok') : r.ativo ? chip('ATIVA') : chip('INATIVA', 'cancelado') }], lista,
        { vazio: 'Nenhuma empresa cadastrada.', acoes: r => `<button class="btn sm" data-ed="${r.id}">Editar</button> ${r.em_uso ? '' : (r.ativo ? `<button class="btn sm primary" data-us="${r.id}">Usar esta empresa</button> <button class="btn sm" data-in="${r.id}">Inativar</button>` : `<button class="btn sm" data-re="${r.id}">Reativar</button>`) + ` <button class="btn sm danger" data-ex="${r.id}">Excluir</button>`}` });
  };
  el.innerHTML = `<div class="card"><div class="row" style="align-items:center"><div style="flex:1"><h3 style="margin:0">Empresas cadastradas</h3><p class="muted" style="margin:4px 0 0">A empresa <b>em uso</b> aparece nos relatórios e comprovantes e é a remetente dos e-mails do sistema. Troque a qualquer momento em <b>Usar esta empresa</b>.</p></div><button class="btn primary auto" id="enova">+ Nova empresa</button></div></div><div id="elista"></div>
    <div class="card"><h3>Testar envio de e-mail (empresa em uso)</h3><div class="row"><label style="flex:2">Enviar e-mail de teste para<input id="e_teste" placeholder="seu@email.com"></label><button class="btn auto" id="etest">Enviar teste</button></div></div>`;
  desenhar();
  el.onclick = seguro(async e => {
    const d = e.target.dataset, rec = async () => { try { S.cfg = await api('/config'); } catch { /* */ } mostrarEmpresaTerminal(); await carregar(); };
    if (e.target.id === 'enova') abrir(null);
    if (d.ed) abrir(lista.find(x => x.id == d.ed));
    if (d.us) { await api('/empresa/' + d.us + '/usar', { method: 'POST' }); toast('Empresa em uso alterada.'); await rec(); }
    if (d.in) { await api('/empresa/' + d.in + '/ativo', { method: 'POST', body: { ativo: false } }); await rec(); }
    if (d.re) { await api('/empresa/' + d.re + '/ativo', { method: 'POST', body: { ativo: true } }); await rec(); }
    if (d.ex && await confirmar('Excluir esta empresa? Não dá para desfazer.')) { await api('/empresa/' + d.ex, { method: 'DELETE' }); toast('Empresa excluída.'); await rec(); }
    if (e.target.id === 'etest') { toast('Enviando e-mail de teste...'); await api('/empresa/email-teste', { method: 'POST', body: { para: $('#e_teste', el).value } }); toast('E-mail de teste enviado. Confira a caixa de entrada (e o spam).'); }
  });
} });
