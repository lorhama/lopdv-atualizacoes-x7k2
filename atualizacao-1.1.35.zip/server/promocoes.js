// Promoções de produtos com data e horário. Horários são locais do computador do sistema (timestamp sem fuso).
// Preço promocional vigente de um produto = menor preço entre as promoções ativas cujo período contém o momento atual.
const PRECO_PROMO = alias => `(select min(case when pr.tipo='percentual' then round(${alias}.preco_venda * (1 - pr.valor / 100.0), 2) else pr.valor end)
  from promocoes pr where pr.produto_id=${alias}.id and pr.ativo and localtimestamp between pr.inicio and pr.fim)`;
async function precoVigente(c, produtoId) {
  const r = (await c.query(`select p.preco_venda, ${PRECO_PROMO('p')} promo from produtos p where p.id=$1`, [produtoId])).rows[0];
  if (!r) return null;
  const n = Number(r.preco_venda), pr = r.promo === null ? null : Number(r.promo);
  return pr !== null && pr < n ? pr : n;
}
module.exports = { PRECO_PROMO, precoVigente };
