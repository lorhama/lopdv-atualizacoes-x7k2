// Núcleo do front-end: utilitários, API, modais, formulários, menu e roteamento.
const S = { token: sessionStorage.getItem('tk'), user: null, timer: null, cfg: {} };
const VIEWS = [];
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const R = n => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const N = (n, d = 3) => Number(n || 0).toLocaleString('pt-BR', { maximumFractionDigits: d });
const dt = s => (s ? new Date(s).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '');
const hr = s => (s ? new Date(s).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '');
const dia = s => (s ? String(s).slice(0, 10).split('-').reverse().join('/') : '');
const hojeISO = () => { const d = new Date(); return new Date(d - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); };
const iniMes = () => hojeISO().slice(0, 8) + '01';
const tem = p => !!S.user && (S.user.perms.includes('*') || S.user.perms.includes(p));
const num = v => { const n = parseFloat(String(v ?? '').replace(/\./g, '').replace(',', '.')); return Number.isFinite(n) ? n : 0; };
const numIn = v => { const s = String(v ?? '').trim(); if (/^-?\d+(\.\d+)?$/.test(s)) return parseFloat(s); return num(s); };

// Empresa deste terminal: o instalador do atalho abre o sistema com ?e=<id>; fica guardada neste computador
(() => { try { const q = new URLSearchParams(location.search).get('e'); if (q && /^\d+$/.test(q)) { localStorage.setItem('lopdv_empresa', q); history.replaceState(null, '', location.pathname + location.hash); } } catch { /* */ } })();
function empresaTerminal() { try { return localStorage.getItem('lopdv_empresa') || ''; } catch { return ''; } }
async function mostrarEmpresaTerminal() {
  try {
    const { lista } = await (await fetch('/api/empresas-terminal')).json(); const id = empresaTerminal();
    const e = lista.find(x => String(x.id) === id) || lista.find(x => x.em_uso); let b = $('#topEmp');
    if (!e) { if (b) b.remove(); return; }
    if (!b) { b = document.createElement('span'); b.id = 'topEmp'; b.className = 'chip'; b.style.marginRight = '10px'; $('#quem').parentNode.insertBefore(b, $('#quem')); }
    b.textContent = '🏢 ' + e.nome; b.title = 'Empresa usada neste terminal';
  } catch { /* */ }
}
async function api(path, { method = 'GET', body } = {}) {
  const r = await fetch('/api' + path, { method, headers: { 'Content-Type': 'application/json', ...(S.token ? { Authorization: 'Bearer ' + S.token } : {}), ...(empresaTerminal() ? { 'X-Empresa-Id': empresaTerminal() } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
  let j = {}; try { j = await r.json(); } catch { /* sem corpo */ }
  if (!r.ok) {
    if (j.setup) { location = '/setup.html'; }
    if (r.status === 401 && S.token) { S.token = null; sessionStorage.removeItem('tk'); mostrarLogin(); }
    const e = new Error(j.erro || 'Erro ' + r.status); e.status = r.status; e.data = j; throw e;
  }
  return j;
}
const qs = o => Object.entries(o).filter(([, v]) => v !== '' && v != null).map(([k, v]) => k + '=' + encodeURIComponent(v)).join('&');

function toast(msg, tipo = 'ok') {
  const t = document.createElement('div'); t.className = 'toast ' + (tipo === 'ok' ? '' : tipo); t.textContent = msg;
  $('#toasts').appendChild(t); setTimeout(() => t.remove(), tipo === 'erro' ? 6000 : 3500);
}
// executa uma ação mostrando erros como aviso
const seguro = fn => async (...a) => { try { return await fn(...a); } catch (e) { toast(e.message, 'erro'); } };

function modal({ titulo, corpo, botoes = [], tam = '', aoAbrir }) {
  const bg = document.createElement('div'); bg.className = 'modal-bg';
  bg.innerHTML = `<div class="modal ${tam}"><h3>${esc(titulo)}</h3><div class="body"></div><div class="foot"></div></div>`;
  const body = $('.body', bg); if (typeof corpo === 'string') body.innerHTML = corpo; else body.appendChild(corpo);
  const m = { el: bg, body, fechar: () => bg.remove() };
  botoes.forEach(b => {
    const bt = document.createElement('button'); bt.className = 'btn ' + (b.cls || ''); bt.textContent = b.txt;
    bt.onclick = async () => {
      if (!b.fn) return m.fechar();
      bt.disabled = true;
      try { const r = await b.fn(m); if (r !== false) m.fechar(); } catch (e) { toast(e.message, 'erro'); }
      bt.disabled = false;
    };
    $('.foot', bg).appendChild(bt);
  });
  document.body.appendChild(bg);
  const f = $('input,select,textarea', body); if (f) f.focus();
  if (aoAbrir) aoAbrir(m);
  return m;
}
const confirmarSaidaVenda = () => confirmar('Você tem uma venda em andamento que ainda não foi finalizada.\n\nTem certeza que deseja sair? A venda ficará salva como PENDENTE e, ao voltar para Vendas, você poderá resgatá-la ou excluí-la.', 'Sair sem finalizar a venda?');
const confirmar = (txt, titulo = 'Confirmar') => new Promise(res => {
  modal({ titulo, corpo: `<p>${esc(txt)}</p>`, botoes: [{ txt: 'Cancelar', fn: () => { res(false); } }, { txt: 'Confirmar', cls: 'primary', fn: () => { res(true); } }] });
});
// ---- Máscaras (CPF/CNPJ, telefone, CEP) e validação de CPF/CNPJ
const soNum = v => String(v == null ? '' : v).replace(/\D/g, '');
function mascaraDoc(v) { const d = soNum(v).slice(0, 14); return d.length <= 11 ? d.replace(/^(\d{3})(\d)/, '$1.$2').replace(/^(\d{3})\.(\d{3})(\d)/, '$1.$2.$3').replace(/^(\d{3})\.(\d{3})\.(\d{3})(\d)/, '$1.$2.$3-$4') : d.replace(/^(\d{2})(\d)/, '$1.$2').replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3').replace(/^(\d{2})\.(\d{3})\.(\d{3})(\d)/, '$1.$2.$3/$4').replace(/^(\d{2})\.(\d{3})\.(\d{3})\/(\d{4})(\d)/, '$1.$2.$3/$4-$5'); }
function mascaraTel(v) { let d = soNum(v); if (d.startsWith('55') && d.length > 11) d = d.slice(2); d = d.slice(0, 11); if (!d) return ''; if (d.length <= 2) return '(' + d; return d.length <= 10 ? d.replace(/^(\d{2})(\d{0,4})(\d{0,4}).*/, (m, a, b, c) => `(${a}) ${b}` + (c ? '-' + c : '')) : d.replace(/^(\d{2})(\d{5})(\d{0,4}).*/, '($1) $2-$3'); }
function mascaraCep(v) { const d = soNum(v).slice(0, 8); return d.length > 5 ? d.slice(0, 5) + '-' + d.slice(5) : d; }
function docValido(v) {
  const d = soNum(v);
  const dv = (base, pesos) => { const s = base.split('').reduce((t, n, i) => t + Number(n) * pesos[i], 0) % 11; return s < 2 ? 0 : 11 - s; };
  if (/^(\d)\1+$/.test(d)) return false;
  if (d.length === 11) return dv(d.slice(0, 9), [10, 9, 8, 7, 6, 5, 4, 3, 2]) === +d[9] && dv(d.slice(0, 10), [11, 10, 9, 8, 7, 6, 5, 4, 3, 2]) === +d[10];
  if (d.length === 14) return dv(d.slice(0, 12), [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]) === +d[12] && dv(d.slice(0, 13), [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]) === +d[13];
  return false;
}
const aviso = (txt, titulo = 'Aviso') => modal({ titulo, corpo: `<p style="white-space:pre-line">${esc(txt)}</p>`, botoes: [{ txt: 'OK', cls: 'primary' }] });

// ---- Formulários
function campoHtml(f, v) {
  const val = v ?? f.padrao ?? '';
  const id = ' data-k="' + f.k + '"';
  if (f.t === 'check') return `<label class="chk"><input type="checkbox"${id} ${val === true || val === 'true' || (val === '' && f.padrao) ? 'checked' : ''}> ${esc(f.l)}</label>`;
  let inp;
  if (f.t === 'select') inp = `<select${id}>${(f.op || []).map(o => `<option value="${esc(o[0])}" ${String(o[0]) === String(val) ? 'selected' : ''}>${esc(o[1])}</option>`).join('')}</select>`;
  else if (f.t === 'textarea') inp = `<textarea${id} rows="2">${esc(val)}</textarea>`;
  else inp = `<input${id} type="${f.t || 'text'}" value="${esc(val)}" ${f.ph ? `placeholder="${esc(f.ph)}"` : ''} ${f.ro ? 'readonly tabindex="-1" class="ro"' : ''} ${f.step ? `step="${f.step}"` : ''} ${f.t === 'password' ? 'autocomplete="new-password"' : ''}>`;
  return `<label>${esc(f.l)}${f.req ? ' *' : ''}${inp}</label>`;
}
function camposHtml(campos, vals = {}) {
  let out = '', linha = [];
  const flush = () => { if (linha.length) out += `<div class="row">${linha.join('')}</div>`; linha = []; };
  campos.forEach(f => { if (f.t === 'check' || f.full) { flush(); out += campoHtml(f, vals[f.k]); } else { linha.push(campoHtml(f, vals[f.k])); if (linha.length === (f.cols || 2)) flush(); } });
  flush(); return out;
}
function lerCampos(root, campos) {
  const o = {};
  campos.forEach(f => {
    const el = $(`[data-k="${f.k}"]`, root); if (!el) return;
    if (f.t === 'check') o[f.k] = el.checked;
    else if (f.t === 'number') o[f.k] = el.value === '' ? '' : numIn(el.value);
    else o[f.k] = el.value.trim();
  });
  return o;
}
function validar(o, campos) { for (const f of campos) if (f.req && (o[f.k] === '' || o[f.k] == null)) throw new Error(`Preencha: ${f.l}`); }

function formModal({ titulo, campos, valores = {}, onSave, tam = '', extra = '' }) {
  return modal({ titulo, tam, corpo: camposHtml(campos, valores) + extra, botoes: [{ txt: 'Cancelar' }, { txt: 'Salvar', cls: 'primary', fn: async m => { const o = lerCampos(m.body, campos); validar(o, campos); return onSave(o, m); } }] });
}

// ---- Tabelas
function tabela(cols, rows, { acoes, vazio = 'Nenhum registro.', rowCls } = {}) {
  if (!rows.length) return `<div class="card muted">${esc(vazio)}</div>`;
  const th = cols.map(c => `<th class="${c.n ? 'n' : ''}">${esc(c.l)}</th>`).join('') + (acoes ? '<th></th>' : '');
  const tr = rows.map((r, i) => `<tr data-i="${i}" class="${rowCls ? rowCls(r) : ''}">` + cols.map(c => `<td class="${c.n ? 'n' : ''}">${c.f ? c.f(r) : esc(r[c.k])}</td>`).join('') + (acoes ? `<td class="n">${acoes(r)}</td>` : '') + '</tr>').join('');
  const filtro = rows.length > 6 ? `<div class="tfil"><input class="tf" type="search" placeholder="🔎 Filtrar esta tabela..." autocomplete="off"><span class="muted tfn"></span></div>` : '';
  return `${filtro}<div class="tw"><table class="ord"><thead><tr>${th}</tr></thead><tbody>${tr}</tbody></table></div>`;
}
// Todas as tabelas: clique no título da coluna ordena (A→Z, depois Z→A, como no Excel); a caixa acima filtra as linhas.
const _valOrd = t => { t = String(t || '').replace(/\s+/g, ' ').trim(); if (!t) return { v: null };
  let m = /^(\d{2})\/(\d{2})\/(\d{4})(?:[ ,]+(\d{2}):(\d{2}))?/.exec(t); if (m) return { n: Date.UTC(+m[3], +m[2] - 1, +m[1], +(m[4] || 0), +(m[5] || 0)) };
  m = /^(\d{4})-(\d{2})-(\d{2})/.exec(t); if (m) return { n: Date.UTC(+m[1], +m[2] - 1, +m[3]) };
  const c = t.replace(/^R\$\s*/, '').replace(/\s*(%|un|kg|g|l|ml)$/i, '');
  if (/^-?[\d.]*\d(,\d+)?$/.test(c) || /^-?\d+(\.\d+)?$/.test(c)) return { n: Number(c.includes(',') ? c.replace(/\./g, '').replace(',', '.') : c) };
  return { s: t.toLowerCase() }; };
document.addEventListener('click', e => {
  const th = e.target.closest && e.target.closest('table.ord thead th'); if (!th || th.dataset.nosort !== undefined) return;
  const tb = th.closest('table'), i = [...th.parentElement.children].indexOf(th), body = tb.tBodies[0]; if (!body || !th.textContent.trim()) return;
  const dir = th.dataset.dir === 'asc' ? 'desc' : 'asc'; tb.querySelectorAll('thead th').forEach(x => { delete x.dataset.dir; x.classList.remove('s-asc', 's-desc'); });
  th.dataset.dir = dir; th.classList.add('s-' + dir);
  const rows = [...body.rows].map((tr, k) => ({ tr, k, o: _valOrd(tr.cells[i] ? tr.cells[i].textContent : '') }));
  rows.sort((a, b) => { const x = a.o, y = b.o; if (x.v === null || y.v === null) return x.v === y.v ? a.k - b.k : (x.v === null ? 1 : -1);   // vazios sempre no fim
    let c; if (x.n !== undefined && y.n !== undefined) c = x.n - y.n; else c = String(x.s ?? x.n).localeCompare(String(y.s ?? y.n), 'pt-BR', { numeric: true });
    return (dir === 'asc' ? c : -c) || a.k - b.k; });
  rows.forEach(r => body.appendChild(r.tr));
});
document.addEventListener('input', e => {
  const inp = e.target; if (!inp.classList || !inp.classList.contains('tf')) return;
  const box = inp.closest('.tfil'), tw = box.nextElementSibling, q = inp.value.trim().toLowerCase(); if (!tw) return;
  let vis = 0; const trs = [...tw.querySelectorAll('tbody tr')];
  trs.forEach(tr => { const ok = !q || tr.textContent.toLowerCase().includes(q); tr.style.display = ok ? '' : 'none'; if (ok) vis++; });
  box.querySelector('.tfn').textContent = q ? `${vis} de ${trs.length} linha(s)` : '';
});
const chip = (t, c = '') => `<span class="chip ${c}">${esc(t)}</span>`;
function csv(nome, cols, rows) {
  const l = [cols.map(c => c.l).join(';')].concat(rows.map(r => cols.map(c => { const v = c.csv ? c.csv(r) : r[c.k]; return '"' + String(v ?? '').replace(/"/g, '""') + '"'; }).join(';')));
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + l.join('\n')], { type: 'text/csv;charset=utf-8' })); a.download = nome + '.csv'; a.click();
}
// campo de busca por produto com datalist: "Nome (#id)"
const rotuloProd = p => `${p.nome} (#${p.id})`;
const idDoRotulo = t => { const m = /\(#(\d+)\)\s*$/.exec(t || ''); return m ? Number(m[1]) : null; };

// ---- CRUD genérico
function crudView({ id, titulo, grupo, perm, endpoint, campos, cols, editar = 'cadastros.editar', excluir = 'cadastros.excluir', ordemBusca }) {
  registrar({ id, titulo, grupo, perm, render: async el => {
    let dados = [];
    const desenhar = () => {
      const q = ($('#bq', el)?.value || '').toLowerCase();
      const lista = dados.filter(d => !q || JSON.stringify(Object.values(d)).toLowerCase().includes(q));
      $('#lista', el).innerHTML = tabela(cols, lista, { acoes: r => (tem(editar) ? `<button class="btn sm" data-ed="${r.id}">Editar</button> ` : '') + (tem(excluir) ? `<button class="btn sm danger" data-ex="${r.id}">Excluir</button>` : '') });
    };
    const carregar = seguro(async () => { dados = await api(endpoint); desenhar(); });
    el.innerHTML = `<div class="bar"><input id="bq" placeholder="Buscar..."><div class="grow"></div>${tem(editar) ? '<button class="btn primary" id="novo">+ Novo</button>' : ''}</div><div id="lista"></div>`;
    $('#bq', el).oninput = desenhar;
    const abrir = reg => formModal({ titulo: (reg ? 'Editar ' : 'Novo ') + titulo.toLowerCase(), campos, valores: reg || {}, tam: 'md',
      onSave: async o => { await api(endpoint + (reg ? '/' + reg.id : ''), { method: reg ? 'PUT' : 'POST', body: o }); toast('Salvo.'); carregar(); } });
    if ($('#novo', el)) $('#novo', el).onclick = () => abrir(null);
    el.onclick = seguro(async e => {
      const ed = e.target.dataset.ed, ex = e.target.dataset.ex;
      if (ed) abrir(dados.find(d => d.id == ed));
      if (ex && await confirmar('Excluir este registro? (se já foi usado, inative-o em vez de excluir)')) { await api(endpoint + '/' + ex, { method: 'DELETE' }); toast('Excluído.'); carregar(); }
    });
    await carregar();
  } });
}

// ---- Roteamento / menu
function registrar(v) { VIEWS.push(v); }
function limparTimer() { if (S.timer) { clearInterval(S.timer); S.timer = null; } }
// Menu em grupos suspensos (abre/fecha ao clicar). Todos os relatórios ficam num grupo só.
const MENU_GRUPOS = [
  ['Início', '🏠', ['painel']],
  ['Vendas', '🧾', ['vendas', 'producao']],
  ['Estoque', '📦', ['entrada', 'notas-sefaz', 'ajuste-avulso', 'balanco', 'producao-estoque', 'consignacoes', 'patrimonio']],
  ['Cadastros', '🗂️', ['produtos', 'clientes', 'fornecedores', 'formas']],
  ['Financeiro', '💰', ['caixa', 'conferencia', 'fiado', 'contas-receber', 'contas-pagar']],
  ['Relatórios', '📊', ['relatorios', 'rel-entradas', 'extrato-produto', 'posicao', 'movimentos', 'auditoria']],
  ['Equipe', '👥', ['usuarios', 'perfis']],
  ['Configurações', '⚙️', ['empresa', 'config', 'integracao-fiscal']],
];
function menuAbertos() { try { return JSON.parse(sessionStorage.getItem('menuAb') || '[]'); } catch { return []; } }
function montarMenu() {
  const vis = VIEWS.filter(v => !v.perm || [].concat(v.perm).some(tem));
  const ativo = location.hash.replace('#/', '') || 'painel', usados = new Set(), abertos = menuAbertos();
  let h = '<div class="logo"><img src="icon.png" width="22" height="22" style="vertical-align:-5px" alt=""> LoPDV</div>';
  const todosIds = new Set(MENU_GRUPOS.flatMap(g => g[2]));
  // tela nova que não está na lista: entra no grupo que ela declara (ex.: todo relatório fica em Relatórios), não em "Outros"
  const grupos = MENU_GRUPOS.map(([nome, ic, ids]) => [nome, ic, ids.map(id => vis.find(v => v.id === id)).filter(Boolean).concat(vis.filter(v => v.grupo === nome && !todosIds.has(v.id)))]);
  grupos.forEach(g => g[2].forEach(v => usados.add(v.id)));
  const sobra = vis.filter(v => !usados.has(v.id)); if (sobra.length) grupos.push(['Outros', '•', sobra]);
  grupos.forEach(([nome, ic, itens]) => {
    if (!itens.length) return;
    if (itens.length === 1 && nome === 'Início') { h += `<a class="mi" href="#/${itens[0].id}" data-id="${itens[0].id}"><span class="ico">${ic}</span>${esc(itens[0].titulo)}</a>`; return; }
    const aberto = abertos.includes(nome) || itens.some(v => v.id === ativo);
    h += `<div class="mg ${aberto ? 'open' : ''}" data-g="${esc(nome)}"><button type="button" class="mh"><span class="ico">${ic}</span><span class="mt">${esc(nome)}</span><span class="chev">▾</span></button><div class="ms">${itens.map(v => `<a href="#/${v.id}" data-id="${v.id}">${esc(v.titulo)}</a>`).join('')}</div></div>`;
  });
  if (S.versao) h += `<div class="grp" style="margin-top:18px">LoPDV v${esc(S.versao)}</div>`;
  const m = $('#menu'); m.innerHTML = h;
  m.onclick = e => {
    const b = e.target.closest('.mh'); if (!b) return;
    const g = b.parentElement; g.classList.toggle('open'); const nome = g.dataset.g;
    const l = menuAbertos().filter(x => x !== nome); if (g.classList.contains('open')) l.push(nome);
    try { sessionStorage.setItem('menuAb', JSON.stringify(l)); } catch { /* */ }
  };
}
// Durante um evento as permissões mudam (função do dia); confere com o servidor e refaz o menu se mudou.
async function sincronizarPerfil() {
  try { const me = await api('/me'); const mudou = JSON.stringify(me.perms) !== JSON.stringify(S.user.perms); S.user = me; $('#quem').textContent = `${me.nome} · ${me.perfil || ''}`; if (mudou) montarMenu(); } catch { /* sem rede: mantém */ }
}
async function rotear() {
  limparTimer(); S.guarda = null; await sincronizarPerfil();
  const id = (location.hash.replace('#/', '') || 'painel');
  const v = VIEWS.find(x => x.id === id && (!x.perm || [].concat(x.perm).some(tem))) || VIEWS.find(x => x.id === 'painel');
  $$('#menu a').forEach(a => a.classList.toggle('on', a.dataset.id === v.id)); const am = $('#menu a.on'); if (am && am.closest('.mg')) am.closest('.mg').classList.add('open');
  $('#titulo').textContent = v.titulo; $('#menu').classList.remove('open');
  const el = $('#view'); el.innerHTML = '<p class="muted">Carregando...</p>'; el.onclick = null;
  try { await v.render(el); } catch (e) { el.innerHTML = `<div class="card erro">${esc(e.message)}</div>`; }
}
// Janela do aplicativo: no login fica pequena (so o cartao); depois do login ocupa a area util da tela do cliente.
function ajustarJanela(modo) {
  try {
    const aw = screen.availWidth, ah = screen.availHeight, ax = screen.availLeft || 0, ay = screen.availTop || 0;
    if (modo === 'login') { const w = Math.min(460, aw), h = Math.min(700, ah); window.resizeTo(w, h); window.moveTo(ax + Math.round((aw - w) / 2), ay + Math.round((ah - h) / 2)); }
    else { window.moveTo(ax, ay); window.resizeTo(aw, ah); }
  } catch { /* navegador comum: ignora */ }
}
function mostrarLogin() { $('#app').classList.add('hidden'); $('#login').classList.remove('hidden'); limparTimer(); ajustarJanela('login'); $('#lg').focus(); }
async function entrar() {
  $('#login').classList.add('hidden'); $('#app').classList.remove('hidden'); ajustarJanela('app');
  $('#quem').textContent = `${S.user.nome} · ${S.user.perfil || ''}`; mostrarEmpresaTerminal();
  try { S.cfg = await api('/config'); } catch { S.cfg = {}; }
  montarMenu(); await rotear();
  if (typeof iniciarAtualizacao === 'function') iniciarAtualizacao();
}
// Recuperação de senha: pede o usuário (ou e-mail), manda um código ao e-mail cadastrado e redefine com o código.
function recuperarSenha() {
  let usuario = $('#lg').value.trim();
  const m1 = modal({ titulo: 'Recuperar senha', corpo: `<p>Informe seu usuário (ou o e-mail cadastrado). Enviaremos um código de 6 dígitos para o e-mail do seu cadastro e mostraremos (parcialmente) para qual e-mail foi.</p><label>Usuário ou e-mail<input id="rcu" value="${esc(usuario)}" autocomplete="off"></label>`,
    botoes: [{ txt: 'Cancelar' }, { txt: 'Enviar código', cls: 'primary', fn: async m => {
      usuario = $('#rcu', m.body).value.trim(); if (!usuario) throw new Error('Informe o usuário ou e-mail.');
      const r = await api('/senha/solicitar', { method: 'POST', body: { usuario } }); toast(r.mensagem, 'ok'); setTimeout(() => passo2(r.email), 50); } }] });
  const passo2 = em => modal({ titulo: 'Digite o código e a nova senha', corpo: `<p>Enviamos o código para <b>${esc(em || "o e-mail do seu cadastro")}</b>.</p><p class="muted">Confira também a caixa de spam. O código vale por 15 minutos.</p>
      <label>Código de 6 dígitos<input id="rcc" inputmode="numeric" maxlength="6" autocomplete="off"></label><label>Nova senha (mín. 4)<input id="rcn" type="password" autocomplete="off"></label><label>Repita a nova senha<input id="rcn2" type="password" autocomplete="off"></label>`,
    botoes: [{ txt: 'Cancelar' }, { txt: 'Redefinir senha', cls: 'primary', fn: async m => {
      const n = $('#rcn', m.body).value; if (n !== $('#rcn2', m.body).value) throw new Error('As senhas não conferem.');
      await api('/senha/redefinir', { method: 'POST', body: { usuario, codigo: $('#rcc', m.body).value, nova: n } }); toast('Senha redefinida. Entre com a nova senha.'); $('#ls').value = ''; $('#lg').value = usuario; } }] });
}
// Tela de entrada: ao clicar no campo Usuário lista os usuários ativos (número e nome); a partir de 2 letras filtra por nome ou número.
function ligarListaUsuarios() {
  const inp = $('#lg'); if (!inp || inp.dataset.lista) return; inp.dataset.lista = '1';
  const box = document.createElement('div'); box.className = 'ulista hidden'; inp.parentNode.style.position = 'relative'; inp.parentNode.appendChild(box);
  let lista = [], idx = -1;
  const pad = c => String(Number(c)), norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const filtra = () => { const q = norm(inp.value).trim(); return lista.filter(u => q.length < 2 || norm(u.nome).includes(q) || pad(u.codigo).startsWith(q.replace(/^0+/, '')) || String(u.codigo) === q.replace(/^0+/, '')); };
  const desenha = () => { const l = filtra(); if (!l.length && inp.value.trim().length >= 2) { box.classList.add('hidden'); return; }
    box.innerHTML = l.map((u, i) => `<button type="button" data-c="${u.codigo}" class="${i === idx ? 'on' : ''}"><b>${pad(u.codigo)}</b> ${esc(u.nome)}</button>`).join('') || '<div class="muted" style="padding:8px">Nenhum usuário ativo.</div>'; box.classList.remove('hidden'); };
  const abre = async () => { try { lista = await (await fetch('/api/login/usuarios', { cache: 'no-store' })).json(); } catch { lista = []; } idx = -1; desenha(); };
  const escolhe = c => { inp.value = pad(c); box.classList.add('hidden'); $('#ls').focus(); };
  inp.addEventListener('focus', abre); inp.addEventListener('click', () => { if (box.classList.contains('hidden')) abre(); });
  inp.addEventListener('input', () => { idx = -1; desenha(); });
  inp.addEventListener('keydown', e => { const n = filtra().length;
    if (e.key === 'ArrowDown' && n) { e.preventDefault(); idx = (idx + 1) % n; desenha(); }
    else if (e.key === 'ArrowUp' && n) { e.preventDefault(); idx = (idx - 1 + n) % n; desenha(); }
    else if (e.key === 'Enter' && idx >= 0 && !box.classList.contains('hidden')) { e.preventDefault(); escolhe(filtra()[idx].codigo); }
    else if (e.key === 'Escape') box.classList.add('hidden'); });
  box.addEventListener('mousedown', e => { const b = e.target.closest('[data-c]'); if (b) { e.preventDefault(); escolhe(b.dataset.c); } });
  inp.addEventListener('blur', () => setTimeout(() => box.classList.add('hidden'), 150));
}
async function iniciar() {
  ligarListaUsuarios();
  try { const j = await (await fetch('/api/saude')).json(); S.versao = j.versao; const v = $('#verlogin'); if (v && j.versao) v.textContent = 'Versão ' + j.versao; } catch { /* sem versão */ }
  // Menu lateral: fica parado se todos os itens cabem na tela; se não cabem, sobe junto com a rolagem até mostrar o fim do menu
  const ajustaMenu = () => { const m = $('#menu'); if (!m) return;
    if (window.innerWidth <= 900) { m.style.top = ''; return; }
    const folga = m.offsetHeight - window.innerHeight; m.style.top = folga > 0 ? -Math.min(window.scrollY, folga) + 'px' : '0px'; };
  window.addEventListener('scroll', ajustaMenu, { passive: true }); window.addEventListener('resize', ajustaMenu);
  try { new ResizeObserver(ajustaMenu).observe($('#menu')); } catch { }
  ajustaMenu();
  // Venda em andamento: não deixa sair da tela sem confirmar (a venda fica salva como pendente)
  S.hashAtual = location.hash;
  window.addEventListener('hashchange', async () => {
    if (location.hash === S.hashAtual) return;
    if (S.guarda && S.guarda()) {
      const novo = location.hash; location.hash = S.hashAtual;   // volta para a venda enquanto pergunta
      if (await confirmarSaidaVenda()) { S.guarda = null; S.hashAtual = novo; location.hash = novo; rotear(); }   // o hashchange dessa troca é ignorado (hash igual), por isso abre a tela aqui
      return;
    }
    S.hashAtual = location.hash; rotear();
  });
  const aplicarRecolhido = r => { $('#app').classList.toggle('recolhido', r); if (r) document.documentElement.style.setProperty('--menuw', '0px'); else document.documentElement.style.removeProperty('--menuw'); window.dispatchEvent(new Event('resize')); };
  try { if (localStorage.getItem('menuRecolhido') === '1' && window.innerWidth > 900) aplicarRecolhido(true); } catch { }
  $('#btnMenu').onclick = () => {
    if (window.innerWidth <= 900) return $('#menu').classList.toggle('open');   // celular/tela pequena: abre por cima
    const r = !$('#app').classList.contains('recolhido'); aplicarRecolhido(r);   // computador: recolhe e a tela ocupa o espaço
    try { localStorage.setItem('menuRecolhido', r ? '1' : '0'); } catch { }
  };
  // clicou fora do menu lateral (aberto): recolhe sozinho (computador) ou fecha (celular)
  document.addEventListener('click', e => {   // 'click' (e não 'pointerdown'): o layout só muda depois do clique, senão o botão sai de baixo do mouse e o clique se perde
    if (!S.token || !$('#app') || $('#app').classList.contains('hidden')) return;
    if (e.target.closest && (e.target.closest('#menu') || e.target.closest('#btnMenu'))) return;
    if (window.innerWidth <= 900) { if ($('#menu').classList.contains('open')) $('#menu').classList.remove('open'); return; }
    if (!$('#app').classList.contains('recolhido')) setTimeout(() => { aplicarRecolhido(true); try { localStorage.setItem('menuRecolhido', '1'); } catch { } }, 0);
  }, true);
  // modo noturno: a escolha fica guardada neste computador
  { const sw = $('#temaEscuro'), aplicar = esc => { if (esc) document.documentElement.setAttribute('data-tema', 'escuro'); else document.documentElement.removeAttribute('data-tema'); };
    sw.checked = document.documentElement.getAttribute('data-tema') === 'escuro';
    sw.onchange = () => { aplicar(sw.checked); try { localStorage.setItem('tema', sw.checked ? 'escuro' : 'claro'); } catch { /* */ } }; }
  $('#btnSair').onclick = async () => { if (S.guarda && S.guarda() && !(await confirmarSaidaVenda())) return; S.guarda = null; try { await api('/logout', { method: 'POST' }); } catch { /* */ } S.token = null; sessionStorage.removeItem('tk'); mostrarLogin(); };
  $('#btnSenha').onclick = () => formModal({ titulo: 'Alterar minha senha', campos: [{ k: 'atual', l: 'Senha atual', t: 'password', req: true, full: true }, { k: 'nova', l: 'Nova senha (mín. 4)', t: 'password', req: true, full: true }],
    onSave: async o => { await api('/me/senha', { method: 'POST', body: o }); toast('Senha alterada.'); } });
  $('#esqueci').onclick = e => { e.preventDefault(); recuperarSenha(); };
  $('#loginForm').onsubmit = async e => {
    e.preventDefault(); $('#lerr').textContent = '';
    try {
      const r = await api('/login', { method: 'POST', body: { login: $('#lg').value, senha: $('#ls').value } });
      S.token = r.token; S.user = r.user; sessionStorage.setItem('tk', r.token); $('#ls').value = ''; entrar();
    } catch (er) { $('#lerr').textContent = er.message; }
  };
  if (S.token) { try { S.user = await api('/me'); return entrar(); } catch { /* cai no login */ } }
  mostrarLogin();
}


// Senhas: o navegador nunca deve oferecer salvar usuário/senha. Todo <input type=password> vira texto mascarado, sem autopreenchimento.
(function () {
  const fix = el => { if (el.matches && el.matches('input[type=password]')) { el.type = 'text'; el.classList.add('pw'); el.setAttribute('autocomplete', 'off'); el.setAttribute('autocapitalize', 'off'); el.setAttribute('spellcheck', 'false'); } };
  // Campos de usuário/senha de AUTORIZAÇÃO (e senhas em janelas) nunca ficam preenchidos: sem sugestão do navegador e esvaziados se algo preencher sozinho.
  const cred = el => { if (!el.matches || !el.matches('input') || el.dataset.blindado) return;
    if (!(el.matches('[data-cred],[data-k=aut_login],[data-k=aut_senha]') || (el.classList.contains('pw') && el.closest('.modal')))) return;
    el.dataset.blindado = '1'; let digitou = false;
    el.setAttribute('autocomplete', el.classList.contains('pw') || /senha/i.test(el.dataset.k || el.id || '') ? 'new-password' : 'off'); el.setAttribute('name', 'x' + Math.random().toString(36).slice(2));
    const libera = () => { el.readOnly = false; }; ['focus', 'mousedown', 'touchstart', 'keydown'].forEach(ev => el.addEventListener(ev, libera));
    if (document.activeElement !== el) el.readOnly = true;
    ['keydown', 'paste', 'compositionstart'].forEach(ev => el.addEventListener(ev, () => { digitou = true; }));
    const limpa = () => { if (!digitou && el.value) el.value = ''; };
    limpa(); let n = 0; const t = setInterval(() => { limpa(); if (++n > 40 || digitou) clearInterval(t); }, 100); };
  const varre = no => { if (no.nodeType !== 1) return; fix(no); no.querySelectorAll && no.querySelectorAll('input[type=password]').forEach(fix); cred(no); no.querySelectorAll && no.querySelectorAll('input').forEach(cred); };
  new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(varre))).observe(document.documentElement, { childList: true, subtree: true });
  document.querySelectorAll('input[type=password]').forEach(fix);
})();

// Telas de venda e de entrada de mercadoria só abrem com a empresa cadastrada (Configurações → Empresa).
async function semEmpresa(el, acao = 'continuar') {
  let cfg = null; try { cfg = await api('/config'); S.cfg = cfg; } catch { return false; } // sem resposta: o servidor também bloqueia
  if (String(cfg.empresa || '').trim()) return false;
  el.innerHTML = `<div class="card"><h3>Empresa não cadastrada</h3><p>Para ${esc(acao)}, primeiro cadastre os dados da empresa (nome fantasia).</p>${tem('config.gerenciar') ? '<a class="btn primary" href="#/empresa">Cadastrar empresa</a>' : '<p class="muted">Peça a um administrador para cadastrar em Configurações → Empresa.</p>'}</div>`;
  el.onclick = null; return true;
}

// Pede usuário e senha (sempre em branco) e executa a ação; se a senha estiver errada, pergunta de novo sem perder o que já foi escolhido.
function confirmarCredenciais(titulo, acao) {
  return new Promise((resolve, reject) => {
    let feito = false;
    modal({ titulo, corpo: '<p class="muted">Informe usuário e senha de quem tem permissão para autorizar.</p><div class="row"><label>Usuário<input id="cl" data-cred autocomplete="off"></label><label>Senha<input id="cs" type="password" data-cred autocomplete="new-password"></label></div>',
      botoes: [{ txt: 'Cancelar', fn: async () => { feito = true; reject(new Error('Operação cancelada.')); } },
        { txt: 'Autorizar', cls: 'primary', fn: async m => {
          const l = $('#cl', m.body).value.trim(), sn = $('#cs', m.body).value; if (!l || !sn) throw new Error('Informe usuário e senha.');
          try { await acao({ login: l, senha: sn }); feito = true; resolve(); } catch (e) { $('#cs', m.body).value = ''; throw e; } } }],
      aoAbrir: m => { setTimeout(() => $('#cl', m.body)?.focus(), 50); } });
  }).catch(e => { if (e.message !== 'Operação cancelada.') throw e; });
}

// Padrão do sistema: campos de cadastro (nome, descrição, endereço...) digitam em MAIÚSCULAS. O servidor também converte ao salvar.
(() => {
  const K = new Set(['nome', 'razao', 'descricao', 'fantasia', 'endereco', 'cidade', 'bairro', 'complemento', 'contato', 'cargo', 'condicao_pagamento', 'bandeira', 'marca', 'modelo', 'local', 'responsavel', 'serie', 'uf', 'empresa', 'empresa_razao', 'empresa_endereco', 'empresa_cidade']);
  document.addEventListener('input', e => {
    const t = e.target; if (!t || !(t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) return;
    if (t.type && !['text', 'search', ''].includes(t.type) && t.tagName === 'INPUT') return;
    const k = t.dataset ? t.dataset.k : ''; if (!K.has(k) && !t.dataset.mai) return;
    const v = t.value, u = v.toLocaleUpperCase('pt-BR'); if (v === u) return;
    const a = t.selectionStart, b = t.selectionEnd; t.value = u; try { t.setSelectionRange(a, b); } catch { /* */ }
  }, true);
})();
