// Gerador mínimo de PDF (texto + linhas) sem dependências: fonte Helvetica, página A4. Usado nos relatórios (ex.: balanço de estoque).
const W = [278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,334,260,334,584];
const base = ch => ch.normalize('NFD').replace(/[̀-ͯ]/g, '');
const limpa = s => String(s == null ? '' : s).replace(/[—–]/g, '-').replace(/[“”]/g, '"').replace(/[‘’]/g, "'").replace(/[^\x09\x20-\x7E -ÿ]/g, '?');
function larg(s, size, bold) { let t = 0; for (const ch of limpa(s)) { const b = base(ch).charCodeAt(0); t += (b >= 32 && b <= 126 ? W[b - 32] : 556); } return t * size / 1000 * (bold ? 1.06 : 1); }
function cortar(s, max, size, bold) { s = limpa(s); if (larg(s, size, bold) <= max) return s; while (s.length > 1 && larg(s + '...', size, bold) > max) s = s.slice(0, -1); return s + '...'; }
const hex = s => Buffer.from(limpa(s), 'latin1').toString('hex');
const n = v => (Math.round(v * 100) / 100).toString();

function criar({ largura = 595.28, altura = 841.89, margem = 40 } = {}) {
  const paginas = []; let ops = null;
  const nova = () => { ops = []; paginas.push(ops); };
  nova();
  const api = {
    largura, altura, margem,
    nova,
    // (x, y) em pontos a partir do topo da página
    texto(x, y, s, { size = 10, bold = false, align = 'left', cor = 0, max = null } = {}) {
      let t = max ? cortar(s, max, size, bold) : limpa(s);
      const w = larg(t, size, bold); if (align === 'right') x -= w; else if (align === 'center') x -= w / 2;
      ops.push(`BT /${bold ? 'F2' : 'F1'} ${size} Tf ${cor} g ${n(x)} ${n(altura - y)} Td <${hex(t)}> Tj ET`);
    },
    linha(x1, y1, x2, y2, { w = 0.5, cinza = 0.6 } = {}) { ops.push(`${cinza} G ${w} w ${n(x1)} ${n(altura - y1)} m ${n(x2)} ${n(altura - y2)} l S`); },
    caixa(x, y, w, h, cinza = 0.9) { ops.push(`${cinza} g ${n(x)} ${n(altura - y - h)} ${n(w)} ${n(h)} re f 0 g`); },
    largura_texto: larg,
    total: () => paginas.length,
    // rodapé em todas as páginas: "Página x de y"
    build(rodape) {
      const tot = paginas.length;
      const objs = []; const add = s => { objs.push(s); return objs.length; };
      add('<< /Type /Catalog /Pages 2 0 R >>'); add(null); // 2 = Pages (preenchido depois)
      const f1 = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
      const f2 = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
      const kids = [];
      paginas.forEach((p, i) => {
        const extra = rodape ? `BT /F1 8 Tf 0.4 g ${n(largura - margem - larg(`Página ${i + 1} de ${tot}`, 8))} ${n(24)} Td <${hex(`Página ${i + 1} de ${tot}`)}> Tj ET BT /F1 8 Tf 0.4 g ${n(margem)} ${n(24)} Td <${hex(rodape)}> Tj ET\n` : '';
        const conteudo = Buffer.from(p.join('\n') + '\n' + extra, 'latin1');
        const c = add(`<< /Length ${conteudo.length} >>\nstream\n${conteudo.toString('latin1')}\nendstream`);
        const pg = add(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${n(largura)} ${n(altura)}] /Resources << /Font << /F1 ${f1} 0 R /F2 ${f2} 0 R >> >> /Contents ${c} 0 R >>`);
        kids.push(pg + ' 0 R');
      });
      objs[1] = `<< /Type /Pages /Kids [${kids.join(' ')}] /Count ${tot} >>`;
      let out = '%PDF-1.4\n'; const off = [];
      objs.forEach((o, i) => { off.push(Buffer.byteLength(out, 'latin1')); out += `${i + 1} 0 obj\n${o}\nendobj\n`; });
      const xref = Buffer.byteLength(out, 'latin1');
      out += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n` + off.map(o => String(o).padStart(10, '0') + ' 00000 n \n').join('') + `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
      return Buffer.from(out, 'latin1');
    },
  };
  return api;
}
module.exports = { criar, larg, cortar };
