// Mantém o iniciador do Windows (Abrir-LoPDV.vbs) atualizado e impede abrir o LoPDV duas vezes no mesmo computador.
// O texto vem de abrir.vbs.tpl; o instalador usa o mesmo modelo, e o servidor o reescreve ao iniciar (assim a atualização automática também o renova).
const fs = require('fs'), path = require('path');

function navegador() {
  const pf = process.env.ProgramFiles, pf86 = process.env['ProgramFiles(x86)'];
  return [pf && path.join(pf, 'Microsoft/Edge/Application/msedge.exe'), pf86 && path.join(pf86, 'Microsoft/Edge/Application/msedge.exe'),
    pf && path.join(pf, 'Google/Chrome/Application/chrome.exe'), pf86 && path.join(pf86, 'Google/Chrome/Application/chrome.exe')]
    .filter(Boolean).map(p => p.replace(/\//g, '\\')).find(p => { try { return fs.existsSync(p); } catch { return false; } });
}

function gerar({ dir, porta, nav }) {
  const tpl = fs.readFileSync(path.join(__dirname, 'abrir.vbs.tpl'), 'utf8');
  const perfil = dir + '\\data\\perfil-app';
  const url = 'http://localhost:' + porta + '/';
  const abrir = nav
    ? 'sh.Run """' + nav + '"" --app=' + url + ' --user-data-dir=""' + perfil + '"" --window-size=460,700 --disable-save-password-bubble --disable-features=PasswordManagerOnboarding,AutofillCreditCardSignin", 1, False'
    : 'sh.Run "' + url + '", 1, False';
  // sem navegador conhecido não há como saber se já está aberto: só vale a verificação do iniciador duplicado
  const verifica = nav ? 'If JaAberto() Then\r\n  On Error Resume Next\r\n  sh.AppActivate TITULO\r\n  On Error GoTo 0\r\n  MsgBox "O LoPDV já está aberto neste computador." & vbCrLf & vbCrLf & "Use a janela que já está aberta (veja na barra de tarefas).", 64 + 4096, TITULO\r\n  WScript.Quit\r\nEnd If' : '';
  return tpl.replace(/\r?\n/g, '\r\n').replace('@@PERFIL@@', perfil).replace(/@@PORTA@@/g, String(porta)).replace(/@@DIR@@/g, dir).replace('@@VERIFICA@@', verifica).replace('@@ABRIR@@', abrir);
}

function atualizar(porta) {
  if (process.platform !== 'win32') return false;
  try {
    const dir = path.resolve(__dirname, '..');
    if (!fs.existsSync(path.join(dir, 'servidor.cmd'))) return false; // só onde foi instalado pelo instalador
    const alvo = path.join(dir, 'Abrir-LoPDV.vbs');
    const novo = Buffer.from(gerar({ dir, porta, nav: navegador() }), 'latin1');
    let atual = null; try { atual = fs.readFileSync(alvo); } catch { /* */ }
    if (atual && atual.equals(novo)) return false;
    fs.writeFileSync(alvo, novo); return true;
  } catch (e) { console.error('Iniciador:', e.message); return false; }
}

// já existe um LoPDV respondendo nesta porta? (evita um segundo servidor mexendo no mesmo banco)
function portaEmUso(porta) {
  return new Promise(resolve => {
    const s = require('net').connect({ port: porta, host: '127.0.0.1' });
    s.setTimeout(1500);
    s.on('connect', () => { s.destroy(); resolve(true); });
    s.on('timeout', () => { s.destroy(); resolve(false); });
    s.on('error', () => resolve(false));
  });
}
module.exports = { gerar, atualizar, navegador, portaEmUso };
