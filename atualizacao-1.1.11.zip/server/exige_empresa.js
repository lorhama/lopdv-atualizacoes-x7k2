// Sem empresa cadastrada (Configurações → Empresa) não se vende nem se dá entrada de mercadoria.
const db = require('./db');
const { HttpError } = require('./util');
module.exports = async function exigeEmpresa() {
  const x = (await db.q("select valor from config where chave='empresa'")).rows[0];
  if (!x || !String(x.valor || '').trim()) throw new HttpError(409, 'Cadastre a empresa em Configurações → Empresa antes de continuar.', { codigo: 'EMPRESA_NAO_CADASTRADA' });
};
