// Gera o instalador de atalho (.bat) para os terminais: baixa o ícone do servidor e cria o atalho na área de trabalho.
function gerarBat(host) {
  const ps = [
    `$h='${host}'; $u='http://'+$h+'/'`,
    `$d=Join-Path $env:APPDATA 'LoPDV'; New-Item -Force -ItemType Directory $d | Out-Null`,
    `$ico=Join-Path $d 'icone.ico'; Invoke-WebRequest -UseBasicParsing ($u+'icone.ico') -OutFile $ico`,
    `$desk=[Environment]::GetFolderPath('Desktop')`,
    `$edge=Join-Path ${'${env:ProgramFiles(x86)}'} 'Microsoft\\Edge\\Application\\msedge.exe'`,
    `if(Test-Path $edge){ $s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $desk 'LoPDV.lnk')); $s.TargetPath=$edge; $s.Arguments='--app='+$u; $s.IconLocation=$ico; $s.Description='LoPDV'; $s.Save() }`,
    `else { Set-Content -Encoding ASCII (Join-Path $desk 'LoPDV.url') ('[InternetShortcut]'+[Environment]::NewLine+'URL='+$u+[Environment]::NewLine+'IconFile='+$ico+[Environment]::NewLine+'IconIndex=0') }`,
  ].join('; ');
  return ['@echo off', 'chcp 65001 >nul', 'echo Instalando o atalho do LoPDV...',
    `powershell -NoProfile -ExecutionPolicy Bypass -Command "${ps.replace(/"/g, '\\"')}"`,
    'if errorlevel 1 (echo Nao foi possivel instalar. Verifique se o servidor esta ligado e na mesma rede. & pause & exit /b 1)',
    'echo Pronto! O atalho "LoPDV" foi criado na area de trabalho.', 'pause', ''].join('\r\n');
}
module.exports = { gerarBat };
