// PostgreSQL embutido: se o instalador trouxe os binários, o próprio sistema cria, inicia e para o banco.
const { execFile } = require('child_process');
const fs = require('fs'), path = require('path');
const exe = n => (process.platform === 'win32' ? n + '.exe' : n);
const PORTA = 54329;
let raiz = null, bin = null, senhaAdmin = null;

function achar() {
  const c = [process.env.GESTAO_PG_DIR, process.resourcesPath && path.join(process.resourcesPath, 'pgsql'), path.join(__dirname, '..', 'vendor', 'pgsql')].filter(Boolean);
  return c.find(d => fs.existsSync(path.join(d, 'bin', exe('postgres'))));
}
const run = (cmd, args, env = {}) => new Promise((res, rej) => execFile(path.join(bin, 'bin', exe(cmd)), args, { windowsHide: true, env: { ...process.env, ...env }, maxBuffer: 1e7 }, (e, so, se) => (e ? rej(new Error((se || so || e.message).toString().trim())) : res(so))));

async function rodando() { try { await run('pg_ctl', ['-D', raiz, 'status']); return true; } catch { return false; } }

// Cria o cluster na primeira vez, inicia o servidor e garante banco/usuário do sistema. Atualiza o config.json.
async function iniciar(cfgmod, db) {
  bin = achar(); if (!bin) return { embutido: false };
  raiz = path.join(cfgmod.DIR, 'pgdata');
  const cfg = cfgmod.load();
  const pg = cfg.pg || {};
  senhaAdmin = 'postgres123'; // padrão pedido: usuário postgres / senha postgres123 (banco só escuta em 127.0.0.1)
  const senhaApp = senhaAdmin;
  if (!fs.existsSync(path.join(raiz, 'PG_VERSION'))) {
    fs.mkdirSync(cfgmod.DIR, { recursive: true });
    const pw = path.join(cfgmod.DIR, '.pgpw'); fs.writeFileSync(pw, senhaAdmin);
    try { await run('initdb', ['-D', raiz, '-U', 'postgres', '-A', 'scram-sha-256', '--pwfile=' + pw, '-E', 'UTF8']); }
    finally { try { fs.unlinkSync(pw); } catch { /* */ } }
  }
  if (!(await rodando())) await run('pg_ctl', ['-D', raiz, '-o', `-p ${PORTA} -c listen_addresses=127.0.0.1`, '-l', path.join(raiz, 'servidor.log'), '-w', '-t', '90', 'start']);
  await db.ensure({ host: '127.0.0.1', port: PORTA, adminUser: 'postgres', adminPass: senhaAdmin, dbName: 'gestao', appUser: 'postgres', appPass: senhaApp });
  cfg.pg = { porta: PORTA };
  cfg.db = { host: '127.0.0.1', port: PORTA, user: 'postgres', password: senhaApp, database: 'gestao' };
  cfgmod.save(cfg);
  return { embutido: true };
}

async function parar() { if (bin && raiz && await rodando()) { try { await run('pg_ctl', ['-D', raiz, '-m', 'fast', '-w', 'stop']); } catch { /* */ } } }

// Backup diário (mantém os 14 mais recentes) em <dados>/backups
async function backup(cfgmod) {
  if (!bin || !(await rodando())) return;
  const dir = path.join(cfgmod.DIR, 'backups'); fs.mkdirSync(dir, { recursive: true });
  const f = path.join(dir, `gestao-${new Date().toISOString().slice(0, 10)}.dump`);
  if (fs.existsSync(f)) return;
  await run('pg_dump', ['-h', '127.0.0.1', '-p', String(PORTA), '-U', 'postgres', '-F', 'c', '-f', f, 'gestao'], { PGPASSWORD: senhaAdmin });
  fs.readdirSync(dir).filter(x => x.endsWith('.dump')).sort().slice(0, -14).forEach(x => fs.unlinkSync(path.join(dir, x)));
}
module.exports = { iniciar, parar, backup, achar };
