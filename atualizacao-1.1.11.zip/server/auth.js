const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const db = require('./db');
const { HttpError, wrap } = require('./util');

const can = (user, perm) => !!user && (user.perms.includes('*') || user.perms.includes(perm));

async function criarSessao(userId) {
  const token = crypto.randomBytes(24).toString('hex');
  await db.q("insert into sessoes(token, usuario_id, expira_em) values($1,$2, now() + interval '12 hours')", [token, userId]);
  return token;
}

// Durante um evento (caixa aberto), quem está na equipe do evento usa SÓ as permissões da função que recebeu naquele dia.
// Administrador (acesso total) nunca é restringido. Quando o caixa fecha, volta ao perfil do cadastro.
async function aplicarEvento(user) {
  if (!user || (user.perms || []).includes('*')) return user;
  const e = (await db.q(`select p.nome perfil, coalesce(p.permissoes,'{}') perms, ev.nome evento from evento_equipe ee join eventos ev on ev.id=ee.evento_id
    join caixas c on c.id=ev.caixa_id and c.status='aberto' join perfis p on p.id=ee.perfil_id where ee.usuario_id=$1 limit 1`, [user.id])).rows[0];
  if (e) { user.perms_cadastro = user.perms; user.perms = e.perms; user.funcao_evento = e.perfil; user.evento = e.evento; user.perfil = e.perfil + ' · evento ' + e.evento; }
  return user;
}

// Middleware: exige login e (opcionalmente) uma permissão. perm pode ser string ou lista (qualquer uma).
function auth(perm) {
  return wrap(async (req, res, next) => {
    const tk = (req.headers.authorization || '').replace(/^Bearer /, '');
    if (!tk) throw new HttpError(401, 'Faça login para continuar.');
    const r = await db.q(`select u.id, u.codigo, u.nome, u.login, u.ativo, p.nome perfil, coalesce(p.permissoes,'{}') perms
      from sessoes s join usuarios u on u.id=s.usuario_id left join perfis p on p.id=u.perfil_id
      where s.token=$1 and s.expira_em > now()`, [tk]);
    if (!r.rowCount || !r.rows[0].ativo) throw new HttpError(401, 'Sessão expirada. Faça login novamente.');
    req.user = await aplicarEvento(r.rows[0]); req.token = tk;
    if (perm) {
      const lista = Array.isArray(perm) ? perm : [perm];
      if (!lista.some(p => can(req.user, p))) throw new HttpError(403, 'Você não tem permissão para esta função (' + lista.join(' ou ') + ').');
    }
    next();
  });
}

// Autorização de supervisor: confere usuário/senha digitados na tela e se ele possui a permissão.
async function verificarAutorizacao(cli, aut, perm) {
  if (!aut || !aut.login || !aut.senha) throw new HttpError(403, 'Informe usuário e senha do autorizador.', { codigo: 'AUTORIZACAO_INVALIDA' });
  const r = await cli.query(`select u.id, u.nome, u.senha_hash, u.ativo, coalesce(p.permissoes,'{}') perms
    from usuarios u left join perfis p on p.id=u.perfil_id where lower(u.login)=lower($1)`, [aut.login]);
  const u = r.rows[0];
  if (!u || !u.ativo || !bcrypt.compareSync(String(aut.senha), u.senha_hash))
    throw new HttpError(403, 'Usuário ou senha do autorizador inválidos.', { codigo: 'AUTORIZACAO_INVALIDA' });
  if (!can({ perms: u.perms }, perm))
    throw new HttpError(403, `O usuário ${u.nome} não tem permissão para autorizar esta operação.`, { codigo: 'AUTORIZACAO_INVALIDA' });
  return { id: u.id, nome: u.nome };
}

async function auditar(cli, user, acao, detalhe) {
  const sql = 'insert into auditoria(usuario_id, usuario_nome, acao, detalhe) values($1,$2,$3,$4)';
  const params = [user?.id || null, user?.nome || null, acao, JSON.stringify(detalhe || {})];
  if (cli) await cli.query(sql, params); else await db.q(sql, params);
}

module.exports = { aplicarEvento, can, auth, criarSessao, verificarAutorizacao, auditar, bcrypt };
