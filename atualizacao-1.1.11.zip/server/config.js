const fs = require('fs');
const path = require('path');
const DIR = process.env.GESTAO_DATA_DIR || path.join(__dirname, '..', 'data');
const FILE = path.join(DIR, 'config.json');
const PADRAO = {
  porta: 3737,
  db: { host: 'localhost', port: 5432, user: 'gestao', password: 'gestao', database: 'gestao' },
};
function load() {
  let c = {};
  try { c = JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { /* primeira execução */ }
  const cfg = { ...PADRAO, ...c, db: { ...PADRAO.db, ...(c.db || {}) } };
  if (process.env.GESTAO_PORT) cfg.porta = Number(process.env.GESTAO_PORT);
  if (process.env.DATABASE_HOST) cfg.db.host = process.env.DATABASE_HOST;
  if (process.env.DATABASE_PORT) cfg.db.port = Number(process.env.DATABASE_PORT);
  if (process.env.DATABASE_USER) cfg.db.user = process.env.DATABASE_USER;
  if (process.env.DATABASE_PASSWORD) cfg.db.password = process.env.DATABASE_PASSWORD;
  if (process.env.DATABASE_NAME) cfg.db.database = process.env.DATABASE_NAME;
  return cfg;
}
function save(cfg) {
  fs.mkdirSync(DIR, { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(cfg, null, 2));
}
module.exports = { load, save, DIR, FILE };
