// Leitura OFFLINE de foto de nota de compra (OCR) e interpretação dos itens. Nada sai do computador.
// Motor 1: programa "tesseract" instalado na máquina (se houver). Motor 2: biblioteca tesseract.js (instalada com o sistema), usando o
// idioma português que acompanha o sistema em server/ocr/por.traineddata.
const fs = require('fs'), os = require('os'), path = require('path'), cp = require('child_process');
const DIR = path.join(__dirname, 'ocr');

function acharExe() {
  const cand = [process.env.LOPDV_TESSERACT, 'tesseract', 'C:\\Program Files\\Tesseract-OCR\\tesseract.exe', 'C:\\Program Files (x86)\\Tesseract-OCR\\tesseract.exe'].filter(Boolean);
  for (const c of cand) {
    try { const r = cp.spawnSync(c, ['--version'], { timeout: 8000, windowsHide: true }); if (r.status === 0) return c; } catch { /* próximo */ }
  }
  return null;
}

function rodarExe(exe, arq, psm) {
  return new Promise((ok, err) => cp.execFile(exe, [arq, 'stdout', '-l', 'por', '--tessdata-dir', DIR, '--psm', String(psm)], { timeout: 120000, maxBuffer: 20e6, windowsHide: true }, (e, out) => (e ? err(e) : ok(String(out)))));
}

async function viaTesseractJs(buf) {
  let T; try { T = require('tesseract.js'); } catch { return null; }
  const w = await T.createWorker('por', 1, { langPath: DIR, gzip: false, cacheMethod: 'none' });
  try { await w.setParameters({ tessedit_pageseg_mode: '6', preserve_interword_spaces: '1' }); } catch { /* opcional */ }
  try { const r = await w.recognize(buf); return r.data.text; } finally { try { await w.terminate(); } catch { /* */ } }
}

// Devolve { texto, motor }. Lança erro com mensagem clara se nenhum motor estiver disponível.
async function lerImagem(buf) {
  const exe = acharExe();
  if (exe) {
    const arq = path.join(os.tmpdir(), 'lopdv-ocr-' + process.pid + '-' + Date.now() + '.img');
    fs.writeFileSync(arq, buf);
    try {
      let melhor = '', n = -1;
      for (const psm of [6, 4]) { const t = await rodarExe(exe, arq, psm); const k = interpretar(t).length; if (k > n || (k === n && t.length > melhor.length)) { melhor = t; n = k; } if (n >= 3) break; }
      return { texto: melhor, motor: 'tesseract' };
    } finally { try { fs.unlinkSync(arq); } catch { /* */ } }
  }
  const t = await viaTesseractJs(buf);
  if (t !== null) return { texto: t, motor: 'tesseract.js' };
  const e = new Error('O leitor offline (OCR) ainda não está instalado neste computador. Atualize o sistema (a atualização instala o leitor) ou instale o Tesseract.'); e.status = 501; throw e;
}

// ---------- interpretação do texto ----------
const UNS = new Set(['UN', 'UND', 'UNID', 'PC', 'PÇ', 'PCT', 'PT', 'CX', 'FD', 'FARDO', 'KG', 'G', 'GR', 'L', 'LT', 'ML', 'DZ', 'SC', 'PAC', 'GF', 'LA', 'BD', 'TP']);
const IGNORA = /\b(TOTAL|SUBTOTAL|TROCO|ICMS|PIS|COFINS|CNPJ|CPF|CHAVE|PROTOCOLO|FRETE|DESCONTO|PAGAMENTO|EMISS|DANFE|VENCIMENTO|PARCELA|DUPLICATA|TRANSPORTADOR|IMPOSTOS|TRIBUTOS|S[ÉE]RIE|INSCRI)/i;
const numRe = /^\d{1,3}(\.\d{3})*,\d{1,4}$|^\d+,\d{1,4}$|^\d+\.\d{1,4}$|^\d+$/;
const toN = s => { s = String(s).trim(); if (/,/.test(s)) s = s.replace(/\./g, '').replace(',', '.'); return parseFloat(s); };
const r2 = x => Math.round(x * 100) / 100;
const semAcento = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '');

function interpretar(texto) {
  const out = [];
  for (const bruta of String(texto || '').split(/\r?\n/)) {
    const linha = bruta.replace(/[|\[\]{}_~“”"]/g, ' ').replace(/\s+/g, ' ').trim();
    if (linha.length < 8 || IGNORA.test(linha)) continue;
    // separa "6,0000/9,9500", tira pontuação solta nas pontas ("12,0000." / "UN:")
    const tk = linha.replace(/(\d)['`´](?=[A-Za-z])/g, '$1 ').replace(/(\d)\/(\d)/g, '$1 $2').split(' ').map(x => x.replace(/^[.:;,'`]+|[.:;'`]+$/g, '')).filter(Boolean);
    const nums = tk.map((t, i) => (numRe.test(t) ? i : -1)).filter(i => i >= 0);
    if (nums.length < 2) continue;
    let q, u, t, ini = -1, conferir = false;
    // 1) três números seguidos em que qtd × unitário = total
    for (let a = 0; a + 2 < nums.length && ini < 0; a++) {
      const [i, j, k] = [nums[a], nums[a + 1], nums[a + 2]];
      if (j !== i + 1 || k !== j + 1) continue;
      const qq = toN(tk[i]), uu = toN(tk[j]), tt = toN(tk[k]);
      if (qq > 0 && uu > 0 && /[,.]/.test(tk[j]) && Math.abs(qq * uu - tt) <= Math.max(0.03, tt * 0.01)) { q = qq; u = uu; t = tt; ini = i; }
    }
    // 2) três números seguidos que quase fecham (OCR errou um dígito): usa quantidade e total e recalcula o unitário — fica marcado "conferir"
    for (let a = 0; a + 2 < nums.length && ini < 0; a++) {
      const [i, j, k] = [nums[a], nums[a + 1], nums[a + 2]];
      if (j !== i + 1 || k !== j + 1 || !/[,.]/.test(tk[j]) || !/[,.]/.test(tk[k])) continue;
      const qq = toN(tk[i]), uu = toN(tk[j]), tt = toN(tk[k]);
      if (qq > 0 && uu > 0 && tt > 0 && Math.abs(qq * uu - tt) <= tt * 0.15) { q = qq; u = tt / qq; t = tt; ini = i; conferir = true; }
    }
    // 3) só unitário e total no fim da linha (quantidade = total ÷ unitário, só se der número inteiro/meio)
    if (ini < 0) {
      const dec = nums.filter(i => /[,.]/.test(tk[i]));
      if (dec.length >= 2) {
        const j = dec[dec.length - 2], k = dec[dec.length - 1]; const uu = toN(tk[j]), tt = toN(tk[k]);
        if (uu > 0 && tt >= uu - 0.005 && k === j + 1) {
          const qq = tt / uu; if (Math.abs(qq - Math.round(qq * 2) / 2) < 0.02) { u = uu; t = tt; q = Math.round(qq * 2) / 2; ini = j; }
        }
      }
    }
    if (ini < 0) continue;
    // descrição = tudo antes dos números, sem códigos fiscais soltos e sem a unidade
    let ds = tk.slice(0, ini);
    let un = '';
    while (ds.length && (UNS.has(semAcento(ds[ds.length - 1]).toUpperCase().replace(/\.$/, '')) || /^\d{3,8}$/.test(ds[ds.length - 1]) || /^[0-9]{1,2}[,.]?[0-9]*%?$/.test(ds[ds.length - 1]))) {
      const x = ds.pop(); const up = semAcento(x).toUpperCase().replace(/\.$/, ''); if (UNS.has(up) && !un) un = up;
    }
    let codigo = '';
    if (ds.length > 1 && /^\d{4,14}$/.test(ds[0])) codigo = ds.shift();
    const desc = ds.join(' ').replace(/^[\d\s.,x*×-]{1,6}(?=[A-Za-zÀ-ú])/, '').trim();
    if ((desc.match(/[A-Za-zÀ-ú]/g) || []).length < 3) continue;
    out.push({ codigo, descricao: desc, un, qtd: Math.round(q * 1000) / 1000, valor_unit: Math.round(u * 10000) / 10000, total: r2(t), conferir });
  }
  return out;
}

// ---------- casamento com o cadastro de produtos ----------
const norm = s => semAcento(s).toLowerCase().replace(/\b(un|und|unid|pct|cx|kg|g|ml|l|lt|c\/|com)\b/g, ' ').replace(/[^a-z0-9]+/g, ' ').trim();
const toks = s => new Set(norm(s).split(' ').filter(x => x.length > 1));
function similar(a, b) { const A = toks(a), B = toks(b); if (!A.size || !B.size) return 0; let n = 0; A.forEach(x => { if (B.has(x)) n++; }); return 2 * n / (A.size + B.size); }
function casar(itens, produtos) { // produtos: [{id,codigo,nome,codigos_barras:[]}]
  const porCod = new Map(); produtos.forEach(p => { if (p.codigo) porCod.set(String(p.codigo).toLowerCase(), p); (p.codigos_barras || []).forEach(b => porCod.set(String(b), p)); });
  return itens.map(it => {
    let p = it.codigo ? porCod.get(it.codigo.toLowerCase()) : null, conf = p ? 1 : 0;
    if (!p) { let melhor = null, s = 0; for (const x of produtos) { const v = similar(it.descricao, x.nome); if (v > s) { s = v; melhor = x; } } if (melhor && s >= 0.5) { p = melhor; conf = Math.round(s * 100) / 100; } }
    return { ...it, produto_id: p ? p.id : null, produto_nome: p ? p.nome : null, confianca: conf };
  });
}
module.exports = { lerImagem, interpretar, casar, acharExe, similar };
