CREATE TABLE IF NOT EXISTS perfis(
  id serial PRIMARY KEY, nome text UNIQUE NOT NULL,
  permissoes text[] NOT NULL DEFAULT '{}', criado_em timestamptz DEFAULT now());

CREATE TABLE IF NOT EXISTS usuarios(
  id serial PRIMARY KEY, nome text NOT NULL, login text UNIQUE NOT NULL,
  senha_hash text NOT NULL, perfil_id int REFERENCES perfis(id),
  ativo boolean NOT NULL DEFAULT true, telefone text, cargo text,
  criado_em timestamptz DEFAULT now());

CREATE TABLE IF NOT EXISTS sessoes(
  token text PRIMARY KEY, usuario_id int REFERENCES usuarios(id) ON DELETE CASCADE,
  criado_em timestamptz DEFAULT now(), expira_em timestamptz NOT NULL);

CREATE TABLE IF NOT EXISTS auditoria(
  id bigserial PRIMARY KEY, usuario_id int, usuario_nome text, acao text NOT NULL,
  detalhe jsonb, criado_em timestamptz DEFAULT now());

CREATE TABLE IF NOT EXISTS config(chave text PRIMARY KEY, valor text);

CREATE TABLE IF NOT EXISTS categorias(id serial PRIMARY KEY, nome text UNIQUE NOT NULL);

CREATE TABLE IF NOT EXISTS produtos(
  id serial PRIMARY KEY, codigo text UNIQUE, codigo_barras text, nome text NOT NULL,
  categoria_id int REFERENCES categorias(id),
  unidade text NOT NULL DEFAULT 'UN',
  tipo text NOT NULL DEFAULT 'revenda' CHECK (tipo IN ('revenda','insumo','preparado')),
  destino text NOT NULL DEFAULT 'nenhum' CHECK (destino IN ('cozinha','bar','nenhum')),
  preco_venda numeric(14,2) NOT NULL DEFAULT 0,
  custo_medio numeric(14,4) NOT NULL DEFAULT 0,
  estoque_atual numeric(14,3) NOT NULL DEFAULT 0,
  estoque_minimo numeric(14,3) NOT NULL DEFAULT 0,
  controla_estoque boolean NOT NULL DEFAULT true,
  vendavel boolean NOT NULL DEFAULT true,
  ativo boolean NOT NULL DEFAULT true,
  criado_em timestamptz DEFAULT now());

CREATE TABLE IF NOT EXISTS receitas(
  produto_id int REFERENCES produtos(id) ON DELETE CASCADE,
  insumo_id int REFERENCES produtos(id),
  quantidade numeric(14,4) NOT NULL,
  PRIMARY KEY(produto_id, insumo_id));

CREATE TABLE IF NOT EXISTS clientes(
  id serial PRIMARY KEY, nome text NOT NULL, documento text, telefone text,
  email text, endereco text, observacao text, ativo boolean NOT NULL DEFAULT true);

CREATE TABLE IF NOT EXISTS fornecedores(
  id serial PRIMARY KEY, nome text NOT NULL, fantasia text, documento text UNIQUE,
  contato text, telefone text, email text, endereco text, cidade text, uf text,
  condicao_pagamento text, observacao text, ativo boolean NOT NULL DEFAULT true);

CREATE TABLE IF NOT EXISTS de_para(
  fornecedor_doc text, codigo_fornecedor text,
  produto_id int REFERENCES produtos(id) ON DELETE CASCADE,
  fator numeric(14,4) DEFAULT 1,
  PRIMARY KEY(fornecedor_doc, codigo_fornecedor));

CREATE TABLE IF NOT EXISTS entradas(
  id serial PRIMARY KEY, fornecedor_id int REFERENCES fornecedores(id),
  numero text, chave text UNIQUE, origem text CHECK (origem IN ('xml','manual')),
  total numeric(14,2) DEFAULT 0, data_emissao date, observacao text,
  usuario_id int, criado_em timestamptz DEFAULT now());

CREATE TABLE IF NOT EXISTS entrada_itens(
  id serial PRIMARY KEY, entrada_id int REFERENCES entradas(id) ON DELETE CASCADE,
  produto_id int REFERENCES produtos(id), quantidade numeric(14,3) NOT NULL,
  custo_unit numeric(14,4) NOT NULL);

CREATE TABLE IF NOT EXISTS mov_estoque(
  id bigserial PRIMARY KEY, produto_id int REFERENCES produtos(id),
  tipo text NOT NULL, quantidade numeric(14,3) NOT NULL, custo_unit numeric(14,4),
  saldo_apos numeric(14,3), origem text, ref_id int, motivo text, usuario_id int,
  criado_em timestamptz DEFAULT now());
CREATE INDEX IF NOT EXISTS ix_mov_prod ON mov_estoque(produto_id, criado_em);
CREATE INDEX IF NOT EXISTS ix_mov_data ON mov_estoque(criado_em);
CREATE INDEX IF NOT EXISTS ix_mov_ref ON mov_estoque(origem, ref_id);

CREATE TABLE IF NOT EXISTS caixas(
  id serial PRIMARY KEY, usuario_id int REFERENCES usuarios(id),
  aberto_em timestamptz DEFAULT now(), fechado_em timestamptz,
  valor_abertura numeric(14,2) DEFAULT 0, valor_informado numeric(14,2),
  valor_esperado numeric(14,2), status text DEFAULT 'aberto');

CREATE TABLE IF NOT EXISTS caixa_mov(
  id serial PRIMARY KEY, caixa_id int REFERENCES caixas(id),
  tipo text CHECK (tipo IN ('sangria','suprimento')), valor numeric(14,2) NOT NULL,
  motivo text, usuario_id int, criado_em timestamptz DEFAULT now());

CREATE TABLE IF NOT EXISTS pedidos(
  id serial PRIMARY KEY, tipo text DEFAULT 'mesa', mesa text,
  cliente_id int REFERENCES clientes(id),
  status text DEFAULT 'aberto' CHECK (status IN ('aberto','fechado','cancelado')),
  usuario_id int REFERENCES usuarios(id), caixa_id int REFERENCES caixas(id),
  desconto numeric(14,2) DEFAULT 0, total numeric(14,2) DEFAULT 0, observacao text,
  motivo_cancelamento text, aberto_em timestamptz DEFAULT now(), fechado_em timestamptz);
CREATE INDEX IF NOT EXISTS ix_ped_status ON pedidos(status, fechado_em);

CREATE TABLE IF NOT EXISTS pedido_itens(
  id serial PRIMARY KEY, pedido_id int REFERENCES pedidos(id) ON DELETE CASCADE,
  produto_id int REFERENCES produtos(id), nome text,
  quantidade numeric(14,3) NOT NULL, preco_unit numeric(14,2) NOT NULL,
  custo_unit numeric(14,4) DEFAULT 0, destino text,
  status text DEFAULT 'novo' CHECK (status IN ('novo','enviado','retirado','cancelado')),
  observacao text, usuario_id int, criado_em timestamptz DEFAULT now(),
  enviado_em timestamptz, retirado_em timestamptz, retirado_por int,
  cancelado_em timestamptz, cancelado_por int, motivo_cancelamento text,
  autorizado_por int);
CREATE INDEX IF NOT EXISTS ix_item_ped ON pedido_itens(pedido_id);
CREATE INDEX IF NOT EXISTS ix_item_status ON pedido_itens(status, destino);

CREATE TABLE IF NOT EXISTS pagamentos(
  id serial PRIMARY KEY, pedido_id int REFERENCES pedidos(id),
  caixa_id int REFERENCES caixas(id), forma text NOT NULL,
  valor numeric(14,2) NOT NULL, criado_em timestamptz DEFAULT now());

CREATE TABLE IF NOT EXISTS titulos(
  id serial PRIMARY KEY, tipo text CHECK (tipo IN ('pagar','receber')),
  descricao text NOT NULL, categoria text, fornecedor_id int, cliente_id int,
  entrada_id int, pedido_id int, valor numeric(14,2) NOT NULL, vencimento date NOT NULL,
  status text DEFAULT 'aberto' CHECK (status IN ('aberto','pago','cancelado')),
  pago_em date, valor_pago numeric(14,2), forma text, criado_em timestamptz DEFAULT now());

CREATE TABLE IF NOT EXISTS impressoras(
  id serial PRIMARY KEY, nome text NOT NULL,
  destino text CHECK (destino IN ('cozinha','bar','caixa')),
  ip text NOT NULL, porta int DEFAULT 9100, colunas int DEFAULT 42,
  ativo boolean NOT NULL DEFAULT true);

-- Formas de pagamento (cadastro) + integração TEF por troca de arquivos (pastas)
CREATE TABLE IF NOT EXISTS formas_pagamento(
  id serial PRIMARY KEY, codigo text UNIQUE NOT NULL, descricao text NOT NULL,
  tipo text NOT NULL CHECK (tipo IN ('dinheiro','pix','debito','credito','voucher','fiado','outro')),
  ativo boolean DEFAULT true, ordem int DEFAULT 0,
  max_parcelas int DEFAULT 1, taxa_pct numeric(6,3) DEFAULT 0, dias_recebimento int DEFAULT 0, bandeira text,
  tef_ativo boolean DEFAULT false, tef_rede text, tef_vias int DEFAULT 1, tef_timeout int DEFAULT 120,
  tef_dir_envio text, tef_arq_envio text DEFAULT 'IntPos', tef_ext_envio text DEFAULT '001',
  tef_dir_retorno text, tef_arq_retorno text DEFAULT 'IntPos', tef_ext_retorno text DEFAULT '001',
  tef_dir_status text, tef_arq_status text DEFAULT 'IntPos', tef_ext_status text DEFAULT 'sts',
  tef_dir_temp text, tef_arq_temp text DEFAULT 'IntPos', tef_ext_temp text DEFAULT 'pod',
  tef_dir_exec text);
INSERT INTO formas_pagamento(codigo, descricao, tipo, ordem) VALUES
  ('dinheiro','Dinheiro','dinheiro',1), ('pix','PIX','pix',2), ('debito','Cartão de débito','debito',3),
  ('credito','Cartão de crédito','credito',4), ('voucher','Voucher / Vale','voucher',5), ('fiado','Fiado (cliente)','fiado',6)
  ON CONFLICT (codigo) DO NOTHING;
ALTER TABLE pagamentos ADD COLUMN IF NOT EXISTS parcelas int;
ALTER TABLE pagamentos ADD COLUMN IF NOT EXISTS tef_nsu text;
ALTER TABLE pagamentos ADD COLUMN IF NOT EXISTS tef_autorizacao text;
ALTER TABLE pagamentos ADD COLUMN IF NOT EXISTS tef_rede text;
ALTER TABLE formas_pagamento ADD COLUMN IF NOT EXISTS tef_provedor text;

-- Caixa: fechamento por forma de pagamento, divergência e recebimento de fiado
ALTER TABLE caixas ADD COLUMN IF NOT EXISTS motivo_divergencia text;
ALTER TABLE caixas ADD COLUMN IF NOT EXISTS diferenca numeric(14,2);
CREATE TABLE IF NOT EXISTS caixa_fechamento(
  caixa_id int REFERENCES caixas(id) ON DELETE CASCADE, forma text NOT NULL,
  informado numeric(14,2) NOT NULL, PRIMARY KEY (caixa_id, forma));
ALTER TABLE pagamentos ADD COLUMN IF NOT EXISTS titulo_id int REFERENCES titulos(id);
ALTER TABLE pagamentos ADD COLUMN IF NOT EXISTS origem text DEFAULT 'venda';
CREATE INDEX IF NOT EXISTS ix_pag_caixa ON pagamentos(caixa_id);
CREATE INDEX IF NOT EXISTS ix_pag_titulo ON pagamentos(titulo_id);

-- Gestão de versão: histórico das versões do sistema que rodaram neste banco
CREATE TABLE IF NOT EXISTS versoes(id serial PRIMARY KEY, versao text NOT NULL, aplicado_em timestamptz DEFAULT now());

-- ===== Numeração sequencial própria de CAIXAS e VENDAS (guardada no banco) =====
CREATE SEQUENCE IF NOT EXISTS seq_caixa_numero;
ALTER TABLE caixas ADD COLUMN IF NOT EXISTS numero int;
WITH o AS (SELECT id, nextval('seq_caixa_numero') AS n FROM (SELECT id FROM caixas WHERE numero IS NULL ORDER BY id) q)
  UPDATE caixas c SET numero = o.n FROM o WHERE c.id = o.id;
ALTER TABLE caixas ALTER COLUMN numero SET DEFAULT nextval('seq_caixa_numero');
CREATE UNIQUE INDEX IF NOT EXISTS ux_caixas_numero ON caixas(numero);

CREATE SEQUENCE IF NOT EXISTS seq_venda_numero;
CREATE TABLE IF NOT EXISTS vendas(
  id serial PRIMARY KEY,
  numero int NOT NULL DEFAULT nextval('seq_venda_numero') UNIQUE,
  pedido_id int NOT NULL UNIQUE REFERENCES pedidos(id) ON DELETE CASCADE,
  caixa_id int REFERENCES caixas(id), vendedor_id int REFERENCES usuarios(id), cliente_id int REFERENCES clientes(id),
  status text, desconto numeric(14,2) DEFAULT 0, total numeric(14,2) DEFAULT 0,
  criado_em timestamptz DEFAULT now(), fechado_em timestamptz);
CREATE INDEX IF NOT EXISTS ix_vendas_caixa ON vendas(caixa_id);
-- vendas já existentes (comandas anteriores), em ordem de abertura
INSERT INTO vendas(pedido_id, caixa_id, vendedor_id, cliente_id, status, desconto, total, criado_em, fechado_em)
  SELECT p.id, p.caixa_id, p.usuario_id, p.cliente_id, p.status, p.desconto, p.total, p.aberto_em, p.fechado_em
  FROM pedidos p WHERE NOT EXISTS (SELECT 1 FROM vendas v WHERE v.pedido_id = p.id) ORDER BY p.id;

-- A venda (e o seu número sequencial) só nasce quando o PRIMEIRO item é lançado; depois o pedido a mantém atualizada
CREATE OR REPLACE FUNCTION fn_sync_venda() RETURNS trigger AS $f$
BEGIN
  UPDATE vendas SET caixa_id = COALESCE(NEW.caixa_id, caixa_id), cliente_id = NEW.cliente_id, status = NEW.status,
         desconto = NEW.desconto, total = NEW.total, fechado_em = NEW.fechado_em WHERE pedido_id = NEW.id;
  RETURN NEW;
END $f$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS tg_sync_venda ON pedidos;
CREATE TRIGGER tg_sync_venda AFTER UPDATE ON pedidos FOR EACH ROW EXECUTE FUNCTION fn_sync_venda();
CREATE OR REPLACE FUNCTION fn_venda_primeiro_item() RETURNS trigger AS $f$
BEGIN
  INSERT INTO vendas(pedido_id, caixa_id, vendedor_id, cliente_id, status, desconto, total, criado_em)
  SELECT p.id, COALESCE(p.caixa_id, (SELECT id FROM caixas WHERE usuario_id = p.usuario_id AND status = 'aberto' ORDER BY id DESC LIMIT 1)),
         p.usuario_id, p.cliente_id, p.status, p.desconto, p.total, p.aberto_em FROM pedidos p WHERE p.id = NEW.pedido_id
  ON CONFLICT (pedido_id) DO NOTHING;
  RETURN NEW;
END $f$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS tg_venda_primeiro_item ON pedido_itens;
CREATE TRIGGER tg_venda_primeiro_item AFTER INSERT ON pedido_itens FOR EACH ROW EXECUTE FUNCTION fn_venda_primeiro_item();
-- vendas em andamento ainda sem nenhum item não ocupam número
DELETE FROM vendas v WHERE v.status = 'aberto' AND NOT EXISTS (SELECT 1 FROM pedido_itens i WHERE i.pedido_id = v.pedido_id);

-- ===== Painel de caixa: totais do fechamento e conferência =====
ALTER TABLE caixas ADD COLUMN IF NOT EXISTS total_calculado numeric(14,2);
ALTER TABLE caixas ADD COLUMN IF NOT EXISTS total_informado numeric(14,2);
ALTER TABLE caixas ADD COLUMN IF NOT EXISTS conferido boolean NOT NULL DEFAULT false;
ALTER TABLE caixas ADD COLUMN IF NOT EXISTS conferido_por int REFERENCES usuarios(id);
ALTER TABLE caixas ADD COLUMN IF NOT EXISTS conferido_em timestamptz;
UPDATE caixas c SET total_informado = x.t, total_calculado = x.t - COALESCE(c.diferenca, 0)
  FROM (SELECT caixa_id, SUM(informado) t FROM caixa_fechamento GROUP BY caixa_id) x
  WHERE x.caixa_id = c.id AND c.status = 'fechado' AND c.total_informado IS NULL;

-- ===== Código interno automático dos produtos + tabela própria de códigos de barras =====
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_class WHERE relname = 'seq_produto_codigo') THEN
    CREATE SEQUENCE seq_produto_codigo;
    PERFORM setval('seq_produto_codigo', coalesce((SELECT max(codigo::bigint) FROM produtos WHERE codigo ~ '^[0-9]{1,12}$'), 0) + 1, false);
  END IF;
END $$;

CREATE OR REPLACE FUNCTION fn_produto_codigo() RETURNS trigger AS $$
BEGIN
  IF NEW.codigo IS NULL OR btrim(NEW.codigo) = '' THEN
    LOOP
      NEW.codigo := nextval('seq_produto_codigo')::text;
      EXIT WHEN NOT EXISTS (SELECT 1 FROM produtos WHERE codigo = NEW.codigo);
    END LOOP;
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS tg_produto_codigo ON produtos;
CREATE TRIGGER tg_produto_codigo BEFORE INSERT ON produtos FOR EACH ROW EXECUTE FUNCTION fn_produto_codigo();
-- produtos antigos sem código interno recebem um
UPDATE produtos SET codigo = nextval('seq_produto_codigo')::text WHERE codigo IS NULL OR btrim(codigo) = '';

-- 1 produto (código interno) pode ter vários códigos de barras; a ligação é o código interno
CREATE TABLE IF NOT EXISTS produto_codigos_barras(
  id serial PRIMARY KEY,
  produto_codigo text NOT NULL REFERENCES produtos(codigo) ON UPDATE CASCADE ON DELETE CASCADE,
  codigo_barras text NOT NULL UNIQUE,
  principal boolean NOT NULL DEFAULT false,
  criado_em timestamptz NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS ix_pcb_produto ON produto_codigos_barras(produto_codigo);
-- migração única: o código de barras que ficava dentro do produto passa para a tabela nova
INSERT INTO produto_codigos_barras(produto_codigo, codigo_barras, principal)
  SELECT codigo, btrim(codigo_barras), true FROM produtos WHERE btrim(coalesce(codigo_barras, '')) <> ''
  ON CONFLICT (codigo_barras) DO NOTHING;
UPDATE produtos SET codigo_barras = NULL WHERE codigo_barras IS NOT NULL;

-- ===== Fator por código de barras + códigos do produto no fornecedor (tabela própria) =====
ALTER TABLE produto_codigos_barras ADD COLUMN IF NOT EXISTS fator numeric(14,4) NOT NULL DEFAULT 1;

CREATE TABLE IF NOT EXISTS produto_fornecedor(
  id serial PRIMARY KEY,
  produto_codigo text NOT NULL REFERENCES produtos(codigo) ON UPDATE CASCADE ON DELETE CASCADE,
  fornecedor_id int NOT NULL REFERENCES fornecedores(id) ON DELETE CASCADE,
  codigo_fornecedor text NOT NULL,
  fator numeric(14,4) NOT NULL DEFAULT 1,
  criado_em timestamptz NOT NULL DEFAULT now(),
  UNIQUE (fornecedor_id, codigo_fornecedor));
CREATE INDEX IF NOT EXISTS ix_pf_produto ON produto_fornecedor(produto_codigo);
-- migração única: vínculos antigos (de_para) passam para a tabela nova
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM config WHERE chave = 'mig_produto_fornecedor') THEN
    INSERT INTO produto_fornecedor(produto_codigo, fornecedor_id, codigo_fornecedor, fator)
      SELECT p.codigo, f.id, d.codigo_fornecedor, coalesce(nullif(d.fator, 0), 1)
      FROM de_para d JOIN fornecedores f ON f.documento = d.fornecedor_doc JOIN produtos p ON p.id = d.produto_id
      ON CONFLICT (fornecedor_id, codigo_fornecedor) DO NOTHING;
    INSERT INTO config(chave, valor) VALUES ('mig_produto_fornecedor', 'ok');
  END IF;
END $$;

-- ===== Forma "Consignado", forma prevista nas contas a pagar e Ajuste de estoque (avulso) =====
ALTER TABLE formas_pagamento DROP CONSTRAINT IF EXISTS formas_pagamento_tipo_check;
ALTER TABLE formas_pagamento ADD CONSTRAINT formas_pagamento_tipo_check CHECK (tipo IN ('dinheiro','pix','debito','credito','voucher','fiado','consignado','outro'));
INSERT INTO formas_pagamento(codigo, descricao, tipo, ordem) VALUES ('consignado','Consignado','consignado',7) ON CONFLICT (codigo) DO NOTHING;
ALTER TABLE titulos ADD COLUMN IF NOT EXISTS forma_prevista text;

-- cada ajuste avulso fica registrado aqui (além do movimento no extrato do produto)
CREATE TABLE IF NOT EXISTS ajustes_estoque(
  id serial PRIMARY KEY,
  produto_codigo text NOT NULL REFERENCES produtos(codigo) ON UPDATE CASCADE,
  estoque_sistema numeric(14,3) NOT NULL,
  estoque_informado numeric(14,3) NOT NULL,
  diferenca numeric(14,3) NOT NULL,
  custo_unit numeric(14,4),
  motivo text NOT NULL,
  usuario_id int REFERENCES usuarios(id),
  criado_em timestamptz NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS ix_ajuste_produto ON ajustes_estoque(produto_codigo, criado_em);

-- ===== Impressoras: instaladas no Windows e "todos os setores" =====
ALTER TABLE impressoras ADD COLUMN IF NOT EXISTS conexao text NOT NULL DEFAULT 'rede';
ALTER TABLE impressoras ADD COLUMN IF NOT EXISTS windows_nome text;
ALTER TABLE impressoras ALTER COLUMN ip DROP NOT NULL;
ALTER TABLE impressoras DROP CONSTRAINT IF EXISTS impressoras_destino_check;
ALTER TABLE impressoras ADD CONSTRAINT impressoras_destino_check CHECK (destino IN ('cozinha','bar','caixa','todos'));
ALTER TABLE impressoras DROP CONSTRAINT IF EXISTS impressoras_conexao_check;
ALTER TABLE impressoras ADD CONSTRAINT impressoras_conexao_check CHECK (conexao IN ('rede','windows'));

-- Comandas da cozinha/bar são impressas somente ao receber o pagamento
ALTER TABLE pedido_itens ADD COLUMN IF NOT EXISTS impresso_em timestamptz;

-- Arredondamento no recebimento (valor em R$, + acrescenta / - reduz), com limite configurável e permissão própria
ALTER TABLE pedidos ADD COLUMN IF NOT EXISTS arredondamento numeric(14,2) DEFAULT 0;
ALTER TABLE pedidos ADD COLUMN IF NOT EXISTS arredondamento_por int;
INSERT INTO config(chave,valor) VALUES('arred_max_mais','1.00') ON CONFLICT(chave) DO NOTHING;
INSERT INTO config(chave,valor) VALUES('arred_max_menos','1.00') ON CONFLICT(chave) DO NOTHING;
-- o perfil Gerente já existente passa a ter a nova permissão (uma única vez)
UPDATE perfis SET permissoes = array_append(permissoes,'vendas.arredondar')
 WHERE nome='Gerente' AND NOT ('vendas.arredondar' = ANY(permissoes)) AND NOT ('*' = ANY(permissoes))
   AND NOT EXISTS (SELECT 1 FROM config WHERE chave='mig_perm_arredondar');
INSERT INTO config(chave,valor) VALUES('mig_perm_arredondar','1') ON CONFLICT(chave) DO NOTHING;

-- Baixa de estoque da venda: só depois que todos os itens foram entregues (retirados) na cozinha/bar
ALTER TABLE pedidos ADD COLUMN IF NOT EXISTS estoque_baixado_em timestamptz;

-- Imagem do produto (aparece no botão da tela de vendas) e produtos liberados para venda em cada caixa/evento
ALTER TABLE produtos ADD COLUMN IF NOT EXISTS imagem text;
CREATE TABLE IF NOT EXISTS caixa_produtos(
  caixa_id int NOT NULL REFERENCES caixas(id) ON DELETE CASCADE,
  produto_id int NOT NULL REFERENCES produtos(id) ON DELETE CASCADE,
  PRIMARY KEY(caixa_id, produto_id));

-- Produção: consome insumos pela ficha técnica e gera estoque do produto preparado (ex.: pipoca feita antes do evento)
CREATE TABLE IF NOT EXISTS producoes(
  id serial PRIMARY KEY, produto_id int NOT NULL REFERENCES produtos(id),
  quantidade numeric(14,3) NOT NULL, custo_total numeric(14,2) NOT NULL DEFAULT 0, custo_unit numeric(14,4) NOT NULL DEFAULT 0,
  observacao text, usuario_id int REFERENCES usuarios(id), criado_em timestamptz DEFAULT now());
CREATE INDEX IF NOT EXISTS ix_producoes_prod ON producoes(produto_id, criado_em);
UPDATE perfis SET permissoes = array_append(permissoes,'estoque.producao')
 WHERE nome IN ('Gerente','Estoquista') AND NOT ('estoque.producao' = ANY(permissoes)) AND NOT ('*' = ANY(permissoes))
   AND NOT EXISTS (SELECT 1 FROM config WHERE chave='mig_perm_producao');
INSERT INTO config(chave,valor) VALUES('mig_perm_producao','1') ON CONFLICT(chave) DO NOTHING;

-- Baixa dos insumos da produção só no fechamento do caixa (com a sobra contada pelo operador)
ALTER TABLE producoes ADD COLUMN IF NOT EXISTS caixa_id int REFERENCES caixas(id);
ALTER TABLE producoes ADD COLUMN IF NOT EXISTS insumos_baixados_em timestamptz;
UPDATE producoes SET insumos_baixados_em = criado_em WHERE insumos_baixados_em IS NULL
  AND NOT EXISTS (SELECT 1 FROM config WHERE chave='mig_producao_baixa_fechamento');
INSERT INTO config(chave,valor) VALUES('mig_producao_baixa_fechamento','1') ON CONFLICT(chave) DO NOTHING;
CREATE TABLE IF NOT EXISTS caixa_insumos(
  id serial PRIMARY KEY, caixa_id int NOT NULL REFERENCES caixas(id) ON DELETE CASCADE, insumo_id int NOT NULL REFERENCES produtos(id),
  estoque_antes numeric(14,3) NOT NULL, consumo_previsto numeric(14,3) NOT NULL, sobra_informada numeric(14,3),
  consumo_real numeric(14,3) NOT NULL, diferenca numeric(14,3) NOT NULL, criado_em timestamptz DEFAULT now());
CREATE INDEX IF NOT EXISTS ix_caixa_insumos ON caixa_insumos(caixa_id);

-- Só um caixa aberto por vez (evita conflito de estoque e insumos); o índice só é criado se não houver mais de um aberto hoje
DO $$ BEGIN
  IF (SELECT count(*) FROM caixas WHERE status='aberto') <= 1 THEN
    CREATE UNIQUE INDEX IF NOT EXISTS ux_um_caixa_aberto ON caixas((status)) WHERE status='aberto';
  END IF;
END $$;

-- Integração fiscal: notas buscadas na SEFAZ (certificado A1) ou em serviço pago por chave
CREATE TABLE IF NOT EXISTS sefaz_docs(
  chave text PRIMARY KEY, nsu text, emitente_nome text, emitente_doc text, valor numeric(14,2) DEFAULT 0, emissao date, numero text,
  xml text, origem text DEFAULT 'sefaz', manifestado_em timestamptz, ignorado boolean NOT NULL DEFAULT false,
  criado_em timestamptz DEFAULT now(), atualizado_em timestamptz DEFAULT now());
CREATE INDEX IF NOT EXISTS ix_sefaz_docs_cri ON sefaz_docs(criado_em DESC);
ALTER TABLE sefaz_docs ADD COLUMN IF NOT EXISTS busca_origem text;   -- 'agendada' (busca automática) ou 'manual' (botão), na primeira vez que a nota foi encontrada
CREATE TABLE IF NOT EXISTS sefaz_buscas(
  id serial PRIMARY KEY, criado_em timestamptz DEFAULT now(), origem text, novos int DEFAULT 0, completos int DEFAULT 0, resumos int DEFAULT 0,
  ciencias int DEFAULT 0, cstat int, resultado text, erro text);
INSERT INTO config(chave,valor) VALUES('fiscal_uf','42') ON CONFLICT(chave) DO NOTHING;
INSERT INTO config(chave,valor) VALUES('fiscal_ambiente','1') ON CONFLICT(chave) DO NOTHING;
INSERT INTO config(chave,valor) VALUES('fiscal_agenda','desligado') ON CONFLICT(chave) DO NOTHING;

ALTER TABLE formas_pagamento ADD COLUMN IF NOT EXISTS taxa_fixa numeric(12,2) NOT NULL DEFAULT 0;

ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS versao_vista text;

CREATE TABLE IF NOT EXISTS doacoes(id serial PRIMARY KEY, pedido_id int UNIQUE REFERENCES pedidos(id), caixa_id int REFERENCES caixas(id),
  destino text NOT NULL, valor numeric(14,2) NOT NULL, usuario_id int, criado_em timestamptz DEFAULT now());
INSERT INTO config(chave,valor) VALUES('doacao_ativa','0') ON CONFLICT(chave) DO NOTHING;
INSERT INTO config(chave,valor) VALUES('doacao_destinos','') ON CONFLICT(chave) DO NOTHING;

INSERT INTO config(chave,valor) VALUES('estoque_negativo','sim') ON CONFLICT(chave) DO NOTHING;

-- Evento: definido na abertura do caixa, com a equipe do dia e a função (perfil) de cada pessoa durante o evento
CREATE TABLE IF NOT EXISTS eventos(id serial PRIMARY KEY, nome text NOT NULL, caixa_id int UNIQUE REFERENCES caixas(id), criado_em timestamptz DEFAULT now());
CREATE TABLE IF NOT EXISTS evento_equipe(evento_id int NOT NULL REFERENCES eventos(id) ON DELETE CASCADE, usuario_id int NOT NULL REFERENCES usuarios(id),
  perfil_id int NOT NULL REFERENCES perfis(id), PRIMARY KEY(evento_id, usuario_id));

ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS email text;
CREATE TABLE IF NOT EXISTS recuperacao_senha(id serial PRIMARY KEY, usuario_id int NOT NULL REFERENCES usuarios(id), codigo_hash text NOT NULL,
  expira_em timestamptz NOT NULL, tentativas int NOT NULL DEFAULT 0, usado boolean NOT NULL DEFAULT false, criado_em timestamptz DEFAULT now());

-- Código sequencial do usuário (usado no acesso ao sistema e no campo Vendedor da venda)
CREATE SEQUENCE IF NOT EXISTS usuarios_codigo_seq;
ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS codigo int;
UPDATE usuarios u SET codigo=nextval('usuarios_codigo_seq') FROM (SELECT id FROM usuarios WHERE codigo IS NULL ORDER BY id) s WHERE u.id=s.id;
ALTER TABLE usuarios ALTER COLUMN codigo SET DEFAULT nextval('usuarios_codigo_seq');
CREATE UNIQUE INDEX IF NOT EXISTS ux_usuarios_codigo ON usuarios(codigo);
ALTER TABLE pedidos ADD COLUMN IF NOT EXISTS vendedor_id int REFERENCES usuarios(id);

-- Produto permite observação na venda (ex.: "sem cebola"); porções, pratos e sobremesas já nascem marcados
DO $b$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='produtos' AND column_name='permite_obs') THEN
    ALTER TABLE produtos ADD COLUMN permite_obs boolean NOT NULL DEFAULT false;
    UPDATE produtos SET permite_obs = true WHERE categoria_id IN (SELECT id FROM categorias WHERE lower(translate(nome,'ÇÕçõ','COco')) ~ '(porco|prato|sobremesa)');
  END IF;
END $b$;


-- Controle de patrimônio: bens não imobilizados (nem revenda nem consumo) comprados ou doados
ALTER TABLE entradas ADD COLUMN IF NOT EXISTS doacao boolean NOT NULL DEFAULT false;
ALTER TABLE entradas ADD COLUMN IF NOT EXISTS valor_doacao numeric(14,2) NOT NULL DEFAULT 0;
ALTER TABLE entrada_itens ADD COLUMN IF NOT EXISTS descricao text;
ALTER TABLE entrada_itens ADD COLUMN IF NOT EXISTS doacao boolean NOT NULL DEFAULT false;
ALTER TABLE entrada_itens ADD COLUMN IF NOT EXISTS patrimonio boolean NOT NULL DEFAULT false;
CREATE SEQUENCE IF NOT EXISTS seq_patrimonio_numero;
CREATE TABLE IF NOT EXISTS patrimonio(
  id serial PRIMARY KEY, numero int NOT NULL UNIQUE DEFAULT nextval('seq_patrimonio_numero'),
  descricao text NOT NULL, marca text, modelo text, serie text, local text, responsavel text, observacao text,
  origem text NOT NULL DEFAULT 'compra' CHECK (origem IN ('compra','doacao')),
  valor numeric(14,2) NOT NULL DEFAULT 0, data_aquisicao date NOT NULL DEFAULT current_date,
  fornecedor_id int REFERENCES fornecedores(id), entrada_id int REFERENCES entradas(id) ON DELETE SET NULL,
  situacao text NOT NULL DEFAULT 'ativo' CHECK (situacao IN ('ativo','baixado')),
  baixa_em date, baixa_motivo text, usuario_id int, criado_em timestamptz NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS ix_patrimonio_entrada ON patrimonio(entrada_id);
UPDATE perfis SET permissoes = array_cat(permissoes, ARRAY['patrimonio.ver','patrimonio.gerenciar'])
 WHERE nome='Gerente' AND NOT ('*' = ANY(permissoes)) AND NOT EXISTS (SELECT 1 FROM config WHERE chave='mig_perm_patrimonio');
UPDATE perfis SET permissoes = array_append(permissoes,'patrimonio.ver')
 WHERE nome='Estoquista' AND NOT ('*' = ANY(permissoes)) AND NOT EXISTS (SELECT 1 FROM config WHERE chave='mig_perm_patrimonio');
INSERT INTO config(chave,valor) VALUES('mig_perm_patrimonio','1') ON CONFLICT(chave) DO NOTHING;

-- Consignação: mercadoria entra no estoque sem conta a pagar; devolução dá saída; o acerto (com a nota final) gera o contas a pagar
ALTER TABLE entradas ADD COLUMN IF NOT EXISTS consignada boolean NOT NULL DEFAULT false;
ALTER TABLE entradas ADD COLUMN IF NOT EXISTS consig_status text CHECK (consig_status IN ('aberta','acertada'));
ALTER TABLE entradas ADD COLUMN IF NOT EXISTS acerto_em timestamptz;
ALTER TABLE entradas ADD COLUMN IF NOT EXISTS acerto_nf text;
ALTER TABLE entradas ADD COLUMN IF NOT EXISTS acerto_chave text;
ALTER TABLE entradas ADD COLUMN IF NOT EXISTS acerto_usuario_id int;
ALTER TABLE entradas ADD COLUMN IF NOT EXISTS acerto_total numeric(14,2);
ALTER TABLE entrada_itens ADD COLUMN IF NOT EXISTS qtd_devolvida numeric(14,3) NOT NULL DEFAULT 0;
CREATE INDEX IF NOT EXISTS ix_entradas_consig ON entradas(consig_status) WHERE consignada;

-- Novas permissões de autorização (tela de vendas): Gerente passa a tê-las; os demais perfis liberam em Equipe > Perfis
UPDATE perfis SET permissoes = array_cat(permissoes, ARRAY['vendas.lancar_producao','caixa.produtos'])
 WHERE nome='Gerente' AND NOT ('*' = ANY(permissoes)) AND NOT EXISTS (SELECT 1 FROM config WHERE chave='mig_perm_aut_vendas');
INSERT INTO config(chave,valor) VALUES('mig_perm_aut_vendas','1') ON CONFLICT(chave) DO NOTHING;

-- Padrão: cadastros em letras MAIÚSCULAS. Converte uma vez o que já existe (se der conflito de nome repetido, aquele cadastro é mantido como está).
DO $mai$
DECLARE r record;
BEGIN
  IF EXISTS (SELECT 1 FROM config WHERE chave='mig_maiusculas') THEN RETURN; END IF;
  FOR r IN SELECT * FROM (VALUES
    ('perfis','nome'),('usuarios','nome'),('usuarios','cargo'),('categorias','nome'),('produtos','nome'),
    ('clientes','nome'),('clientes','endereco'),('clientes','observacao'),
    ('fornecedores','nome'),('fornecedores','fantasia'),('fornecedores','contato'),('fornecedores','endereco'),('fornecedores','cidade'),('fornecedores','uf'),('fornecedores','condicao_pagamento'),('fornecedores','observacao'),
    ('formas_pagamento','descricao'),('formas_pagamento','bandeira'),('impressoras','nome'),('eventos','nome'),
    ('patrimonio','descricao'),('patrimonio','marca'),('patrimonio','modelo'),('patrimonio','serie'),('patrimonio','local'),('patrimonio','responsavel'),('patrimonio','observacao')
  ) AS t(tab,col) LOOP
    BEGIN
      EXECUTE format('UPDATE %I SET %I = upper(%I) WHERE %I IS NOT NULL AND %I <> upper(%I)', r.tab, r.col, r.col, r.col, r.col, r.col);
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
  END LOOP;
  UPDATE config SET valor = upper(valor) WHERE chave IN ('empresa','empresa_razao','empresa_endereco','empresa_cidade') AND valor IS NOT NULL;
  INSERT INTO config(chave,valor) VALUES('mig_maiusculas','1') ON CONFLICT(chave) DO NOTHING;
END
$mai$;

-- Várias empresas (CNPJs): uma fica "em uso" e é espelhada em config (empresa, empresa_*, smtp_*), que o resto do sistema já lê.
CREATE TABLE IF NOT EXISTS empresas(
  id serial PRIMARY KEY, nome text NOT NULL, razao text, cnpj text, ie text, tel text, endereco text, cidade text, email text,
  smtp_host text, smtp_porta text, smtp_seguranca text DEFAULT 'starttls', smtp_usuario text, smtp_senha text,
  em_uso boolean NOT NULL DEFAULT false, ativo boolean NOT NULL DEFAULT true, criado_em timestamptz DEFAULT now());
DO $emp$
BEGIN
  IF EXISTS (SELECT 1 FROM config WHERE chave='mig_empresas') THEN RETURN; END IF;
  IF NOT EXISTS (SELECT 1 FROM empresas) AND COALESCE((SELECT valor FROM config WHERE chave='empresa'),'') <> '' THEN
    INSERT INTO empresas(nome, razao, cnpj, ie, tel, endereco, cidade, email, smtp_host, smtp_porta, smtp_seguranca, smtp_usuario, smtp_senha, em_uso)
    SELECT (SELECT valor FROM config WHERE chave='empresa'), (SELECT valor FROM config WHERE chave='empresa_razao'), (SELECT valor FROM config WHERE chave='empresa_cnpj'),
      (SELECT valor FROM config WHERE chave='empresa_ie'), (SELECT valor FROM config WHERE chave='empresa_tel'), (SELECT valor FROM config WHERE chave='empresa_endereco'),
      (SELECT valor FROM config WHERE chave='empresa_cidade'), (SELECT valor FROM config WHERE chave='empresa_email'), (SELECT valor FROM config WHERE chave='smtp_host'),
      (SELECT valor FROM config WHERE chave='smtp_porta'), COALESCE((SELECT valor FROM config WHERE chave='smtp_seguranca'),'starttls'), (SELECT valor FROM config WHERE chave='smtp_usuario'),
      (SELECT valor FROM config WHERE chave='smtp_senha'), true;
  END IF;
  INSERT INTO config(chave,valor) VALUES('mig_empresas','1') ON CONFLICT(chave) DO NOTHING;
END
$emp$;

-- Cada venda guarda a empresa do terminal que a fez
ALTER TABLE pedidos ADD COLUMN IF NOT EXISTS empresa_id int REFERENCES empresas(id) ON DELETE SET NULL;

-- Motivos de ajuste de estoque (cadastro). Os padrões são criados uma única vez; depois o cliente cadastra/edita/remove como quiser.
CREATE TABLE IF NOT EXISTS motivos_ajuste(id serial PRIMARY KEY, descricao text UNIQUE NOT NULL, ativo boolean NOT NULL DEFAULT true);
DO $mot$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM config WHERE chave='mig_motivos_ajuste') THEN
    INSERT INTO motivos_ajuste(descricao) VALUES ('ACERTO ESTOQUE'),('DEVOLUCAO P/FORNEC.'),('DOACAO'),('PRODUTO VENCIDO'),('QUEBRAS'),('ROUBO'),('USO INTERNO') ON CONFLICT DO NOTHING;
    INSERT INTO config(chave, valor) VALUES ('mig_motivos_ajuste', '1') ON CONFLICT DO NOTHING;
  END IF;
END
$mot$;

-- Balanço geral de estoque (conferência de todo o estoque, com ou sem acúmulo). Só pode haver 1 em andamento.
CREATE TABLE IF NOT EXISTS balancos(
  id serial PRIMARY KEY,
  status text NOT NULL DEFAULT 'andamento' CHECK (status IN ('andamento','finalizado','cancelado')),
  acumula boolean NOT NULL DEFAULT false,
  iniciado_em timestamptz NOT NULL DEFAULT now(), iniciado_por int REFERENCES usuarios(id),
  caixa_aberto boolean NOT NULL DEFAULT false,
  finalizado_em timestamptz, finalizado_por int REFERENCES usuarios(id),
  zerou_nao_conferidos boolean, observacao text);
CREATE UNIQUE INDEX IF NOT EXISTS ux_balanco_andamento ON balancos(status) WHERE status='andamento';
CREATE TABLE IF NOT EXISTS balanco_itens(
  id serial PRIMARY KEY, balanco_id int NOT NULL REFERENCES balancos(id) ON DELETE CASCADE,
  produto_id int NOT NULL REFERENCES produtos(id), conferido boolean NOT NULL DEFAULT true,
  qtd_contada numeric(14,3), primeiro_em timestamptz DEFAULT now(), contado_em timestamptz DEFAULT now(), leituras int NOT NULL DEFAULT 1,
  estoque_sistema numeric(14,3), mov_depois numeric(14,3), estoque_final numeric(14,3), diferenca numeric(14,3), acao text,
  UNIQUE(balanco_id, produto_id));

-- Cadastro automático de produtos vindos de XML: fica "suspenso" (código provisório AUTO-n, sem usar o sequencial do cadastro, não vendável)
-- até alguém confirmar o cadastro (aí recebe o código sequencial) ou amarrar a um produto já existente (o automático é descartado).
CREATE SEQUENCE IF NOT EXISTS seq_produto_auto;
ALTER TABLE produtos ADD COLUMN IF NOT EXISTS suspenso boolean NOT NULL DEFAULT false;
ALTER TABLE produtos ADD COLUMN IF NOT EXISTS auto_origem text;
