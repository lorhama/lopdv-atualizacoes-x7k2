// Controle de patrimônio: bens não imobilizados (nem revenda nem consumo), comprados ou doados.
const express = require('express');
const db = require('../db');
const { auth, auditar } = require('../auth');
const { HttpError, wrap, num, r2, hoje } = require('../util');
const r = express.Router();

const COLS = `p.*, f.nome fornecedor, e.numero nota, u.nome usuario`;
const FROM = `from patrimonio p left join fornecedores f on f.id=p.fornecedor_id left join entradas e on e.id=p.entrada_id left join usuarios u on u.id=p.usuario_id`;

r.get('/', auth('patrimonio.ver'), wrap(async (req, res) => {
  const q = req.query, w = [], a = [];
  if (q.situacao === 'ativo' || q.situacao === 'baixado') { a.push(q.situacao); w.push(`p.situacao=$${a.length}`); }
  if (q.origem === 'compra' || q.origem === 'doacao') { a.push(q.origem); w.push(`p.origem=$${a.length}`); }
  if (q.q) { a.push('%' + String(q.q).toLowerCase() + '%'); w.push(`(lower(p.descricao||' '||coalesce(p.marca,'')||' '||coalesce(p.modelo,'')||' '||coalesce(p.serie,'')||' '||coalesce(p.local,'')||' '||coalesce(p.responsavel,'')) like $${a.length} or p.numero::text like $${a.length})`); }
  res.json((await db.q(`select ${COLS} ${FROM} ${w.length ? 'where ' + w.join(' and ') : ''} order by p.numero desc limit 1000`, a)).rows);
}));

r.get('/:id(\\d+)', auth('patrimonio.ver'), wrap(async (req, res) => {
  const x = (await db.q(`select ${COLS} ${FROM} where p.id=$1`, [req.params.id])).rows[0];
  if (!x) throw new HttpError(404, 'Bem não encontrado.');
  res.json(x);
}));

const campos = b => ({
  descricao: String(b.descricao || '').trim(), marca: b.marca || null, modelo: b.modelo || null, serie: b.serie || null,
  local: b.local || null, responsavel: b.responsavel || null, observacao: b.observacao || null,
});

// bem cadastrado direto (já existente na casa, sem nota)
r.post('/', auth('patrimonio.gerenciar'), wrap(async (req, res) => {
  const b = req.body || {}, c = campos(b);
  if (!c.descricao) throw new HttpError(400, 'Informe a descrição do bem.');
  const qtd = Math.max(1, Math.floor(num(b.quantidade, 1)));
  if (qtd > 200) throw new HttpError(400, 'Máximo de 200 bens por cadastro.');
  const origem = b.origem === 'doacao' ? 'doacao' : 'compra';
  const nums = [];
  await db.tx(async cx => {
    for (let k = 0; k < qtd; k++) {
      const p = await cx.query(`insert into patrimonio(descricao,marca,modelo,serie,local,responsavel,observacao,origem,valor,data_aquisicao,fornecedor_id,usuario_id)
        values($1,$2,$3,$4,$5,$6,$7,$8,$9,coalesce($10::date,current_date),$11,$12) returning numero`,
        [c.descricao, c.marca, c.modelo, c.serie, c.local, c.responsavel, c.observacao, origem, r2(num(b.valor)), b.data_aquisicao || null, b.fornecedor_id || null, req.user.id]);
      nums.push(p.rows[0].numero);
    }
    await auditar(cx, req.user, 'patrimonio_novo', { numeros: nums, descricao: c.descricao });
  });
  res.json({ numeros: nums });
}));

r.put('/:id(\\d+)', auth('patrimonio.gerenciar'), wrap(async (req, res) => {
  const b = req.body || {}, c = campos(b);
  if (!c.descricao) throw new HttpError(400, 'Informe a descrição do bem.');
  const x = await db.q(`update patrimonio set descricao=$1,marca=$2,modelo=$3,serie=$4,local=$5,responsavel=$6,observacao=$7,valor=$8 where id=$9 returning numero`,
    [c.descricao, c.marca, c.modelo, c.serie, c.local, c.responsavel, c.observacao, r2(num(b.valor)), req.params.id]);
  if (!x.rowCount) throw new HttpError(404, 'Bem não encontrado.');
  await auditar(null, req.user, 'patrimonio_editar', { numero: x.rows[0].numero });
  res.json({ ok: true });
}));

// baixa (venda, perda, descarte, devolução...) — não apaga: fica no histórico
r.post('/:id(\\d+)/baixar', auth('patrimonio.gerenciar'), wrap(async (req, res) => {
  const b = req.body || {}, motivo = String(b.motivo || '').trim();
  if (!motivo) throw new HttpError(400, 'Informe o motivo da baixa.');
  const x = await db.q(`update patrimonio set situacao='baixado', baixa_em=coalesce($1::date,current_date), baixa_motivo=$2 where id=$3 and situacao='ativo' returning numero`,
    [b.data || null, motivo, req.params.id]);
  if (!x.rowCount) throw new HttpError(400, 'Bem não encontrado ou já baixado.');
  await auditar(null, req.user, 'patrimonio_baixa', { numero: x.rows[0].numero, motivo });
  res.json({ ok: true });
}));

r.post('/:id(\\d+)/reativar', auth('patrimonio.gerenciar'), wrap(async (req, res) => {
  const x = await db.q(`update patrimonio set situacao='ativo', baixa_em=null, baixa_motivo=null where id=$1 and situacao='baixado' returning numero`, [req.params.id]);
  if (!x.rowCount) throw new HttpError(400, 'Bem não encontrado ou não está baixado.');
  await auditar(null, req.user, 'patrimonio_reativar', { numero: x.rows[0].numero });
  res.json({ ok: true });
}));

module.exports = r;
