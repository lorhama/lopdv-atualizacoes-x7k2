// Login, usuários, perfis, impressoras, configurações e auditoria.
const express = require('express');
const db = require('../db');
const { auth, criarSessao, auditar, bcrypt, can, aplicarEvento } = require('../auth');
const { HttpError, wrap } = require('../util');
const { GRUPOS, TODAS } = require('../permissoes');
const { imprimirTexto, listarWindows, enviar, montar } = require('../printer');
const r = express.Router();

r.post('/login', wrap(async (req, res) => {
  const { login, senha } = req.body || {};
  const entrada = String(login || '').trim();
  const busca = async campo => (await db.q(`select u.*, p.nome perfil, coalesce(p.permissoes,'{}') perms from usuarios u
    left join perfis p on p.id=u.perfil_id where ${campo}`, [campo.includes('codigo') ? Number(entrada) : entrada])).rows[0];
  // aceita o login digitado ou o NÚMERO (código) do usuário
  const u = (await busca('lower(u.login)=lower($1)')) || (/^\d{1,9}$/.test(entrada) ? await busca('u.codigo=$1') : null);
  if (!u || !u.ativo || !bcrypt.compareSync(String(senha || ''), u.senha_hash)) {
    await auditar(null, null, 'login_falhou', { login });
    throw new HttpError(401, 'Usuário ou senha inválidos.');
  }
  await aplicarEvento(u);
  const token = await criarSessao(u.id);
  await auditar(null, u, 'login', {});
  res.json({ token, user: { id: u.id, codigo: u.codigo, nome: u.nome, login: u.login, perfil: u.perfil, perms: u.perms } });
}));

// ---- Recuperação de senha por e-mail (código de 6 dígitos válido por 15 minutos, no máximo 5 tentativas)
const email = require('../email');
const crypto = require('crypto');
const achaUsuario = async id => (await db.q('select id, nome, email, login from usuarios where ativo and (lower(login)=lower($1) or lower(email)=lower($1) or codigo::text=$1)', [String(id || '').trim()])).rows[0];
r.post('/senha/solicitar', wrap(async (req, res) => {
  const cfg = await email.config(db);
  if (!email.configurado(cfg)) throw new HttpError(400, 'O envio de e-mail ainda não foi configurado neste sistema. Peça ao administrador para redefinir sua senha em Equipe > Usuários.');
  const u = await achaUsuario(req.body?.usuario);
  const generico = { ok: true, mensagem: 'Se o usuário existir e tiver e-mail cadastrado, enviamos um código de 6 dígitos para esse e-mail. Ele vale por 15 minutos.' };
  if (!u || !u.email) { await auditar(null, null, 'senha_recuperacao_sem_usuario', { informado: String(req.body?.usuario || '').slice(0, 60) }); return res.json(generico); }
  const recentes = (await db.q("select count(*)::int n from recuperacao_senha where usuario_id=$1 and criado_em > now() - interval '1 hour'", [u.id])).rows[0].n;
  if (recentes >= 5) return res.json(generico);
  const codigo = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
  await db.q('update recuperacao_senha set usado=true where usuario_id=$1 and not usado', [u.id]);
  await db.q("insert into recuperacao_senha(usuario_id, codigo_hash, expira_em) values($1,$2, now() + interval '15 minutes')", [u.id, bcrypt.hashSync(codigo, 8)]);
  try { await email.enviar(db, { para: u.email, assunto: 'Código para redefinir sua senha - LoPDV', texto: `Olá, ${u.nome}.\n\nSeu código para redefinir a senha do LoPDV é: ${codigo}\n\nEle vale por 15 minutos. Se você não pediu, ignore este e-mail: sua senha continua a mesma.` }); }
  catch (e) { await auditar(null, u, 'senha_recuperacao_falha_email', { erro: e.message }); throw new HttpError(500, 'Não foi possível enviar o e-mail agora: ' + e.message); }
  await auditar(null, u, 'senha_recuperacao_solicitada', {});
  res.json(generico);
}));
r.post('/senha/redefinir', wrap(async (req, res) => {
  const { usuario, codigo, nova } = req.body || {};
  if (!nova || String(nova).length < 4) throw new HttpError(400, 'A nova senha deve ter ao menos 4 caracteres.');
  const u = await achaUsuario(usuario); const invalido = new HttpError(400, 'Código inválido ou vencido. Peça um novo código.');
  if (!u) throw invalido;
  const rec = (await db.q('select * from recuperacao_senha where usuario_id=$1 and not usado and expira_em > now() order by id desc limit 1', [u.id])).rows[0];
  if (!rec || rec.tentativas >= 5) throw invalido;
  if (!bcrypt.compareSync(String(codigo || '').trim(), rec.codigo_hash)) { await db.q('update recuperacao_senha set tentativas=tentativas+1 where id=$1', [rec.id]); throw invalido; }
  await db.q('update usuarios set senha_hash=$1 where id=$2', [bcrypt.hashSync(String(nova), 10), u.id]);
  await db.q('update recuperacao_senha set usado=true where usuario_id=$1', [u.id]);
  await db.q('delete from sessoes where usuario_id=$1', [u.id]);
  await auditar(null, u, 'senha_recuperada', {});
  res.json({ ok: true });
}));

// Lista pública (tela de entrada) dos usuários ativos: só código e nome, para escolher/pesquisar ao entrar
r.get('/login/usuarios', wrap(async (req, res) => {
  res.json((await db.q('select codigo, nome from usuarios where ativo order by nome')).rows);
}));
// Vendedores possíveis (usuários ativos) para o campo Vendedor da venda
r.get('/vendedores', auth(), wrap(async (req, res) => {
  res.json((await db.q('select id, codigo, nome from usuarios where ativo order by nome')).rows);
}));

r.post('/logout', auth(), wrap(async (req, res) => {
  await db.q('delete from sessoes where token=$1', [req.token]); res.json({ ok: true });
}));

r.get('/me', auth(), (req, res) => res.json({ id: req.user.id, codigo: req.user.codigo, nome: req.user.nome, login: req.user.login, perfil: req.user.perfil, perms: req.user.perms }));

r.post('/me/senha', auth(), wrap(async (req, res) => {
  const { atual, nova } = req.body || {};
  const u = (await db.q('select senha_hash from usuarios where id=$1', [req.user.id])).rows[0];
  if (!bcrypt.compareSync(String(atual || ''), u.senha_hash)) throw new HttpError(400, 'Senha atual incorreta.');
  if (String(nova || '').length < 4) throw new HttpError(400, 'A nova senha deve ter ao menos 4 caracteres.');
  await db.q('update usuarios set senha_hash=$1 where id=$2', [bcrypt.hashSync(nova, 10), req.user.id]);
  res.json({ ok: true });
}));

r.get('/permissoes', auth(), (req, res) => res.json(GRUPOS));

// ---- Usuários
const emailUsuario = s => { const e = String(s || '').trim().toLowerCase(); if (!e) return null; if (!/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(e)) throw new HttpError(400, 'E-mail do usuário inválido.'); return e; };
r.get('/usuarios', auth(['equipe.gerenciar']), wrap(async (req, res) => {
  res.json((await db.q(`select u.id,u.codigo,u.nome,u.login,u.email,u.ativo,u.telefone,u.cargo,u.perfil_id,p.nome perfil from usuarios u
    left join perfis p on p.id=u.perfil_id order by u.nome`)).rows);
}));
r.post('/usuarios', auth('equipe.gerenciar'), wrap(async (req, res) => {
  const b = req.body || {};
  if (!b.nome || !b.login || !b.senha) throw new HttpError(400, 'Informe nome, login e senha.');
  if (String(b.senha).length < 4) throw new HttpError(400, 'A senha deve ter ao menos 4 caracteres.');
  const x = await db.q(`insert into usuarios(nome,login,senha_hash,perfil_id,telefone,cargo,ativo,email) values($1,$2,$3,$4,$5,$6,$7,$8) returning id`,
    [b.nome, b.login.trim(), bcrypt.hashSync(b.senha, 10), b.perfil_id || null, b.telefone || null, b.cargo || null, b.ativo !== false, emailUsuario(b.email)]);
  await auditar(null, req.user, 'usuario_criado', { id: x.rows[0].id, login: b.login });
  res.json({ id: x.rows[0].id });
}));
r.put('/usuarios/:id', auth('equipe.gerenciar'), wrap(async (req, res) => {
  const b = req.body || {}; const id = Number(req.params.id);
  if (id === req.user.id && b.ativo === false) throw new HttpError(400, 'Você não pode desativar o próprio usuário.');
  await db.q(`update usuarios set nome=$1, login=$2, perfil_id=$3, telefone=$4, cargo=$5, ativo=$6 where id=$7`,
    [b.nome, b.login.trim(), b.perfil_id || null, b.telefone || null, b.cargo || null, b.ativo !== false, id]);
  if (b.email !== undefined) await db.q('update usuarios set email=$1 where id=$2', [emailUsuario(b.email), id]);
  if (b.senha) {
    if (String(b.senha).length < 4) throw new HttpError(400, 'A senha deve ter ao menos 4 caracteres.');
    await db.q('update usuarios set senha_hash=$1 where id=$2', [bcrypt.hashSync(b.senha, 10), id]);
    await db.q('delete from sessoes where usuario_id=$1', [id]);
  }
  if (b.ativo === false) await db.q('delete from sessoes where usuario_id=$1', [id]);
  await auditar(null, req.user, 'usuario_alterado', { id, senha_trocada: !!b.senha });
  res.json({ ok: true });
}));

// ---- Perfis (conjunto de permissões)
r.get('/perfis', auth(['equipe.gerenciar']), wrap(async (req, res) => {
  res.json((await db.q('select * from perfis order by nome')).rows);
}));
r.post('/perfis', auth('equipe.gerenciar'), wrap(async (req, res) => {
  const b = req.body || {}; if (!b.nome) throw new HttpError(400, 'Informe o nome do perfil.');
  const perms = (b.permissoes || []).filter(p => TODAS.includes(p));
  const x = await db.q('insert into perfis(nome, permissoes) values($1,$2) returning id', [b.nome, perms]);
  await auditar(null, req.user, 'perfil_criado', { nome: b.nome });
  res.json({ id: x.rows[0].id });
}));
r.put('/perfis/:id', auth('equipe.gerenciar'), wrap(async (req, res) => {
  const b = req.body || {}; const perms = (b.permissoes || []).filter(p => TODAS.includes(p));
  const atual = (await db.q('select * from perfis where id=$1', [req.params.id])).rows[0];
  if (!atual) throw new HttpError(404, 'Perfil não encontrado.');
  if (atual.permissoes.includes('*')) throw new HttpError(400, 'O perfil Administrador não pode ser alterado.');
  await db.q('update perfis set nome=$1, permissoes=$2 where id=$3', [b.nome, perms, req.params.id]);
  await auditar(null, req.user, 'perfil_alterado', { id: req.params.id, permissoes: perms });
  res.json({ ok: true });
}));
r.delete('/perfis/:id', auth('equipe.gerenciar'), wrap(async (req, res) => {
  const atual = (await db.q('select * from perfis where id=$1', [req.params.id])).rows[0];
  if (atual?.permissoes.includes('*')) throw new HttpError(400, 'O perfil Administrador não pode ser excluído.');
  await db.q('delete from perfis where id=$1', [req.params.id]); res.json({ ok: true });
}));

// ---- Impressoras
r.get('/impressoras', auth(['config.gerenciar', 'vendas.acessar']), wrap(async (req, res) => {
  res.json((await db.q('select * from impressoras order by destino, id')).rows);
}));
r.get('/impressoras/windows', auth('config.gerenciar'), wrap(async (req, res) => {
  try { res.json({ ok: true, impressoras: await listarWindows() }); } catch (e) { res.json({ ok: false, erro: e.message, impressoras: [] }); }
}));
function dadosImpressora(b) {
  const conexao = b.conexao === 'windows' ? 'windows' : 'rede';
  if (!String(b.nome || '').trim()) throw new HttpError(400, 'Informe o nome da impressora.');
  if (!['cozinha', 'bar', 'caixa', 'todos'].includes(b.destino)) throw new HttpError(400, 'Escolha o setor da impressora.');
  if (conexao === 'rede' && !String(b.ip || '').trim()) throw new HttpError(400, 'Informe o endereço IP da impressora.');
  if (conexao === 'windows' && !String(b.windows_nome || '').trim()) throw new HttpError(400, 'Escolha a impressora instalada no Windows.');
  return [String(b.nome).trim(), b.destino, conexao === 'rede' ? String(b.ip).trim() : null, b.porta || 9100, b.colunas || 42, b.ativo !== false, conexao, conexao === 'windows' ? String(b.windows_nome).trim() : null];
}
r.post('/impressoras', auth('config.gerenciar'), wrap(async (req, res) => {
  const x = await db.q('insert into impressoras(nome,destino,ip,porta,colunas,ativo,conexao,windows_nome) values($1,$2,$3,$4,$5,$6,$7,$8) returning id', dadosImpressora(req.body || {}));
  res.json({ id: x.rows[0].id });
}));
r.put('/impressoras/:id', auth('config.gerenciar'), wrap(async (req, res) => {
  await db.q('update impressoras set nome=$1,destino=$2,ip=$3,porta=$4,colunas=$5,ativo=$6,conexao=$7,windows_nome=$8 where id=$9', [...dadosImpressora(req.body || {}), req.params.id]);
  res.json({ ok: true });
}));
r.delete('/impressoras/:id', auth('config.gerenciar'), wrap(async (req, res) => {
  await db.q('delete from impressoras where id=$1', [req.params.id]); res.json({ ok: true });
}));
r.post('/impressoras/:id/teste', auth('config.gerenciar'), wrap(async (req, res) => {
  const p = (await db.q('select * from impressoras where id=$1', [req.params.id])).rows[0];
  if (!p) throw new HttpError(404, 'Impressora não encontrada.');
  try { await enviar(p, montar('Impressao de teste\nLoPDV\nSetor: ' + p.destino + '\n' + new Date().toLocaleString('pt-BR'), { titulo: 'TESTE' })); res.json({ ok: true }); }
  catch (e) { res.json({ ok: false, erro: e.message }); }
}));


// ---- Configurações simples (nome da empresa, etc.)
r.get('/config', auth(), wrap(async (req, res) => {
  const o = {}; (await db.q('select * from config')).rows.forEach(x => { o[x.chave] = x.valor; }); res.json(o);
}));
r.put('/config', auth('config.gerenciar'), wrap(async (req, res) => {
  for (const [k, v] of Object.entries(req.body || {}))
    await db.q('insert into config(chave,valor) values($1,$2) on conflict(chave) do update set valor=excluded.valor', [k, String(v ?? '')]);
  res.json({ ok: true });
}));

r.get('/auditoria', auth('config.gerenciar'), wrap(async (req, res) => {
  res.json((await db.q('select * from auditoria order by id desc limit 500')).rows);
}));

module.exports = r;
