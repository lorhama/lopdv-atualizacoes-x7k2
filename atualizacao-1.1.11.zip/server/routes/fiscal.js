// Integração fiscal: certificado digital A1 + busca de XML na SEFAZ (manual e agendada) + serviço pago por chave + painel de notas.
const express = require('express');
const fs = require('fs');
const db = require('../db');
const { auth } = require('../auth');
const { HttpError, wrap } = require('../util');
const sf = require('../sefaz');
const r = express.Router();

const so = s => String(s || '').replace(/\D/g, '');
const chaveOk = s => /^\d{44}$/.test(so(s));

r.get('/config', auth(['config.gerenciar', 'estoque.entrada']), wrap(async (req, res) => {
  const c = await sf.cfgGet(db);
  res.json({
    cert: fs.existsSync(sf.ARQ_CERT) && c.fiscal_cert_senha ? { nome: c.fiscal_cert_nome || '', titular: c.fiscal_cert_titular || '', validade: c.fiscal_cert_validade || '' } : null,
    cnpj: c.fiscal_cnpj || '', uf: c.fiscal_uf || '42', ambiente: c.fiscal_ambiente || '1',
    agenda: c.fiscal_agenda || 'desligado', intervalo_min: c.fiscal_intervalo_min || '120', hora: c.fiscal_hora || '06:00', auto_ciencia: c.fiscal_auto_ciencia === '1',
    ultima_busca: c.fiscal_ultima_busca || null, proxima_consulta: c.fiscal_proxima_consulta || null, ultimo_nsu: c.fiscal_ultimo_nsu || '0',
    svc: { url: c.fiscal_svc_url || '', metodo: c.fiscal_svc_metodo || 'GET', header_nome: c.fiscal_svc_header_nome || '', header_prefixo: c.fiscal_svc_header_prefixo || '', tem_chave: !!c.fiscal_svc_header_valor, resposta: c.fiscal_svc_resposta || 'xml', campo: c.fiscal_svc_campo || 'xml' },
  });
}));

r.put('/config', auth('config.gerenciar'), wrap(async (req, res) => {
  const b = req.body || {}, o = {};
  if (b.cnpj !== undefined) { const d = so(b.cnpj); if (d && d.length !== 14) throw new HttpError(400, 'CNPJ inválido (14 números).'); o.fiscal_cnpj = d; }
  if (b.uf !== undefined) o.fiscal_uf = so(b.uf);
  if (b.ambiente !== undefined) o.fiscal_ambiente = Number(b.ambiente) === 2 ? 2 : 1;
  if (b.agenda !== undefined) { if (!['desligado', 'intervalo', 'diario'].includes(b.agenda)) throw new HttpError(400, 'Agendamento inválido.'); o.fiscal_agenda = b.agenda; }
  if (b.intervalo_min !== undefined) { const n = Number(b.intervalo_min); if (!(n >= 61)) throw new HttpError(400, 'O intervalo mínimo é de 61 minutos: a SEFAZ exige mais de 1 hora entre as consultas.'); o.fiscal_intervalo_min = Math.round(n); }
  if (b.hora !== undefined) { if (!/^\d{2}:\d{2}$/.test(b.hora)) throw new HttpError(400, 'Horário inválido (HH:MM).'); o.fiscal_hora = b.hora; }
  if (b.auto_ciencia !== undefined) o.fiscal_auto_ciencia = b.auto_ciencia ? '1' : '0';
  const s = b.svc;
  if (s) {
    if (s.url !== undefined) { if (s.url && !/^https:\/\//i.test(s.url)) throw new HttpError(400, 'O endereço do serviço precisa começar com https://'); o.fiscal_svc_url = String(s.url).trim(); }
    if (s.metodo !== undefined) o.fiscal_svc_metodo = s.metodo === 'POST' ? 'POST' : 'GET';
    if (s.header_nome !== undefined) o.fiscal_svc_header_nome = String(s.header_nome).trim();
    if (s.header_prefixo !== undefined) o.fiscal_svc_header_prefixo = String(s.header_prefixo);
    if (s.header_valor) o.fiscal_svc_header_valor = sf.cifrar(String(s.header_valor).trim());
    if (s.resposta !== undefined) o.fiscal_svc_resposta = s.resposta === 'json' ? 'json' : 'xml';
    if (s.campo !== undefined) o.fiscal_svc_campo = String(s.campo).trim() || 'xml';
  }
  await sf.cfgSet(db, o); res.json({ ok: true });
}));

// Certificado A1: recebe o .pfx em base64 e a senha; confere no Windows antes de guardar
r.post('/certificado', auth('config.gerenciar'), wrap(async (req, res) => {
  const { pfx_base64, senha, nome } = req.body || {};
  if (!pfx_base64 || !senha) throw new HttpError(400, 'Escolha o arquivo do certificado (.pfx) e informe a senha.');
  const buf = Buffer.from(String(pfx_base64), 'base64');
  if (buf.length < 500 || buf.length > 200000) throw new HttpError(400, 'Arquivo de certificado inválido.');
  const tmp = sf.ARQ_CERT + '.novo'; fs.mkdirSync(require('path').dirname(tmp), { recursive: true }); fs.writeFileSync(tmp, buf, { mode: 0o600 });
  let info;
  try { info = await sf.infoCertificado(tmp, String(senha)); } catch (e) { fs.rmSync(tmp, { force: true }); throw new HttpError(400, e.message); }
  if (new Date(info.validade) < new Date()) { fs.rmSync(tmp, { force: true }); throw new HttpError(400, 'Este certificado está vencido (' + info.validade + ').'); }
  fs.renameSync(tmp, sf.ARQ_CERT);
  await sf.cfgSet(db, { fiscal_cert_senha: sf.cifrar(String(senha)), fiscal_cert_nome: String(nome || 'certificado.pfx').slice(0, 120), fiscal_cert_titular: info.subject.slice(0, 200), fiscal_cert_validade: info.validade });
  const c = await sf.cfgGet(db); if (!c.fiscal_cnpj && info.cnpj) await sf.cfgSet(db, { fiscal_cnpj: info.cnpj });
  res.json({ ok: true, titular: info.subject, validade: info.validade, cnpj: info.cnpj });
}));
r.delete('/certificado', auth('config.gerenciar'), wrap(async (req, res) => {
  fs.rmSync(sf.ARQ_CERT, { force: true });
  await sf.cfgSet(db, { fiscal_cert_senha: '', fiscal_cert_nome: '', fiscal_cert_titular: '', fiscal_cert_validade: '', fiscal_agenda: 'desligado' });
  res.json({ ok: true });
}));

r.post('/buscar', auth('estoque.entrada'), wrap(async (req, res) => {
  const c = await sf.cfgGet(db);
  res.json(await sf.buscarSefaz(db, { origem: 'manual', ciencia: c.fiscal_auto_ciencia === '1' }));
}));
r.post('/ciencia', auth('estoque.entrada'), wrap(async (req, res) => {
  const chaves = (req.body?.chaves || []).map(so).filter(chaveOk).slice(0, 50);
  if (!chaves.length) throw new HttpError(400, 'Nenhuma nota selecionada.');
  const out = { ok: 0, erros: [] };
  for (const ch of chaves) { try { await sf.darCiencia(db, ch); out.ok++; } catch (e) { out.erros.push(e.message); break; } }
  res.json(out);
}));
r.post('/chave', auth('estoque.entrada'), wrap(async (req, res) => {
  const chaves = [...new Set((Array.isArray(req.body?.chaves) ? req.body.chaves : String(req.body?.chaves || '').split(/[\s,;]+/)).map(so).filter(Boolean))].slice(0, 50);
  if (!chaves.length) throw new HttpError(400, 'Informe ao menos uma chave de acesso (44 números).');
  const out = [];
  for (const ch of chaves) {
    if (!chaveOk(ch)) { out.push({ chave: ch, ok: false, erro: 'A chave precisa ter 44 números.' }); continue; }
    try { const reg = await sf.buscarServico(db, ch); out.push({ chave: ch, ok: true, emitente: reg.emitente_nome, valor: reg.valor }); } catch (e) { out.push({ chave: ch, ok: false, erro: e.message }); }
  }
  res.json(out);
}));
r.post('/servico/testar', auth('config.gerenciar'), wrap(async (req, res) => {
  const ch = so(req.body?.chave); if (!chaveOk(ch)) throw new HttpError(400, 'Informe uma chave de acesso de 44 números para testar.');
  const reg = await sf.buscarServico(db, ch); res.json({ ok: true, emitente: reg.emitente_nome, valor: reg.valor });
}));

// Painel: o que está pendente para entrada e o que já foi importado para o estoque
r.get('/painel', auth('estoque.entrada'), wrap(async (req, res) => {
  const base = `select d.chave, d.emitente_nome, d.emitente_doc, d.valor, d.emissao, d.numero, d.origem, d.criado_em, d.manifestado_em, d.ignorado, (d.xml is not null) tem_xml,
      e.id entrada_id, e.criado_em importada_em from sefaz_docs d left join entradas e on e.chave=d.chave`;
  const pendentes = (await db.q(`${base} where e.id is null and not d.ignorado order by d.emissao desc nulls last, d.criado_em desc limit 300`)).rows;
  const importadas = (await db.q(`${base} where e.id is not null order by e.criado_em desc limit 200`)).rows;
  const ignoradas = (await db.q(`${base} where e.id is null and d.ignorado order by d.criado_em desc limit 100`)).rows;
  const buscas = (await db.q('select * from sefaz_buscas order by id desc limit 15')).rows;
  res.json({ pendentes, importadas, ignoradas, buscas, resumo: { pendentes: pendentes.length, pendentes_com_xml: pendentes.filter(x => x.tem_xml).length, importadas: importadas.length, valor_pendente: pendentes.reduce((s, x) => s + Number(x.valor), 0) } });
}));
r.get('/doc/:chave/xml', auth('estoque.entrada'), wrap(async (req, res) => {
  const d = (await db.q('select xml from sefaz_docs where chave=$1', [so(req.params.chave)])).rows[0];
  if (!d) throw new HttpError(404, 'Nota não encontrada.');
  if (!d.xml) throw new HttpError(409, 'Esta nota só tem o resumo. Dê ciência da operação e busque novamente para receber o XML completo.');
  res.json({ xml: d.xml });
}));
r.post('/ignorar', auth('estoque.entrada'), wrap(async (req, res) => {
  await db.q('update sefaz_docs set ignorado=$2 where chave=any($1)', [(req.body?.chaves || []).map(so), req.body?.ignorar !== false]); res.json({ ok: true });
}));

module.exports = r;
