// Cadastros: produtos (com ficha técnica), categorias, clientes e fornecedores.
const express = require('express');
const db = require('../db');
const { auth, auditar } = require('../auth');
const { HttpError, wrap, num } = require('../util');
const r = express.Router();

const UNIDADES = ['UN', 'KG', 'G', 'L', 'ML', 'CX', 'PCT'];
const nulo = v => (v === '' || v === undefined ? null : v);
const valor = (b, c) => (c === 'ativo' ? b.ativo !== false : nulo(b[c]));

// Fábrica de CRUD simples para tabelas sem regra especial
function crud(path, tabela, campos, ordem = 'nome') {
  r.get(path, auth(['cadastros.ver', 'financeiro.ver', 'estoque.entrada', 'vendas.acessar']), wrap(async (req, res) => {
    const so = req.query.ativos === '1' ? 'where ativo' : '';
    res.json((await db.q(`select * from ${tabela} ${so} order by ${ordem}`)).rows);
  }));
  r.post(path, auth('cadastros.editar'), wrap(async (req, res) => {
    const b = req.body || {}; if (!b.nome) throw new HttpError(400, 'Informe o nome.');
    const vals = campos.map(c => valor(b, c));
    const ph = campos.map((_, i) => '$' + (i + 1)).join(',');
    const x = await db.q(`insert into ${tabela}(${campos.join(',')}) values(${ph}) returning id`, vals);
    await auditar(null, req.user, tabela + '_criado', { id: x.rows[0].id, nome: b.nome });
    res.json({ id: x.rows[0].id });
  }));
  r.put(path + '/:id', auth('cadastros.editar'), wrap(async (req, res) => {
    const b = req.body || {}; if (!b.nome) throw new HttpError(400, 'Informe o nome.');
    const set = campos.map((c, i) => `${c}=$${i + 1}`).join(',');
    await db.q(`update ${tabela} set ${set} where id=$${campos.length + 1}`, [...campos.map(c => valor(b, c)), req.params.id]);
    res.json({ ok: true });
  }));
  r.delete(path + '/:id', auth('cadastros.excluir'), wrap(async (req, res) => {
    await db.q(`delete from ${tabela} where id=$1`, [req.params.id]);
    await auditar(null, req.user, tabela + '_excluido', { id: req.params.id });
    res.json({ ok: true });
  }));
}

// Cadastro rápido de cliente na tela de recebimento (venda fiado) — não exige a permissão de cadastros
r.post('/clientes/rapido', auth(['vendas.receber', 'cadastros.editar']), wrap(async (req, res) => {
  const b = req.body || {}; if (!String(b.nome || '').trim()) throw new HttpError(400, 'Informe o nome do cliente.');
  const x = await db.q('insert into clientes(nome, documento, telefone, endereco, ativo) values($1,$2,$3,$4,true) returning id, nome', [b.nome.trim(), nulo(b.documento), nulo(b.telefone), nulo(b.endereco)]);
  await auditar(null, req.user, 'clientes_criado', { id: x.rows[0].id, nome: x.rows[0].nome, origem: 'fiado' });
  res.json(x.rows[0]);
}));

crud('/clientes', 'clientes', ['nome', 'documento', 'telefone', 'email', 'endereco', 'observacao', 'ativo']);
crud('/fornecedores', 'fornecedores', ['nome', 'fantasia', 'documento', 'contato', 'telefone', 'email', 'endereco', 'cidade', 'uf', 'condicao_pagamento', 'observacao', 'ativo']);

// ---- Categorias
r.get('/categorias', auth(), wrap(async (req, res) => res.json((await db.q('select * from categorias order by nome')).rows)));
r.post('/categorias', auth('cadastros.editar'), wrap(async (req, res) => {
  if (!req.body.nome) throw new HttpError(400, 'Informe o nome.');
  const x = await db.q('insert into categorias(nome) values($1) returning id', [req.body.nome.trim()]); res.json({ id: x.rows[0].id });
}));
r.put('/categorias/:id', auth('cadastros.editar'), wrap(async (req, res) => {
  await db.q('update categorias set nome=$1 where id=$2', [req.body.nome.trim(), req.params.id]); res.json({ ok: true });
}));
r.delete('/categorias/:id', auth('cadastros.excluir'), wrap(async (req, res) => {
  await db.q('delete from categorias where id=$1', [req.params.id]); res.json({ ok: true });
}));

// ---- Produtos
r.get('/produtos', auth(['cadastros.ver', 'estoque.ver', 'vendas.acessar', 'estoque.entrada', 'estoque.ajuste']), wrap(async (req, res) => {
  const f = [];
  if (req.query.ativos === '1') f.push('p.ativo');
  if (req.query.vendaveis === '1') f.push('p.vendavel');
  if (req.query.tipo) f.push(`p.tipo='${['revenda', 'insumo', 'preparado'].includes(req.query.tipo) ? req.query.tipo : 'revenda'}'`);
  const x = await db.q(`select p.*, c.nome categoria, (select coalesce(json_agg(b.codigo_barras order by b.principal desc, b.id), '[]'::json) from produto_codigos_barras b where b.produto_codigo=p.codigo) codigos_barras from produtos p left join categorias c on c.id=p.categoria_id
    ${f.length ? 'where ' + f.join(' and ') : ''} order by p.nome`);
  res.json(x.rows);
}));
r.get('/produtos/:id', auth(['cadastros.ver', 'estoque.ver']), wrap(async (req, res) => {
  const p = (await db.q('select p.*, '+`(select coalesce(json_agg(b.codigo_barras order by b.principal desc, b.id), '[]'::json) from produto_codigos_barras b where b.produto_codigo=p.codigo) codigos_barras`+' from produtos p where p.id=$1', [req.params.id])).rows[0];
  if (!p) throw new HttpError(404, 'Produto não encontrado.');
  p.codigos_barras_det = (await db.q('select codigo_barras, fator, principal from produto_codigos_barras where produto_codigo=$1 order by principal desc, id', [p.codigo])).rows.map(x => ({ ...x, fator: Number(x.fator) }));
  p.codigos_fornecedor = (await db.q(`select pf.fornecedor_id, f.nome fornecedor, pf.codigo_fornecedor, pf.fator from produto_fornecedor pf join fornecedores f on f.id=pf.fornecedor_id
    where pf.produto_codigo=$1 order by f.nome, pf.id`, [p.codigo])).rows.map(x => ({ ...x, fator: Number(x.fator) }));
  p.receita = (await db.q(`select r.insumo_id, r.quantidade, i.nome, i.unidade, i.custo_medio from receitas r
    join produtos i on i.id=r.insumo_id where r.produto_id=$1 order by i.nome`, [p.id])).rows;
  res.json(p);
}));

async function salvarProduto(c, id, b) {
  if (!b.nome) throw new HttpError(400, 'Informe o nome do produto.');
  const unidade = UNIDADES.includes(b.unidade) ? b.unidade : 'UN';
  const tipo = ['revenda', 'insumo', 'preparado'].includes(b.tipo) ? b.tipo : 'revenda';
  const destino = ['cozinha', 'bar', 'nenhum'].includes(b.destino) ? b.destino : 'nenhum';
  const vendavel = tipo === 'insumo' ? !!b.vendavel : b.vendavel !== false;
  const controla = tipo === 'preparado' ? !!b.controla_estoque : b.controla_estoque !== false;
  // permite observação na venda: se não vier da tela, porções/pratos/sobremesas ficam marcados por padrão
  let obsOk = b.permite_obs;
  if (obsOk === undefined && !id) { const ct = b.categoria_id ? (await c.query('select nome from categorias where id=$1', [b.categoria_id])).rows[0] : null; obsOk = !!ct && /(porco|prato|sobremesa)/.test(String(ct.nome).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase()); }
  const vals = [null /* código interno: sempre gerado pelo sistema (sequencial) e nunca alterado pela tela */, b.nome, nulo(b.categoria_id), unidade, tipo, destino,
    num(b.preco_venda), num(b.estoque_minimo), controla, vendavel, b.ativo !== false];
  const obsParam = obsOk === undefined ? null : !!obsOk;
  if (id && b.ativo === false) {   // inativar: não pode haver saldo em estoque (saldo negativo não impede)
    const at = (await c.query('select ativo, estoque_atual, controla_estoque, nome from produtos where id=$1', [id])).rows[0];
    if (at && at.ativo && at.controla_estoque && Number(at.estoque_atual) > 0.0005) throw new HttpError(400, `"${at.nome}" ainda tem ${Number(at.estoque_atual).toLocaleString('pt-BR')} em estoque e não pode ser inativado. Dê baixa no estoque (Estoque → Ajuste) e tente de novo.`);
  }
  if (id) {
    await c.query(`update produtos set codigo=coalesce($1,codigo),nome=$2,categoria_id=$3,unidade=$4,tipo=$5,destino=$6,
      preco_venda=$7,estoque_minimo=$8,controla_estoque=$9,vendavel=($10::boolean and not suspenso),ativo=$11,permite_obs=coalesce($13,permite_obs) where id=$12`, [...vals, id, obsParam]);
  } else {
    const x = await c.query(`insert into produtos(codigo,nome,categoria_id,unidade,tipo,destino,preco_venda,estoque_minimo,controla_estoque,vendavel,ativo,permite_obs)
      values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) returning id`, [...vals, !!obsOk]);
    id = x.rows[0].id;
  }
  const codProd = (await c.query('select codigo from produtos where id=$1', [id])).rows[0].codigo;
  if (b.imagem !== undefined) { // imagem do produto (data URL reduzida pela tela); vazio remove
    const im = String(b.imagem || '');
    if (im && (!/^data:image\/(jpeg|png|webp);base64,/.test(im) || im.length > 300000)) throw new HttpError(400, 'Imagem inválida ou muito grande.');
    await c.query('update produtos set imagem=$1 where id=$2', [im || null, id]);
  }
  if (Array.isArray(b.codigos_barras)) { // códigos de barras do produto (cada um com seu fator): tabela própria, ligada pelo código interno
    const lista = []; const vistos = new Set();
    for (const x of b.codigos_barras) {
      const eb = String(typeof x === 'object' && x ? x.codigo_barras : x ?? '').trim(); if (!eb || vistos.has(eb)) continue; vistos.add(eb);
      const fator = typeof x === 'object' && x && x.fator !== undefined && x.fator !== '' ? num(x.fator, 0) : 1;
      if (!(fator > 0)) throw new HttpError(400, 'Informe o fator do código de barras ' + eb + ' (1 se for unitário).');
      lista.push({ eb, fator });
    }
    for (const { eb } of lista) {
      if (eb.length > 40) throw new HttpError(400, 'Código de barras muito longo: ' + eb);
      const o = (await c.query('select p.nome from produto_codigos_barras b join produtos p on p.codigo=b.produto_codigo where b.codigo_barras=$1 and b.produto_codigo<>$2', [eb, codProd])).rows[0];
      if (o) throw new HttpError(400, `O código de barras ${eb} já pertence ao produto "${o.nome}".`);
    }
    await c.query('delete from produto_codigos_barras where produto_codigo=$1 and not (codigo_barras = any($2::text[]))', [codProd, lista.map(x => x.eb)]);
    for (const [i, { eb, fator }] of lista.entries())
      await c.query(`insert into produto_codigos_barras(produto_codigo, codigo_barras, principal, fator) values($1,$2,$3,$4)
        on conflict (codigo_barras) do update set principal=excluded.principal, fator=excluded.fator`, [codProd, eb, i === 0, fator]);
  }
  if (Array.isArray(b.codigos_fornecedor)) { // código do produto em cada fornecedor + fator de compra
    const lista = []; const vistos = new Set();
    for (const x of b.codigos_fornecedor) {
      const fid = Number(x.fornecedor_id), cf = String(x.codigo_fornecedor ?? '').trim(); if (!fid || !cf) continue;
      const k = fid + '|' + cf; if (vistos.has(k)) continue; vistos.add(k);
      const fator = x.fator !== undefined && x.fator !== '' ? num(x.fator, 0) : 1;
      if (!(fator > 0)) throw new HttpError(400, 'Informe o fator do código do fornecedor ' + cf + ' (1 se for unitário).');
      const o = (await c.query('select p.nome from produto_fornecedor pf join produtos p on p.codigo=pf.produto_codigo where pf.fornecedor_id=$1 and pf.codigo_fornecedor=$2 and pf.produto_codigo<>$3', [fid, cf, codProd])).rows[0];
      if (o) throw new HttpError(400, `O código ${cf} deste fornecedor já está ligado ao produto "${o.nome}".`);
      lista.push({ fid, cf, fator });
    }
    await c.query('delete from produto_fornecedor where produto_codigo=$1', [codProd]);
    for (const { fid, cf, fator } of lista)
      await c.query('insert into produto_fornecedor(produto_codigo, fornecedor_id, codigo_fornecedor, fator) values($1,$2,$3,$4)', [codProd, fid, cf, fator]);
  }
  if (Array.isArray(b.receita)) {
    await c.query('delete from receitas where produto_id=$1', [id]);
    if (tipo === 'preparado') {
      const vistos = new Set();
      for (const it of b.receita) {
        const ins = Number(it.insumo_id); const q = num(it.quantidade);
        if (!ins || q <= 0 || vistos.has(ins) || ins === id) continue; vistos.add(ins);
        await c.query('insert into receitas(produto_id, insumo_id, quantidade) values($1,$2,$3)', [id, ins, q]);
      }
    }
  }
  return id;
}
r.post('/produtos', auth('cadastros.editar'), wrap(async (req, res) => {
  const id = await db.tx(c => salvarProduto(c, null, req.body || {}));
  await auditar(null, req.user, 'produto_criado', { id, nome: req.body.nome });
  res.json({ id });
}));
r.put('/produtos/:id', auth('cadastros.editar'), wrap(async (req, res) => {
  await db.tx(c => salvarProduto(c, Number(req.params.id), req.body || {}));
  await auditar(null, req.user, 'produto_alterado', { id: req.params.id, preco: req.body.preco_venda });
  res.json({ ok: true });
}));
// ---- Cadastro automático suspenso (vindo do XML): confirmar ou amarrar a um produto existente
const gerarCodigo = async c => { for (;;) { const cod = (await c.query(`select nextval('seq_produto_codigo')::text c`)).rows[0].c; if (!(await c.query('select 1 from produtos where codigo=$1', [cod])).rowCount) return cod; } };
r.post('/produtos/:id(\\d+)/confirmar-cadastro', auth('cadastros.editar'), wrap(async (req, res) => {
  const out = await db.tx(async c => {
    const p = (await c.query('select * from produtos where id=$1 for update', [req.params.id])).rows[0];
    if (!p) throw new HttpError(404, 'Produto não encontrado.');
    if (!p.suspenso) throw new HttpError(400, 'Este cadastro já está confirmado.');
    const cod = await gerarCodigo(c);   // só agora usa o sequencial; os códigos de barras e do fornecedor acompanham (ON UPDATE CASCADE)
    await c.query('update produtos set codigo=$1, suspenso=false where id=$2', [cod, p.id]);
    await auditar(c, req.user, 'produto_cadastro_confirmado', { id: p.id, nome: p.nome, codigo: cod });
    return { id: p.id, codigo: cod };
  });
  res.json(out);
}));
r.post('/produtos/:id(\\d+)/amarrar', auth('cadastros.editar'), wrap(async (req, res) => {
  const out = await db.tx(async c => {
    const dst = Number((req.body || {}).destino_id);
    const s = (await c.query('select * from produtos where id=$1 for update', [req.params.id])).rows[0];
    const d = dst ? (await c.query('select * from produtos where id=$1 for update', [dst])).rows[0] : null;
    if (!s) throw new HttpError(404, 'Produto não encontrado.');
    if (!s.suspenso) throw new HttpError(400, 'Só cadastro automático pendente pode ser amarrado a outro produto.');
    if (!d) throw new HttpError(400, 'Escolha o produto do cadastro ao qual amarrar.');
    if (d.suspenso) throw new HttpError(400, 'Escolha um produto já confirmado (não um cadastro automático pendente).');
    if (d.id === s.id) throw new HttpError(400, 'Escolha outro produto.');
    // o que apontava para o cadastro automático passa para o produto escolhido (estoque, histórico, códigos de barras e do fornecedor)
    await c.query('update produto_codigos_barras set principal=false where produto_codigo=$1', [s.codigo]);
    const fks = (await c.query(`select c.conrelid::regclass::text tbl, a.attname col, fa.attname refcol from pg_constraint c
      join pg_attribute a on a.attrelid=c.conrelid and a.attnum=c.conkey[1] join pg_attribute fa on fa.attrelid=c.confrelid and fa.attnum=c.confkey[1]
      where c.contype='f' and c.confrelid='produtos'::regclass and array_length(c.conkey,1)=1`)).rows;
    for (const f of fks) {
      const novo = f.refcol === 'codigo' ? d.codigo : d.id, velho = f.refcol === 'codigo' ? s.codigo : s.id;
      await c.query('savepoint sp_fk');
      try { await c.query(`update ${f.tbl} set ${f.col}=$1 where ${f.col}=$2`, [novo, velho]); await c.query('release savepoint sp_fk'); }
      catch (er) { await c.query('rollback to savepoint sp_fk'); if (er.code !== '23505') throw er; await c.query(`delete from ${f.tbl} where ${f.col}=$1`, [velho]); }
    }
    const ea = Number(d.estoque_atual), es = Number(s.estoque_atual), soma = ea + es;
    const custo = soma > 0 && es > 0 ? (Math.max(ea, 0) * Number(d.custo_medio) + es * Number(s.custo_medio)) / (Math.max(ea, 0) + es) : Number(d.custo_medio);
    await c.query('update produtos set estoque_atual=$1, custo_medio=$2 where id=$3', [soma, Math.round(custo * 1e4) / 1e4, d.id]);
    await c.query('delete from produtos where id=$1', [s.id]);
    await auditar(c, req.user, 'produto_amarrado', { automatico: s.nome, para: d.nome, de_id: s.id, para_id: d.id, estoque_transferido: es });
    return { id: d.id, nome: d.nome, estoque_transferido: es };
  });
  res.json(out);
}));

// Produto com histórico (movimento de estoque, vendas, compras, produção ou uso em ficha técnica) nunca é excluído: só inativado.
async function temHistorico(c, id) {
  const q = async (sql) => (await c.query(sql, [id])).rowCount > 0;
  return (await q('select 1 from mov_estoque where produto_id=$1 limit 1')) || (await q('select 1 from pedido_itens where produto_id=$1 limit 1'))
    || (await q('select 1 from entrada_itens where produto_id=$1 limit 1')) || (await q('select 1 from producoes where produto_id=$1 limit 1'))
    || (await q('select 1 from receitas where insumo_id=$1 limit 1')) || (await q('select 1 from caixa_insumos where insumo_id=$1 limit 1'));
}
r.delete('/produtos/:id', auth('cadastros.excluir'), wrap(async (req, res) => {
  const id = Number(req.params.id);
  if (await temHistorico({ query: (s, p) => db.q(s, p) }, id)) throw new HttpError(400, 'Este produto tem histórico (movimentação de estoque, vendas, compras, produção ou uso em ficha técnica) e não pode ser excluído. Use "Editar" e desmarque "Ativo" para inativá-lo.');
  await db.q('delete from produtos where id=$1', [id]);
  await auditar(null, req.user, 'produto_excluido', { id: req.params.id });
  res.json({ ok: true });
}));

module.exports = r;
