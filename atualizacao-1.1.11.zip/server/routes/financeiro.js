// Financeiro: contas a pagar e a receber.
const express = require('express');
const db = require('../db');
const { auth, auditar } = require('../auth');
const { HttpError, wrap, num, r2, hoje } = require('../util');
const r = express.Router();

r.get('/titulos', auth('financeiro.ver'), wrap(async (req, res) => {
  const par = []; const f = [];
  if (['pagar', 'receber'].includes(req.query.tipo)) { par.push(req.query.tipo); f.push(`t.tipo=$${par.length}`); }
  if (['aberto', 'pago', 'cancelado'].includes(req.query.status)) { par.push(req.query.status); f.push(`t.status=$${par.length}`); }
  if (req.query.de) { par.push(req.query.de); f.push(`t.vencimento >= $${par.length}`); }
  if (req.query.ate) { par.push(req.query.ate); f.push(`t.vencimento <= $${par.length}`); }
  const x = await db.q(`select t.*, f.nome fornecedor, c.nome cliente, (t.status='aberto' and t.vencimento < current_date) vencido
    from titulos t left join fornecedores f on f.id=t.fornecedor_id left join clientes c on c.id=t.cliente_id
    ${f.length ? 'where ' + f.join(' and ') : ''} order by t.vencimento, t.id limit 1000`, par);
  const tot = { aberto: 0, vencido: 0, pago: 0 };
  x.rows.forEach(t => { if (t.status === 'aberto') { tot.aberto += t.valor; if (t.vencido) tot.vencido += t.valor; } if (t.status === 'pago') tot.pago += Number(t.valor_pago || 0); });
  res.json({ titulos: x.rows, totais: { aberto: r2(tot.aberto), vencido: r2(tot.vencido), pago: r2(tot.pago) } });
}));

r.post('/titulos', auth('financeiro.editar'), wrap(async (req, res) => {
  const b = req.body || {};
  if (!['pagar', 'receber'].includes(b.tipo)) throw new HttpError(400, 'Tipo inválido.');
  if (!b.descricao || !b.vencimento || num(b.valor) <= 0) throw new HttpError(400, 'Informe descrição, valor e vencimento.');
  const parcelas = Math.min(Math.max(parseInt(b.parcelas || 1, 10), 1), 60);
  const ids = [];
  for (let n = 0; n < parcelas; n++) {
    const d = new Date(b.vencimento + 'T12:00:00'); d.setMonth(d.getMonth() + n);
    const x = await db.q(`insert into titulos(tipo,descricao,categoria,fornecedor_id,cliente_id,valor,vencimento) values($1,$2,$3,$4,$5,$6,$7) returning id`,
      [b.tipo, parcelas > 1 ? `${b.descricao} (${n + 1}/${parcelas})` : b.descricao, b.categoria || null, b.fornecedor_id || null, b.cliente_id || null, r2(num(b.valor)), d.toISOString().slice(0, 10)]);
    ids.push(x.rows[0].id);
  }
  res.json({ ids });
}));

r.put('/titulos/:id', auth('financeiro.editar'), wrap(async (req, res) => {
  const b = req.body || {};
  const t = (await db.q('select status from titulos where id=$1', [req.params.id])).rows[0];
  if (!t) throw new HttpError(404, 'Título não encontrado.');
  if (t.status !== 'aberto') throw new HttpError(400, 'Só é possível editar títulos em aberto.');
  await db.q('update titulos set descricao=$1, categoria=$2, fornecedor_id=$3, cliente_id=$4, valor=$5, vencimento=$6 where id=$7',
    [b.descricao, b.categoria || null, b.fornecedor_id || null, b.cliente_id || null, r2(num(b.valor)), b.vencimento, req.params.id]);
  res.json({ ok: true });
}));

r.post('/titulos/:id/baixar', auth('financeiro.baixar'), wrap(async (req, res) => {
  const b = req.body || {};
  const t = (await db.q('select * from titulos where id=$1', [req.params.id])).rows[0];
  if (!t || t.status !== 'aberto') throw new HttpError(400, 'Título não está em aberto.');
  if (t.tipo === 'receber' && t.categoria === 'Venda fiado') throw new HttpError(400, 'Fiado só pode ser baixado em "Receber fiado" (exige caixa aberto e forma de pagamento).');
  const v = r2(num(b.valor, t.valor)); if (v <= 0) throw new HttpError(400, 'Valor inválido.');
  await db.q("update titulos set status='pago', pago_em=$1, valor_pago=$2, forma=$3 where id=$4", [b.data || hoje(), v, b.forma || null, t.id]);
  await auditar(null, req.user, 'titulo_baixado', { id: t.id, tipo: t.tipo, valor: v });
  res.json({ ok: true });
}));

r.post('/titulos/:id/cancelar', auth('financeiro.editar'), wrap(async (req, res) => {
  await db.q("update titulos set status='cancelado' where id=$1 and status='aberto'", [req.params.id]);
  await auditar(null, req.user, 'titulo_cancelado', { id: req.params.id });
  res.json({ ok: true });
}));

module.exports = r;
