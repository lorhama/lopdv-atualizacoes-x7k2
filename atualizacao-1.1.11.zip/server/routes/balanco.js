// Balanço geral de estoque: conferência de todo o estoque (com ou sem acúmulo), ajuste final e relatório em PDF.
const express = require('express');
const db = require('../db');
const { auth, auditar } = require('../auth');
const { HttpError, wrap, num, r2 } = require('../util');
const est = require('../estoque_lib');
const pdf = require('../pdf_simples');
const r = express.Router();
const P = 'estoque.ajuste';
const q3 = v => Math.round(Number(v) * 1000) / 1000;

const MSG_ABERTO = 'Já existe um balanço em andamento. Finalize ou cancele o balanço pendente antes de abrir outro.';

async function emAndamento() { return (await db.q("select * from balancos where status='andamento' limit 1")).rows[0] || null; }
async function exigirAndamento(id) {
  const b = (await db.q('select * from balancos where id=$1', [id])).rows[0];
  if (!b) throw new HttpError(404, 'Balanço não encontrado.');
  if (b.status !== 'andamento') throw new HttpError(400, 'Este balanço já foi ' + (b.status === 'finalizado' ? 'finalizado.' : 'cancelado.'));
  return b;
}

// ---- Lista de balanços (histórico com a situação)
r.get('/', auth([P, 'estoque.ver']), wrap(async (req, res) => {
  const l = (await db.q(`select b.id, b.status, b.acumula, b.iniciado_em, b.finalizado_em, b.caixa_aberto, b.zerou_nao_conferidos, u.nome iniciado_por, f.nome finalizado_por,
      (select count(*) from balanco_itens i where i.balanco_id=b.id and i.conferido)::int conferidos,
      (select count(*) from balanco_itens i where i.balanco_id=b.id and not i.conferido)::int nao_conferidos
    from balancos b left join usuarios u on u.id=b.iniciado_por left join usuarios f on f.id=b.finalizado_por order by b.id desc limit 200`)).rows;
  res.json(l);
}));

// ---- Balanço em andamento (com os itens já conferidos)
r.get('/atual', auth(P), wrap(async (req, res) => {
  const b = await emAndamento();
  if (!b) return res.json({ balanco: null, caixas_abertos: (await db.q("select count(*)::int n from caixas where status='aberto'")).rows[0].n });
  const itens = (await db.q(`select i.produto_id, p.codigo, p.nome, p.unidade, i.qtd_contada, i.contado_em, i.primeiro_em, i.leituras
    from balanco_itens i join produtos p on p.id=i.produto_id where i.balanco_id=$1 and i.conferido order by i.contado_em desc`, [b.id])).rows;
  const tot = (await db.q("select count(*)::int n from produtos where controla_estoque and ativo")).rows[0].n;
  res.json({ balanco: b, itens, total_produtos: tot, caixas_abertos: (await db.q("select count(*)::int n from caixas where status='aberto'")).rows[0].n });
}));

// ---- Novo balanço (não deixa abrir se houver um pendente)
r.post('/', auth(P), wrap(async (req, res) => {
  if (await emAndamento()) throw new HttpError(400, MSG_ABERTO);
  const acumula = !!(req.body || {}).acumula;
  const cx = (await db.q("select count(*)::int n from caixas where status='aberto'")).rows[0].n;
  let b;
  try { b = (await db.q('insert into balancos(acumula, iniciado_por, caixa_aberto) values($1,$2,$3) returning *', [acumula, req.user.id, cx > 0])).rows[0]; }
  catch (e) { if (e.code === '23505') throw new HttpError(400, MSG_ABERTO); throw e; }
  await auditar(null, req.user, 'balanco_iniciado', { id: b.id, acumula, caixas_abertos: cx });
  res.json({ balanco: b, caixas_abertos: cx });
}));

// ---- Localiza o produto pelo código de barras / código interno / nome
async function achar(texto) {
  const t = String(texto || '').trim();
  if (!t) throw new HttpError(400, 'Informe ou leia o código do produto.');
  const SQL = `select p.id, p.codigo, p.nome, p.unidade, p.controla_estoque, p.ativo, p.estoque_atual, coalesce(b.fator,1) fator
    from produtos p left join produto_codigos_barras b on b.produto_codigo=p.codigo and b.codigo_barras=$1`;
  let l = (await db.q(`${SQL} where p.codigo=$1 or b.codigo_barras=$1 or p.codigo_barras=$1 order by (b.codigo_barras is null) limit 2`, [t])).rows;
  if (!l.length) {
    l = (await db.q(`select p.id, p.codigo, p.nome, p.unidade, p.controla_estoque, p.ativo, p.estoque_atual, 1 fator from produtos p where p.ativo and p.nome ilike $1 order by p.nome limit 6`, ['%' + t + '%'])).rows;
    if (l.length > 1) throw new HttpError(400, 'Vários produtos encontrados com "' + t + '": ' + l.map(x => x.nome).slice(0, 4).join(', ') + '... Leia o código de barras ou digite o nome completo.');
  }
  if (!l.length) throw new HttpError(404, 'Produto não encontrado: ' + t);
  const p = l[0];
  if (!p.controla_estoque) throw new HttpError(400, `"${p.nome}" não controla estoque; não entra no balanço.`);
  if (!p.ativo) throw new HttpError(400, `"${p.nome}" está inativo.`);
  return { ...p, fator: Number(p.fator) || 1 };
}

r.get('/:id(\\d+)/produto', auth(P), wrap(async (req, res) => {
  const b = await exigirAndamento(req.params.id);
  const p = await achar(req.query.codigo);
  const it = (await db.q('select qtd_contada, contado_em from balanco_itens where balanco_id=$1 and produto_id=$2 and conferido', [b.id, p.id])).rows[0];
  res.json({ produto: { id: p.id, codigo: p.codigo, nome: p.nome, unidade: p.unidade, fator: p.fator }, contada: it ? Number(it.qtd_contada) : null });
}));

// ---- Lança uma leitura. Com acúmulo: soma (padrão 1 por leitura). Sem acúmulo: grava a quantidade informada (substitui).
r.post('/:id(\\d+)/ler', auth(P), wrap(async (req, res) => {
  const b = await exigirAndamento(req.params.id);
  const body = req.body || {};
  const p = body.produto_id ? { id: +body.produto_id, fator: 1 } : await achar(body.codigo);
  if (!p.nome) { const x = (await db.q('select id, codigo, nome, unidade, controla_estoque from produtos where id=$1', [p.id])).rows[0]; if (!x || !x.controla_estoque) throw new HttpError(400, 'Produto inválido para balanço.'); Object.assign(p, x); }
  const definir = body.definir === true || !b.acumula;
  let q = body.quantidade === undefined || body.quantidade === null || body.quantidade === '' ? null : q3(num(body.quantidade));
  if (definir && q === null) throw new HttpError(400, 'Informe a quantidade contada.');
  if (q !== null && q < 0) throw new HttpError(400, 'A quantidade contada não pode ser negativa.');
  const un = body.produto_id ? 1 : p.fator;
  let r2x;
  if (!definir) { // acúmulo
    const add = q3((q === null ? 1 : q) * un);
    r2x = (await db.q(`insert into balanco_itens(balanco_id, produto_id, qtd_contada) values($1,$2,$3)
      on conflict (balanco_id, produto_id) do update set qtd_contada = coalesce(balanco_itens.qtd_contada,0) + $3, contado_em=now(), leituras = balanco_itens.leituras + 1, conferido=true
      returning qtd_contada, leituras`, [b.id, p.id, add])).rows[0];
  } else {
    const v = q3(q * un);
    r2x = (await db.q(`insert into balanco_itens(balanco_id, produto_id, qtd_contada) values($1,$2,$3)
      on conflict (balanco_id, produto_id) do update set qtd_contada=$3, contado_em=now(), leituras = balanco_itens.leituras + 1, conferido=true
      returning qtd_contada, leituras`, [b.id, p.id, v])).rows[0];
  }
  res.json({ produto: { id: p.id, codigo: p.codigo, nome: p.nome, unidade: p.unidade }, qtd_contada: Number(r2x.qtd_contada), leituras: r2x.leituras });
}));

// ---- Remove um produto da conferência (volta a ser "não conferido")
r.delete('/:id(\\d+)/itens/:pid(\\d+)', auth(P), wrap(async (req, res) => {
  const b = await exigirAndamento(req.params.id);
  await db.q('delete from balanco_itens where balanco_id=$1 and produto_id=$2', [b.id, req.params.pid]);
  res.json({ ok: true });
}));

// ---- Cálculo do ajuste: contado + (tudo que movimentou o produto DEPOIS da contagem, ex.: vendas) = estoque final
async function calcular(c0, b, bloquear) {
  const c = c0.query ? c0 : { query: (...a) => c0.q(...a) };
  const cont = (await c.query(`select i.produto_id, i.qtd_contada, i.contado_em, p.codigo, p.nome, p.unidade, p.estoque_atual, p.custo_medio,
      coalesce((select sum(m.quantidade) from mov_estoque m where m.produto_id=i.produto_id and m.criado_em > i.contado_em),0) mov
    from balanco_itens i join produtos p on p.id=i.produto_id where i.balanco_id=$1 and i.conferido order by p.nome ${bloquear ? 'for update of p' : ''}`, [b.id])).rows
    .map(x => { const sist = Number(x.estoque_atual), cont2 = Number(x.qtd_contada), mov = q3(x.mov), fin = q3(cont2 + mov);
      return { produto_id: x.produto_id, codigo: x.codigo, nome: x.nome, unidade: x.unidade, custo: Number(x.custo_medio), contado_em: x.contado_em, sistema: sist, contado: cont2, mov_depois: mov, final: fin, diferenca: q3(fin - sist) }; });
  const nao = (await c.query(`select p.id produto_id, p.codigo, p.nome, p.unidade, p.estoque_atual, p.custo_medio from produtos p
    where p.controla_estoque and p.ativo and not exists (select 1 from balanco_itens i where i.balanco_id=$1 and i.produto_id=p.id and i.conferido) order by p.nome ${bloquear ? 'for update of p' : ''}`, [b.id])).rows
    .map(x => ({ produto_id: x.produto_id, codigo: x.codigo, nome: x.nome, unidade: x.unidade, custo: Number(x.custo_medio), sistema: Number(x.estoque_atual) }));
  return { conferidos: cont, nao_conferidos: nao };
}

r.post('/:id(\\d+)/previa', auth(P), wrap(async (req, res) => {
  const b = await exigirAndamento(req.params.id);
  const c = await calcular(db, b, false);
  const com = c.conferidos.filter(x => Math.abs(x.mov_depois) > 0.0004);
  res.json({ conferidos: c.conferidos.length, nao_conferidos: c.nao_conferidos.length, com_movimento_depois: com.length,
    vendas_abatidas: com.slice(0, 50).map(x => ({ nome: x.nome, unidade: x.unidade, mov: x.mov_depois })),
    nao_conferidos_valor: r2(c.nao_conferidos.reduce((s, x) => s + Math.max(0, x.sistema) * x.custo, 0)),
    caixas_abertos: (await db.q("select count(*)::int n from caixas where status='aberto'")).rows[0].n });
}));

// ---- Finaliza: aplica as contagens (já abatendo o movimento posterior) e zera, ou não, os não conferidos
r.post('/:id(\\d+)/finalizar', auth(P), wrap(async (req, res) => {
  const body = req.body || {};
  if (body.zerar !== true && body.zerar !== false) throw new HttpError(400, 'Informe se os produtos não conferidos devem ser zerados.');
  if (body.confirmado !== true) throw new HttpError(400, 'Confirmação necessária para finalizar o balanço.');
  const out = await db.tx(async c => {
    const b = (await c.query("select * from balancos where id=$1 for update", [req.params.id])).rows[0];
    if (!b) throw new HttpError(404, 'Balanço não encontrado.');
    if (b.status !== 'andamento') throw new HttpError(400, 'Este balanço já foi ' + (b.status === 'finalizado' ? 'finalizado.' : 'cancelado.'));
    const { conferidos, nao_conferidos } = await calcular(c, b, true);
    for (const x of conferidos) {
      if (Math.abs(x.diferenca) > 0.0004) await est.mover(c, { produto_id: x.produto_id, tipo: 'ajuste', quantidade: x.diferenca, custo_unit: x.custo, origem: 'balanco', ref_id: b.id, motivo: `Balanço #${b.id}` + (Math.abs(x.mov_depois) > 0.0004 ? ` (abatido ${x.mov_depois} movimentado após a contagem)` : ''), usuario_id: req.user.id });
      await c.query('update balanco_itens set estoque_sistema=$1, mov_depois=$2, estoque_final=$3, diferenca=$4, acao=$5 where balanco_id=$6 and produto_id=$7',
        [x.sistema, x.mov_depois, x.final, x.diferenca, 'atualizado', b.id, x.produto_id]);
    }
    for (const x of nao_conferidos) {
      const zera = body.zerar && Math.abs(x.sistema) > 0.0004;
      if (zera) await est.mover(c, { produto_id: x.produto_id, tipo: 'ajuste', quantidade: q3(-x.sistema), custo_unit: x.custo, origem: 'balanco', ref_id: b.id, motivo: `Balanço #${b.id} - não conferido (zerado)`, usuario_id: req.user.id });
      await c.query(`insert into balanco_itens(balanco_id, produto_id, conferido, qtd_contada, contado_em, primeiro_em, estoque_sistema, mov_depois, estoque_final, diferenca, acao)
        values($1,$2,false,null,null,null,$3,0,$4,$5,$6) on conflict (balanco_id, produto_id) do update set conferido=false, estoque_sistema=$3, estoque_final=$4, diferenca=$5, acao=$6`,
        [b.id, x.produto_id, x.sistema, body.zerar ? 0 : x.sistema, body.zerar ? q3(-x.sistema) : 0, body.zerar ? 'zerado' : 'mantido']);
    }
    await c.query("update balancos set status='finalizado', finalizado_em=now(), finalizado_por=$1, zerou_nao_conferidos=$2, observacao=$3 where id=$4", [req.user.id, body.zerar, String(body.observacao || '').trim() || null, b.id]);
    await auditar(c, req.user, 'balanco_finalizado', { id: b.id, conferidos: conferidos.length, nao_conferidos: nao_conferidos.length, zerou: body.zerar, com_movimento_depois: conferidos.filter(x => Math.abs(x.mov_depois) > 0.0004).length });
    return { id: b.id, conferidos: conferidos.length, nao_conferidos: nao_conferidos.length, zerou: body.zerar };
  });
  res.json(out);
}));

// ---- Cancela (nada do estoque é alterado)
r.post('/:id(\\d+)/cancelar', auth(P), wrap(async (req, res) => {
  const b = await exigirAndamento(req.params.id);
  await db.q("update balancos set status='cancelado', finalizado_em=now(), finalizado_por=$1 where id=$2", [req.user.id, b.id]);
  await auditar(null, req.user, 'balanco_cancelado', { id: b.id });
  res.json({ ok: true });
}));

// ---- Relatório PDF (itens conferidos e não conferidos)
r.get('/:id(\\d+)/relatorio.pdf', auth([P, 'estoque.ver', 'relatorios.estoque']), wrap(async (req, res) => {
  const b = (await db.q(`select b.*, u.nome iniciado_nome, f.nome finalizado_nome from balancos b left join usuarios u on u.id=b.iniciado_por left join usuarios f on f.id=b.finalizado_por where b.id=$1`, [req.params.id])).rows[0];
  if (!b) throw new HttpError(404, 'Balanço não encontrado.');
  if (b.status !== 'finalizado') throw new HttpError(400, 'O relatório só existe para balanços finalizados.');
  const it = (await db.q(`select i.*, p.codigo, p.nome, p.unidade from balanco_itens i join produtos p on p.id=i.produto_id where i.balanco_id=$1 order by p.nome`, [b.id])).rows;
  const emp = ((await db.q("select valor from config where chave='empresa'")).rows[0] || {}).valor || '';
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `inline; filename="balanco-${b.id}.pdf"`);
  res.send(relatorioPdf(b, it, emp));
}));

const fq = v => (v === null || v === undefined ? '' : Number(v).toLocaleString('pt-BR', { maximumFractionDigits: 3 }));
const fd = d => { if (!d) return ''; const x = new Date(d), z = k => String(k).padStart(2, '0'); return `${z(x.getDate())}/${z(x.getMonth() + 1)}/${x.getFullYear()} ${z(x.getHours())}:${z(x.getMinutes())}`; };
function relatorioPdf(b, itens, empresa) {
  const d = pdf.criar(), M = d.margem, R = d.largura - M, H = d.altura;
  const conf = itens.filter(i => i.conferido), nao = itens.filter(i => !i.conferido);
  let y = M;
  const cab = () => {
    d.texto(M, y + 4, 'RELATÓRIO DE BALANÇO DE ESTOQUE Nº ' + b.id, { size: 15, bold: true }); y += 20;
    if (empresa) { d.texto(M, y, empresa, { size: 10, max: R - M }); y += 14; }
    d.linha(M, y, R, y, { cinza: 0.3, w: 1 }); y += 14;
  };
  const novaPag = () => { d.nova(); y = M; };
  const garantir = h => { if (y + h > H - 50) { novaPag(); return true; } return false; };
  cab();
  const info = [['Modo de conferência', b.acumula ? 'COM ACÚMULO (cada leitura soma)' : 'SEM ACÚMULO (informa o total e salva)'], ['Início', fd(b.iniciado_em) + (b.iniciado_nome ? ' - ' + b.iniciado_nome : '')], ['Finalização', fd(b.finalizado_em) + (b.finalizado_nome ? ' - ' + b.finalizado_nome : '')],
    ['Itens conferidos', String(conf.length)], ['Itens não conferidos', String(nao.length) + (nao.length ? (b.zerou_nao_conferidos ? ' (estoque ZERADO)' : ' (estoque MANTIDO)') : '')],
    ['Caixa aberto durante o balanço', b.caixa_aberto ? 'Sim - o movimento após cada contagem (vendas) foi abatido' : 'Não']];
  info.forEach(([k, v]) => { d.texto(M, y, k + ':', { size: 9.5, bold: true }); d.texto(M + 160, y, v, { size: 9.5, max: R - M - 160 }); y += 13; });
  if (b.observacao) { d.texto(M, y, 'Observação:', { size: 9.5, bold: true }); d.texto(M + 160, y, b.observacao, { size: 9.5, max: R - M - 160 }); y += 13; }
  y += 8;
  const secao = (titulo, cols, linhas) => {
    garantir(60); d.texto(M, y + 2, titulo, { size: 12, bold: true }); y += 14;
    const cabT = () => { d.caixa(M, y - 9, R - M, 14, 0.88); cols.forEach(c => d.texto(c.al === 'right' ? c.x + c.w - 3 : c.x + 3, y + 1, c.t, { size: 8, bold: true, align: c.al === 'right' ? 'right' : 'left' })); y += 14; };
    cabT();
    if (!linhas.length) { d.texto(M + 3, y, '(nenhum item)', { size: 9 }); y += 14; return; }
    linhas.forEach((l, k) => {
      if (garantir(14)) { cabT(); }
      cols.forEach((c, j) => d.texto(c.al === 'right' ? c.x + c.w - 3 : c.x + 3, y, l[j], { size: 8.5, max: c.w - 6, align: c.al === 'right' ? 'right' : 'left' }));
      y += 12; if (k % 1 === 0) d.linha(M, y - 8, R, y - 8, { cinza: 0.88, w: 0.3 });
    });
    y += 10;
  };
  const cC = [['Cód.', 42, 'l'], ['Produto', 182, 'l'], ['Un', 24, 'l'], ['Sistema', 53, 'right'], ['Contado', 53, 'right'], ['Mov. após', 53, 'right'], ['Final', 53, 'right'], ['Diferença', 55, 'right']];
  let x = M; const colsC = cC.map(([t, w, al]) => { const o = { t, w, x, al: al === 'right' ? 'right' : 'l' }; x += w; return o; });
  secao('Itens conferidos (' + conf.length + ')', colsC, conf.map(i => [i.codigo, i.nome, i.unidade, fq(i.estoque_sistema), fq(i.qtd_contada), fq(i.mov_depois), fq(i.estoque_final), (Number(i.diferenca) > 0 ? '+' : '') + fq(i.diferenca)]));
  const cN = [['Cód.', 56, 'l'], ['Produto', 230, 'l'], ['Un', 30, 'l'], ['Estoque antes', 75, 'right'], ['Estoque final', 75, 'right'], ['Situação', 49, 'l']];
  x = M; const colsN = cN.map(([t, w, al]) => { const o = { t, w, x, al: al === 'right' ? 'right' : 'l' }; x += w; return o; });
  secao('Itens NÃO conferidos (' + nao.length + ')', colsN, nao.map(i => [i.codigo, i.nome, i.unidade, fq(i.estoque_sistema), fq(i.estoque_final), i.acao === 'zerado' ? 'ZERADO' : 'MANTIDO']));
  garantir(40); d.texto(M, y + 4, 'Mov. após = movimentação do produto depois da contagem (ex.: vendas, em negativo). Final = Contado + Mov. após.', { size: 8, cor: 0.35 });
  return d.build('LoPDV - Balanço de estoque nº ' + b.id);
}

module.exports = r;
module.exports.relatorioPdf = relatorioPdf;
