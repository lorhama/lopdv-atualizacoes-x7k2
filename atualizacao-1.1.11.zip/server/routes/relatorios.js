// Relatórios financeiros e de estoque/vendas + painel.
const express = require('express');
const db = require('../db');
const { auth } = require('../auth');
const { wrap, r2, periodo, HttpError } = require('../util');
const r = express.Router();

const FECH = "p.status='fechado' and p.fechado_em >= $1::date and p.fechado_em < $2::date + 1";

r.get('/ticket-medio', auth('relatorios.financeiro'), wrap(async (req, res) => {
  const { de, ate } = periodo(req); const par = [de, ate];
  const dias = (await db.q(`select to_char(date_trunc('day',p.fechado_em),'YYYY-MM-DD') dia, count(*)::int vendas,
    sum(p.total) faturamento, round(avg(p.total)::numeric,2) ticket from pedidos p where ${FECH} group by 1 order by 1`, par)).rows;
  const usuarios = (await db.q(`select u.nome usuario, count(*)::int vendas, sum(p.total) faturamento, round(avg(p.total)::numeric,2) ticket
    from pedidos p join usuarios u on u.id=coalesce(p.vendedor_id,p.usuario_id) where ${FECH} group by u.nome order by faturamento desc`, par)).rows;
  const t = (await db.q(`select count(*)::int vendas, coalesce(sum(p.total),0) faturamento, coalesce(round(avg(p.total)::numeric,2),0) ticket from pedidos p where ${FECH}`, par)).rows[0];
  res.json({ de, ate, total: t, por_dia: dias, por_atendente: usuarios });
}));

r.get('/lucratividade', auth('relatorios.financeiro'), wrap(async (req, res) => {
  const { de, ate } = periodo(req); const par = [de, ate];
  const produtos = (await db.q(`select i.produto_id, i.nome, sum(i.quantidade) quantidade, sum(i.quantidade*i.preco_unit) receita,
    sum(i.quantidade*i.custo_unit) custo, sum(i.quantidade*(i.preco_unit-i.custo_unit)) lucro,
    case when sum(i.quantidade*i.preco_unit)>0 then round((sum(i.quantidade*(i.preco_unit-i.custo_unit))/sum(i.quantidade*i.preco_unit)*100)::numeric,1) else 0 end margem
    from pedido_itens i join pedidos p on p.id=i.pedido_id where ${FECH} and i.status<>'cancelado' group by i.produto_id, i.nome order by lucro desc`, par)).rows;
  const d = (await db.q(`select coalesce(sum(p.desconto),0) descontos from pedidos p where ${FECH}`, par)).rows[0].descontos;
  const desp = (await db.q(`select coalesce(sum(valor_pago),0) v from titulos where tipo='pagar' and status='pago' and entrada_id is null and pago_em between $1::date and $2::date`, par)).rows[0].v;
  const receita = r2(produtos.reduce((s, p) => s + p.receita, 0));
  const custo = r2(produtos.reduce((s, p) => s + p.custo, 0));
  const lucroBruto = r2(receita - custo - Number(d));
  res.json({ de, ate, produtos, resumo: { receita_bruta: receita, descontos: Number(d), receita_liquida: r2(receita - Number(d)), custo_mercadoria: custo,
    lucro_bruto: lucroBruto, margem_pct: receita ? r2((lucroBruto / receita) * 100) : 0, despesas_operacionais_pagas: Number(desp), resultado: r2(lucroBruto - Number(desp)) } });
}));

r.get('/mais-vendidos', auth(['relatorios.estoque', 'relatorios.financeiro']), wrap(async (req, res) => {
  const { de, ate } = periodo(req);
  const lim = Math.min(Number(req.query.limite) || 30, 200);
  res.json({ de, ate, produtos: (await db.q(`select i.produto_id, i.nome, sum(i.quantidade) quantidade, sum(i.quantidade*i.preco_unit) receita, count(distinct i.pedido_id)::int comandas
    from pedido_itens i join pedidos p on p.id=i.pedido_id where ${FECH} and i.status<>'cancelado'
    group by i.produto_id, i.nome order by quantidade desc limit ${lim}`, [de, ate])).rows });
}));

r.get('/painel', auth(), wrap(async (req, res) => {
  const hoje = (await db.q(`select count(*)::int vendas, coalesce(sum(total),0) faturamento, coalesce(round(avg(total)::numeric,2),0) ticket
    from pedidos where status='fechado' and fechado_em >= current_date`)).rows[0];
  const abertas = (await db.q("select count(*)::int n from pedidos where status='aberto' and exists (select 1 from pedido_itens i where i.pedido_id=pedidos.id and i.status<>'cancelado')")).rows[0].n;
  const prod = (await db.q("select destino, count(*)::int n from pedido_itens where status='enviado' group by destino")).rows;
  const baixo = (await db.q(`select id, nome, unidade, estoque_atual, estoque_minimo from produtos where ativo and controla_estoque and estoque_minimo>0
    and estoque_atual <= estoque_minimo order by nome limit 15`)).rows;
  const venc = (await db.q("select tipo, count(*)::int n, coalesce(sum(valor),0) total from titulos where status='aberto' and vencimento < current_date group by tipo")).rows;
  res.json({ hoje, comandas_abertas: abertas, pendentes_producao: prod, estoque_baixo: baixo, titulos_vencidos: venc });
}));

// Painel gráfico: venda líquida, atendimentos, ticket médio, previsão do mês, top 10, participação por categoria, compras x vendas e contas a pagar.
r.get('/dashboard', auth(), wrap(async (req, res) => {
  const dia = s => (/^\d{4}-\d{2}-\d{2}$/.test(s || '') ? s : null);
  let ate = dia(req.query.ate) || (await db.q("select to_char(current_date,'YYYY-MM-DD') d")).rows[0].d;
  let de = dia(req.query.de) || (await db.q("select to_char($1::date-7,'YYYY-MM-DD') d", [ate])).rows[0].d;
  if (de > ate) [de, ate] = [ate, de];
  const F = async (ini, fim) => (await db.q("select coalesce(sum(total),0)::float v, count(*)::int n from pedidos where status='fechado' and fechado_em >= " + ini + ' and fechado_em < ' + fim)).rows[0];
  const par = async (ini, fim) => { const x = await F(ini, fim); return { v: x.v, n: x.n, t: x.n ? x.v / x.n : 0 }; };
  const hoje = await par('current_date', "now()+interval '1 second'");
  const ontemMH = await par("current_date-1", "now()-interval '1 day'"), ontem = await par('current_date-1', 'current_date');
  const semMH = await par("current_date-7", "now()-interval '7 days'"), sem = await par('current_date-7', 'current_date-6');
  const mes = (await db.q(`select coalesce(sum(total),0)::float v, count(*)::int n,
      extract(day from current_date)::int dia, extract(day from (date_trunc('month',current_date)+interval '1 month - 1 day'))::int dias
    from pedidos where status='fechado' and fechado_em >= date_trunc('month',current_date)`)).rows[0];
  const mesAnt = (await db.q(`select coalesce(sum(total),0)::float v, extract(day from (date_trunc('month',current_date - interval '1 year')+interval '1 month - 1 day'))::int dias
    from pedidos where status='fechado' and fechado_em >= date_trunc('month',current_date - interval '1 year') and fechado_em < date_trunc('month',current_date - interval '1 year') + interval '1 month'`)).rows[0];
  const serie = (await db.q(`select to_char(d,'DD/MM') rotulo, coalesce(s.v,0)::float v, coalesce(s.n,0)::int n from generate_series($1::date,$2::date,'1 day') d
    left join (select fechado_em::date dia, sum(total) v, count(*) n from pedidos where status='fechado' group by 1) s on s.dia=d order by d`, [de, ate])).rows;
  const itens = `from pedido_itens i join pedidos p on p.id=i.pedido_id left join produtos pr on pr.id=i.produto_id left join categorias c on c.id=pr.categoria_id
    where p.status='fechado' and i.status<>'cancelado' and p.fechado_em::date between $1 and $2`;
  const totItens = (await db.q('select coalesce(sum(i.quantidade*i.preco_unit),0)::float v ' + itens, [de, ate])).rows[0].v;
  const top = (await db.q(`select coalesce(pr.nome,i.nome) nome, pr.codigo_barras, sum(i.quantidade)::float un, sum(i.quantidade*i.preco_unit)::float venda,
      case when sum(i.quantidade*i.preco_unit)>0 then (sum(i.quantidade*coalesce(i.custo_unit,0))/sum(i.quantidade*i.preco_unit)*100)::float else 0 end cmv ${itens}
    group by 1,2 order by venda desc limit 10`, [de, ate])).rows.map(x => ({ ...x, part: totItens ? x.venda / totItens * 100 : 0 }));
  const grupos = (await db.q(`select coalesce(c.nome,'Sem categoria') nome, sum(i.quantidade*i.preco_unit)::float venda ${itens} group by 1 order by venda desc limit 12`, [de, ate])).rows.map(x => ({ ...x, part: totItens ? x.venda / totItens * 100 : 0 }));
  const compras = (await db.q("select coalesce(sum(total),0)::float v from entradas where criado_em >= date_trunc('month',current_date)")).rows[0].v;
  const cp = (await db.q(`select coalesce(sum(valor),0)::float total,
      coalesce(sum(valor) filter (where vencimento=current_date),0)::float hoje,
      coalesce(sum(valor) filter (where vencimento<current_date),0)::float vencidos,
      coalesce(sum(valor) filter (where vencimento>current_date and vencimento < date_trunc('month',current_date)+interval '1 month'),0)::float mes,
      coalesce(sum(valor) filter (where vencimento >= date_trunc('month',current_date)+interval '1 month'),0)::float proximos
    from titulos where tipo='pagar' and status='aberto'`)).rows[0];
  res.json({ de, ate, hoje, ontemMH, ontem, semMH, sem, mes: { ...mes, media: mes.dia ? mes.v / mes.dia : 0, previsao: mes.dia ? mes.v / mes.dia * mes.dias : 0, restantes: mes.dias - mes.dia }, mediaAnoAnt: mesAnt.dias ? mesAnt.v / mesAnt.dias : 0, serie, top, grupos, compras, contas_pagar: cp });
}));

// Painel (layout A): cada cartão tem o seu próprio período. card = venda | atend | ticket | compras | hora | top | pagto | pagar | estoque
r.get('/painel-card', auth(), wrap(async (req, res) => {
  const dia = x => (/^\d{4}-\d{2}-\d{2}$/.test(x || '') ? x : null);
  const hoje = (await db.q("select to_char(current_date,'YYYY-MM-DD') d")).rows[0].d;
  let ate = dia(req.query.ate) || hoje, de = dia(req.query.de) || ate;
  if (de > ate) [de, ate] = [ate, de];
  const ant = (await db.q("select to_char($1::date-($2::date-$1::date+1)::int,'YYYY-MM-DD') de, to_char($1::date-1,'YYYY-MM-DD') ate", [de, ate])).rows[0];
  const resumo = async (a, b) => { const x = (await db.q("select coalesce(sum(total),0)::float v, count(*)::int n from pedidos where status='fechado' and fechado_em::date between $1 and $2", [a, b])).rows[0]; return { v: x.v, n: x.n, t: x.n ? x.v / x.n : 0 }; };
  const card = req.query.card;
  if (['venda', 'atend', 'ticket'].includes(card)) return res.json({ de, ate, ant, atual: await resumo(de, ate), anterior: await resumo(ant.de, ant.ate) });
  if (card === 'compras') {
    const c = async (a, b) => (await db.q("select coalesce(sum(total),0)::float v from entradas where criado_em::date between $1 and $2", [a, b])).rows[0].v;
    const v = (await resumo(de, ate)).v, cp = await c(de, ate);
    const vA = (await resumo(ant.de, ant.ate)).v, cA = await c(ant.de, ant.ate);
    return res.json({ de, ate, ant, vendas: v, compras: cp, pct: v ? cp / v * 100 : 0, pct_ant: vA ? cA / vA * 100 : 0 });
  }
  if (card === 'hora') {
    if (de === ate) {   // um dia só: por hora
      const rows = (await db.q("select extract(hour from fechado_em)::int h, sum(total)::float v, count(*)::int n from pedidos where status='fechado' and fechado_em::date=$1 group by 1", [de])).rows;
      const mapa = new Map(rows.map(x => [x.h, x]));
      const hs = rows.length ? [Math.min(...rows.map(x => x.h)), Math.max(...rows.map(x => x.h))] : [8, 20];
      const serie = []; for (let h = Math.min(hs[0], 8); h <= Math.max(hs[1], 20); h++) serie.push({ rotulo: String(h).padStart(2, '0') + 'h', v: mapa.get(h)?.v || 0, n: mapa.get(h)?.n || 0 });
      return res.json({ de, ate, modo: 'hora', serie });
    }
    const serie = (await db.q(`select to_char(d,'DD/MM') rotulo, coalesce(s.v,0)::float v, coalesce(s.n,0)::int n from generate_series($1::date,$2::date,'1 day') d
      left join (select fechado_em::date dia, sum(total) v, count(*) n from pedidos where status='fechado' group by 1) s on s.dia=d order by d`, [de, ate])).rows;
    return res.json({ de, ate, modo: 'dia', serie });
  }
  if (card === 'top') {
    const itens = `from pedido_itens i join pedidos p on p.id=i.pedido_id left join produtos pr on pr.id=i.produto_id
      where p.status='fechado' and i.status<>'cancelado' and p.fechado_em::date between $1 and $2`;
    const tot = (await db.q('select coalesce(sum(i.quantidade*i.preco_unit),0)::float v ' + itens, [de, ate])).rows[0].v;
    const top = (await db.q(`select coalesce(pr.nome,i.nome) nome, sum(i.quantidade)::float un, sum(i.quantidade*i.preco_unit)::float venda ${itens} group by 1 order by venda desc limit 5`, [de, ate])).rows;
    return res.json({ de, ate, top: top.map(x => ({ ...x, part: tot ? x.venda / tot * 100 : 0 })) });
  }
  if (card === 'pagto') {
    const f = (await db.q(`select coalesce(fp.descricao, p.forma) nome, coalesce(fp.tipo,p.forma) tipo, sum(p.valor)::float v from pagamentos p left join formas_pagamento fp on fp.codigo=p.forma
      where coalesce(p.origem,'venda')='venda' and p.criado_em::date between $1 and $2 group by 1,2 order by v desc`, [de, ate])).rows;
    const tot = f.reduce((a, x) => a + x.v, 0);
    return res.json({ de, ate, total: tot, formas: f.map(x => ({ ...x, pct: tot ? x.v / tot * 100 : 0 })) });
  }
  if (card === 'pagar') {
    const x = (await db.q(`select coalesce(sum(valor) filter (where vencimento between $1 and $2),0)::float periodo, count(*) filter (where vencimento between $1 and $2)::int n_periodo,
        coalesce(sum(valor) filter (where vencimento < current_date),0)::float vencidos, coalesce(sum(valor),0)::float total
      from titulos where tipo='pagar' and status='aberto'`, [de, ate])).rows[0];
    return res.json({ de, ate, ...x });
  }
  if (card === 'estoque') {
    const baixo = (await db.q(`select id, nome, unidade, estoque_atual::float, estoque_minimo::float from produtos where ativo and controla_estoque and estoque_minimo>0
      and estoque_atual <= estoque_minimo order by (estoque_atual/estoque_minimo) , nome limit 8`)).rows;
    return res.json({ baixo });
  }
  throw new HttpError(400, 'Cartão desconhecido.');
}));

module.exports = r;
