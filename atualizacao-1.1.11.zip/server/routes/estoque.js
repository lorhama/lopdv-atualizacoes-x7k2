// Estoque: entrada manual, entrada por XML de NF-e, ajuste/inventário e movimentação.
const express = require('express');
const { XMLParser } = require('fast-xml-parser');
const db = require('../db');
const { auth, auditar, verificarAutorizacao } = require('../auth');
const { HttpError, wrap, num, r2, hoje, periodo } = require('../util');
const est = require('../estoque_lib');
const exigeEmpresa = require('../exige_empresa');
const r = express.Router();

// Não deixa dar entrada de mercadoria enquanto houver balanço de estoque em andamento
async function exigirSemBalanco() {
  if ((await db.q("select 1 from balancos where status='andamento' limit 1")).rowCount) throw new HttpError(400, 'Existe um balanço de estoque em andamento. Finalize ou cancele o balanço (menu Estoque > Balanço geral) antes de dar entrada de mercadoria.');
}
const soDigitos = s => String(s || '').replace(/\D/g, '');
const arr = v => (v === undefined || v === null ? [] : [].concat(v));
const UN_MAP = { KG: 'KG', G: 'G', L: 'L', LT: 'L', ML: 'ML', UN: 'UN', UND: 'UN', UNID: 'UN', PC: 'UN', CX: 'CX', PCT: 'PCT', PT: 'PCT' };

// ---- Posição de estoque
r.get('/posicao', auth('estoque.ver'), wrap(async (req, res) => {
  res.json((await db.q(`select p.id,p.codigo,p.nome,p.unidade,p.tipo,p.estoque_atual,p.estoque_minimo,p.custo_medio,
    round((p.estoque_atual*p.custo_medio)::numeric,2) valor_estoque, c.nome categoria, p.controla_estoque,
    (p.estoque_atual <= p.estoque_minimo and p.estoque_minimo > 0) abaixo_minimo
    from produtos p left join categorias c on c.id=p.categoria_id where p.ativo and p.controla_estoque order by p.nome`)).rows);
}));

// ---- Ajuste de estoque (avulso): o usuário informa a quantidade que realmente existe
r.get('/saldo', auth('estoque.ajuste'), wrap(async (req, res) => {
  const p = (await db.q('select id, codigo, nome, unidade, estoque_atual, controla_estoque from produtos where id=$1', [req.query.produto_id])).rows[0];
  if (!p) throw new HttpError(404, 'Produto não encontrado.'); res.json(p);
}));
// ---- Motivos de ajuste de estoque (cadastro)
r.get('/motivos', auth(['estoque.ajuste', 'relatorios.estoque']), wrap(async (req, res) => {
  res.json((await db.q(`select id, descricao, ativo from motivos_ajuste ${req.query.todos === '1' ? '' : 'where ativo'} order by descricao`)).rows);
}));
const descMotivo = v => { const d = String(v || '').trim().toUpperCase().slice(0, 60); if (!d) throw new HttpError(400, 'Informe a descrição do motivo.'); return d; };
r.post('/motivos', auth('estoque.ajuste'), wrap(async (req, res) => {
  const d = descMotivo((req.body || {}).descricao);
  if ((await db.q('select 1 from motivos_ajuste where descricao=$1', [d])).rowCount) throw new HttpError(400, 'Esse motivo já está cadastrado.');
  res.json((await db.q('insert into motivos_ajuste(descricao) values($1) returning id, descricao, ativo', [d])).rows[0]);
}));
r.put('/motivos/:id', auth('estoque.ajuste'), wrap(async (req, res) => {
  const b = req.body || {}, cur = (await db.q('select * from motivos_ajuste where id=$1', [req.params.id])).rows[0];
  if (!cur) throw new HttpError(404, 'Motivo não encontrado.');
  const d = b.descricao != null ? descMotivo(b.descricao) : cur.descricao, ativo = b.ativo != null ? !!b.ativo : cur.ativo;
  if (d !== cur.descricao && (await db.q('select 1 from motivos_ajuste where descricao=$1 and id<>$2', [d, cur.id])).rowCount) throw new HttpError(400, 'Já existe outro motivo com esse nome.');
  res.json((await db.q('update motivos_ajuste set descricao=$1, ativo=$2 where id=$3 returning id, descricao, ativo', [d, ativo, cur.id])).rows[0]);
}));
r.delete('/motivos/:id', auth('estoque.ajuste'), wrap(async (req, res) => {
  await db.q('delete from motivos_ajuste where id=$1', [req.params.id]); // os ajustes antigos guardam o texto do motivo, então nada se perde
  res.json({ ok: true });
}));
r.post('/ajuste', auth('estoque.ajuste'), wrap(async (req, res) => {
  const { produto_id, nova_qtd, motivo } = req.body || {};
  if (!String(motivo || '').trim()) throw new HttpError(400, 'Informe o motivo do ajuste.');
  if (nova_qtd === undefined || nova_qtd === '' || !Number.isFinite(Number(nova_qtd))) throw new HttpError(400, 'Informe o estoque real (quantidade contada).');
  if (Number(nova_qtd) < 0) throw new HttpError(400, 'O estoque real não pode ser negativo.');
  const out = await db.tx(async c => {
    const p = (await c.query('select * from produtos where id=$1 for update', [produto_id])).rows[0];
    if (!p) throw new HttpError(404, 'Produto não encontrado.');
    const antes = Number(p.estoque_atual), delta = Math.round((Number(nova_qtd) - antes) * 1000) / 1000;
    if (Math.abs(delta) < 0.0005) return { delta: 0, estoque: antes };
    const aj = (await c.query(`insert into ajustes_estoque(produto_codigo, estoque_sistema, estoque_informado, diferenca, custo_unit, motivo, usuario_id)
      values($1,$2,$3,$4,$5,$6,$7) returning id`, [p.codigo, antes, Number(nova_qtd), delta, p.custo_medio, String(motivo).trim(), req.user.id])).rows[0];
    await est.mover(c, { produto_id, tipo: 'ajuste', quantidade: delta, custo_unit: p.custo_medio, origem: 'ajuste_avulso', ref_id: aj.id, motivo: String(motivo).trim(), usuario_id: req.user.id });
    await auditar(c, req.user, 'ajuste_estoque', { ajuste: aj.id, produto_id, de: antes, para: Number(nova_qtd), motivo });
    return { id: aj.id, delta, estoque: Number(nova_qtd) };
  });
  res.json(out);
}));
r.get('/ajustes', auth(['estoque.ajuste', 'relatorios.estoque']), wrap(async (req, res) => {
  res.json((await db.q(`select a.*, p.id produto_id, p.nome produto, p.unidade, u.nome usuario from ajustes_estoque a
    join produtos p on p.codigo=a.produto_codigo left join usuarios u on u.id=a.usuario_id order by a.id desc limit 300`)).rows);
}));


// ---- Produção: coloca o produto preparado no estoque; os insumos da ficha técnica baixam só no fechamento do caixa (pela sobra contada)
async function necessidadeProducao(c, produtoId, qtd) {
  const p = (await c.query('select * from produtos where id=$1 for update', [produtoId])).rows[0];
  if (!p || p.tipo !== 'preparado') throw new HttpError(400, 'Escolha um produto do tipo Prato / preparado.');
  if (!p.controla_estoque) throw new HttpError(400, 'Este produto está como "feito na hora" (não controla estoque). Marque "Controla estoque deste item" no cadastro para produzir com antecedência.');
  const rec = (await c.query(`select i.*, r.quantidade rq from receitas r join produtos i on i.id=r.insumo_id where r.produto_id=$1 order by i.id for update of i`, [p.id])).rows;
  if (!rec.length) throw new HttpError(400, 'O produto não tem ficha técnica (insumos por unidade). Cadastre a ficha técnica primeiro.');
  // insumos já comprometidos em produções ainda não baixadas (a baixa acontece no fechamento do caixa)
  for (const i of rec) i.pendente = Number((await c.query(`select coalesce(sum(pr.quantidade*r.quantidade),0) q from producoes pr join receitas r on r.produto_id=pr.produto_id
    where pr.insumos_baixados_em is null and r.insumo_id=$1`, [i.id])).rows[0].q);
  const itens = rec.map(i => ({ insumo: i, necessario: Math.round(Number(i.rq) * qtd * 1000) / 1000, custo: Number(i.rq) * qtd * Number(i.custo_medio) }));
  return { p, itens, custoTotal: r2(itens.reduce((s, x) => s + x.custo, 0)) };
}
r.get('/producao/previa', auth('estoque.producao'), wrap(async (req, res) => {
  const qtd = Number(req.query.quantidade) || 0;
  const out = await db.tx(async c => { const n = await necessidadeProducao(c, req.query.produto_id, qtd > 0 ? qtd : 1);
    return { produto: n.p.nome, unidade: n.p.unidade, itens: n.itens.map(x => ({ nome: x.insumo.nome, unidade: x.insumo.unidade, por_unidade: Number(x.insumo.rq), necessario: x.necessario, disponivel: Number(x.insumo.estoque_atual) - x.insumo.pendente, custo: r2(x.custo) })), custo_total: n.custoTotal }; });
  res.json(out);
}));
r.post('/producao', auth('estoque.producao'), wrap(async (req, res) => {
  const b = req.body || {}, qtd = Number(b.quantidade);
  if (!(qtd > 0)) throw new HttpError(400, 'Informe a quantidade produzida.');
  const out = await db.tx(async c => {
    if (b.exigir_autorizacao) await verificarAutorizacao(c, b.autorizacao, 'vendas.lancar_producao'); // lançada pela tela de vendas: pede usuário e senha
    const n = await necessidadeProducao(c, b.produto_id, qtd);
    const falta = n.itens.filter(x => Number(x.insumo.estoque_atual) - x.insumo.pendente - x.necessario < -0.0005);
    if (falta.length) throw new HttpError(400, 'Insumo insuficiente em estoque: ' + falta.map(x => `${x.insumo.nome} (precisa ${x.necessario} ${x.insumo.unidade}, tem ${Number(x.insumo.estoque_atual) - x.insumo.pendente})`).join('; ') + '.');
    const cu = n.custoTotal / qtd;
    const cxa = (await c.query("select id from caixas where usuario_id=$1 and status='aberto' order by id desc limit 1", [req.user.id])).rows[0];
    const pr = (await c.query('insert into producoes(produto_id,quantidade,custo_total,custo_unit,observacao,usuario_id,caixa_id) values($1,$2,$3,$4,$5,$6,$7) returning id',
      [n.p.id, qtd, n.custoTotal, cu, String(b.observacao || '').trim() || null, req.user.id, cxa?.id || null])).rows[0];
    // os insumos NÃO baixam agora: a baixa é feita no fechamento do caixa, a partir do que sobrou
    await est.entrada(c, { produto_id: n.p.id, quantidade: qtd, custo_unit: cu, origem: 'producao', ref_id: pr.id, usuario_id: req.user.id, motivo: 'Produção #' + pr.id });
    await auditar(c, req.user, 'producao', { id: pr.id, produto: n.p.nome, quantidade: qtd, custo_total: n.custoTotal });
    return { id: pr.id, custo_unit: cu };
  });
  res.json(out);
}));
r.get('/producoes', auth(['estoque.producao', 'estoque.ver', 'relatorios.estoque']), wrap(async (req, res) => {
  res.json((await db.q(`select pr.*, p.nome produto, p.unidade, u.nome usuario from producoes pr join produtos p on p.id=pr.produto_id left join usuarios u on u.id=pr.usuario_id order by pr.id desc limit 300`)).rows);
}));

// ---- Extrato do produto: toda entrada e saída, com saldo linha a linha
r.get('/extrato', auth(['relatorios.estoque', 'estoque.ver']), wrap(async (req, res) => {
  const { de, ate } = periodo(req);
  const p = (await db.q('select id, codigo, nome, unidade, estoque_atual, custo_medio from produtos where id=$1', [req.query.produto_id])).rows[0];
  if (!p) throw new HttpError(404, 'Escolha um produto.');
  const ini = (await db.q('select saldo_apos from mov_estoque where produto_id=$1 and criado_em < $2::date order by id desc limit 1', [p.id, de])).rows[0];
  const linhas = (await db.q(`select m.id, m.criado_em, m.tipo, m.quantidade, m.custo_unit, m.saldo_apos, m.origem, m.ref_id, m.motivo, u.nome usuario,
      case m.origem
        when 'entrada' then 'Entrada #' || m.ref_id || coalesce(' · ' || nullif(e.numero, '') , '') || coalesce(' · ' || f.nome, '')
        when 'ajuste_avulso' then 'Ajuste avulso #' || m.ref_id
        when 'balanco' then 'Balanço #' || m.ref_id
        when 'ajuste' then 'Ajuste de estoque'
        when 'producao' then 'Produção #' || m.ref_id
        when 'fechamento_caixa' then 'Consumo de insumos · fechamento do caixa #' || m.ref_id
        when 'pedido_item' then 'Venda · ' || coalesce(m.motivo, '')
        else coalesce(m.origem, '') end documento
    from mov_estoque m left join usuarios u on u.id=m.usuario_id
    left join entradas e on m.origem='entrada' and e.id=m.ref_id left join fornecedores f on f.id=e.fornecedor_id
    where m.produto_id=$1 and m.criado_em >= $2::date and m.criado_em < $3::date + 1 order by m.id`, [p.id, de, ate])).rows;
  const entradas = linhas.filter(l => Number(l.quantidade) > 0).reduce((s, l) => s + Number(l.quantidade), 0);
  const saidas = -linhas.filter(l => Number(l.quantidade) < 0).reduce((s, l) => s + Number(l.quantidade), 0);
  const saldo_inicial = ini ? Number(ini.saldo_apos) : (linhas.length ? Number(linhas[0].saldo_apos) - Number(linhas[0].quantidade) : Number(p.estoque_atual));
  res.json({ produto: p, de, ate, saldo_inicial, entradas: Math.round(entradas * 1000) / 1000, saidas: Math.round(saidas * 1000) / 1000,
    saldo_final: linhas.length ? Number(linhas[linhas.length - 1].saldo_apos) : saldo_inicial, linhas });
}));

// ---- Entrada manual
async function gravarEntrada(c, user, { fornecedor_id, numero, chave, origem, data_emissao, observacao, itens, doacao, consignada }) {
  consignada = !!consignada;
  if (consignada && (itens || []).some(i => i.patrimonio || i.doacao)) throw new HttpError(400, 'Nota consignada não pode ter item de doação ou patrimônio. Lance essa parte em outra entrada.');
  const lista = (itens || []).filter(i => (i.patrimonio ? String(i.descricao || '').trim() : Number(i.produto_id)) && num(i.quantidade) > 0);
  if (!lista.length) throw new HttpError(400, 'Informe ao menos um item com quantidade.');
  let total = 0, valorDoacao = 0;
  const e = await c.query(`insert into entradas(fornecedor_id,numero,chave,origem,data_emissao,observacao,usuario_id,doacao,consignada,consig_status)
    values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) returning id`, [fornecedor_id || null, numero || null, chave || null, origem, data_emissao || null, observacao || null, user.id, !!doacao, consignada, consignada ? 'aberta' : null]);
  const id = e.rows[0].id;
  const patrimonios = [];
  for (const i of lista) {
    const q = num(i.quantidade), cu = num(i.custo_unit), dc = !!i.doacao;
    if (cu < 0) throw new HttpError(400, 'Custo inválido.');
    if (dc) valorDoacao += q * cu; else total += q * cu;
    if (i.patrimonio) { // bem durável: não entra no estoque, ganha número de patrimônio (um por unidade)
      if (q !== Math.floor(q) || q > 500) throw new HttpError(400, 'Bem de patrimônio: informe a quantidade em unidades inteiras (máx. 500): ' + i.descricao);
      const ei = await c.query('insert into entrada_itens(entrada_id,produto_id,quantidade,custo_unit,descricao,doacao,patrimonio) values($1,null,$2,$3,$4,$5,true) returning id', [id, q, cu, String(i.descricao).trim(), dc]);
      for (let k = 0; k < q; k++) {
        const p = await c.query(`insert into patrimonio(descricao,marca,modelo,local,observacao,origem,valor,data_aquisicao,fornecedor_id,entrada_id,usuario_id)
          values($1,$2,$3,$4,$5,$6,$7,coalesce($8::date,current_date),$9,$10,$11) returning id, numero`,
          [String(i.descricao).trim(), i.marca || null, i.modelo || null, i.local || null, i.observacao || null, dc ? 'doacao' : 'compra', r2(cu), data_emissao || null, fornecedor_id || null, id, user.id]);
        patrimonios.push(p.rows[0].numero);
      }
      continue;
    }
    await c.query('insert into entrada_itens(entrada_id,produto_id,quantidade,custo_unit,doacao) values($1,$2,$3,$4,$5)', [id, i.produto_id, q, cu, dc]);
    // mercadoria doada entra no estoque sem custo (não gera contas a pagar)
    await est.entrada(c, { produto_id: i.produto_id, quantidade: q, custo_unit: dc ? 0 : cu, origem: 'entrada', ref_id: id, usuario_id: user.id, motivo: (dc ? 'Doação' : consignada ? 'Consignação' + (numero ? ' · ' + numero : '') : (numero ? 'NF ' + numero : 'Entrada manual')) + (dc && numero ? ' · NF ' + numero : '') });
  }
  total = r2(total); valorDoacao = r2(valorDoacao);
  await c.query('update entradas set total=$1, valor_doacao=$2 where id=$3', [total, valorDoacao, id]);
  return { id, total, valor_doacao: valorDoacao, patrimonios, consignada };
}

async function gerarTitulos(c, { entrada_id, fornecedor_id, numero, titulos, total, categoria }) {
  const lista = (titulos || []).filter(t => num(t.valor) > 0 && t.vencimento);
  if (!lista.length) return 0;
  const formas = new Set((await c.query('select codigo from formas_pagamento where ativo')).rows.map(x => x.codigo));
  let n = 0;
  for (const t of lista) {
    n++;
    const forma = t.forma || null;
    if (forma && !formas.has(forma)) throw new HttpError(400, 'Forma de pagamento inválida na parcela ' + n + '.');
    const pago = !!t.pago;
    await c.query(`insert into titulos(tipo,descricao,categoria,fornecedor_id,entrada_id,valor,vencimento,forma_prevista,status,pago_em,valor_pago,forma)
      values('pagar',$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
      [`Compra${numero ? ' NF ' + numero : ''} (${n}/${lista.length})`, String(categoria || '').trim() || 'Compra de mercadoria', fornecedor_id || null, entrada_id, r2(num(t.valor)), t.vencimento, forma,
        pago ? 'pago' : 'aberto', pago ? hoje() : null, pago ? r2(num(t.valor)) : null, pago ? forma : null]);
  }
  return n;
}

r.post('/entrada', auth('estoque.entrada'), wrap(async (req, res) => {
  await exigirSemBalanco();
  await exigeEmpresa();
  const b = req.body || {};
  const out = await db.tx(async c => {
    // fator: 1 fardo com 12 un → quantidade x12 e custo ÷12 (estoque e custo ficam na unidade do produto)
    const itens = (b.itens || []).map(i => { if (i.patrimonio) return { ...i, quantidade: num(i.quantidade), custo_unit: num(i.custo_unit) };
      const fator = num(i.fator, 1);
      if (!(fator > 0)) throw new HttpError(400, 'Informe o fator (quantas unidades vêm em cada embalagem; use 1 se já é unitário).');
      return { ...i, quantidade: num(i.quantidade) * fator, custo_unit: num(i.custo_unit) / fator }; });
    const e = await gravarEntrada(c, req.user, { ...b, itens, origem: 'manual', doacao: !!b.doacao, consignada: !!b.consignada });
    const t = await gerarTitulos(c, { entrada_id: e.id, fornecedor_id: b.fornecedor_id, numero: b.numero, titulos: b.consignada ? [] : b.titulos, total: e.total, categoria: b.categoria_despesa });
    await auditar(c, req.user, 'entrada_manual', { id: e.id, total: e.total });
    return { ...e, titulos: t };
  });
  res.json(out);
}));

// ---- Entrada por XML: NF-e, NFC-e (cupom fiscal eletrônico) e CF-e SAT (cupom fiscal)
const eanValido = v => { const d = soDigitos(v); return d && !/^0+$/.test(d) ? d : ''; };
const fatorSugerido = (pr, q) => { const qt = num(pr.qTrib); return String(pr.uTrib || '').toUpperCase() !== String(pr.uCom || '').toUpperCase() && q > 0 && qt / q > 1.0001 ? Math.round((qt / q) * 10000) / 10000 : 1; };
function lerFiscal(xml) {
  const p = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: '@_', parseTagValue: false, trimValues: true });
  let j; try { j = p.parse(xml); } catch { throw new HttpError(400, 'Arquivo XML inválido.'); }
  const nfe = j?.nfeProc?.NFe || j?.NFe;
  const cfe = j?.CFe || j?.enviCFe?.LoteCFe?.CFe || j?.CFeSAT;
  const inf = nfe?.infNFe || cfe?.infCFe;
  if (!inf) throw new HttpError(400, 'Este XML não parece ser uma NF-e, NFC-e ou cupom fiscal (CF-e SAT).');
  const sat = !nfe?.infNFe;
  const emit = inf.emit || {};
  const doc = soDigitos(emit.CNPJ || emit.CPF);
  const destinatario = soDigitos((inf.dest || {}).CNPJ || (inf.dest || {}).CPF);
  const itens = arr(inf.det).map(d => {
    const pr = d.prod || {};
    const q = num(pr.qCom);
    const bruto = num(pr.vProd) + num(pr.vFrete) + num(pr.vSeg) + num(pr.vOutro) - num(pr.vDesc);
    const ean = eanValido(pr.cEAN), eanT = eanValido(pr.cEANTrib);
    return {
      codigo_fornecedor: String(pr.cProd || ''), ean, ean_trib: eanT && eanT !== ean ? eanT : '',
      nome: pr.xProd || '', unidade_xml: String(pr.uCom || '').toUpperCase(),
      unidade: UN_MAP[String(pr.uCom || '').toUpperCase()] || 'UN', unidade_trib: UN_MAP[String(pr.uTrib || '').toUpperCase()] || 'UN',
      quantidade: q, custo_unit: q > 0 ? Math.round((bruto / q) * 10000) / 10000 : 0, total: r2(bruto),
      fator_sugerido: sat ? 1 : fatorSugerido(pr, q),
    };
  });
  const dup = sat ? [] : arr(inf.cobr?.dup).map(d => ({ numero: d.nDup, vencimento: d.dVenc, valor: num(d.vDup) }));
  const dEmi = String(inf.ide?.dhEmi || inf.ide?.dEmi || '');
  const emissao = /^\d{8}$/.test(dEmi) ? `${dEmi.slice(0, 4)}-${dEmi.slice(4, 6)}-${dEmi.slice(6, 8)}` : dEmi.slice(0, 10);
  const modelo = String(inf.ide?.mod || '');
  return {
    tipo_doc: sat ? 'cupom SAT (CF-e)' : (modelo === '65' ? 'cupom NFC-e' : 'NF-e'),
    chave: String(inf['@_Id'] || '').replace(/^(NFe|CFe)/, ''), numero: String(inf.ide?.nNF || inf.ide?.nCFe || ''), serie: String(inf.ide?.serie || ''),
    data_emissao: emissao || null, destinatario,
    fornecedor: { documento: doc, nome: emit.xNome || '', fantasia: emit.xFant || '', telefone: emit.enderEmit?.fone || '',
      endereco: [emit.enderEmit?.xLgr, emit.enderEmit?.nro, emit.enderEmit?.xBairro].filter(Boolean).join(', '),
      cidade: emit.enderEmit?.xMun || '', uf: emit.enderEmit?.UF || '' },
    total_nf: num(sat ? inf.total?.vCFe : inf.total?.ICMSTot?.vNF) || r2(itens.reduce((s, i) => s + i.total, 0)), itens, duplicatas: dup,
  };
}

// Só aceita XML emitido para o CNPJ da empresa em uso (cadastro da empresa)
const fmtCnpj = d => (d.length === 14 ? d.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5') : d);
async function exigirCnpjDaEmpresa(destinatario) {
  const emp = soDigitos(((await db.q("select valor from config where chave='empresa_cnpj'")).rows[0] || {}).valor);
  if (!emp) throw new HttpError(400, 'Cadastre o CNPJ da empresa (menu Configurações > Empresa) para poder importar XML. O sistema só aceita notas emitidas para o CNPJ da empresa.');
  const d = soDigitos(destinatario);
  if (!d) throw new HttpError(400, 'Este XML não traz o CNPJ do destinatário (nota sem identificação do comprador). O sistema só aceita XML emitido para o CNPJ da empresa (' + fmtCnpj(emp) + ').');
  if (d !== emp) throw new HttpError(400, 'Este XML foi emitido para outro CNPJ (' + fmtCnpj(d) + '). O sistema só aceita XML emitido para o CNPJ da empresa (' + fmtCnpj(emp) + ').');
}

// Entrada por foto da nota: leitura OFFLINE (OCR) da imagem e sugestão de itens (o operador confere antes de lançar)
r.post('/ocr-nota', auth('estoque.entrada'), express.raw({ type: ['image/*', 'application/octet-stream'], limit: '20mb' }), wrap(async (req, res) => {
  await exigirSemBalanco();
  if (!Buffer.isBuffer(req.body) || req.body.length < 2000) throw new HttpError(400, 'Envie a foto da nota (imagem).');
  const ocr = require('../ocr_nota');
  const { texto, motor } = await ocr.lerImagem(req.body);
  const prods = (await db.q(`select p.id, p.codigo, p.nome, p.unidade, coalesce((select json_agg(b.codigo_barras) from produto_codigos_barras b where b.produto_codigo=p.codigo),'[]'::json) codigos_barras
    from produtos p where p.ativo and p.tipo<>'preparado'`)).rows;
  res.json({ motor, texto, itens: ocr.casar(ocr.interpretar(texto), prods) });
}));

r.post('/xml/ler', auth('estoque.entrada'), wrap(async (req, res) => {
  await exigirSemBalanco();
  const nf = lerFiscal(String((req.body || {}).xml || ''));
  await exigirCnpjDaEmpresa(nf.destinatario);
  if (nf.chave) {
    const ja = await db.q('select id, criado_em from entradas where chave=$1 or acerto_chave=$1', [nf.chave]);
    if (ja.rowCount) nf.ja_importada = ja.rows[0];
  }
  const forn = nf.fornecedor.documento ? (await db.q('select id,nome from fornecedores where documento=$1', [nf.fornecedor.documento])).rows[0] : null;
  nf.fornecedor_id = forn?.id || null;
  for (const i of nf.itens) {
    // 1) código do fornecedor já vinculado  2) código de barras já cadastrado (nunca duplica)  3) produto novo
    const m = forn && i.codigo_fornecedor ? (await db.q(`select p.id produto_id, pf.fator from produto_fornecedor pf join produtos p on p.codigo=pf.produto_codigo
      where pf.fornecedor_id=$1 and pf.codigo_fornecedor=$2`, [forn.id, i.codigo_fornecedor])).rows[0] : null;
    if (m) { i.produto_id = m.produto_id; i.fator = Number(m.fator); i.origem_match = 'vinculo'; continue; }
    const b = i.ean ? (await db.q(`select p.id produto_id, bb.fator from produto_codigos_barras bb join produtos p on p.codigo=bb.produto_codigo where bb.codigo_barras=$1`, [i.ean])).rows[0] : null;
    if (b) { i.produto_id = b.produto_id; i.fator = Number(b.fator); i.origem_match = 'ean'; continue; }
    i.fator = i.fator_sugerido || 1; i.origem_match = 'novo';
  }
  res.json(nf);
}));

r.post('/xml/confirmar', auth('estoque.entrada'), wrap(async (req, res) => {
  await exigirSemBalanco();
  await exigeEmpresa();
  const b = req.body || {};
  await exigirCnpjDaEmpresa(b.destinatario);
  const out = await db.tx(async c => {
    if (b.chave) {
      const ja = await c.query('select id from entradas where chave=$1', [b.chave]);
      if (ja.rowCount) throw new HttpError(409, 'Este documento já foi importado (entrada #' + ja.rows[0].id + ').');
      const ac = await c.query('select id from entradas where acerto_chave=$1', [b.chave]);
      if (ac.rowCount) throw new HttpError(409, 'Esta nota já foi lançada no acerto da consignação #' + ac.rows[0].id + '. Não importe de novo (duplicaria o estoque).');
    }
    // fornecedor: usa o existente ou cadastra pelo CNPJ
    let fornecedor_id = b.fornecedor_id || null;
    const f = b.fornecedor || {};
    if (!fornecedor_id && f.documento) {
      const ex = (await c.query('select id from fornecedores where documento=$1', [f.documento])).rows[0];
      if (ex) fornecedor_id = ex.id;
      else fornecedor_id = (await c.query(`insert into fornecedores(nome,fantasia,documento,telefone,endereco,cidade,uf)
        values($1,$2,$3,$4,$5,$6,$7) returning id`, [f.nome || 'Fornecedor', f.fantasia || null, f.documento, f.telefone || null, f.endereco || null, f.cidade || null, f.uf || null])).rows[0].id;
    }
    const itens = [];
    for (const i of b.itens || []) {
      const fator = num(i.fator, 0);
      const ean = eanValido(i.ean);
      let pid = Number(i.produto_id) || null, cod = null, criado = false;
      if (i.patrimonio) { // bem durável da nota: vira patrimônio (sem produto, sem estoque)
        itens.push({ patrimonio: true, descricao: i.descricao || i.nome, quantidade: num(i.quantidade), custo_unit: num(i.custo_unit), doacao: !!i.doacao, marca: i.marca, modelo: i.modelo, local: i.local, observacao: i.observacao });
        continue;
      }
      if (!pid && !i.criar) continue; // item ignorado
      if (!(fator > 0)) throw new HttpError(400, 'Informe o fator de: ' + (i.nome || 'item'));
      if (!pid && i.criar && ean) { // o código de barras já existe no cadastro? então usa o produto existente (sem duplicar)
        const ex = (await c.query('select p.id, p.codigo from produto_codigos_barras bb join produtos p on p.codigo=bb.produto_codigo where bb.codigo_barras=$1', [ean])).rows[0];
        if (ex) { pid = ex.id; cod = ex.codigo; }
      }
      if (!pid && i.criar) { // cadastra produto novo com os dados da nota
        const un = fator > 1 ? (['UN', 'KG', 'G', 'L', 'ML', 'CX', 'PCT'].includes(i.unidade_trib) ? i.unidade_trib : 'UN') : (['UN', 'KG', 'G', 'L', 'ML', 'CX', 'PCT'].includes(i.unidade) ? i.unidade : 'UN');
        const tipo = ['revenda', 'insumo'].includes(i.tipo) ? i.tipo : 'revenda';
        // cadastro automático SUSPENSO: código provisório (não consome o sequencial), não vendável, até alguém confirmar ou amarrar a um produto existente
        const np = (await c.query(`insert into produtos(codigo,nome,unidade,tipo,vendavel,preco_venda,suspenso,auto_origem) values('AUTO-'||nextval('seq_produto_auto'),$1,$2,$3,false,0,true,$4) returning id, codigo`,
          [i.nome, un, tipo, `NF ${b.numero || ''} · ${(b.fornecedor && b.fornecedor.nome) || ''}`.trim()])).rows[0];
        pid = np.id; cod = np.codigo; criado = true;
      }
      if (!cod) cod = (await c.query('select codigo from produtos where id=$1', [pid])).rows[0].codigo;
      if (ean) { // código de barras da nota ligado ao produto, com o fator confirmado
        const ex = (await c.query('select produto_codigo from produto_codigos_barras where codigo_barras=$1', [ean])).rows[0];
        if (!ex) await c.query(`insert into produto_codigos_barras(produto_codigo, codigo_barras, principal, fator)
          values($1,$2,not exists(select 1 from produto_codigos_barras where produto_codigo=$1),$3)`, [cod, ean, fator]);
        else if (ex.produto_codigo === cod) await c.query('update produto_codigos_barras set fator=$1 where codigo_barras=$2', [fator, ean]);
        else throw new HttpError(400, `O código de barras ${ean} já pertence a outro produto do cadastro. Escolha esse produto na linha de: ${i.nome}.`);
      }
      const et = eanValido(i.ean_trib);
      if (criado && et && et !== ean) await c.query(`insert into produto_codigos_barras(produto_codigo, codigo_barras, principal, fator)
        values($1,$2,false,1) on conflict (codigo_barras) do nothing`, [cod, et]);
      if (fornecedor_id && i.codigo_fornecedor) // código do produto no fornecedor + fator
        await c.query(`insert into produto_fornecedor(produto_codigo, fornecedor_id, codigo_fornecedor, fator) values($1,$2,$3,$4)
          on conflict (fornecedor_id, codigo_fornecedor) do update set produto_codigo=excluded.produto_codigo, fator=excluded.fator`, [cod, fornecedor_id, String(i.codigo_fornecedor), fator]);
      itens.push({ produto_id: pid, quantidade: num(i.quantidade) * fator, custo_unit: num(i.custo_unit) / fator, doacao: !!i.doacao });
    }
    const e = await gravarEntrada(c, req.user, { fornecedor_id, numero: b.numero, chave: b.chave, origem: 'xml', data_emissao: b.data_emissao, observacao: b.observacao, itens, doacao: !!b.doacao, consignada: !!b.consignada });
    const t = await gerarTitulos(c, { entrada_id: e.id, fornecedor_id, numero: b.numero, titulos: b.consignada ? [] : b.titulos, total: e.total, categoria: b.categoria_despesa });
    await auditar(c, req.user, 'entrada_xml', { id: e.id, nf: b.numero, total: e.total });
    return { ...e, titulos: t };
  });
  res.json(out);
}));

// ---- Consignação: lista, devolução (saída de estoque) e acerto (nota final + contas a pagar)
r.get('/consignacoes', auth('estoque.ver'), wrap(async (req, res) => {
  const ab = req.query.status === 'acertada' ? 'acertada' : 'aberta';
  const ents = (await db.q(`select e.id, e.numero, e.data_emissao, e.criado_em, e.consig_status, e.acerto_em, e.acerto_nf, e.acerto_total, e.observacao, f.nome fornecedor, e.fornecedor_id
    from entradas e left join fornecedores f on f.id=e.fornecedor_id where e.consignada and e.consig_status=$1 order by e.id desc limit 200`, [ab])).rows;
  const ids = ents.map(e => e.id);
  const its = ids.length ? (await db.q(`select i.id, i.entrada_id, i.produto_id, i.quantidade, i.qtd_devolvida, i.custo_unit, p.nome produto, p.unidade, p.estoque_atual
    from entrada_itens i join produtos p on p.id=i.produto_id where i.entrada_id = any($1) order by i.id`, [ids])).rows : [];
  res.json(ents.map(e => ({ ...e, itens: its.filter(i => i.entrada_id === e.id) })));
}));

async function devolverItens(c, user, entradaId, devolucoes) {
  let n = 0;
  for (const d of devolucoes || []) {
    const q = num(d.qtd); if (!(q > 0)) continue;
    const i = (await c.query('select i.*, p.estoque_atual, p.nome from entrada_itens i join produtos p on p.id=i.produto_id where i.id=$1 and i.entrada_id=$2 for update of i, p', [d.item_id, entradaId])).rows[0];
    if (!i) throw new HttpError(400, 'Item inválido.');
    if (q + Number(i.qtd_devolvida) > Number(i.quantidade) + 0.0005) throw new HttpError(400, `Devolução maior que o recebido: ${i.nome}.`);
    if (q > Number(i.estoque_atual) + 0.0005) throw new HttpError(400, `Estoque insuficiente para devolver ${i.nome} (saldo ${Number(i.estoque_atual)}). Confira o estoque antes.`);
    await c.query('update entrada_itens set qtd_devolvida=qtd_devolvida+$1 where id=$2', [q, i.id]);
    await est.mover(c, { produto_id: i.produto_id, tipo: 'devolucao', quantidade: -q, custo_unit: i.custo_unit, origem: 'devolucao_consig', ref_id: entradaId, motivo: 'Devolução de consignado #' + entradaId, usuario_id: user.id });
    n++;
  }
  return n;
}
const consigAberta = async (c, id) => {
  const e = (await c.query('select * from entradas where id=$1 and consignada for update', [id])).rows[0];
  if (!e) throw new HttpError(404, 'Consignação não encontrada.');
  if (e.consig_status !== 'aberta') throw new HttpError(400, 'Esta consignação já foi acertada.');
  return e;
};

r.post('/consignacoes/:id(\\d+)/devolver', auth('estoque.entrada'), wrap(async (req, res) => {
  const out = await db.tx(async c => {
    await consigAberta(c, req.params.id);
    const n = await devolverItens(c, req.user, req.params.id, req.body?.devolucoes);
    if (!n) throw new HttpError(400, 'Informe a quantidade devolvida de ao menos um item.');
    await auditar(c, req.user, 'consignado_devolucao', { id: Number(req.params.id), itens: n });
    return { ok: true, itens: n };
  });
  res.json(out);
}));

r.post('/consignacoes/:id(\\d+)/acerto', auth('estoque.entrada'), wrap(async (req, res) => {
  const b = req.body || {};
  const out = await db.tx(async c => {
    const e = await consigAberta(c, req.params.id);
    const chave = soDigitos(b.chave);
    if (chave) {
      if (chave.length !== 44) throw new HttpError(400, 'A chave da nota final deve ter 44 dígitos.');
      const ja = await c.query('select id from entradas where chave=$1 or acerto_chave=$1', [chave]);
      if (ja.rowCount) throw new HttpError(409, 'Esta nota (chave) já foi lançada na entrada #' + ja.rows[0].id + '.');
    }
    if (!String(b.numero || '').trim()) throw new HttpError(400, 'Informe o número da nota final emitida pelo fornecedor.');
    await devolverItens(c, req.user, e.id, b.devolucoes);
    const itens = (await c.query('select quantidade, qtd_devolvida, custo_unit from entrada_itens where entrada_id=$1', [e.id])).rows;
    const total = r2(itens.reduce((s, i) => s + (Number(i.quantidade) - Number(i.qtd_devolvida)) * Number(i.custo_unit), 0));
    await c.query(`update entradas set consig_status='acertada', acerto_em=now(), acerto_nf=$1, acerto_chave=$2, acerto_usuario_id=$3, acerto_total=$4, total=$4 where id=$5`,
      [String(b.numero).trim(), chave || null, req.user.id, total, e.id]);
    const t = total > 0 ? await gerarTitulos(c, { entrada_id: e.id, fornecedor_id: e.fornecedor_id, numero: String(b.numero).trim(), titulos: b.titulos, total, categoria: b.categoria_despesa }) : 0;
    await auditar(c, req.user, 'consignado_acerto', { id: e.id, nf: b.numero, total });
    return { id: e.id, total, titulos: t };
  });
  res.json(out);
}));

// fator sugerido para a entrada manual: vínculo com o fornecedor > código de barras informado > código de barras principal
r.get('/fator', auth('estoque.entrada'), wrap(async (req, res) => {
  const pid = Number(req.query.produto_id); if (!pid) return res.json({ fator: 1, origem: 'padrao' });
  const cod = (await db.q('select codigo from produtos where id=$1', [pid])).rows[0]?.codigo; if (!cod) return res.json({ fator: 1, origem: 'padrao' });
  const barras = String(req.query.barras || '').trim();
  if (barras) { const x = (await db.q('select fator from produto_codigos_barras where produto_codigo=$1 and codigo_barras=$2', [cod, barras])).rows[0]; if (x) return res.json({ fator: Number(x.fator), origem: 'barras' }); }
  if (Number(req.query.fornecedor_id)) { const x = (await db.q('select fator from produto_fornecedor where produto_codigo=$1 and fornecedor_id=$2 order by id limit 1', [cod, Number(req.query.fornecedor_id)])).rows[0]; if (x) return res.json({ fator: Number(x.fator), origem: 'fornecedor' }); }
  const x = (await db.q('select fator from produto_codigos_barras where produto_codigo=$1 order by principal desc, id limit 1', [cod])).rows[0];
  res.json({ fator: x ? Number(x.fator) : 1, origem: x ? 'barras' : 'padrao' });
}));

// cadastro rápido de produto direto na entrada manual: código no fornecedor, nome, código de barras e fator
r.post('/produto-rapido', auth(['estoque.entrada', 'cadastros.editar']), wrap(async (req, res) => {
  const b = req.body || {}; const nome = String(b.nome || '').trim(); const fator = num(b.fator, 0);
  if (!nome) throw new HttpError(400, 'Informe o nome do produto.');
  if (!(fator > 0)) throw new HttpError(400, 'Informe o fator (unidades dentro da embalagem deste código de barras; 1 se for unitário).');
  const ean = eanValido(b.codigo_barras), cf = String(b.codigo_fornecedor || '').trim(), fid = Number(b.fornecedor_id) || null;
  const out = await db.tx(async c => {
    if (ean) { const ex = (await c.query('select p.nome from produto_codigos_barras bb join produtos p on p.codigo=bb.produto_codigo where bb.codigo_barras=$1', [ean])).rows[0];
      if (ex) throw new HttpError(400, `Este código de barras já está cadastrado no produto "${ex.nome}". Procure-o na busca em vez de cadastrar de novo.`); }
    if (fid && cf) { const ex = (await c.query('select p.nome from produto_fornecedor pf join produtos p on p.codigo=pf.produto_codigo where pf.fornecedor_id=$1 and pf.codigo_fornecedor=$2', [fid, cf])).rows[0];
      if (ex) throw new HttpError(400, `Este código do fornecedor já está ligado ao produto "${ex.nome}".`); }
    const tipo = ['revenda', 'insumo'].includes(b.tipo) ? b.tipo : 'revenda';
    const un = ['UN', 'KG', 'G', 'L', 'ML', 'CX', 'PCT'].includes(b.unidade) ? b.unidade : 'UN';
    const p = (await c.query(`insert into produtos(nome,unidade,tipo,vendavel,preco_venda) values($1,$2,$3,$4,0) returning id, codigo, nome, unidade, tipo`, [nome, un, tipo, tipo === 'revenda'])).rows[0];
    if (ean) await c.query('insert into produto_codigos_barras(produto_codigo, codigo_barras, principal, fator) values($1,$2,true,$3)', [p.codigo, ean, fator]);
    if (fid && cf) await c.query('insert into produto_fornecedor(produto_codigo, fornecedor_id, codigo_fornecedor, fator) values($1,$2,$3,$4)', [p.codigo, fid, cf, fator]);
    await auditar(c, req.user, 'produto_criado', { id: p.id, nome, origem: 'entrada' });
    return { ...p, fator, codigos_barras: ean ? [ean] : [] };
  });
  res.json(out);
}));

r.get('/entradas', auth('estoque.ver'), wrap(async (req, res) => {
  res.json((await db.q(`select e.*, f.nome fornecedor, u.nome usuario,
      (case when e.consignada then e.consig_status end) consig,
      (select count(*) from patrimonio pt where pt.entrada_id=e.id)::int qtd_patrimonio,
      (select count(*) from entrada_itens ei where ei.entrada_id=e.id)::int qtd_itens,
      (select count(*) from entrada_itens ei where ei.entrada_id=e.id and ei.doacao)::int qtd_doacao,
      case when e.origem='manual' then 'manual'
           when d.origem='sefaz' and d.busca_origem='agendada' then 'busca_auto'
           when d.origem='sefaz' then 'busca_botao'
           when d.origem='servico' then 'servico'
           else 'arquivo' end via
    from entradas e left join fornecedores f on f.id=e.fornecedor_id
    left join usuarios u on u.id=e.usuario_id left join sefaz_docs d on d.chave=e.chave and e.chave is not null order by e.id desc limit 200`)).rows);
}));

// ---- Relatório de entradas (filtros: período, tipo, fornecedor)
r.get('/relatorio-entradas', auth(['estoque.ver', 'relatorios.estoque']), wrap(async (req, res) => {
  const { de, ate } = periodo(req); const par = [de, ate]; let f = '';
  const tipo = String(req.query.tipo || '');
  if (['xml', 'consignado', 'manual', 'doacao'].includes(tipo)) { par.push(tipo); f += ` and x.tipo=$${par.length}`; }
  if (Number(req.query.fornecedor_id)) { par.push(Number(req.query.fornecedor_id)); f += ` and x.fornecedor_id=$${par.length}`; }
  const linhas = (await db.q(`select * from (select e.id, e.numero, e.chave, e.fornecedor_id, f.nome fornecedor, e.total, e.data_emissao, e.criado_em, u.nome usuario, e.consig_status,
      case when e.consignada then 'consignado' when e.origem='xml' then 'xml' when e.doacao then 'doacao' else 'manual' end tipo,
      (select count(*) from entrada_itens ei where ei.entrada_id=e.id)::int qtd_itens,
      (select coalesce(sum(ei.quantidade),0) from entrada_itens ei where ei.entrada_id=e.id) qtd_total
      from entradas e left join fornecedores f on f.id=e.fornecedor_id left join usuarios u on u.id=e.usuario_id
      where e.criado_em >= $1::date and e.criado_em < $2::date + 1) x where true ${f} order by x.criado_em desc, x.id desc limit 3000`, par)).rows;
  const ids = linhas.map(l => l.id); let itens = [];
  if (ids.length) itens = (await db.q(`select ei.entrada_id, coalesce(p.nome, ei.descricao) produto, p.unidade, ei.quantidade, ei.custo_unit, round(ei.quantidade*ei.custo_unit,2) total, ei.doacao, ei.patrimonio
      from entrada_itens ei left join produtos p on p.id=ei.produto_id where ei.entrada_id = any($1) order by ei.id`, [ids])).rows;
  const por = {}; for (const i of itens) (por[i.entrada_id] ||= []).push(i);
  const tot = { entradas: linhas.length, valor: r2(linhas.reduce((a, l) => a + Number(l.total || 0), 0)) };
  const porTipo = {}; for (const l of linhas) { const t = (porTipo[l.tipo] ||= { entradas: 0, valor: 0 }); t.entradas++; t.valor = r2(t.valor + Number(l.total || 0)); }
  res.json({ de, ate, total: tot, por_tipo: porTipo, entradas: linhas.map(l => ({ ...l, itens: por[l.id] || [] })) });
}));

// ---- Movimentação
r.get('/movimentos', auth(['estoque.ver', 'relatorios.estoque']), wrap(async (req, res) => {
  const { de, ate } = periodo(req); const par = [de, ate]; let f = '';
  if (req.query.produto_id) { par.push(req.query.produto_id); f += ` and m.produto_id=$${par.length}`; }
  if (req.query.tipo) { par.push(req.query.tipo); f += ` and m.tipo=$${par.length}`; }
  const base = `m.criado_em >= $1::date and m.criado_em < $2::date + 1 ${f}`;
  const movimentos = (await db.q(`select m.*, p.nome produto, p.unidade, u.nome usuario from mov_estoque m
    join produtos p on p.id=m.produto_id left join usuarios u on u.id=m.usuario_id where ${base} order by m.id desc limit 2000`, par)).rows;
  const resumo = (await db.q(`select p.id, p.nome, p.unidade,
    coalesce(sum(m.quantidade) filter (where m.quantidade>0 and m.tipo in ('entrada','ajuste','estorno')),0) entradas,
    coalesce(-sum(m.quantidade) filter (where m.quantidade<0),0) saidas, p.estoque_atual
    from mov_estoque m join produtos p on p.id=m.produto_id where ${base} group by p.id order by p.nome`, par)).rows;
  res.json({ de, ate, resumo, movimentos });
}));

module.exports = r;
module.exports.lerFiscal = lerFiscal;
