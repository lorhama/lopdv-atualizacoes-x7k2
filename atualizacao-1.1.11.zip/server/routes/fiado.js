// Recebimento (baixa) de fiado: exige caixa aberto, escolha do caixa e forma de pagamento (nunca Fiado).
const express = require('express');
const db = require('../db');
const tef = require('../tef');
const prn = require('../printer');
const { auth, auditar } = require('../auth');
const { HttpError, wrap, num, r2, hoje } = require('../util');
const r = express.Router();

const SALDO = "t.valor - coalesce((select sum(p.valor) from pagamentos p where p.titulo_id=t.id),0)";

r.get('/pendentes', auth('vendas.receber'), wrap(async (req, res) => {
  const caixas = (await db.q("select id, numero, aberto_em, valor_abertura from caixas where usuario_id=$1 and status='aberto' order by id", [req.user.id])).rows;
  const titulos = (await db.q(`select t.id, t.descricao, t.valor, t.vencimento, t.cliente_id, c.nome cliente, t.pedido_id, t.criado_em, coalesce(v.numero, t.pedido_id) num, ${SALDO} saldo
    from titulos t join clientes c on c.id=t.cliente_id left join vendas v on v.pedido_id=t.pedido_id where t.tipo='receber' and t.categoria='Venda fiado' and t.status='aberto' order by c.nome, t.vencimento, t.id`)).rows;
  res.json({ caixas, titulos });
}));

// Vendas fiado de um cliente (em aberto e, se pedido, as já quitadas) — consulta da tela de vendas
r.get('/cliente/:id', auth('vendas.receber'), wrap(async (req, res) => {
  const quit = req.query.quitados === '1';
  const titulos = (await db.q(`select t.id, t.descricao, t.valor, t.vencimento, t.status, t.pago_em, t.pedido_id, t.criado_em, coalesce(v.numero, t.pedido_id) num, ${SALDO} saldo
    from titulos t left join vendas v on v.pedido_id=t.pedido_id where t.tipo='receber' and t.categoria='Venda fiado' and t.cliente_id=$1 and t.status<>'cancelado' and ($2 or t.status='aberto') order by t.criado_em desc, t.id desc limit 300`, [req.params.id, quit])).rows;
  const cli = (await db.q('select id, nome, telefone from clientes where id=$1', [req.params.id])).rows[0];
  res.json({ cliente: cli || null, titulos });
}));

// Comprovante de pagamento do recebimento de fiado (via do cliente)
async function comprovanteFiado(pagId) {
  const g = (await db.q(`select g.id, g.valor, g.forma, g.criado_em, g.tef_nsu, g.tef_autorizacao, g.titulo_id, t.cliente_id, t.pedido_id, t.valor titulo_valor, t.status tstatus,
      c.nome cliente, coalesce(v.numero, t.pedido_id) num, coalesce(cx.numero, cx.id) caixa_num, u.nome operador, f.descricao forma_desc,
      t.valor - coalesce((select sum(x.valor) from pagamentos x where x.titulo_id=t.id),0) saldo_titulo
    from pagamentos g join titulos t on t.id=g.titulo_id join clientes c on c.id=t.cliente_id left join vendas v on v.pedido_id=t.pedido_id
    left join caixas cx on cx.id=g.caixa_id left join usuarios u on u.id=cx.usuario_id left join formas_pagamento f on f.codigo=g.forma
    where g.id=$1 and g.origem='recebimento_fiado'`, [pagId])).rows[0];
  if (!g) throw new HttpError(404, 'Pagamento de fiado não encontrado.');
  const outros = (await db.q(`select coalesce(sum(t.valor - coalesce((select sum(x.valor) from pagamentos x where x.titulo_id=t.id),0)),0) s from titulos t
    where t.tipo='receber' and t.categoria='Venda fiado' and t.status='aberto' and t.cliente_id=$1`, [g.cliente_id])).rows[0].s;
  const emp = ((await db.q("select valor from config where chave='empresa'")).rows[0] || {}).valor || '';
  const W = 42, brl = n => Number(n).toFixed(2).replace('.', ','), dh = x => { const d = new Date(x), z = n => String(n).padStart(2, '0'); return `${z(d.getDate())}/${z(d.getMonth() + 1)}/${d.getFullYear()} ${z(d.getHours())}:${z(d.getMinutes())}`; };
  const par = (a, b) => String(a).padEnd(W - 14) + String(b).padStart(14);
  const quitado = Number(g.saldo_titulo) <= 0.004, saldo = Math.max(0, r2(Number(g.saldo_titulo)));
  const L = [];
  if (emp) L.push(String(emp).toUpperCase().slice(0, W));
  L.push('COMPROVANTE DE PAGAMENTO', '(recebimento de fiado)', prn.linha(W), 'Cliente: ' + String(g.cliente).slice(0, W - 9), 'Data: ' + dh(g.criado_em), 'Recebido por: ' + String(g.operador || '').slice(0, W - 14) + (g.caixa_num != null ? ' (caixa ' + g.caixa_num + ')' : ''), prn.linha(W),
    par('Referente a venda ' + String(g.num).padStart(6, '0'), ''), par('Valor da venda', brl(g.titulo_valor)),
    par('Forma: ' + (g.forma_desc || g.forma), ''));
  if (g.tef_nsu) L.push('NSU ' + g.tef_nsu + (g.tef_autorizacao ? '  Aut. ' + g.tef_autorizacao : ''));
  L.push(par('VALOR PAGO', brl(g.valor)), par(quitado ? 'Situacao da venda' : 'Saldo restante da venda', quitado ? 'QUITADA' : brl(saldo)), prn.linha(W),
    par('Total em aberto do cliente', brl(outros)), '', 'Obrigado!', 'Comprovante sem valor fiscal');
  return L.join('\n');
}

r.post('/pagamentos/:id/comprovante', auth('vendas.receber'), wrap(async (req, res) => {
  const txt = await comprovanteFiado(Number(req.params.id));
  res.json({ comprovante: txt, impressao: await prn.imprimirTexto(db, 'caixa', 'PAGAMENTO', txt) });
}));

r.post('/baixar', auth('vendas.receber'), wrap(async (req, res) => {
  const b = req.body || {};
  const forma = (await db.q('select * from formas_pagamento where codigo=$1 and ativo', [b.forma])).rows[0];
  if (!forma) throw new HttpError(400, 'Escolha a forma de pagamento da baixa.');
  if (forma.tipo === 'fiado') throw new HttpError(400, 'A baixa de fiado não pode ser feita na forma Fiado.');
  const ref = b.tef_ref || null; let comprovante = null;
  try {
    await db.tx(async c => {
      const cx = (await c.query("select id from caixas where id=$1 and usuario_id=$2 and status='aberto'", [b.caixa_id, req.user.id])).rows[0];
      if (!cx) throw new HttpError(400, 'Para baixar fiado é necessário informar um caixa seu que esteja aberto.');
      const t = (await c.query(`select t.*, ${SALDO} saldo from titulos t where t.id=$1 for update of t`, [b.titulo_id])).rows[0];
      if (!t || t.categoria !== 'Venda fiado' || t.status !== 'aberto') throw new HttpError(400, 'Fiado não encontrado ou já baixado.');
      const saldo = r2(Number(t.saldo)); const valor = r2(num(b.valor, saldo));
      if (valor <= 0) throw new HttpError(400, 'Informe um valor maior que zero.');
      if (valor > saldo + 0.004) throw new HttpError(400, `O valor excede o saldo do fiado (${saldo.toFixed(2)}).`);
      let tx = null;
      if (forma.tef_ativo) { tx = tef.reservar(ref, forma.codigo, valor, req.user.id); comprovante = { linhas: tx.comprovante, vias: forma.tef_vias || 1 }; }
      else if (ref) throw new HttpError(400, 'Forma sem TEF recebeu uma transação TEF.');
      const pg = (await c.query("insert into pagamentos(pedido_id, caixa_id, forma, valor, titulo_id, origem, tef_nsu, tef_autorizacao, tef_rede) values(null,$1,$2,$3,$4,'recebimento_fiado',$5,$6,$7) returning id",
        [cx.id, forma.codigo, valor, t.id, tx?.nsu || null, tx?.autorizacao || null, tx?.rede || null])).rows[0];
      res.locals.pagId = pg.id;
      const quitado = r2(saldo - valor) <= 0.004;
      if (quitado) await c.query("update titulos set status='pago', pago_em=$1, valor_pago=$2, forma=$3 where id=$4", [hoje(), t.valor, forma.codigo, t.id]);
      await auditar(c, req.user, 'fiado_baixado', { titulo: t.id, cliente: t.cliente_id, valor, forma: forma.codigo, caixa: cx.id, quitado });
      res.locals.out = { ok: true, quitado, saldo_restante: quitado ? 0 : r2(saldo - valor) };
    });
  } catch (e) { if (ref) await tef.finalizar(ref, false); throw e; }
  const imp = [];
  if (ref) { await tef.finalizar(ref, true); if (comprovante?.linhas?.length) for (let i = 0; i < comprovante.vias; i++) imp.push(await prn.imprimirTexto(db, 'caixa', '', comprovante.linhas.join('\n'))); }
  // comprovante de pagamento para o cliente (sempre impresso, além do comprovante do cartão)
  let pagamento = null;
  try { const txt = await comprovanteFiado(res.locals.pagId); pagamento = { id: res.locals.pagId, texto: txt, impressao: await prn.imprimirTexto(db, 'caixa', 'PAGAMENTO', txt) }; }
  catch (e) { pagamento = { id: res.locals.pagId, texto: null, impressao: { ok: false, erro: e.message } }; }
  res.json({ ...res.locals.out, impressao: imp, comprovante: comprovante?.linhas || [], pagamento });
}));

module.exports = r;
module.exports.comprovanteFiado = comprovanteFiado;
