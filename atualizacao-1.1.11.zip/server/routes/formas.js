// Cadastro de formas de pagamento + integração TEF (pastas) + navegador de pastas do servidor.
const express = require('express');
const fs = require('fs'), path = require('path');
const db = require('../db');
const tef = require('../tef');
const prn = require('../printer');
const { auth, auditar } = require('../auth');
const { HttpError, wrap, num, r2 } = require('../util');
const r = express.Router();

const TIPOS = ['dinheiro', 'pix', 'debito', 'credito', 'voucher', 'fiado', 'consignado', 'outro'];
const TEXTO = ['descricao', 'tipo', 'bandeira', 'tef_provedor', 'tef_rede', 'tef_dir_envio', 'tef_arq_envio', 'tef_ext_envio', 'tef_dir_retorno', 'tef_arq_retorno', 'tef_ext_retorno',
  'tef_dir_status', 'tef_arq_status', 'tef_ext_status', 'tef_dir_temp', 'tef_arq_temp', 'tef_ext_temp', 'tef_dir_exec'];
const INTS = ['ordem', 'max_parcelas', 'dias_recebimento', 'tef_vias', 'tef_timeout'];
const slug = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 40) || 'forma';

function ler(b) {
  if (!b.descricao) throw new HttpError(400, 'Informe a descrição.');
  if (!TIPOS.includes(b.tipo)) throw new HttpError(400, 'Tipo inválido.');
  const o = { ativo: b.ativo !== false, taxa_pct: num(b.taxa_pct), taxa_fixa: num(b.taxa_fixa) };
  TEXTO.forEach(c => { o[c] = b[c] === undefined || b[c] === '' ? null : String(b[c]).trim(); });
  INTS.forEach(c => { o[c] = b[c] === undefined || b[c] === '' ? null : Math.max(0, Math.round(num(b[c]))); });
  o.max_parcelas = o.max_parcelas || 1; o.tef_vias = o.tef_vias || 1; o.tef_timeout = o.tef_timeout || 120;
  o.tef_ativo = !!b.tef_ativo && !['dinheiro', 'fiado', 'consignado'].includes(b.tipo);
  if (o.tipo !== 'credito') o.max_parcelas = 1;
  if (o.tef_ativo && (!o.tef_dir_envio || !o.tef_dir_retorno)) throw new HttpError(400, 'Com TEF ativo, informe as pastas de envio e de retorno.');
  return o;
}
const COLS = ['ativo', 'taxa_pct', 'taxa_fixa', ...TEXTO, ...INTS, 'tef_ativo'];

// Lista para cadastro (completa) ou para a tela de recebimento (?ativas=1, só o necessário)
r.get('/formas-pagamento', auth(['formas.gerenciar', 'cadastros.ver', 'vendas.acessar', 'estoque.entrada', 'financeiro.ver']), wrap(async (req, res) => {
  if (req.query.ativas === '1') { // vendas/caixa: sem o Consignado (só serve para pagar compras)
    return res.json((await db.q("select id, codigo, descricao, tipo, max_parcelas, tef_ativo from formas_pagamento where ativo and tipo<>'consignado' order by ordem, id")).rows);
  }
  if (req.query.uso === 'pagar') { // contas a pagar / entrada de mercadoria
    return res.json((await db.q("select id, codigo, descricao, tipo from formas_pagamento where ativo and tipo<>'fiado' order by ordem, id")).rows);
  }
  res.json((await db.q('select * from formas_pagamento order by ordem, id')).rows);
}));

r.post('/formas-pagamento', auth('formas.gerenciar'), wrap(async (req, res) => {
  const o = ler(req.body || {});
  let cod = slug(o.descricao); const ex = (await db.q('select codigo from formas_pagamento where codigo like $1', [cod + '%'])).rows.map(x => x.codigo);
  for (let i = 2; ex.includes(cod); i++) cod = slug(o.descricao) + '_' + i;
  const x = await db.q(`insert into formas_pagamento(codigo, ${COLS.join(',')}) values($1, ${COLS.map((_, i) => '$' + (i + 2)).join(',')}) returning id`, [cod, ...COLS.map(c => o[c])]);
  await auditar(null, req.user, 'forma_pagamento_criada', { id: x.rows[0].id, descricao: o.descricao, tef: o.tef_ativo });
  res.json({ id: x.rows[0].id });
}));

r.put('/formas-pagamento/:id', auth('formas.gerenciar'), wrap(async (req, res) => {
  const o = ler(req.body || {});
  const atual = (await db.q('select tipo from formas_pagamento where id=$1', [req.params.id])).rows[0];
  if (!atual) throw new HttpError(404, 'Forma não encontrada.');
  if (['dinheiro', 'fiado'].includes(atual.tipo) && o.tipo !== atual.tipo) throw new HttpError(400, 'O tipo das formas Dinheiro e Fiado não pode ser alterado.');
  if (atual.tipo === 'dinheiro' && !o.ativo) throw new HttpError(400, 'A forma Dinheiro não pode ser inativada (é usada no fechamento do caixa).');
  await db.q(`update formas_pagamento set ${COLS.map((c, i) => `${c}=$${i + 1}`).join(',')} where id=$${COLS.length + 1}`, [...COLS.map(c => o[c]), req.params.id]);
  await auditar(null, req.user, 'forma_pagamento_alterada', { id: req.params.id, descricao: o.descricao, tef: o.tef_ativo });
  res.json({ ok: true });
}));

r.delete('/formas-pagamento/:id', auth('formas.gerenciar'), wrap(async (req, res) => {
  const f = (await db.q('select * from formas_pagamento where id=$1', [req.params.id])).rows[0];
  if (!f) throw new HttpError(404, 'Forma não encontrada.');
  if (['dinheiro', 'fiado'].includes(f.tipo)) throw new HttpError(400, 'Dinheiro e Fiado não podem ser excluídos.');
  if ((await db.q('select 1 from pagamentos where forma=$1 limit 1', [f.codigo])).rowCount) throw new HttpError(400, 'Esta forma já foi usada em vendas. Inative-a em vez de excluir.');
  await db.q('delete from formas_pagamento where id=$1', [f.id]);
  await auditar(null, req.user, 'forma_pagamento_excluida', { id: f.id, descricao: f.descricao });
  res.json({ ok: true });
}));

// ---- Navegador de pastas do servidor (para escolher as pastas do TEF)
r.get('/fs/listar', auth('formas.gerenciar'), wrap(async (req, res) => {
  let dir = String(req.query.dir || '').trim();
  if (!dir) {
    if (process.platform === 'win32') return res.json({ dir: '', pai: null, pastas: 'CDEFGHIJKLMNOPQRSTUVWXYZAB'.split('').filter(l => fs.existsSync(l + ':\\')).map(l => ({ nome: l + ':\\', caminho: l + ':\\' })) });
    dir = '/';
  }
  dir = path.resolve(dir);
  let itens;
  try { itens = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { throw new HttpError(400, 'Não foi possível abrir a pasta: ' + e.message); }
  const pastas = itens.filter(d => { try { return d.isDirectory(); } catch { return false; } }).map(d => ({ nome: d.name, caminho: path.join(dir, d.name) }))
    .sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'));
  const arquivos = req.query.arquivos === '1' ? itens.filter(d => { try { return d.isFile() && /\.exe$/i.test(d.name); } catch { return false; } }).map(d => ({ nome: d.name, caminho: path.join(dir, d.name) })) : [];
  const raiz = path.parse(dir).root;
  res.json({ dir, arquivos, pai: dir === raiz ? (process.platform === 'win32' ? '' : null) : path.dirname(dir), pastas });
}));

// ---- TEF
r.post('/tef/testar', auth('formas.gerenciar'), wrap(async (req, res) => { res.json({ resultados: tef.testar(req.body || {}) }); }));

r.post('/tef/transacao', auth('vendas.receber'), wrap(async (req, res) => {
  const b = req.body || {};
  const f = (await db.q('select * from formas_pagamento where codigo=$1 and ativo', [b.forma])).rows[0];
  if (!f || !f.tef_ativo) throw new HttpError(400, 'Esta forma de pagamento não usa TEF.');
  const valor = r2(num(b.valor)); if (valor <= 0) throw new HttpError(400, 'Valor inválido.');
  const parcelas = Math.min(Math.max(1, Math.round(num(b.parcelas) || 1)), f.max_parcelas || 1);
  const out = await tef.vender(f, { valor, identificacao: b.pedido_id || Date.now(), parcelas, usuario: req.user.id });
  await auditar(null, req.user, out.aprovado ? 'tef_aprovado' : 'tef_negado', { forma: f.codigo, valor, pedido: b.pedido_id, nsu: out.nsu });
  const { comprovante, ...resto } = out; res.json({ ...resto, comprovante });
}));

r.post('/tef/desfazer', auth('vendas.receber'), wrap(async (req, res) => {
  for (const ref of req.body?.refs || []) await tef.finalizar(ref, false);
  res.json({ ok: true });
}));

module.exports = r;
