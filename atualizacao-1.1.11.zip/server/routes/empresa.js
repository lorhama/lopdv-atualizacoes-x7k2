// Empresas (CNPJs) que usam o sistema: dados, e-mail padrão (remetente) e servidor de envio (SMTP).
// Uma empresa fica "em uso": os dados dela são espelhados em config (empresa, empresa_*, smtp_*), de onde comprovantes, relatórios e e-mails leem.
const express = require('express');
const db = require('../db');
const { auth, auditar } = require('../auth');
const { wrap, HttpError } = require('../util');
const { cifrar } = require('../sefaz');
const email = require('../email');
const r = express.Router();
const emailOk = s => /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(String(s || '').trim());
const set = (c, k, v) => c.query('insert into config(chave,valor) values($1,$2) on conflict(chave) do update set valor=excluded.valor', [k, String(v ?? '')]);
const ESPELHO = { empresa: 'nome', empresa_razao: 'razao', empresa_cnpj: 'cnpj', empresa_ie: 'ie', empresa_tel: 'tel', empresa_endereco: 'endereco', empresa_cidade: 'cidade', empresa_email: 'email',
  smtp_host: 'smtp_host', smtp_porta: 'smtp_porta', smtp_seguranca: 'smtp_seguranca', smtp_usuario: 'smtp_usuario', smtp_senha: 'smtp_senha' };
async function espelhar(c) {
  const e = (await c.query('select * from empresas where em_uso limit 1')).rows[0] || {};
  for (const [k, col] of Object.entries(ESPELHO)) await set(c, k, e[col] || '');
}
const CAMPOS = ['nome', 'razao', 'cnpj', 'ie', 'tel', 'endereco', 'cidade', 'email', 'smtp_host', 'smtp_porta', 'smtp_seguranca', 'smtp_usuario'];
function validar(b) {
  if (!String(b.nome || '').trim()) throw new HttpError(400, 'Informe o nome fantasia da empresa.');
  if (b.email && !emailOk(b.email)) throw new HttpError(400, 'E-mail padrão da empresa inválido.');
  if (b.cnpj) { const d = String(b.cnpj).replace(/\D/g, ''); if (d.length !== 14 && d.length !== 11) throw new HttpError(400, 'CNPJ/CPF inválido.'); b.cnpj = d; }
  if (b.smtp_seguranca && !['ssl', 'starttls', 'nenhuma'].includes(b.smtp_seguranca)) throw new HttpError(400, 'Segurança do e-mail inválida.');
}
const limpa = e => { const { smtp_senha, ...o } = e; o.smtp_tem_senha = !!smtp_senha; return o; };

r.get('/', auth('config.gerenciar'), wrap(async (req, res) => { res.json((await db.q('select * from empresas order by em_uso desc, ativo desc, nome')).rows.map(limpa)); }));
r.post('/', auth('config.gerenciar'), wrap(async (req, res) => {
  const b = req.body || {}; validar(b);
  const id = await db.tx(async c => {
    if (b.cnpj && (await c.query('select 1 from empresas where cnpj=$1', [b.cnpj])).rows.length) throw new HttpError(409, 'Já existe empresa cadastrada com esse CNPJ/CPF.');
    const primeira = !(await c.query('select 1 from empresas where em_uso')).rows.length;
    const x = await c.query(`insert into empresas(${CAMPOS.join(',')}, smtp_senha, em_uso) values(${CAMPOS.map((_, i) => '$' + (i + 1)).join(',')}, $${CAMPOS.length + 1}, $${CAMPOS.length + 2}) returning id`,
      [...CAMPOS.map(k => String(b[k] ?? '').trim() || (k === 'smtp_seguranca' ? 'starttls' : null)), b.smtp_senha ? cifrar(String(b.smtp_senha)) : null, primeira]);
    if (primeira) await espelhar(c); return x.rows[0].id;
  });
  await auditar(null, req.user, 'empresa_criada', { id, nome: b.nome }); res.json({ ok: true, id });
}));
r.put('/:id(\\d+)', auth('config.gerenciar'), wrap(async (req, res) => {
  const b = req.body || {}; validar(b); const id = +req.params.id;
  await db.tx(async c => {
    if (!(await c.query('select 1 from empresas where id=$1', [id])).rows.length) throw new HttpError(404, 'Empresa não encontrada.');
    if (b.cnpj && (await c.query('select 1 from empresas where cnpj=$1 and id<>$2', [b.cnpj, id])).rows.length) throw new HttpError(409, 'Já existe outra empresa com esse CNPJ/CPF.');
    const sets = CAMPOS.map((k, i) => `${k}=$${i + 1}`); const vals = CAMPOS.map(k => String(b[k] ?? '').trim() || (k === 'smtp_seguranca' ? 'starttls' : null));
    let q = `update empresas set ${sets.join(',')}`; if (b.smtp_senha) { vals.push(cifrar(String(b.smtp_senha))); q += `, smtp_senha=$${vals.length}`; }
    vals.push(id); await c.query(q + ` where id=$${vals.length}`, vals);
    await espelhar(c);
  });
  await auditar(null, req.user, 'empresa_alterada', { id, nome: b.nome }); res.json({ ok: true });
}));
r.post('/:id(\\d+)/usar', auth('config.gerenciar'), wrap(async (req, res) => {
  const id = +req.params.id;
  await db.tx(async c => {
    const e = (await c.query('select ativo from empresas where id=$1', [id])).rows[0]; if (!e) throw new HttpError(404, 'Empresa não encontrada.');
    if (!e.ativo) throw new HttpError(400, 'Reative a empresa antes de usá-la.');
    await c.query('update empresas set em_uso = (id=$1)', [id]); await espelhar(c);
  });
  await auditar(null, req.user, 'empresa_em_uso', { id }); res.json({ ok: true });
}));
r.post('/:id(\\d+)/ativo', auth('config.gerenciar'), wrap(async (req, res) => {
  const id = +req.params.id, ativo = !!req.body?.ativo;
  const e = (await db.q('select em_uso from empresas where id=$1', [id])).rows[0]; if (!e) throw new HttpError(404, 'Empresa não encontrada.');
  if (!ativo && e.em_uso) throw new HttpError(400, 'Esta é a empresa em uso. Escolha outra empresa como "em uso" antes de inativar.');
  await db.q('update empresas set ativo=$2 where id=$1', [id, ativo]); res.json({ ok: true });
}));
r.delete('/:id(\\d+)', auth('config.gerenciar'), wrap(async (req, res) => {
  const id = +req.params.id; const e = (await db.q('select em_uso from empresas where id=$1', [id])).rows[0]; if (!e) throw new HttpError(404, 'Empresa não encontrada.');
  if (e.em_uso) throw new HttpError(400, 'Esta é a empresa em uso. Escolha outra como "em uso" antes de excluir.');
  await db.q('delete from empresas where id=$1', [id]); await auditar(null, req.user, 'empresa_excluida', { id }); res.json({ ok: true });
}));
r.post('/email-teste', auth('config.gerenciar'), wrap(async (req, res) => {
  const para = String(req.body?.para || '').trim();
  if (!emailOk(para)) throw new HttpError(400, 'Informe um e-mail válido para receber o teste.');
  try { await email.enviar(db, { para, assunto: 'Teste de e-mail do LoPDV', texto: 'Este é um e-mail de teste do LoPDV.\nSe você recebeu, o envio de e-mails (recuperação de senha) está funcionando.' }); }
  catch (e) { throw new HttpError(400, e.message); }
  res.json({ ok: true });
}));
module.exports = r;
