class HttpError extends Error {
  constructor(status, message, extra) { super(message); this.status = status; this.extra = extra || {}; }
}
const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const r2 = n => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
const num = (v, d = 0) => { const n = Number(String(v ?? '').replace(',', '.')); return Number.isFinite(n) ? n : d; };
const hoje = () => new Date().toISOString().slice(0, 10);
function periodo(req) {
  const d = new Date(); const ini = new Date(d.getFullYear(), d.getMonth(), 1);
  const iso = x => new Date(x.getTime() - x.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  return { de: req.query.de || iso(ini), ate: req.query.ate || iso(d) };
}
function errorHandler(err, req, res, next) { // eslint-disable-line
  if (err.code === '23505') return res.status(409).json({ erro: 'Registro duplicado (já existe um cadastro com esse valor).' });
  if (err.code === '23503') return res.status(409).json({ erro: 'Registro em uso por outros dados; não pode ser excluído. Inative-o.' });
  if (err.code === '23514') return res.status(400).json({ erro: 'Valor inválido.' });
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ erro: err.message || 'Erro interno', ...(err.extra || {}) });
}
module.exports = { HttpError, wrap, r2, num, hoje, periodo, errorHandler };
