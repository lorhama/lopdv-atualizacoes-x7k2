// Envio de e-mail por SMTP (sem bibliotecas externas). Usa os dados do cadastro da empresa: e-mail padrão (remetente) e servidor SMTP.
const net = require('net'), tls = require('tls'), crypto = require('crypto');
const { decifrar } = require('./sefaz');

const limpa = s => String(s || '').replace(/[\r\n]+/g, ' ').trim();
const b64 = s => Buffer.from(String(s), 'utf8').toString('base64');
const encCab = s => (/^[\x20-\x7e]*$/.test(s) ? s : '=?UTF-8?B?' + b64(s) + '?=');

// leitor de respostas SMTP (aceita respostas de várias linhas: "250-..." até "250 ...")
function leitor(sock) {
  let buf = '', fila = [], erro = null;
  const tenta = () => {
    while (fila.length) {
      const linhas = buf.split('\r\n'); if (linhas.length < 2) return;
      let fim = -1; for (let i = 0; i < linhas.length - 1; i++) if (/^\d{3} /.test(linhas[i]) || /^\d{3}$/.test(linhas[i])) { fim = i; break; }
      if (fim < 0) return;
      const bloco = linhas.slice(0, fim + 1); buf = linhas.slice(fim + 1).join('\r\n');
      fila.shift().ok({ codigo: Number(bloco[fim].slice(0, 3)), texto: bloco.map(l => l.slice(4)).join('\n') });
    }
  };
  sock.on('data', d => { buf += d.toString('utf8'); tenta(); });
  const falha = e => { erro = e; fila.splice(0).forEach(f => f.erro(e)); };
  sock.on('error', falha); sock.on('close', () => falha(new Error('Conexão encerrada pelo servidor de e-mail.')));
  sock.setTimeout(25000, () => sock.destroy(new Error('O servidor de e-mail demorou demais para responder.')));
  return { ler: () => new Promise((ok, erroF) => { if (erro) return erroF(erro); fila.push({ ok, erro: erroF }); tenta(); }) };
}

async function enviarSmtp(o) {
  const porta = Number(o.porta) || (o.seguranca === 'ssl' ? 465 : 587);
  let sock = await new Promise((ok, no) => {
    const s = o.seguranca === 'ssl' ? tls.connect({ host: o.host, port: porta, servername: o.host }, () => ok(s)) : net.connect({ host: o.host, port: porta }, () => ok(s));
    s.once('error', no); s.setTimeout(25000, () => s.destroy(new Error('Não foi possível conectar ao servidor de e-mail (tempo esgotado).')));
  });
  let rd = leitor(sock);
  const cmd = async (linha, esperado) => { if (linha !== null) sock.write(linha + '\r\n'); const r = await rd.ler(); if (!esperado.includes(r.codigo)) throw new Error('Servidor de e-mail: ' + r.codigo + ' ' + r.texto.split('\n')[0]); return r; };
  try {
    await cmd(null, [220]);
    let eh = await cmd('EHLO lopdv.local', [250]);
    if (o.seguranca === 'starttls') {
      await cmd('STARTTLS', [220]);
      sock = await new Promise((ok, no) => { const s = tls.connect({ socket: sock, servername: o.host }, () => ok(s)); s.once('error', no); });
      rd = leitor(sock); eh = await cmd('EHLO lopdv.local', [250]);
    }
    if (o.usuario) {
      const r = await cmd('AUTH PLAIN ' + b64('\0' + o.usuario + '\0' + o.senha), [235, 334, 504, 535, 530]);
      if (r.codigo === 334) { await cmd(b64(o.usuario), [334]); await cmd(b64(o.senha), [235]); }
      else if (r.codigo !== 235) throw new Error('O servidor de e-mail recusou o usuário/senha (' + r.codigo + '). Confira o usuário e a senha do e-mail no cadastro da empresa.');
    }
    const de = limpa(o.de), para = limpa(o.para);
    await cmd('MAIL FROM:<' + de + '>', [250]); await cmd('RCPT TO:<' + para + '>', [250, 251]); await cmd('DATA', [354]);
    const corpo = b64(o.texto).replace(/(.{76})/g, '$1\r\n');
    const msg = ['From: ' + (o.deNome ? encCab(limpa(o.deNome)) + ' ' : '') + '<' + de + '>', 'To: <' + para + '>', 'Subject: ' + encCab(limpa(o.assunto)),
      'Date: ' + new Date().toUTCString(), 'Message-ID: <' + crypto.randomBytes(12).toString('hex') + '@lopdv.local>', 'MIME-Version: 1.0',
      'Content-Type: text/plain; charset=UTF-8', 'Content-Transfer-Encoding: base64', '', corpo, '.'].join('\r\n');
    await cmd(msg, [250]);
    try { sock.write('QUIT\r\n'); } catch { /* */ }
  } finally { try { sock.end(); } catch { /* */ } }
}

async function config(db) {
  const o = {}; (await db.q("select chave, valor from config where chave like 'empresa%' or chave like 'smtp\\_%'")).rows.forEach(x => { o[x.chave] = x.valor; });
  let senha = ''; try { senha = o.smtp_senha ? decifrar(o.smtp_senha) : ''; } catch { senha = ''; }
  return { de: o.empresa_email || '', deNome: o.empresa || o.empresa_razao || 'LoPDV', host: o.smtp_host || '', porta: o.smtp_porta || '', seguranca: o.smtp_seguranca || 'starttls', usuario: o.smtp_usuario || '', senha };
}
const configurado = c => !!(c.de && c.host);
async function enviar(db, { para, assunto, texto }) {
  const c = await config(db);
  if (!configurado(c)) throw Object.assign(new Error('O envio de e-mail ainda não foi configurado (cadastro da empresa).'), { naoConfigurado: true });
  await enviarSmtp({ ...c, para, assunto, texto });
}
module.exports = { enviar, enviarSmtp, config, configurado };
