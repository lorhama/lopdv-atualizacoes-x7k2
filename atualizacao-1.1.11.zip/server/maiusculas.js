// Padrão do sistema: textos de cadastro ficam em LETRAS MAIÚSCULAS (nome, descrição, endereço...).
// Vale para tudo que a tela envia ao servidor; e-mail, login, senha, URLs, códigos e observações de pedido não são tocados.
const CHAVES = new Set(['nome', 'razao', 'descricao', 'fantasia', 'endereco', 'cidade', 'bairro', 'complemento', 'contato', 'cargo', 'condicao_pagamento', 'bandeira',
  'marca', 'modelo', 'local', 'responsavel', 'serie', 'uf', 'empresa', 'empresa_razao', 'empresa_endereco', 'empresa_cidade']);
const OBS_CADASTRO = /^\/api\/(clientes|fornecedores|patrimonio|produtos)(\/|$)/;
function aplicar(v, obs) {
  if (Array.isArray(v)) { v.forEach((x, i) => { if (x && typeof x === 'object') aplicar(x, obs); }); return v; }
  if (!v || typeof v !== 'object') return v;
  for (const k of Object.keys(v)) {
    const x = v[k];
    if (typeof x === 'string') { if (CHAVES.has(k) || (obs && k === 'observacao')) v[k] = x.toLocaleUpperCase('pt-BR'); }
    else if (x && typeof x === 'object') aplicar(x, obs);
  }
  return v;
}
module.exports = (req, res, next) => {
  if (['POST', 'PUT', 'PATCH'].includes(req.method) && req.body && typeof req.body === 'object') aplicar(req.body, OBS_CADASTRO.test(req.originalUrl.split('?')[0]));
  next();
};
