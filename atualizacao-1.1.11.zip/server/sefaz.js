// Integração fiscal: (1) busca de XML na SEFAZ com certificado digital A1 (NFeDistribuicaoDFe + ciência da operação)
// e (2) serviço pago de busca por chave (configurável). Tudo que fala com a SEFAZ usa o PowerShell/.NET do Windows
// (certificado, TLS e assinatura), então não depende de bibliotecas extras.
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const https = require('https');
const crypto = require('crypto');
const { spawn } = require('child_process');
const cfgmod = require('./config');

const DIR = cfgmod.DIR;
const ARQ_CERT = path.join(DIR, 'certificado.pfx');
const ARQ_SEGREDO = path.join(DIR, 'segredo.key');

const URL_DIST = { 1: 'https://www1.nfe.fazenda.gov.br/NFeDistribuicaoDFe/NFeDistribuicaoDFe.asmx', 2: 'https://hom1.nfe.fazenda.gov.br/NFeDistribuicaoDFe/NFeDistribuicaoDFe.asmx' };
const URL_EVENTO = { 1: 'https://www.nfe.fazenda.gov.br/NFeRecepcaoEvento4/NFeRecepcaoEvento4.asmx', 2: 'https://hom.nfe.fazenda.gov.br/NFeRecepcaoEvento4/NFeRecepcaoEvento4.asmx' };

// ---------- segredo para guardar senhas/chaves (AES-256-GCM; a chave fica em arquivo separado do banco) ----------
function chaveSegredo() {
  fs.mkdirSync(DIR, { recursive: true });
  if (!fs.existsSync(ARQ_SEGREDO)) fs.writeFileSync(ARQ_SEGREDO, crypto.randomBytes(32).toString('hex'), { mode: 0o600 });
  return Buffer.from(fs.readFileSync(ARQ_SEGREDO, 'utf8').trim(), 'hex');
}
function cifrar(txt) {
  if (!txt) return '';
  const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', chaveSegredo(), iv);
  const d = Buffer.concat([c.update(String(txt), 'utf8'), c.final()]);
  return [iv, c.getAuthTag(), d].map(b => b.toString('base64')).join('.');
}
function decifrar(txt) {
  if (!txt) return '';
  const [iv, tag, d] = String(txt).split('.').map(x => Buffer.from(x, 'base64'));
  const c = crypto.createDecipheriv('aes-256-gcm', chaveSegredo(), iv); c.setAuthTag(tag);
  return Buffer.concat([c.update(d), c.final()]).toString('utf8');
}

// ---------- configuração (tabela config) ----------
async function cfgGet(db) { const o = {}; (await db.q("select chave, valor from config where chave like 'fiscal\\_%'")).rows.forEach(x => { o[x.chave] = x.valor; }); return o; }
async function cfgSet(db, obj) { for (const [k, v] of Object.entries(obj)) await db.q('insert into config(chave,valor) values($1,$2) on conflict(chave) do update set valor=excluded.valor', [k, String(v ?? '')]); }

// ---------- PowerShell (certificado, TLS e assinatura) ----------
const PS_COMUM = `$ErrorActionPreference='Stop'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($env:LOPDV_PFX, $env:LOPDV_PASS)
$in = [Console]::In.ReadToEnd()
`;
const PS = {
  info: PS_COMUM + `$o = @{ subject=$cert.Subject; validade=$cert.NotAfter.ToString('yyyy-MM-dd'); inicio=$cert.NotBefore.ToString('yyyy-MM-dd'); polegar=$cert.Thumbprint; chave_privada=$cert.HasPrivateKey }
Write-Output ('INFO:' + (ConvertTo-Json $o -Compress))`,
  assinar: PS_COMUM + `$rsa = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($cert)
$sig = $rsa.SignData([Text.Encoding]::UTF8.GetBytes($in), [Security.Cryptography.HashAlgorithmName]::SHA1, [Security.Cryptography.RSASignaturePadding]::Pkcs1)
Write-Output ('SIG:' + [Convert]::ToBase64String($sig))
Write-Output ('CERT:' + [Convert]::ToBase64String($cert.RawData))`,
  enviar: PS_COMUM + `[Net.ServicePointManager]::ServerCertificateValidationCallback = { param($s,$c,$ch,$e) if ($s -is [Net.HttpWebRequest]) { return ($s.RequestUri.Host -like '*.fazenda.gov.br') } return $e -eq 'None' }
$req = [Net.HttpWebRequest]::Create($env:LOPDV_URL)
$req.Method = 'POST'; $req.ContentType = 'application/soap+xml; charset=utf-8'; $req.Timeout = 90000
[void]$req.ClientCertificates.Add($cert)
$bytes = [Text.Encoding]::UTF8.GetBytes($in); $req.ContentLength = $bytes.Length
$st = $req.GetRequestStream(); $st.Write($bytes, 0, $bytes.Length); $st.Close()
try { $resp = $req.GetResponse() } catch [Net.WebException] { if ($_.Exception.Response) { $resp = $_.Exception.Response } else { throw } }
$rd = New-Object IO.StreamReader($resp.GetResponseStream(), [Text.Encoding]::UTF8); $txt = $rd.ReadToEnd(); $rd.Close()
Write-Output ('STATUS:' + [int]$resp.StatusCode)
Write-Output ('BODY:' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($txt)))`,
};
function rodarPS(script, stdin, env) {
  return new Promise((resolve, reject) => {
    if (process.platform !== 'win32') return reject(new Error('A comunicação com a SEFAZ usa o Windows (PowerShell/.NET). Neste computador isso não está disponível.'));
    const enc = Buffer.from(script, 'utf16le').toString('base64');
    const p = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', enc], { env: { ...process.env, ...env }, windowsHide: true });
    let out = '', err = '';
    p.stdout.on('data', d => { out += d; }); p.stderr.on('data', d => { err += d; });
    p.on('error', reject);
    p.on('close', code => (code === 0 ? resolve(out) : reject(new Error((err || out || 'PowerShell falhou (código ' + code + ')').replace(/\s+/g, ' ').trim().slice(0, 400)))));
    p.stdin.end(stdin || '');
  });
}
async function envCert(db) {
  const c = await cfgGet(db);
  if (!fs.existsSync(ARQ_CERT) || !c.fiscal_cert_senha) throw new Error('Certificado digital não cadastrado. Cadastre-o em Integração fiscal.');
  return { LOPDV_PFX: ARQ_CERT, LOPDV_PASS: decifrar(c.fiscal_cert_senha) };
}
const linhaDe = (out, pref) => { const l = out.split(/\r?\n/).find(x => x.startsWith(pref)); return l ? l.slice(pref.length) : ''; };

async function infoCertificado(pfxPath, senha) {
  const out = await rodarPS(PS.info, '', { LOPDV_PFX: pfxPath, LOPDV_PASS: senha });
  const j = JSON.parse(linhaDe(out, 'INFO:') || '{}');
  if (!j.subject) throw new Error('Não foi possível ler o certificado (senha incorreta ou arquivo inválido).');
  if (!j.chave_privada) throw new Error('O arquivo não contém a chave privada. Use o certificado A1 (.pfx / .p12).');
  const m = /(\d{14})/.exec(j.subject);
  return { ...j, cnpj: m ? m[1] : '' };
}
async function enviarSoap(db, url, corpo) {
  const out = await rodarPS(PS.enviar, corpo, { ...(await envCert(db)), LOPDV_URL: url });
  const st = Number(linhaDe(out, 'STATUS:')), body = Buffer.from(linhaDe(out, 'BODY:'), 'base64').toString('utf8');
  if (!(st >= 200 && st < 300)) throw new Error(`A SEFAZ respondeu HTTP ${st}. ${tag(body, 'Text') || tag(body, 'faultstring') || body.slice(0, 200)}`);
  return body;
}

// ---------- XML ----------
const tag = (xml, nome) => { const m = new RegExp('<' + nome + '(?:\\s[^>]*)?>([\\s\\S]*?)</' + nome + '>').exec(xml || ''); return m ? m[1].trim() : ''; };
const so = n => String(n || '').replace(/\D/g, '');

function montarDistDFe({ cnpj, uf, amb, nsu, chave }) {
  const cons = chave ? `<consChNFe><chNFe>${chave}</chNFe></consChNFe>` : `<distNSU><ultNSU>${String(nsu || 0).padStart(15, '0')}</ultNSU></distNSU>`;
  return `<?xml version="1.0" encoding="utf-8"?><soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope"><soap12:Body><nfeDistDFeInteresse xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeDistribuicaoDFe"><nfeDadosMsg><distDFeInt xmlns="http://www.portalfiscal.inf.br/nfe" versao="1.01"><tpAmb>${amb}</tpAmb><cUFAutor>${uf}</cUFAutor><CNPJ>${cnpj}</CNPJ>${cons}</distDFeInt></nfeDadosMsg></nfeDistDFeInteresse></soap12:Body></soap12:Envelope>`;
}
// Lê a resposta da distribuição: cStat, ultNSU, maxNSU e os documentos (docZip em base64+gzip)
function lerRetDist(soap) {
  const ret = tag(soap, 'retDistDFeInt') || soap;
  const docs = [];
  const re = /<docZip\s+([^>]*)>([\s\S]*?)<\/docZip>/g; let m;
  while ((m = re.exec(ret))) {
    const nsu = /NSU="(\d+)"/.exec(m[1]), sch = /schema="([^"]+)"/.exec(m[1]);
    try { docs.push({ nsu: nsu ? nsu[1] : '', schema: sch ? sch[1] : '', xml: zlib.gunzipSync(Buffer.from(m[2].trim(), 'base64')).toString('utf8') }); } catch { /* documento ilegível: ignora */ }
  }
  return { cStat: Number(tag(ret, 'cStat')) || 0, motivo: tag(ret, 'xMotivo'), ultNSU: tag(ret, 'ultNSU'), maxNSU: tag(ret, 'maxNSU'), docs };
}
// Converte um documento da distribuição (resNFe resumo ou procNFe completo) em registro; eventos são ignorados
function lerDocumento(d) {
  const x = d.xml;
  if (/^resNFe/i.test(d.schema) || /<resNFe[\s>]/.test(x)) {
    return { chave: tag(x, 'chNFe'), nsu: d.nsu, completo: false, emitente_nome: tag(x, 'xNome'), emitente_doc: tag(x, 'CNPJ') || tag(x, 'CPF'), valor: Number(tag(x, 'vNF')) || 0, emissao: (tag(x, 'dhEmi') || '').slice(0, 10) || null, numero: '', xml: null };
  }
  if (/^procNFe/i.test(d.schema) || /<nfeProc[\s>]/.test(x) || /<infNFe[\s>]/.test(x)) {
    const idm = /<infNFe[^>]*Id="NFe(\d{44})"/.exec(x), emit = tag(x, 'emit');
    return { chave: idm ? idm[1] : tag(x, 'chNFe'), nsu: d.nsu, completo: true, emitente_nome: tag(emit, 'xNome'), emitente_doc: tag(emit, 'CNPJ') || tag(emit, 'CPF'),
      valor: Number(tag(tag(x, 'ICMSTot'), 'vNF')) || 0, emissao: (tag(x, 'dhEmi') || tag(x, 'dEmi') || '').slice(0, 10) || null, numero: tag(tag(x, 'ide'), 'nNF'), xml: x };
  }
  return null;
}
async function guardarDoc(db, r, origem, buscaOrigem) {
  if (!r || !/^\d{44}$/.test(r.chave || '')) return false;
  await db.q(`insert into sefaz_docs(chave, nsu, emitente_nome, emitente_doc, valor, emissao, numero, xml, origem, busca_origem)
    values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
    on conflict(chave) do update set nsu=coalesce(excluded.nsu, sefaz_docs.nsu), xml=coalesce(excluded.xml, sefaz_docs.xml),
      emitente_nome=coalesce(nullif(excluded.emitente_nome,''), sefaz_docs.emitente_nome), emitente_doc=coalesce(nullif(excluded.emitente_doc,''), sefaz_docs.emitente_doc),
      valor=case when excluded.valor>0 then excluded.valor else sefaz_docs.valor end, emissao=coalesce(excluded.emissao, sefaz_docs.emissao),
      numero=coalesce(nullif(excluded.numero,''), sefaz_docs.numero), atualizado_em=now()`,
    [r.chave, r.nsu || null, r.emitente_nome || null, r.emitente_doc || null, r.valor || 0, r.emissao, r.numero || null, r.xml, origem, buscaOrigem || null]);
  return true;
}

// ---------- ciência da operação (evento 210210) ----------
function montarEvento({ chave, cnpj, amb }) {
  const d = new Date(), p = n => String(n).padStart(2, '0'), off = -d.getTimezoneOffset(), sinal = off >= 0 ? '+' : '-';
  const dh = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}${sinal}${p(Math.floor(Math.abs(off) / 60))}:${p(Math.abs(off) % 60)}`;
  const id = 'ID210210' + chave + '01';
  const inf = `<infEvento Id="${id}"><cOrgao>91</cOrgao><tpAmb>${amb}</tpAmb><CNPJ>${cnpj}</CNPJ><chNFe>${chave}</chNFe><dhEvento>${dh}</dhEvento><tpEvento>210210</tpEvento><nSeqEvento>1</nSeqEvento><verEvento>1.00</verEvento><detEvento versao="1.00"><descEvento>Ciencia da Operacao</descEvento></detEvento></infEvento>`;
  const digest = crypto.createHash('sha1').update(inf.replace('<infEvento ', '<infEvento xmlns="http://www.portalfiscal.inf.br/nfe" '), 'utf8').digest('base64');
  const si = `<SignedInfo><CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"></CanonicalizationMethod><SignatureMethod Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"></SignatureMethod><Reference URI="#${id}"><Transforms><Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"></Transform><Transform Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"></Transform></Transforms><DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"></DigestMethod><DigestValue>${digest}</DigestValue></Reference></SignedInfo>`;
  const siCanon = si.replace('<SignedInfo>', '<SignedInfo xmlns="http://www.w3.org/2000/09/xmldsig#">');
  return { inf, si, siCanon };
}
function envelopeEvento(ev, sig, cert) {
  const evento = `<envEvento xmlns="http://www.portalfiscal.inf.br/nfe" versao="1.00"><idLote>1</idLote><evento versao="1.00">${ev.inf}<Signature xmlns="http://www.w3.org/2000/09/xmldsig#">${ev.si}<SignatureValue>${sig}</SignatureValue><KeyInfo><X509Data><X509Certificate>${cert}</X509Certificate></X509Data></KeyInfo></Signature></evento></envEvento>`;
  return `<?xml version="1.0" encoding="utf-8"?><soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope"><soap12:Body><nfeDadosMsg xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeRecepcaoEvento4">${evento}</nfeDadosMsg></soap12:Body></soap12:Envelope>`;
}
async function darCiencia(db, chave) {
  const c = await cfgGet(db), amb = Number(c.fiscal_ambiente) === 2 ? 2 : 1;
  if (!c.fiscal_cnpj) throw new Error('Informe o CNPJ em Integração fiscal.');
  const ev = montarEvento({ chave, cnpj: so(c.fiscal_cnpj), amb });
  const out = await rodarPS(PS.assinar, ev.siCanon, await envCert(db));
  const sig = linhaDe(out, 'SIG:'), cert = linhaDe(out, 'CERT:');
  if (!sig || !cert) throw new Error('Não foi possível assinar o evento com o certificado.');
  const resp = await enviarSoap(db, URL_EVENTO[amb], envelopeEvento(ev, sig, cert));
  const cs = Number(tag(tag(resp, 'retEvento') || resp, 'cStat')) || 0, mot = tag(tag(resp, 'retEvento') || resp, 'xMotivo');
  if (![135, 136, 573].includes(cs)) throw new Error(`Ciência não registrada (${cs} ${mot}).`);
  await db.q('update sefaz_docs set manifestado_em=coalesce(manifestado_em, now()) where chave=$1', [chave]);
  return { cStat: cs, motivo: mot };
}

// ---------- busca na SEFAZ (distribuição de DF-e) ----------
let rodando = false;
const MIN_ENTRE_CONSULTAS_MS = 3602 * 1000;   // a SEFAZ bloqueia (656) consultas com menos de 1h entre elas: usamos 1h00min02s
async function buscarSefaz(db, { origem = 'manual', ciencia = false } = {}) {
  if (rodando) throw new Error('Já existe uma busca em andamento.');
  const c = await cfgGet(db);
  if (!c.fiscal_cnpj || !c.fiscal_uf) throw new Error('Informe o CNPJ e o estado (UF) em Integração fiscal.');
  const prox = c.fiscal_proxima_consulta ? new Date(c.fiscal_proxima_consulta) : null;
  if (prox && prox > new Date()) throw new Error('A SEFAZ só permite nova consulta a partir de ' + prox.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) + ' (regra: 1 hora depois de não haver notas novas).');
  const ult = c.fiscal_ultima_consulta ? new Date(c.fiscal_ultima_consulta) : null;
  if (ult && Date.now() - ult < MIN_ENTRE_CONSULTAS_MS) {
    const lib = new Date(+ult + MIN_ENTRE_CONSULTAS_MS);
    throw new Error('Para a SEFAZ não bloquear, a nova consulta só pode ser feita 1h00min02s depois da anterior (a partir de ' + lib.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ').');
  }
  rodando = true;
  await cfgSet(db, { fiscal_ultima_consulta: new Date().toISOString() });   // marca ANTES de consultar (vale também se a chamada falhar)
  const amb = Number(c.fiscal_ambiente) === 2 ? 2 : 1;
  const res = { novos: 0, completos: 0, resumos: 0, ciencias: 0, erro: null, cStat: 0, motivo: '' };
  let nsu = Number(c.fiscal_ultimo_nsu) || 0;
  try {
    for (let volta = 0; volta < 30; volta++) {
      const soap = await enviarSoap(db, URL_DIST[amb], montarDistDFe({ cnpj: so(c.fiscal_cnpj), uf: c.fiscal_uf, amb, nsu }));
      const r = lerRetDist(soap); res.cStat = r.cStat; res.motivo = r.motivo;
      if (r.cStat === 138) {
        for (const d of r.docs) { const reg = lerDocumento(d); if (reg && await guardarDoc(db, reg, 'sefaz', origem)) { res.novos++; reg.completo ? res.completos++ : res.resumos++; } }
        nsu = Number(r.ultNSU) || nsu; await cfgSet(db, { fiscal_ultimo_nsu: nsu });
        if (!(Number(r.ultNSU) < Number(r.maxNSU))) break;
      } else {
        if (r.cStat === 137 || r.cStat === 656) await cfgSet(db, { fiscal_proxima_consulta: new Date(Date.now() + MIN_ENTRE_CONSULTAS_MS).toISOString() });
        if (r.cStat === 656) throw new Error('A SEFAZ bloqueou temporariamente por consultas em excesso (656). Tente de novo em 1 hora.');
        if (r.cStat !== 137) throw new Error(`SEFAZ: ${r.cStat} ${r.motivo}`);
        break;
      }
    }
    if (ciencia) { // dá ciência automática nas notas só com resumo, para a SEFAZ liberar o XML completo na próxima busca
      const pend = (await db.q('select chave from sefaz_docs where xml is null and manifestado_em is null order by criado_em limit 30')).rows;
      for (const p of pend) { try { await darCiencia(db, p.chave); res.ciencias++; } catch (e) { res.erro = e.message; break; } }
    }
  } catch (e) { res.erro = e.message; } finally { rodando = false; }
  await cfgSet(db, { fiscal_ultima_busca: new Date().toISOString() });
  await db.q('insert into sefaz_buscas(origem, novos, completos, resumos, ciencias, cstat, resultado, erro) values($1,$2,$3,$4,$5,$6,$7,$8)', [origem, res.novos, res.completos, res.resumos, res.ciencias, res.cStat, res.motivo || null, res.erro]);
  return res;
}

// ---------- serviço pago de busca por chave (genérico/configurável) ----------
function httpsTexto(url, { metodo = 'GET', headers = {}, corpo = null, timeout = 30000 } = {}) {
  return new Promise((resolve, reject) => {
    let u; try { u = new URL(url); } catch { return reject(new Error('Endereço do serviço inválido.')); }
    if (u.protocol !== 'https:') return reject(new Error('O endereço do serviço precisa começar com https://'));
    const req = https.request(u, { method: metodo, headers, timeout }, res => {
      const bufs = []; res.on('data', d => bufs.push(d));
      res.on('end', () => resolve({ status: res.statusCode, texto: Buffer.concat(bufs).toString('utf8') }));
    });
    req.on('timeout', () => req.destroy(new Error('O serviço demorou demais para responder (sem internet?).')));
    req.on('error', e => reject(new Error('Falha ao acessar o serviço: ' + e.message)));
    if (corpo) req.write(corpo); req.end();
  });
}
function extrairXml(texto, cfg) {
  let t = String(texto || '').trim();
  if (cfg.fiscal_svc_resposta === 'json') {
    let j; try { j = JSON.parse(t); } catch { throw new Error('A resposta do serviço não é um JSON válido.'); }
    const campo = cfg.fiscal_svc_campo || 'xml'; t = String(campo.split('.').reduce((o, k) => (o == null ? o : o[k]), j) || '').trim();
  }
  if (t && !t.startsWith('<')) { try { const b = Buffer.from(t, 'base64'); const s = (b[0] === 0x1f && b[1] === 0x8b ? zlib.gunzipSync(b) : b).toString('utf8'); if (s.trim().startsWith('<')) t = s.trim(); } catch { /* não era base64 */ } }
  if (!t.startsWith('<')) throw new Error('O serviço não devolveu um XML para esta chave.');
  return t;
}
async function buscarServico(db, chave) {
  const c = await cfgGet(db);
  if (!c.fiscal_svc_url) throw new Error('Serviço de busca por chave não configurado. Configure em Integração fiscal.');
  const url = c.fiscal_svc_url.replace('{chave}', chave);
  const headers = { Accept: '*/*' }; if (c.fiscal_svc_header_nome) headers[c.fiscal_svc_header_nome] = (c.fiscal_svc_header_prefixo || '') + decifrar(c.fiscal_svc_header_valor);
  const metodo = (c.fiscal_svc_metodo || 'GET').toUpperCase(); let corpo = null;
  if (metodo === 'POST') { corpo = JSON.stringify({ chave }); headers['Content-Type'] = 'application/json'; headers['Content-Length'] = Buffer.byteLength(corpo); }
  const r = await httpsTexto(url, { metodo, headers, corpo });
  if (r.status === 401 || r.status === 403) throw new Error('O serviço recusou a chave de acesso (HTTP ' + r.status + '). Confira a Api-Key.');
  if (r.status === 404) throw new Error('Nota não encontrada pelo serviço (HTTP 404).');
  if (r.status < 200 || r.status >= 300) throw new Error('O serviço respondeu HTTP ' + r.status + ': ' + r.texto.slice(0, 150));
  const xml = extrairXml(r.texto, c);
  const reg = lerDocumento({ schema: 'procNFe', nsu: '', xml });
  if (!reg || !reg.chave) throw new Error('O XML recebido não parece uma NF-e/NFC-e válida.');
  if (reg.chave !== chave) reg.chave = chave;
  await guardarDoc(db, { ...reg, completo: true }, 'servico');
  return reg;
}

// ---------- agendador ----------
function iniciarAgendador(db) {
  const tick = async () => {
    try {
      const c = await cfgGet(db);
      if (!c.fiscal_agenda || c.fiscal_agenda === 'desligado' || !fs.existsSync(ARQ_CERT)) return;
      const agora = new Date(), ult = c.fiscal_ultima_busca ? new Date(c.fiscal_ultima_busca) : null;
      let devido = false;
      const uc = c.fiscal_ultima_consulta ? new Date(c.fiscal_ultima_consulta) : null;
      if (uc && agora - uc < MIN_ENTRE_CONSULTAS_MS) return;   // ainda dentro de 1h00min02s da última consulta
      if (c.fiscal_agenda === 'intervalo') devido = !ult || (agora - ult) >= Math.max(MIN_ENTRE_CONSULTAS_MS, (Number(c.fiscal_intervalo_min) || 60) * 60000);
      else if (c.fiscal_agenda === 'diario') { const [h, m] = String(c.fiscal_hora || '06:00').split(':').map(Number); const alvo = new Date(agora); alvo.setHours(h || 0, m || 0, 0, 0); devido = agora >= alvo && (!ult || ult < alvo); }
      if (devido) await buscarSefaz(db, { origem: 'agendada', ciencia: c.fiscal_auto_ciencia === '1' });
    } catch (e) { console.error('Agendador SEFAZ:', e.message); }
  };
  setTimeout(tick, 60000); return setInterval(tick, 60000);
}

module.exports = { cifrar, decifrar, cfgGet, cfgSet, ARQ_CERT, infoCertificado, buscarSefaz, darCiencia, buscarServico, iniciarAgendador, montarDistDFe, lerRetDist, lerDocumento, montarEvento, envelopeEvento, extrairXml, guardarDoc, URL_DIST };
