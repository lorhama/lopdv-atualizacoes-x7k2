// Impressão ESC/POS: térmicas de rede (porta 9100) ou impressoras instaladas no Windows (spooler, modo RAW).
const net = require('net');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');
const iconv = require('iconv-lite');

function montar(texto, { titulo, corte = true } = {}) {
  const partes = [Buffer.from([0x1b, 0x40]), Buffer.from([0x1b, 0x74, 0x03])]; // init + code page CP860 (pt)
  if (titulo) {
    partes.push(Buffer.from([0x1b, 0x61, 0x01, 0x1d, 0x21, 0x11, 0x1b, 0x45, 0x01]));
    partes.push(iconv.encode(titulo + '\n', 'cp860'));
    partes.push(Buffer.from([0x1d, 0x21, 0x00, 0x1b, 0x45, 0x00, 0x1b, 0x61, 0x00]));
  }
  partes.push(iconv.encode(texto + '\n\n\n\n', 'cp860'));
  if (corte) partes.push(Buffer.from([0x1d, 0x56, 0x42, 0x00]));
  return Buffer.concat(partes);
}

// ---- Windows: lista as impressoras instaladas e envia bytes RAW para uma delas (PowerShell + winspool.drv)
const PS_RAW = [
  "$ErrorActionPreference = 'Stop'",
  'Add-Type -TypeDefinition @"',
  'using System; using System.Runtime.InteropServices;',
  'public class RawPrn {',
  '  [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)] public class DOCINFO { [MarshalAs(UnmanagedType.LPWStr)] public string pDocName; [MarshalAs(UnmanagedType.LPWStr)] public string pOutputFile; [MarshalAs(UnmanagedType.LPWStr)] public string pDataType; }',
  '  [DllImport("winspool.drv", EntryPoint="OpenPrinterW", SetLastError=true, CharSet=CharSet.Unicode)] public static extern bool OpenPrinter(string n, out IntPtr h, IntPtr d);',
  '  [DllImport("winspool.drv", SetLastError=true)] public static extern bool ClosePrinter(IntPtr h);',
  '  [DllImport("winspool.drv", EntryPoint="StartDocPrinterW", SetLastError=true, CharSet=CharSet.Unicode)] public static extern bool StartDocPrinter(IntPtr h, int level, [In] DOCINFO di);',
  '  [DllImport("winspool.drv", SetLastError=true)] public static extern bool EndDocPrinter(IntPtr h);',
  '  [DllImport("winspool.drv", SetLastError=true)] public static extern bool StartPagePrinter(IntPtr h);',
  '  [DllImport("winspool.drv", SetLastError=true)] public static extern bool EndPagePrinter(IntPtr h);',
  '  [DllImport("winspool.drv", SetLastError=true)] public static extern bool WritePrinter(IntPtr h, byte[] b, int n, out int w);',
  '  public static void Send(string printer, byte[] data) {',
  '    IntPtr h; if (!OpenPrinter(printer, out h, IntPtr.Zero)) throw new Exception("Nao foi possivel abrir a impressora (erro " + Marshal.GetLastWin32Error() + ")");',
  '    try {',
  '      DOCINFO di = new DOCINFO(); di.pDocName = "LoPDV"; di.pDataType = "RAW";',
  '      if (!StartDocPrinter(h, 1, di)) throw new Exception("StartDocPrinter falhou (erro " + Marshal.GetLastWin32Error() + ")");',
  '      try { StartPagePrinter(h); int w; if (!WritePrinter(h, data, data.Length, out w)) throw new Exception("WritePrinter falhou (erro " + Marshal.GetLastWin32Error() + ")"); EndPagePrinter(h); } finally { EndDocPrinter(h); }',
  '    } finally { ClosePrinter(h); }',
  '  }',
  '}',
  '"@',
  '[RawPrn]::Send($env:LOPDV_PRN, [IO.File]::ReadAllBytes($env:LOPDV_FILE))',
].join('\n');
const psb64 = s => Buffer.from(s, 'utf16le').toString('base64');
const rodarPS = (script, env = {}, timeout = 20000) => new Promise((resolve, reject) => {
  if (process.platform !== 'win32') return reject(new Error('Impressoras do Windows só funcionam quando o servidor roda no Windows.'));
  execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', psb64(script)],
    { windowsHide: true, timeout, env: { ...process.env, ...env }, maxBuffer: 4 * 1024 * 1024 },
    (err, out, errout) => (err ? reject(new Error((String(errout || '').trim().split('\n')[0] || err.message).slice(0, 300))) : resolve(String(out))));
});
async function listarWindows() {
  const out = await rodarPS("[Console]::OutputEncoding=[Text.Encoding]::UTF8; $p=@(Get-CimInstance Win32_Printer | Select-Object Name,DriverName,PortName,Default,WorkOffline); ConvertTo-Json -InputObject $p -Compress");
  const j = JSON.parse(out.trim() || '[]'); return (Array.isArray(j) ? j : [j]).filter(x => x && x.Name)
    .map(x => ({ nome: x.Name, driver: x.DriverName || '', porta: x.PortName || '', padrao: !!x.Default, offline: !!x.WorkOffline })).sort((a, b) => a.nome.localeCompare(b.nome));
}
async function enviarWindows(imp, buf) {
  if (!imp.windows_nome) throw new Error(`Impressora ${imp.nome}: escolha a impressora do Windows no cadastro.`);
  const tmp = path.join(os.tmpdir(), 'lopdv-prn-' + process.pid + '-' + Date.now() + '.bin'); fs.writeFileSync(tmp, buf);
  try { await rodarPS(PS_RAW, { LOPDV_PRN: imp.windows_nome, LOPDV_FILE: tmp }); }
  catch (e) { throw new Error(`Impressora ${imp.nome} (Windows: ${imp.windows_nome}): ${e.message}`); }
  finally { fs.rm(tmp, () => { }); }
}

function enviar(imp, buf) {
  if (imp.conexao === 'windows') return enviarWindows(imp, buf);
  return new Promise((resolve, reject) => {
    const s = new net.Socket();
    let fim = false;
    const done = (err) => { if (fim) return; fim = true; s.destroy(); err ? reject(err) : resolve(); };
    s.setTimeout(4000, () => done(new Error('Tempo esgotado ao conectar na impressora ' + imp.ip)));
    s.on('error', e => done(new Error(`Impressora ${imp.nome} (${imp.ip}:${imp.porta || 9100}): ${e.message}`)));
    s.connect(imp.porta || 9100, imp.ip, () => s.end(buf, () => done()));
  });
}

const pad = (s, n) => String(s).padEnd(n).slice(0, n);
function linha(c = 42) { return '-'.repeat(c); }
function quebrar(txt, largura) {
  const out = []; let t = String(txt || '');
  while (t.length > largura) { out.push(t.slice(0, largura)); t = t.slice(largura); }
  out.push(t); return out;
}

// Monta o texto do pedido de produção (cozinha/bar).
function comandaTexto({ destino, pedido, usuario, itens, colunas = 42, reimpressao = false, cancelado = false }) {
  const hora = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  const l = [];
  if (reimpressao) l.push('*** REIMPRESSAO ***');
  if (cancelado) l.push('*** ITEM CANCELADO ***');
  l.push(`Venda: ${String(pedido.venda_numero || pedido.id).padStart(6, '0')}`);
  l.push(`Atendente: ${usuario}   ${hora}`);
  if (pedido.observacao) quebrar('OBS VENDA: ' + pedido.observacao, colunas).forEach(x => l.push(x));
  l.push(linha(colunas));
  for (const i of itens) {
    const q = Number(i.quantidade);
    const qtd = Number.isInteger(q) ? q + 'x' : q.toLocaleString('pt-BR') + 'x';
    quebrar(`${qtd} ${i.nome}`, colunas).forEach(x => l.push(x));
    if (i.observacao) quebrar('   OBS: ' + i.observacao, colunas).forEach(x => l.push(x));
  }
  l.push(linha(colunas));
  return { titulo: destino.toUpperCase(), texto: l.join('\n') };
}

async function imprimirDestino(db, destino, dados) {
  const r = await db.q("select * from impressoras where (destino=$1 or destino='todos') and ativo order by (destino='todos'), id limit 1", [destino]);
  if (!r.rowCount) return { destino, ok: false, erro: `Nenhuma impressora ativa cadastrada para ${destino}.` };
  const imp = r.rows[0];
  const { titulo, texto } = comandaTexto({ ...dados, destino, colunas: imp.colunas });
  try { await enviar(imp, montar(texto, { titulo })); return { destino, ok: true }; }
  catch (e) { return { destino, ok: false, erro: e.message, texto }; }
}

async function imprimirTexto(db, destino, titulo, texto) {
  const r = await db.q("select * from impressoras where (destino=$1 or destino='todos') and ativo order by (destino='todos'), id limit 1", [destino]);
  if (!r.rowCount) return { destino, ok: false, erro: `Nenhuma impressora ativa cadastrada para ${destino}.` };
  try { await enviar(r.rows[0], montar(texto, { titulo })); return { destino, ok: true }; }
  catch (e) { return { destino, ok: false, erro: e.message }; }
}

module.exports = { listarWindows, imprimirDestino, imprimirTexto, montar, enviar, comandaTexto, linha, pad, quebrar };
