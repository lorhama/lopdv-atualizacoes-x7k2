// Limpeza de sobras no computador do cliente, para a pasta do sistema não crescer a cada atualização.
// Remove: pacotes de atualização já baixados, cópias de segurança (rollback) antigas (fica só a mais recente),
// notas de versão antigas e arquivos de desenvolvimento que o sistema não usa. Nunca toca em backups do banco, dados ou node_modules.
const fs = require('fs'), path = require('path');
const tam = p => { try { const s = fs.statSync(p); if (!s.isDirectory()) return s.size; return fs.readdirSync(p).reduce((a, f) => a + tam(path.join(p, f)), 0); } catch { return 0; } };
const apaga = p => { const t = tam(p); try { fs.rmSync(p, { recursive: true, force: true }); return t; } catch { return 0; } };
function limparSobras({ raiz, data, ocupado = false, log = () => { } }) {
  let livre = 0;
  try {
    // arquivos soltos que o sistema não usa
    for (const f of fs.readdirSync(raiz)) {
      if (/^Notas-.*\.(md|pdf)$/i.test(f) || f === 'fabrica.json') livre += apaga(path.join(raiz, f));
    }
    for (const d of ['scripts', 'test', '.github']) if (fs.existsSync(path.join(raiz, d))) livre += apaga(path.join(raiz, d));
    // pacotes de atualização já aplicados
    const pa = path.join(data, 'atualizacao');
    if (!ocupado && fs.existsSync(pa)) {
      for (const f of fs.readdirSync(pa)) if (/^pacote-.*\.zip$/i.test(f) || f === 'atualizacao-teste' || f === 'atualizador-saida.txt') livre += apaga(path.join(pa, f));
    }
    // rollback: só a cópia mais recente (a da versão anterior, usada para voltar atrás)
    const rb = path.join(data, 'rollback');
    if (!ocupado && fs.existsSync(rb)) {
      const ds = fs.readdirSync(rb).map(n => ({ n, t: fs.statSync(path.join(rb, n)).mtimeMs })).sort((a, b) => b.t - a.t);
      for (const x of ds.slice(1)) livre += apaga(path.join(rb, x.n));
    }
    // log da atualização: mantém as últimas 3000 linhas
    const lg = path.join(data, 'atualizacao.log');
    if (fs.existsSync(lg) && fs.statSync(lg).size > 400000) { const l = fs.readFileSync(lg, 'utf8').split(/\r?\n/); fs.writeFileSync(lg, l.slice(-3000).join('\n'), 'utf8'); }
  } catch (e) { log('Limpeza: ' + e.message); }
  if (livre > 0) log('Limpeza de sobras: liberou ' + (livre / 1048576).toFixed(1) + ' MB.');
  return livre;
}
module.exports = { limparSobras };
