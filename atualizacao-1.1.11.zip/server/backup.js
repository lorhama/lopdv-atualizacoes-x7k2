// Backup automático do banco (pg_dump). Funciona com o PostgreSQL embutido e com o PostgreSQL instalado no Windows.
// Um backup ao ABRIR o sistema e outro ao FECHAR (+ manual / antes de atualizar). Guarda só os últimos 3 dias (hoje e os 2 anteriores).
const { execFile } = require('child_process');
const fs = require('fs'), path = require('path');
const exe = n => (process.platform === 'win32' ? n + '.exe' : n);
const DIAS = 3;      // dias de backup mantidos (hoje + 2 anteriores)
const MINIMO = 2;    // nunca apaga se sobrar menos que isso
let emAndamento = null;

function achar() {
  const dirs = [process.env.GESTAO_PG_DIR, process.resourcesPath && path.join(process.resourcesPath, 'pgsql'), path.join(__dirname, '..', 'vendor', 'pgsql')].filter(Boolean);
  for (const d of dirs) if (fs.existsSync(path.join(d, 'bin', exe('pg_dump')))) return path.join(d, 'bin', exe('pg_dump'));
  if (process.platform === 'win32') {
    for (const base of [process.env.ProgramFiles, process.env['ProgramFiles(x86)']].filter(Boolean)) {
      const pg = path.join(base, 'PostgreSQL');
      if (!fs.existsSync(pg)) continue;
      for (const v of fs.readdirSync(pg).sort().reverse()) { const p = path.join(pg, v, 'bin', exe('pg_dump')); if (fs.existsSync(p)) return p; }
    }
  } else for (const p of ['/usr/bin/pg_dump', '/usr/lib/postgresql/16/bin/pg_dump']) if (fs.existsSync(p)) return p;
  return null;
}
// Pasta só dos backups: por padrão fica FORA da pasta do sistema (ex.: C:\LoPDV-Backups), para sobreviver a reinstalações e ser fácil de achar/copiar.
// Pode ser trocada em Configurações (config 'backup_pasta').
let PRINCIPAL = '';
const legado = cfgmod => path.join(cfgmod.DIR, 'backups');
const padrao = cfgmod => (process.platform === 'win32' ? path.join(path.dirname(path.join(__dirname, '..')), 'LoPDV-Backups') : legado(cfgmod));
const definirPasta = p => { PRINCIPAL = String(p || '').trim(); };
const pasta = cfgmod => PRINCIPAL || padrao(cfgmod);
// garante que a pasta existe e é gravável; se não der, volta para a pasta antiga (dentro de data)
function garantir(cfgmod) {
  const d = pasta(cfgmod);
  try { fs.mkdirSync(d, { recursive: true }); const t = path.join(d, '.teste-' + process.pid); fs.writeFileSync(t, 'x'); fs.unlinkSync(t); return d; }
  catch (e) { console.error('Pasta de backups indisponível (' + d + '): ' + e.message + ' — usando ' + legado(cfgmod)); PRINCIPAL = legado(cfgmod); fs.mkdirSync(PRINCIPAL, { recursive: true }); return PRINCIPAL; }
}
// move os .dump de uma pasta para a pasta atual (rename; se for outro disco, copia e apaga)
function mover(origem, destino) {
  let n = 0; if (!origem || !fs.existsSync(origem) || path.resolve(origem) === path.resolve(destino)) return 0;
  fs.mkdirSync(destino, { recursive: true });
  for (const x of fs.readdirSync(origem).filter(a => a.endsWith('.dump'))) {
    const o = path.join(origem, x), d = path.join(destino, x); if (fs.existsSync(d)) continue;
    try { fs.renameSync(o, d); n++; } catch { try { fs.copyFileSync(o, d); fs.unlinkSync(o); n++; } catch { /* */ } }
  }
  return n;
}
// no início: usa a pasta configurada e traz para ela os backups que estavam na pasta antiga
function consolidar(cfgmod) { const d = garantir(cfgmod); const n = mover(legado(cfgmod), d) + mover(padrao(cfgmod), d); if (n) console.log('Backups reunidos em ' + d + ': ' + n + ' arquivo(s) movido(s).'); return d; }
const pad = n => String(n).padStart(2, '0');
const hojeLocal = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
const agoraLocal = () => { const d = new Date(); return `${hojeLocal()}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`; };

function listar(cfgmod) {
  const dir = pasta(cfgmod); if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).filter(x => x.endsWith('.dump')).map(x => { const s = fs.statSync(path.join(dir, x)); return { arquivo: x, tamanho: s.size, criado_em: s.mtime.toISOString() }; })
    .sort((a, b) => b.arquivo.localeCompare(a.arquivo));
}

// Apaga backups com data anterior ao limite (hoje - 2 dias), preservando sempre os MINIMO mais recentes.
function podar(dir) {
  try {
    const lim = new Date(); lim.setDate(lim.getDate() - (DIAS - 1));
    const corte = `${lim.getFullYear()}-${pad(lim.getMonth() + 1)}-${pad(lim.getDate())}`;
    const arqs = fs.readdirSync(dir).filter(x => /^gestao-\d{4}-\d{2}-\d{2}.*\.dump$/.test(x)).sort().reverse();
    arqs.slice(MINIMO).filter(x => x.slice(7, 17) < corte).forEach(x => { try { fs.unlinkSync(path.join(dir, x)); } catch { /* */ } });
  } catch { /* pasta inexistente */ }
}

// Faz um backup. nome: 'diario' (um por dia) ou 'manual'. extra: pasta opcional para uma cópia.
function fazer(cfgmod, { tipo = 'manual', extra = '' } = {}) {
  if (emAndamento) return emAndamento;
  emAndamento = (async () => {
    const dump = achar(); if (!dump) throw new Error('pg_dump não encontrado (PostgreSQL não instalado neste computador).');
    const c = cfgmod.load().db;
    const dir = pasta(cfgmod); fs.mkdirSync(dir, { recursive: true });
    const nome = `gestao-${agoraLocal()}-${tipo}.dump`;
    const f = path.join(dir, nome), tmp = f + '.tmp';
    await new Promise((res, rej) => execFile(dump, ['-h', String(c.host), '-p', String(c.port), '-U', c.user, '-F', 'c', '-f', tmp, c.database],
      { windowsHide: true, env: { ...process.env, PGPASSWORD: c.password }, maxBuffer: 1e7 }, (e, so, se) => (e ? rej(new Error((se || e.message).toString().trim())) : res())));
    fs.renameSync(tmp, f);
    podar(dir);
    let copia = null;
    if (extra) { try { fs.mkdirSync(extra, { recursive: true }); fs.copyFileSync(f, path.join(extra, nome)); copia = path.join(extra, nome); podar(extra); } catch (e) { copia = 'FALHOU: ' + e.message; } }
    return { arquivo: nome, caminho: f, tamanho: fs.statSync(f).size, copia };
  })().finally(() => { emAndamento = null; });
  return emAndamento;
}

// Backup ao abrir o sistema (alguns segundos depois da subida, sem atrasar a abertura).
function aoAbrir(cfgmod, db) {
  setTimeout(async () => {
    try {
      let extra = ''; try { extra = (await db.q("select valor from config where chave='backup_pasta_extra'")).rows[0]?.valor || ''; } catch { /* */ }
      const r = await fazer(cfgmod, { tipo: 'abertura', extra }); console.log('Backup (abertura):', r.arquivo, r.copia ? '(cópia: ' + r.copia + ')' : '');
    } catch (e) { console.error('Backup (abertura) falhou:', e.message); }
  }, 15000).unref();
}
// Backup ao fechar o sistema.
async function aoFechar(cfgmod, db) {
  try {
    let extra = ''; try { extra = (await db.q("select valor from config where chave='backup_pasta_extra'")).rows[0]?.valor || ''; } catch { /* */ }
    const r = await fazer(cfgmod, { tipo: 'fechamento', extra }); console.log('Backup (fechamento):', r.arquivo); return r;
  } catch (e) { console.error('Backup (fechamento) falhou:', e.message); return null; }
}
module.exports = { definirPasta, consolidar, mover, garantir, padrao, legado, fazer, listar, aoAbrir, aoFechar, achar, pasta };
