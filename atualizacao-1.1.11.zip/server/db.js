const { Pool, Client, types } = require('pg');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { PERFIS_PADRAO } = require('./permissoes');

types.setTypeParser(1700, v => parseFloat(v)); // numeric -> number
types.setTypeParser(20, v => parseInt(v, 10));  // bigint -> number

let pool = null;
const q = (text, params) => pool.query(text, params);

async function init(dbcfg) {
  if (pool) { try { await pool.end(); } catch { /* ignore */ } }
  pool = new Pool({ ...dbcfg, max: 10, connectionTimeoutMillis: 5000 });
  await pool.query('select 1'); // falha cedo se não conectar
}

async function tx(fn) {
  const c = await pool.connect();
  try { await c.query('BEGIN'); const r = await fn(c); await c.query('COMMIT'); return r; }
  catch (e) { try { await c.query('ROLLBACK'); } catch { /* ignore */ } throw e; }
  finally { c.release(); }
}

const ident = s => { if (!/^[a-zA-Z_][a-zA-Z0-9_]{0,62}$/.test(s || '')) throw new Error('Nome inválido (use letras, números e _)'); return '"' + s + '"'; };

// Cria usuário e banco do sistema usando o superusuário do PostgreSQL (usado só no assistente de configuração).
async function ensure({ host, port, adminUser, adminPass, dbName, appUser, appPass }) {
  const c = new Client({ host, port, user: adminUser, password: adminPass, database: 'postgres', connectionTimeoutMillis: 5000 });
  await c.connect();
  try {
    const pw = c.escapeLiteral(appPass);
    const r = await c.query('select 1 from pg_roles where rolname=$1', [appUser]);
    if (!r.rowCount) await c.query(`CREATE ROLE ${ident(appUser)} LOGIN PASSWORD ${pw}`);
    else await c.query(`ALTER ROLE ${ident(appUser)} LOGIN PASSWORD ${pw}`);
    const d = await c.query('select 1 from pg_database where datname=$1', [dbName]);
    if (!d.rowCount) await c.query(`CREATE DATABASE ${ident(dbName)} OWNER ${ident(appUser)}`);
  } finally { await c.end(); }
}

async function migrate() {
  const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  await pool.query(sql);
  const n = await q('select count(*)::int n from perfis');
  if (n.rows[0].n === 0) {
    for (const [nome, perms] of Object.entries(PERFIS_PADRAO))
      await q('insert into perfis(nome, permissoes) values($1,$2)', [nome, perms]);
    const adm = await q("select id from perfis where nome='Administrador'");
    await q('insert into usuarios(nome, login, senha_hash, perfil_id) values($1,$2,$3,$4)',
      ['Administrador', 'admin', bcrypt.hashSync('admin123', 10), adm.rows[0].id]);
    for (const c of ['Bebidas', 'Porções', 'Pratos', 'Sobremesas', 'Insumos']) await q('insert into categorias(nome) values($1) on conflict do nothing', [c]);
  }
  await q("delete from sessoes where expira_em < now()");
  // gestão de versão: registra no banco cada versão do sistema que passou a rodar
  const versao = require('../package.json').version;
  const ult = (await q('select versao from versoes order by id desc limit 1')).rows[0];
  if (!ult || ult.versao !== versao) await q('insert into versoes(versao) values($1)', [versao]);
}

module.exports = { init, q, tx, ensure, migrate, get pool() { return pool; } };
