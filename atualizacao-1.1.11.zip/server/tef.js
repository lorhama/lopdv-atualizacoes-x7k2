// Integração TEF por troca de arquivos em pastas (padrão "Gerenciador Padrão / TEF Dedicado": IntPos.001 / IntPos.sts).
// O sistema grava a requisição na pasta de ENVIO, aguarda o status e lê a resposta na pasta de RETORNO.
// ATENÇÃO: o layout dos campos segue o padrão mais usado; confirme com o manual do seu provedor de TEF.
// As pastas são lidas pelo SERVIDOR: se o TEF está em outro computador, aponte para a pasta compartilhada (\\PC\TEF\...).
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const { HttpError } = require('./util');

const pausa = ms => new Promise(r => setTimeout(r, ms));
const arq = (dir, nome, ext) => path.join(dir, `${nome || 'IntPos'}.${String(ext || '').replace(/^\./, '')}`);
const trans = new Map();           // ref -> transação aprovada aguardando fechamento da venda
const filas = new Map();           // pasta -> promessa (uma operação por vez em cada pasta)

function serializar(campos) { return Object.entries(campos).map(([k, v]) => `${k} = ${v}`).join('\r\n') + '\r\n999-999 = 0\r\n'; }
function interpretar(txt) {
  const o = {};
  for (const l of String(txt).split(/\r?\n/)) { const m = /^\s*(\d{3}-\d{3})\s*=\s*(.*?)\s*$/.exec(l); if (m) o[m[1]] = m[2].replace(/^"(.*)"$/, '$1'); }
  return o;
}
function gravarAtomico(destino, tmp, conteudo) { fs.writeFileSync(tmp, conteudo, 'latin1'); fs.renameSync(tmp, destino); }
const apagar = f => { try { fs.unlinkSync(f); } catch { /* ignora */ } };
async function esperar(f, ms) { const fim = Date.now() + ms; while (Date.now() < fim) { if (fs.existsSync(f)) { await pausa(300); return true; } await pausa(250); } return false; }
const exclusivo = (chave, fn) => { const ant = filas.get(chave) || Promise.resolve(); const p = ant.catch(() => {}).then(fn); filas.set(chave, p.catch(() => {})); return p; };

function validarConfig(f) {
  if (!f.tef_dir_envio || !f.tef_dir_retorno) throw new HttpError(400, `A forma "${f.descricao}" está com TEF ativo mas sem as pastas de envio/retorno configuradas.`);
}

// Executa uma venda no TEF. Retorna { ref, aprovado, mensagem, nsu, autorizacao, rede, comprovante[] }
async function vender(forma, { valor, identificacao, parcelas = 1, usuario }) {
  validarConfig(forma);
  return exclusivo(forma.tef_dir_envio, async () => {
    const req = arq(forma.tef_dir_envio, forma.tef_arq_envio, forma.tef_ext_envio);
    const tmp = arq(forma.tef_dir_temp || forma.tef_dir_envio, forma.tef_arq_temp, forma.tef_ext_temp);
    const resp = arq(forma.tef_dir_retorno, forma.tef_arq_retorno, forma.tef_ext_retorno);
    const sts = arq(forma.tef_dir_status || forma.tef_dir_retorno, forma.tef_arq_status, forma.tef_ext_status);
    for (const d of [forma.tef_dir_envio, forma.tef_dir_retorno]) if (!fs.existsSync(d)) throw new HttpError(400, `Pasta do TEF não encontrada no servidor: ${d}`);
    apagar(resp); apagar(sts);
    const id = String(identificacao).slice(-10);
    const campos = { '000-000': 'CRT', '001-000': id, '002-000': id, '003-000': Math.round(valor * 100), '004-000': 0 };
    if (parcelas > 1) { campos['018-000'] = parcelas; campos['019-000'] = 1; } // parcelado pelo estabelecimento
    if (forma.tef_rede) campos['716-000'] = forma.tef_rede;
    gravarAtomico(req, tmp, serializar(campos));
    if (!(await esperar(sts, 15000))) { apagar(req); throw new HttpError(504, 'O aplicativo TEF não respondeu. Verifique se ele está aberto e se as pastas estão corretas.'); }
    if (!(await esperar(resp, (forma.tef_timeout || 120) * 1000))) throw new HttpError(504, 'Tempo esgotado aguardando a resposta do TEF. Confira no PIN-pad se a operação foi concluída antes de tentar de novo.');
    const r = interpretar(fs.readFileSync(resp, 'latin1')); apagar(resp); apagar(sts);
    const aprovado = (r['009-000'] ?? '') === '0';
    const linhas = [];
    const n = Number(r['028-000'] || 0);
    for (let i = 1; i <= n; i++) { const l = r['029-' + String(i).padStart(3, '0')]; if (l != null) linhas.push(l); }
    const out = { aprovado, mensagem: r['030-000'] || (aprovado ? 'Aprovado' : 'Transação não aprovada'), nsu: r['012-000'] || '', autorizacao: r['013-000'] || '',
      rede: r['010-000'] || forma.tef_rede || '', finalizacao: r['027-000'] || '', comprovante: linhas, id };
    if (aprovado) { out.ref = crypto.randomBytes(12).toString('hex'); trans.set(out.ref, { ...out, forma: forma.codigo, valor, usuario, criado: Date.now(), cfg: forma }); }
    return out;
  });
}

// Envia confirmação (CNF) ou desfazimento (NCN) ao TEF.
async function finalizar(ref, confirmar) {
  const t = trans.get(ref); if (!t) return false;
  trans.delete(ref);
  const f = t.cfg;
  try {
    const dest = arq(f.tef_dir_envio, f.tef_arq_envio, f.tef_ext_envio), tmp = arq(f.tef_dir_temp || f.tef_dir_envio, f.tef_arq_temp, f.tef_ext_temp);
    await exclusivo(f.tef_dir_envio, async () => {
      for (let i = 0; i < 20 && fs.existsSync(dest); i++) await pausa(250);
      gravarAtomico(dest, tmp, serializar({ '000-000': confirmar ? 'CNF' : 'NCN', '001-000': t.id, '010-000': t.rede, '012-000': t.nsu, '027-000': t.finalizacao }));
    });
    return true;
  } catch (e) { console.error('TEF finalizar:', e.message); return false; }
}

// Valida e consome a referência de uma transação aprovada para a forma/valor informados.
function reservar(ref, forma, valor, usuarioId) {
  const t = trans.get(ref);
  if (!t || t.forma !== forma || Math.abs(t.valor - valor) > 0.005 || t.usuario !== usuarioId) throw new HttpError(400, 'Transação TEF não encontrada ou diferente do valor informado. Refaça o pagamento no cartão.');
  return t;
}
setInterval(() => { for (const [k, t] of trans) if (Date.now() - t.criado > 30 * 60e3) finalizar(k, false); }, 60e3).unref();

// Testa as pastas configuradas (existência e permissão de escrita).
function testar(f) {
  const res = [];
  const chk = (rotulo, dir, escrita) => {
    if (!dir) return res.push({ rotulo, ok: false, msg: 'Não informada' });
    if (!fs.existsSync(dir)) return res.push({ rotulo, ok: false, msg: 'Pasta não encontrada no servidor: ' + dir });
    if (escrita) { try { const t = path.join(dir, '.lopdv_teste_' + Date.now()); fs.writeFileSync(t, 'x'); fs.unlinkSync(t); } catch (e) { return res.push({ rotulo, ok: false, msg: 'Sem permissão de gravação: ' + e.message }); } }
    res.push({ rotulo, ok: true, msg: 'OK' });
  };
  chk('Envio', f.tef_dir_envio, true); chk('Retorno', f.tef_dir_retorno, false); chk('Status', f.tef_dir_status, false);
  if (f.tef_dir_temp) chk('Temporário', f.tef_dir_temp, true);
  if (f.tef_dir_exec) { const ex = f.tef_dir_exec; res.push(fs.existsSync(ex) ? { rotulo: 'Executável', ok: true, msg: 'OK' } : { rotulo: 'Executável', ok: false, msg: 'Não encontrado: ' + ex }); }
  return res;
}

module.exports = { vender, finalizar, reservar, testar, interpretar };
