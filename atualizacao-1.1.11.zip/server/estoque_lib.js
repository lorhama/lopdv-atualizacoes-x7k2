// Movimentação de estoque (sempre dentro de uma transação). quantidade é com sinal: entrada +, saída -.
async function mover(c, { produto_id, tipo, quantidade, custo_unit = null, origem = null, ref_id = null, motivo = null, usuario_id = null }) {
  const r = await c.query('update produtos set estoque_atual = estoque_atual + $1 where id=$2 returning estoque_atual', [quantidade, produto_id]);
  const saldo = r.rows[0].estoque_atual;
  await c.query(`insert into mov_estoque(produto_id,tipo,quantidade,custo_unit,saldo_apos,origem,ref_id,motivo,usuario_id)
    values($1,$2,$3,$4,$5,$6,$7,$8,$9)`, [produto_id, tipo, quantidade, custo_unit, saldo, origem, ref_id, motivo, usuario_id]);
  return saldo;
}

// Entrada com recálculo do custo médio ponderado.
async function entrada(c, { produto_id, quantidade, custo_unit, origem, ref_id, usuario_id, motivo }) {
  const p = (await c.query('select estoque_atual, custo_medio from produtos where id=$1 for update', [produto_id])).rows[0];
  const est = Number(p.estoque_atual);
  const novoCusto = est > 0 ? (est * Number(p.custo_medio) + quantidade * custo_unit) / (est + quantidade) : custo_unit;
  await c.query('update produtos set custo_medio=$1 where id=$2', [novoCusto, produto_id]);
  return mover(c, { produto_id, tipo: 'entrada', quantidade, custo_unit, origem, ref_id, usuario_id, motivo });
}

module.exports = { mover, entrada };
