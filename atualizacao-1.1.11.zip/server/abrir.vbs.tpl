Set sh = CreateObject("Wscript.Shell")
Set wmi = GetObject("winmgmts:\\.\root\cimv2")
Const PERFIL = "@@PERFIL@@"
Const TITULO = "LoPDV"

Function Rodando()
  Rodando = (sh.Run("cmd /c netstat -ano | findstr "":@@PORTA@@ "" | findstr LISTENING >nul", 0, True) = 0)
End Function

' quantas copias deste iniciador estao em execucao (duplo clique rapido)
Function Iniciadores()
  Dim n, p
  n = 0
  For Each p In wmi.ExecQuery("Select CommandLine from Win32_Process Where Name='wscript.exe'")
    If InStr(1, p.CommandLine & "", "Abrir-LoPDV.vbs", 1) > 0 Then n = n + 1
  Next
  Iniciadores = n
End Function

' já existe uma janela do LoPDV aberta neste computador?
Function JaAberto()
  Dim p
  JaAberto = False
  For Each p In wmi.ExecQuery("Select CommandLine from Win32_Process Where Name='msedge.exe' Or Name='chrome.exe'")
    If InStr(1, p.CommandLine & "", PERFIL, 1) > 0 Then JaAberto = True : Exit For
  Next
End Function

If Iniciadores() > 1 Then
  MsgBox "O LoPDV já está sendo aberto neste computador." & vbCrLf & vbCrLf & "Aguarde alguns instantes.", 64 + 4096, TITULO
  WScript.Quit
End If

@@VERIFICA@@

If Not Rodando() Then sh.Run """@@DIR@@\servidor.cmd""", 0, False
For i = 1 To 45
  If Rodando() Then Exit For
  WScript.Sleep 2000
Next
@@ABRIR@@
