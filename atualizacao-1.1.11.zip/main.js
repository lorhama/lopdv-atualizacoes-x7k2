// Janela desktop (Electron): sobe o servidor local e abre a interface. Terminais da rede usam o navegador.
const { app, BrowserWindow, Menu, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');

if (!app.requestSingleInstanceLock()) { app.quit(); }
process.env.GESTAO_DATA_DIR = app.getPath('userData'); // config.json fica aqui (antes de carregar o servidor)
const servidor = require('./server/index.js');
const { gerarBat } = require('./server/atalho');

let win = null, info = null;

function menu() {
  const enderecos = () => (info?.enderecos?.length ? info.enderecos : [`http://localhost:${info?.port}`]);
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: 'Sistema', submenu: [
      { label: 'Endereço para os terminais da rede', click: () => dialog.showMessageBox(win, { type: 'info', title: 'Terminais', message: 'Nos outros computadores, abra o navegador em:', detail: enderecos().join('\n') + '\n\nNos terminais, abra no navegador o endereço seguido de /instalar (ex.: ' + enderecos()[0] + '/instalar) e baixe o instalador do atalho com o ícone LoPDV.' }) },
      { label: 'Salvar instalador de atalho para terminais…', click: async () => {
        const host = enderecos()[0].replace('http://', '');
        const r = await dialog.showSaveDialog(win, { title: 'Salvar instalador de atalho', defaultPath: 'Instalar-LoPDV.bat', filters: [{ name: 'Arquivo em lote', extensions: ['bat'] }] });
        if (!r.canceled && r.filePath) fs.writeFileSync(r.filePath, gerarBat(host));
      } },
      { type: 'separator' },
      { label: 'Abrir pasta de dados e backups', click: () => shell.openPath(app.getPath('userData')) },
      { label: 'Iniciar com o Windows', type: 'checkbox', checked: app.getLoginItemSettings().openAtLogin, click: m => app.setLoginItemSettings({ openAtLogin: m.checked }) },
      { type: 'separator' }, { role: 'quit', label: 'Sair' }] },
    { label: 'Exibir', submenu: [{ role: 'reload', label: 'Recarregar' }, { role: 'togglefullscreen', label: 'Tela cheia' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { role: 'resetZoom' }] },
  ]));
}

app.whenReady().then(async () => {
  win = new BrowserWindow({ width: 1366, height: 820, title: 'LoPDV', icon: path.join(__dirname, 'build', 'icon.png'), webPreferences: { contextIsolation: true } });
  win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent('<body style="font-family:sans-serif;background:#222733;color:#fff;display:flex;align-items:center;justify-content:center;height:100vh;margin:0"><div style="text-align:center"><h2>LoPDV</h2><p>Preparando o banco de dados... (na primeira vez pode levar até 1 minuto)</p></div></body>'));
  try { info = await servidor.start(); }
  catch (e) { dialog.showErrorBox('Não foi possível iniciar o servidor', String(e.message || e) + '\n\nVerifique se a porta já está em uso.'); return app.quit(); }
  menu();
  win.loadURL(`http://localhost:${info.port}`);
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
});
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('window-all-closed', async () => { await servidor.stop(); app.quit(); });
