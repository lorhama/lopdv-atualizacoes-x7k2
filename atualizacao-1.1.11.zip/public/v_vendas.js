// Vendas diretas (PDV), painel de produção (cozinha/bar) e caixa.
const chipItem = i => {
  if (i.status === 'novo') return chip('Novo', 'novo');
  if (i.status === 'enviado') return chip('Na ' + i.destino, 'enviado');
  if (i.status === 'retirado') return chip(i.destino === 'nenhum' ? 'Entregue' : 'Retirado ' + hr(i.retirado_em), 'retirado');
  return chip('Cancelado', 'cancelado');
};


// ---- Produtos liberados para venda no caixa/evento: o operador marca quais produtos aparecem como botões na tela de vendas
const miniProd = p => p.imagem ? `<img src="${p.imagem}" alt="">` : `<div class="noimg">${esc((p.nome || '?').trim().charAt(0).toUpperCase())}</div>`;
function escolherProdutos(inicial, { titulo = 'Produtos que serão vendidos neste caixa', ultimos = true } = {}) {
  return new Promise(async resolve => {
    const todos = await api('/produtos?ativos=1&vendaveis=1');
    const sel = new Set((inicial || []).map(Number));
    let cat = '', busca = '';
    const corpo = document.createElement('div');
    corpo.innerHTML = `<p class="muted">Clique nos produtos que serão vendidos. Só eles aparecerão como botões na tela de vendas.</p>
      <div class="bar" style="gap:8px"><input class="cbusca" placeholder="Filtrar por nome ou código..." autocomplete="off" style="flex:1">
        <button class="btn sm" type="button" data-all>Marcar os da lista</button><button class="btn sm" type="button" data-none>Limpar tudo</button>${ultimos ? '<button class="btn sm" type="button" data-ult>Usar os do último caixa</button>' : ''}</div>
      <div class="cats"></div><div class="prods psel"></div><p class="muted" id="psn"></p>`;
    const lista = () => todos.filter(p => (!cat || p.categoria === cat) && (!busca || casaProd(p, busca)));
    const desenha = () => {
      const cats = [...new Set(todos.map(p => p.categoria).filter(Boolean))].sort();
      $('.cats', corpo).innerHTML = `<button class="${cat === '' ? 'on' : ''}" data-cat="">Todos</button>` + cats.map(c => `<button class="${cat === c ? 'on' : ''}" data-cat="${esc(c)}">${esc(c)}</button>`).join('');
      $('.prods', corpo).innerHTML = lista().map(p => `<button type="button" class="vtile ${sel.has(p.id) ? 'sel' : ''}" data-ps="${p.id}"><span class="vimg">${miniProd(p)}</span><b>${esc(p.nome)}</b><span class="pr">${R(p.preco_venda)}</span>${sel.has(p.id) ? '<i class="ck">✓</i>' : ''}</button>`).join('') || '<p class="muted">Nenhum produto vendável cadastrado.</p>';
      $('#psn', corpo).textContent = sel.size ? `${sel.size} produto(s) selecionado(s).` : 'Nenhum selecionado: a tela de vendas mostrará todos os produtos.';
    };
    const m = modal({ titulo, tam: 'lg', corpo, botoes: [{ txt: 'Cancelar', fn: () => resolve(null) }, { txt: 'Confirmar', cls: 'primary', fn: () => resolve([...sel]) }] });
    desenha();
    $('.cbusca', corpo).oninput = e => { busca = e.target.value.trim(); desenha(); };
    corpo.onclick = seguro(async e => {
      const c = e.target.closest('[data-cat]'); if (c) { cat = c.dataset.cat; return desenha(); }
      const b = e.target.closest('[data-ps]'); if (b) { const id = +b.dataset.ps; sel.has(id) ? sel.delete(id) : sel.add(id); return desenha(); }
      if (e.target.closest('[data-all]')) { lista().forEach(p => sel.add(p.id)); return desenha(); }
      if (e.target.closest('[data-none]')) { sel.clear(); return desenha(); }
      if (e.target.closest('[data-ult]')) { const r = await api('/caixa/cardapio/ultimo'); sel.clear(); r.ids.forEach(i => sel.add(i)); if (!r.ids.length) toast('Nenhum caixa anterior com produtos escolhidos.', 'aviso'); return desenha(); }
    });
  });
}
const casaProd = (p, txt) => { const n = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase(), b = n(txt).trim();
  return b.split(/\s+/).every(w => n(p.nome).includes(w)) || n(p.codigo).includes(b); };

registrar({ id: 'vendas', titulo: 'Vendas', grupo: 'Operação', perm: 'vendas.acessar', render: async el => {
  limparTimer();
  if (await semEmpresa(el, 'vender')) return; // sem empresa cadastrada a tela de vendas não abre
  const cxs = await api('/caixa/abertos');
  if (!cxs.length) {
    if (tem('caixa.acessar')) { try { sessionStorage.setItem('abrirCaixaAuto', '1'); } catch { } location.hash = '#/caixa'; return; }   // pede a abertura do caixa
    el.innerHTML = `<div class="card"><h3>Nenhum caixa aberto</h3><p>Para vender é necessário ter um caixa seu aberto.</p>${tem('caixa.acessar') ? '<a class="btn primary" href="#/caixa">Ir para o Caixa e abrir</a>' : '<p class="muted">Peça a um responsável para abrir o seu caixa.</p>'}</div>`;
    el.onclick = null; return;
  }
  // vendas pendentes (itens lançados e não finalizadas): pergunta se resgata ou exclui
  const pend = (await api('/pedidos?status=aberto')).filter(p => p.itens > 0 && p.usuario_id === S.user.id);
  if (pend.length) return pendentes(el, pend);
  return iniciarVenda(el);   // caixa já aberto: entra direto na venda
} });

// Venda pendente: o operador resgata (continua a venda) ou exclui (pede usuário e senha)
function pendentes(el, lista) {
  const pad = n => String(n || 0).padStart(6, '0');
  el.innerHTML = `<div class="card"><h3>⚠ Você tem ${lista.length > 1 ? lista.length + ' vendas pendentes' : 'uma venda pendente'}</h3>
    <p class="muted">Estas vendas foram iniciadas e não foram finalizadas. Deseja resgatá-las para continuar ou excluí-las?</p>
    ${lista.map(p => `<div class="row" style="align-items:center;border-top:1px solid var(--br);padding:10px 0"><div><b>Venda ${pad(p.venda_numero || p.id)}</b><br><span class="muted">${p.itens} item(ns) · ${R(p.subtotal)} · iniciada ${dt(p.aberto_em)}</span></div>
      <div class="grow"></div><button class="btn primary" data-rg="${p.id}">Resgatar</button><button class="btn danger" data-ex="${p.id}">Excluir</button></div>`).join('')}</div>`;
  el.onclick = seguro(async e => {
    const rg = e.target.dataset.rg, ex = e.target.dataset.ex;
    if (rg) return pdv(el, +rg);
    if (ex) {
      const p = lista.find(x => x.id === +ex);
      formModal({ titulo: 'Excluir venda pendente ' + pad(p.venda_numero || p.id), tam: 'md',
        campos: [{ k: 'aut_login', l: 'Usuário', req: true }, { k: 'aut_senha', l: 'Senha', t: 'password', req: true }],
        onSave: async o => {
          await api(`/pedidos/${p.id}/cancelar`, { method: 'POST', body: { pendente: true, motivo: 'Venda pendente excluída pelo operador', autorizacao: { login: o.aut_login, senha: o.aut_senha } } });
          toast('Venda pendente excluída.');
          const resta = lista.filter(x => x.id !== p.id);
          if (resta.length) pendentes(el, resta); else iniciarVenda(el);
        } });
    }
  });
}

// Venda direta: abre direto uma venda nova (sem mesa, comanda ou identificação)
async function iniciarVenda(el) { const p = await api('/pedidos', { method: 'POST', body: {} }); return pdv(el, p.id); }

// Doação do troco: antes de entregar o troco, pergunta se o cliente quer deixar as moedinhas (ou o troco) para um dos locais cadastrados nas configurações.
// Devolve o troco que ainda precisa ser entregue ao cliente.
let ultimaDoacao = null;
// Janela com tudo que foi feito ao finalizar a venda (pagamento, produção, estoque, fiado, TEF, doação)
function resumoFinalizacao(rs, trocoEntregar, doacao) {
  const pad = n => String(n || 0).padStart(6, '0');
  const ok = t => `<li>✅ ${t}</li>`, av = t => `<li style="color:#b45309">⚠️ ${t}</li>`;
  const L = [];
  L.push(ok(`Venda <b>${pad(rs.venda_numero)}</b> finalizada${rs.caixa != null ? ' no caixa <b>' + esc(rs.caixa) + '</b>' : ''} · operador ${esc(rs.operador || '')}`));
  if (rs.cliente) L.push(ok('Cliente: <b>' + esc(rs.cliente) + '</b>'));
  const nIt = rs.itens.reduce((x, i) => x + i.qtd, 0);
  L.push(ok(`${nIt} ${nIt === 1 ? 'item' : 'itens'} vendido(s): ` + rs.itens.map(i => `${N(i.qtd)}× ${esc(i.nome)}`).join(', ')));
  L.push(ok(`Subtotal ${R(rs.subtotal)}` + (rs.desconto ? ` · desconto −${R(rs.desconto)}` : '') + (rs.arredondamento ? ` · arredondamento ${rs.arredondamento > 0 ? '+' : '−'}${R(Math.abs(rs.arredondamento))}` : '') + ` · <b>total ${R(rs.total)}</b>`));
  rs.pagamentos.forEach(g => L.push(ok(`Pagamento registrado: <b>${esc(g.forma)} ${R(g.valor)}</b>${g.parcelas > 1 ? ' em ' + g.parcelas + 'x' : ''}${g.nsu ? ' · NSU ' + esc(g.nsu) : ''}${g.autorizacao ? ' · aut. ' + esc(g.autorizacao) : ''}`)));
  if (rs.tef_impresso === true) L.push(ok('Comprovante do cartão (TEF) impresso'));
  else if (rs.tef_impresso === false) L.push(av('Comprovante do cartão (TEF) <b>não imprimiu</b> — ele será mostrado na tela'));
  if (rs.fiado) L.push(ok(`Fiado de <b>${R(rs.fiado.valor)}</b> lançado em contas a receber${rs.cliente ? ' de ' + esc(rs.cliente) : ''}, vencimento ${esc(String(rs.fiado.vencimento).slice(0, 10).split('-').reverse().join('/'))}`));
  if (rs.fiado_impresso) L.push(rs.fiado_impresso.ok ? ok(`Via dos débitos do cliente impressa (valor de cada venda + total em aberto${rs.fiado_impresso.total != null ? ' <b>' + R(rs.fiado_impresso.total) + '</b>' : ''})`) : av(`Via dos débitos do cliente <b>não imprimiu</b>: ${esc(rs.fiado_impresso.erro || '')}.`));
  (rs.producao || []).forEach(x => L.push(x.impresso ? ok(`Pedido enviado para a <b>${x.destino}</b> (${x.itens} ${x.itens === 1 ? 'item' : 'itens'}) e impresso`) : av(`Pedido enviado para a <b>${x.destino}</b> (${x.itens} ${x.itens === 1 ? 'item' : 'itens'}), mas <b>não imprimiu</b>${x.erro ? ': ' + esc(x.erro) : ''} — os itens estão na tela da ${x.destino}`)));
  if (rs.entregues_na_hora) L.push(ok(`${rs.entregues_na_hora} ${rs.entregues_na_hora === 1 ? 'item entregue' : 'itens entregues'} na hora (sem cozinha/bar)`));
  L.push(rs.estoque_baixado ? ok('Estoque baixado (produtos e insumos das fichas técnicas)') : `<li>⏳ Estoque será baixado quando a cozinha/bar entregar todos os itens</li>`);
  if (doacao) L.push(ok(`Doação de <b>${R(doacao.valor)}</b> registrada para ${esc(doacao.destino)} (fica na gaveta e aparece no fechamento do caixa)`));
  L.push(ok('Valores lançados no caixa e no fechamento do dia'));
  const troco = trocoEntregar > 0.004 ? `<div style="background:#fff4d6;border:2px solid #f0d58a;border-radius:10px;text-align:center;padding:10px;margin:0 0 12px"><span style="font-size:14px">TROCO A ENTREGAR</span><br><b style="font-size:34px">${R(trocoEntregar)}</b></div>` : '';
  modal({ titulo: 'Venda ' + pad(rs.venda_numero) + ' finalizada', tam: 'md', corpo: `${troco}<ul style="list-style:none;margin:0;padding:0;line-height:1.7;font-size:14.5px">${L.join('')}</ul>`, botoes: [{ txt: 'OK', cls: 'primary' }] });
}
async function perguntarDoacao(pedidoId, troco) {
  const destinos = String(S.cfg.doacao_destinos || '').split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  if (S.cfg.doacao_ativa !== '1' || !destinos.length || !(troco > 0.004)) return troco;
  const c2 = x => Math.round(x * 100) / 100, moedas = c2(troco - Math.floor(troco + 0.0001));
  const escolha = await new Promise(res => {
    const op = destinos.length > 1 ? `<label>Para qual local?<select id="dstd">${destinos.map(d => `<option>${esc(d)}</option>`).join('')}</select></label>` : `<p>Local: <b>${esc(destinos[0])}</b></p>`;
    const bt = [{ txt: 'Não, devolver o troco', fn: () => res(null) }];
    if (moedas > 0.004 && moedas < troco - 0.004) bt.push({ txt: 'Doar as moedinhas ' + R(moedas), cls: 'primary', fn: m => res({ valor: moedas, destino: $('#dstd', m.body)?.value || destinos[0] }) });
    bt.push({ txt: 'Doar o troco todo ' + R(troco), cls: moedas > 0.004 && moedas < troco - 0.004 ? '' : 'primary', fn: m => res({ valor: troco, destino: $('#dstd', m.body)?.value || destinos[0] }) });
    modal({ titulo: 'Troco: ' + R(troco), tam: 'md', corpo: `<p style="font-size:17px"><b>Pergunte ao cliente:</b> deseja deixar as moedinhas como doação?</p>${op}<p class="muted">O valor doado fica na gaveta e aparece no fechamento do caixa, separado por local.</p>`, botoes: bt });
  });
  if (!escolha) return troco;
  try { await api(`/pedidos/${pedidoId}/doacao`, { method: 'POST', body: escolha }); ultimaDoacao = escolha; toast(`Doação de ${R(escolha.valor)} registrada para ${escolha.destino}. Obrigado!`); return c2(troco - escolha.valor); }
  catch (e) { toast('Doação não registrada: ' + e.message, 'erro'); return troco; }
}

// Movimento de caixa (entrada ou saída de dinheiro do caixa, com o motivo) — disponível na tela de vendas
function movimentoCaixa() {
  formModal({ titulo: 'Movimento de caixa', tam: 'md',
    campos: [{ k: 'tipo', l: 'O que é', t: 'select', op: [['suprimento', 'Entrada de dinheiro no caixa (suprimento)'], ['sangria', 'Saída de dinheiro do caixa (sangria / pagamento / retirada)']], full: true },
      { k: 'valor', l: 'Valor (R$)', t: 'number', step: '0.01', req: true, full: true },
      { k: 'motivo', l: 'Do que se trata (obrigatório)', req: true, full: true, ph: 'Ex.: troco inicial, compra de gelo, pagamento de fornecedor, retirada para o cofre' }],
    valores: { tipo: 'suprimento' },
    onSave: async o => { await api('/caixa/movimento', { method: 'POST', body: o }); toast((o.tipo === 'sangria' ? 'Saída de ' : 'Entrada de ') + R(Number(o.valor)) + ' registrada.'); } });
}

// Vendas anteriores (consulta): em andamento, finalizadas e canceladas
async function listaVendas(el, status) {
  limparTimer();
  const ped = await api('/pedidos?status=' + status);
  const tab = (s, t) => `<button class="${status === s ? 'on' : ''}" data-st="${s}">${t}</button>`;
  el.innerHTML = `<div class="bar"><div class="tabs" style="margin:0">${tab('aberto', 'Em andamento')}${tab('fechado', 'Finalizadas')}${tab('cancelado', 'Canceladas')}</div></div>
    ${ped.length ? '<div class="comandas">' + ped.map(p => `<div class="comanda" data-id="${p.id}"><b>Venda ${String(p.venda_numero || p.id).padStart(6, '0')}</b><br>
      <span class="muted">${esc(p.usuario || '')} · ${hr(p.aberto_em)}</span><div>${p.itens} itens</div>
      <div class="tot">${R(p.status === 'aberto' ? p.subtotal : p.total)}</div></div>`).join('') + '</div>' : '<div class="card muted">Nenhuma venda.</div>'}
    <div class="acoes-base">${tem('vendas.receber') ? '<button class="btn big" id="fiado" title="Receber fiado">Receber fiado</button>' : ''}${tem('caixa.movimentar') ? '<button class="btn big" id="movcx" title="Movimento de caixa (sangria/suprimento)">Mov. caixa</button>' : ''}${tem('caixa.fechar') ? '<button class="btn big" id="fechcx">Fechar caixa</button>' : ''}${tem('caixa.alterar_forma') ? '<button class="btn big" id="altfp" title="Alterar forma de pagamento">Alt. pagamento</button>' : ''}<button class="btn primary big" id="nova">+ Nova venda</button></div>`;
  el.onclick = seguro(async e => {
    const st = e.target.closest('[data-st]'); if (st) return listaVendas(el, st.dataset.st);
    if (e.target.id === 'fiado') { location.hash = '#/fiado'; return; }
    if (e.target.id === 'movcx') return movimentoCaixa();
    if (e.target.id === 'fechcx') return fecharPelaVenda(el);
    if (e.target.id === 'altfp') return alterarPelaVenda();
    const c = e.target.closest('.comanda'); if (c) return pdv(el, +c.dataset.id);
    if (e.target.id === 'nova') return iniciarVenda(el);
  });
}

async function pdv(el, id) {
  limparTimer();
  let P = await api('/pedidos/' + id), prods = await api('/produtos?ativos=1&vendaveis=1'), clientes = [];
  const aberta = () => P.status === 'aberto';
  // com itens lançados e a venda ainda aberta, sair da tela pede confirmação (a venda fica pendente)
  S.guarda = () => document.body.contains(el) && !!$('#painel', el) && aberta() && P.itens.some(i => i.status !== 'cancelado');
  // busca de produto: nome (todas as palavras, sem acento), código interno ou código de barras (parte do número)
  const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const casa = (p, txt) => { const b = norm(txt).trim(); if (!b) return true;
    return b.split(/\s+/).every(w => norm(p.nome).includes(w)) || norm(p.codigo).includes(b) || (p.codigos_barras || []).some(c => String(c).includes(b)); };
  const exato = (p, txt) => norm(p.codigo) === norm(txt).trim() || (p.codigos_barras || []).includes(txt.trim());
  const pad = n => String(n || 0).padStart(6, '0');
  if (aberta()) { try { clientes = await api('/clientes?ativos=1'); } catch { clientes = []; } }
  el.innerHTML = `<div class="vend">
    <div class="vend-h">
      <label class="ro">Caixa<input id="f-cx" readonly></label>
      <label class="ro">Nº da venda<input id="f-nv" readonly tabindex="-1"></label>
      <label class="${aberta() ? '' : 'ro'}">Vendedor (nº do usuário)<input id="f-vd" ${aberta() ? 'list="dl-vd" autocomplete="off" placeholder="número ou nome"' : 'readonly'}><datalist id="dl-vd"></datalist></label>
      <label class="vcli">Cliente [F8]<select id="f-cli" ${aberta() ? '' : 'disabled'}></select></label>
      <div class="vstat"><b id="hd"></b></div>
    </div>
    <div class="vend-b ${aberta() ? '' : 'hidden'}">
      <div class="vbusca"><label>Buscar produto ou [F4] consultar<input id="busca" placeholder="nome, código ou código de barras" autocomplete="off"></label><div class="sug hidden" id="sug"></div></div>
      <label class="vq">Quantidade<input id="qtd" value="1" inputmode="decimal"></label>
      <label class="vo">Observação do próximo item<input id="obs" placeholder="ex: sem cebola"></label>
    </div>
    <div class="vmain"><div class="card vgrid" id="vgrid"></div><div class="card vtab" id="painel"></div></div>
    <div class="vend-base" id="base"></div></div>`;

  // Números sequenciais do caixa e da venda vêm do banco (tabelas caixas e vendas)
  const cab = () => {
    $('#f-cx', el).value = P.caixa_numero ? pad(P.caixa_numero) : '—';
    $('#f-nv', el).value = P.venda_numero ? pad(P.venda_numero) : '—';
    $('#f-vd', el).value = P.vendedor_codigo ? P.vendedor_codigo + ' · ' + (P.vendedor || P.usuario || '') : (P.usuario || '');
    $('#f-cli', el).innerHTML = aberta()
      ? '<option value="">Consumidor (sem cliente)</option>' + clientes.map(c => `<option value="${c.id}" ${c.id === P.cliente_id ? 'selected' : ''}>${esc(c.nome)}</option>`).join('')
      : `<option>${esc(P.cliente || 'Consumidor (sem cliente)')}</option>`;
  };

  const montarGrid = (raiz, cat, busca) => {
    const cats = [...new Set(prods.map(p => p.categoria).filter(Boolean))].sort();
    $('.cats', raiz).innerHTML = `<button class="${cat === '' ? 'on' : ''}" data-cat="">Todos</button>` + cats.map(c => `<button class="${cat === c ? 'on' : ''}" data-cat="${esc(c)}">${esc(c)}</button>`).join('');
    const b = busca.toLowerCase();
    const l = prods.filter(p => (!cat || p.categoria === cat) && (!b || casa(p, busca)));
    $('.prods', raiz).innerHTML = l.map(p => { const sem = p.controla_estoque && p.estoque_atual <= 0;
      return `<button class="prod ${sem ? 'sem' : ''}" data-p="${p.id}"><b>${esc(p.nome)}</b><small>${p.controla_estoque ? 'Estoque: ' + N(p.estoque_atual) + ' ' + p.unidade : esc(p.categoria || '')}</small><span class="pr">${R(p.preco_venda)}</span></button>`; }).join('') || '<p class="muted">Nenhum produto.</p>';
  };
  // F4: consultar produtos (grade por categoria)
  const consultar = () => {
    if (!aberta()) return;
    let cat = '', busca = '';
    const corpo = document.createElement('div');
    corpo.innerHTML = '<input class="cbusca" placeholder="Filtrar por nome ou código..." autocomplete="off"><div class="cats"></div><div class="prods"></div>';
    const m = modal({ titulo: 'Consultar produtos', tam: 'lg', corpo, botoes: [{ txt: 'Fechar' }] });
    const redesenha = () => montarGrid(corpo, cat, busca); redesenha();
    $('.cbusca', corpo).oninput = e => { busca = e.target.value.trim(); redesenha(); };
    corpo.onclick = seguro(async e => {
      const c = e.target.closest('[data-cat]'); if (c) { cat = c.dataset.cat; return redesenha(); }
      const p = e.target.closest('[data-p]'); if (p) { m.fechar(); await lancar(+p.dataset.p); $('#busca', el).focus(); }
    });
  };
  const recarregarProds = () => api('/produtos?ativos=1&vendaveis=1').then(r => { prods = r; desenharGrid(); }).catch(() => { });
  // Botões grandes dos produtos liberados para este caixa/evento (clique = lança 1 na venda, ou a quantidade digitada)
  let cardIds = null, catSel = '';
  const carregarCardapio = async () => { try { const r = await api('/caixa/cardapio'); cardIds = r.ids.length ? new Set(r.ids) : null; } catch { cardIds = null; } };
  const desenharGrid = () => {
    const box = $('#vgrid', el); if (!box || !aberta()) { if (box) box.classList.add('hidden'); return; }
    const vis = prods.filter(p => !cardIds || cardIds.has(p.id));
    const cats = [...new Set(vis.map(p => p.categoria).filter(Boolean))].sort();
    const l = vis.filter(p => !catSel || p.categoria === catSel);
    box.innerHTML = `<div class="vg-h"><div class="cats">${`<button class="${catSel === '' ? 'on' : ''}" data-vc="">Todos</button>` + cats.map(c => `<button class="${catSel === c ? 'on' : ''}" data-vc="${esc(c)}">${esc(c)}</button>`).join('')}</div>
      <span>${tem('estoque.producao') ? '<button class="btn sm" type="button" id="vgprod">Lançar produção</button> ' : ''}${tem('caixa.acessar') ? '<button class="btn sm" type="button" id="vgedit">Produtos do caixa</button>' : ''}</span></div>
      <div class="vg-b">${l.map(p => { const sem = p.controla_estoque && p.estoque_atual <= 0;
        return `<button type="button" class="vtile ${sem ? 'sem' : ''}" data-vt="${p.id}"><span class="vimg">${miniProd(p)}</span><b>${esc(p.nome)}</b><span class="pr">${R(p.preco_venda)}</span>${sem ? '<small class="erro">sem estoque</small>' : ''}</button>`; }).join('') || '<p class="muted" style="padding:14px">Nenhum produto. Use "Produtos do caixa" para escolher o que será vendido.</p>'}</div>`;
  };


  const painel = () => {
    cab();
    $('#hd', el).textContent = `${P.venda_numero ? 'Venda ' + pad(P.venda_numero) : 'Nova venda'}${aberta() ? '' : ' · ' + ({ fechado: 'FINALIZADA', cancelado: 'CANCELADA' }[P.status] || P.status.toUpperCase())}`;
    const novos = P.itens.filter(i => i.status === 'novo').length;
    const vivos = P.itens.filter(i => i.status !== 'cancelado');
    $('#painel', el).innerHTML = `<div class="vtit">${vivos.length} itens <span class="muted">· iniciada ${dt(P.aberto_em)}</span></div><div class="rolar"><table class="vt"><thead><tr><th>Item</th><th>Produto</th><th class="n">Qtd × unitário</th><th class="n">Total</th><th>Situação</th><th></th></tr></thead><tbody>` +
      (P.itens.map((i, k) => `<tr class="${i.status === 'cancelado' ? 'canc' : ''}"><td>${k + 1}</td><td><b>${esc(i.nome)}</b>${i.observacao ? `<br><small class="muted">obs.: ${esc(i.observacao)}</small>` : ''}${i.autorizado_por ? '<br><small class="erro">estoque negativo autorizado</small>' : ''}</td>
        <td class="n">${N(i.quantidade)} × ${R(i.preco_unit)}</td><td class="n">${R(i.quantidade * i.preco_unit)}</td><td>${chipItem(i)}</td>
        <td>${aberta() && i.status !== 'cancelado' ? `<button class="btn sm danger" data-rm="${i.id}" title="Remover/cancelar item">✕</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="6" class="muted" style="text-align:center;padding:22px">Nenhum item. Digite no campo de busca ou aperte F4 para consultar.</td></tr>') +
      `</tbody></table></div>`;
    const bruto = P.subtotal, desc = Number(P.desconto || 0), liq = aberta() ? Math.max(0, bruto - desc) : Number(P.total);
    $('#base', el).innerHTML = `<div class="vb-btns">
        <button class="btn" id="voltar" title="Vendas anteriores">Anteriores</button>
        ${tem('caixa.movimentar') ? '<button class="btn" data-a="movcx" title="Movimento de caixa (sangria/suprimento)">Mov. caixa</button>' : ''}
        ${tem('caixa.fechar') ? '<button class="btn" data-a="fechcx" title="Fechar caixa">Fechar caixa</button>' : ''}
        ${tem('caixa.alterar_forma') ? '<button class="btn" data-a="altfp" title="Alterar forma de pagamento">Alt. pagamento</button>' : ''}
        ${tem('vendas.receber') ? '<button class="btn" data-a="fiado" title="Receber fiado / consultar débitos por cliente">Receber fiado</button>' : ''}
        ${aberta() ? `<button class="btn" data-a="conta" title="Imprimir conferência" ${vivos.length ? '' : 'disabled'}>Conferência</button>
        <button class="btn" data-a="consultar" title="Consultar produto [F4]">Consultar F4</button>
        <button class="btn danger" data-a="cancelar" title="Cancelar venda" ${vivos.length ? '' : 'disabled'}>Cancelar</button>` : `${tem('vendas.reimprimir') && P.status === 'fechado' ? '<button class="btn" data-a="reimp" title="Reimprimir pedido (cozinha/bar)">Reimprimir</button>' : ''}${P.pagamentos.length ? `<span class="muted">Pagamentos: ${P.pagamentos.map(p => `${esc(p.forma)} ${R(p.valor)}`).join(' · ')}</span>` : ''}${P.observacao ? `<span class="muted">Obs.: ${esc(P.observacao)}</span>` : ''}`}
      </div>
      <div class="vb-tot"><div><span>Total bruto</span><b>${R(bruto)}</b></div><div><span>Total descontos</span><b>${R(desc)}</b></div></div>
      ${aberta() && tem('vendas.receber') ? `<button class="vb-rec" data-a="receber" ${vivos.length ? '' : 'disabled'}><span>Receber [F2]</span><b>${R(liq)}</b></button>` : `<div class="vb-rec off"><span>Total</span><b>${R(liq)}</b></div>`}`;
  };

  // Pergunta a observação do item (só produtos que permitem). Enter confirma; ESC (ou fechar) lança o produto sem observação.
  const perguntarObs = nome => new Promise(res => {
    let feito = false; const fim = v => { if (feito) return; feito = true; mo.disconnect(); m.fechar(); res(v); };
    const m = modal({ titulo: 'Observação do item', tam: 'md', corpo: `<p><b>${esc(nome)}</b></p><label>Alguma observação para este item?<input id="obsq" autocomplete="off" placeholder="ex.: sem cebola, bem passado"></label><p class="muted">Enter confirma · ESC lança sem observação</p>`,
      botoes: [{ txt: 'Sem observação [ESC]', fn: () => { fim(''); return false; } }, { txt: 'Lançar com observação', cls: 'primary', fn: () => { fim($('#obsq', m.body).value.trim()); return false; } }],
      aoAbrir: mm => { const f = $('#obsq', mm.body); setTimeout(() => f.focus(), 30);
        f.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); fim(f.value.trim()); } else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); fim(''); } }); } });
    const mo = new MutationObserver(() => { if (!document.body.contains(m.el)) fim(''); }); mo.observe(document.body, { childList: true });
    m.el.addEventListener('keydown', e => { if (e.key === 'Escape') fim(''); });
  });
  const lancar = async (prodId, aut, obsFixa) => {
    const q = numIn($('#qtd', el).value) || 1; let obs = obsFixa !== undefined ? obsFixa : $('#obs', el).value.trim();
    const pr = prods.find(x => x.id === prodId);
    if (obsFixa === undefined && !obs && pr && pr.permite_obs) obs = await perguntarObs(pr.nome);
    try {
      P = await api(`/pedidos/${id}/itens`, { method: 'POST', body: { produto_id: prodId, quantidade: q, observacao: obs || undefined, autorizacao: aut } });
      $('#qtd', el).value = '1'; $('#obs', el).value = ''; painel(); recarregarProds();
    } catch (e) {
      if (e.status === 409 && e.data?.codigo === 'ESTOQUE_NEGATIVO') return pedirAutorizacao(e.data.faltas, prodId, obs);
      throw e;
    }
  };
  const pedirAutorizacao = (faltas, prodId, obs) => modal({ titulo: 'Estoque insuficiente', corpo:
    `<p><b>Esta venda deixaria o estoque negativo:</b></p><ul>${faltas.map(f => `<li>${esc(f.produto)}: disponível ${N(f.atual)} ${f.unidade}, necessário ${N(f.necessario)} ${f.unidade}</li>`).join('')}</ul>
     <p class="muted">Apenas usuários com permissão específica podem autorizar. Informe usuário e senha do autorizador:</p>
     <div class="row"><label>Usuário<input id="al" data-cred autocomplete="off"></label><label>Senha<input id="as" type="password" data-cred autocomplete="new-password"></label></div>`,
    botoes: [{ txt: 'Cancelar' }, { txt: 'Autorizar e lançar', cls: 'primary', fn: async m => { await lancar(prodId, { login: $('#al', m.body).value, senha: $('#as', m.body).value }, obs || ''); } }],
    aoAbrir: m => { const f = $('#as', m.body); if (f) f.focus(); } });

  // ---- Receber: tela de recebimento (até 3 formas de pagamento; dinheiro com valor recebido e troco)
  const receber = async () => {
    // os itens novos vão para a cozinha/bar automaticamente ao finalizar o recebimento (servidor)
    const FORMAS = await api('/formas-pagamento?ativas=1'); const fx = c => FORMAS.find(f => f.codigo === c) || {};
    if (!FORMAS.length) return toast('Nenhuma forma de pagamento ativa. Cadastre em Formas de pagamento.', 'aviso');
    const MAX = 3, sub = P.subtotal, c2 = x => Math.round(x * 100) / 100, fmt = x => c2(x).toFixed(2).replace('.', ',');
    const padrao = (FORMAS.find(f => f.tipo === 'dinheiro') || FORMAS[0]).codigo;
    let desconto = 0, arred = 0, arredAut = null, janela, btnOk, trocoCliente = 0, bloqueio = '';
    const linhas = [{ forma: padrao, valor: '', manual: false, recebido: '', parcelas: 1 }];
    const val = l => numIn(l.valor) || 0;
    const corpo = document.createElement('div'); corpo.className = 'rec';
    corpo.innerHTML = `<label class="ro">Vendedor<input readonly value="${esc(P.vendedor || P.usuario || '')}"></label>
      <div class="rec-sec">Cliente [F8]</div>
      <div class="rec-cli"><div class="cli-box"><input id="clibusca" autocomplete="off" placeholder="Digite ao menos 3 letras do nome, CPF ou telefone" value="${esc((clientes.find(c => c.id === P.cliente_id) || {}).nome || '')}"><input type="hidden" id="cli" value="${P.cliente_id || ''}"><div id="clisug" class="clisug hidden"></div></div><button class="btn" id="novocli" type="button">+ Novo cliente</button></div>
      <div id="fiado" class="hidden"><label>Vencimento do fiado<input id="venc" type="date" value="${new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10)}"></label><p class="erro" style="margin:4px 0 0">Venda no fiado exige um cliente cadastrado.</p></div>
      <div class="rec-sec">Forma de pagamento <small class="muted">(até ${MAX})</small></div>
      <div id="pgs"></div>
      <button class="rec-add" id="addpg" type="button" disabled>Incluir forma de pagamento [F10]</button>
      <div class="rec-sec">Observações</div>
      <label style="display:block"><textarea id="obsv" rows="2" maxlength="500" placeholder="Observações da venda (opcional)" style="width:100%"></textarea></label>
      <div class="rec-sec">Totais</div>
      <div class="rec-tot"><div><span>Valor bruto</span><b id="vb"></b></div><div><span>Arredondamento</span><b id="vd"></b></div><div class="big"><span>Valor a receber</span><b id="vr"></b></div></div>
      <div id="recmsg" class="rec-msg hidden"></div>
      <div class="rec-sub"><span>Valor informado <b id="vi"></b></span><span>Valor restante <b id="vs"></b></span><span id="trw" class="hidden">Troco a devolver <b id="vt"></b></span></div>
      <div class="rec-dsc"><button class="btn" id="btarr" type="button">Arredondamento [Ctrl+D]</button><span class="muted" id="arrinfo"></span></div>`;
    const total = () => Math.max(0, c2(sub - desconto + arred));
    const rowEls = () => $$('.rec-l', corpo);
    const linhaHtml = (l, i) => `<div class="rec-l"><label>Forma de pagamento *<select data-f>${FORMAS.map(f => `<option value="${esc(f.codigo)}" ${f.codigo === l.forma ? 'selected' : ''}>${esc(f.descricao)}${f.tef_ativo ? ' (TEF)' : ''}</option>`).join('')}</select></label>
      <label>Valor *<input data-v inputmode="decimal" value="${esc(l.valor)}"></label>
      <label data-rc class="hidden">Valor recebido<input data-r inputmode="decimal" value="${esc(l.recebido)}" placeholder="quanto o cliente deu"></label>
      <label data-pc class="hidden">Parcelas<select data-p></select></label>
      <div class="rec-tr hidden" data-tr></div>${i > 0 ? '<button class="btn danger rec-x" data-x type="button" title="Remover esta forma de pagamento" aria-label="Remover forma de pagamento"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="pointer-events:none"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg></button>' : ''}</div>`;
    const desenharLinhas = () => { $('#pgs', corpo).innerHTML = linhas.map(linhaHtml).join(''); calc(); };
    const calc = () => {
      const t = total(), ult = linhas.length - 1;
      if (!linhas[ult].manual) { const outros = linhas.slice(0, ult).reduce((s, l) => s + val(l), 0); linhas[ult].valor = fmt(Math.max(0, t - outros)); const inp = $('[data-v]', rowEls()[ult]); if (inp && document.activeElement !== inp) inp.value = linhas[ult].valor; }
      const informado = c2(linhas.reduce((s, l) => s + val(l), 0)), restante = c2(t - informado);
      let troco = 0, recebidoBaixo = false;
      rowEls().forEach((row, i) => {
        const l = linhas[i], f = fx(l.forma), din = f.tipo === 'dinheiro';
        $('[data-rc]', row).classList.toggle('hidden', !din);
        const n = f.max_parcelas || 1, pc = $('[data-pc]', row), sel = $('[data-p]', row); pc.classList.toggle('hidden', n <= 1);
        if (sel.options.length !== n) sel.innerHTML = Array.from({ length: n }, (_, k) => `<option value="${k + 1}" ${k + 1 === Number(l.parcelas) ? 'selected' : ''}>${k + 1}x</option>`).join('');
        const tr = $('[data-tr]', row), rec = numIn(l.recebido) || 0;
        if (din && rec > 0) {
          if (rec + 0.004 < val(l)) { recebidoBaixo = true; tr.className = 'rec-tr erro'; tr.textContent = 'Valor recebido menor que o valor em dinheiro'; }
          else { const tc = c2(rec - val(l)); troco += tc; tr.className = 'rec-tr'; tr.innerHTML = 'Troco: <b>' + R(tc) + '</b>'; }
        } else tr.className = 'rec-tr hidden';
      });
      trocoCliente = c2(troco);
      $('#vb', corpo).textContent = R(sub); $('#vd', corpo).textContent = (arred > 0 ? '+ ' : arred < 0 ? '− ' : '') + R(Math.abs(arred)); $('#arrinfo', corpo).textContent = arred ? (arred > 0 ? 'Arredondado para mais' : 'Arredondado para menos') : ''; $('#vr', corpo).textContent = R(t); $('#vi', corpo).textContent = R(informado);
      const vs = $('#vs', corpo); vs.textContent = restante < -0.004 ? 'excede em ' + R(-restante) : R(Math.max(0, restante)); vs.className = restante < -0.004 ? 'erro' : '';
      $('#trw', corpo).classList.toggle('hidden', trocoCliente <= 0); $('#vt', corpo).textContent = R(trocoCliente);
      $('#addpg', corpo).disabled = !(linhas.length < MAX && restante > 0.004 && val(linhas[ult]) > 0);
      $('#fiado', corpo).classList.toggle('hidden', !linhas.some(l => fx(l.forma).tipo === 'fiado'));
      // o botão Receber fica sempre liberado; se algo impede a finalização, a mensagem aparece em destaque e ao clicar abre uma janela explicando
      if (t <= 0) bloqueio = 'A venda não tem valor a receber. Inclua itens na venda antes de finalizar.';
      else if (recebidoBaixo) bloqueio = 'O valor recebido em dinheiro é MENOR que o valor da forma de pagamento. Corrija o campo "Valor recebido" (ou apague-o se não houve troco).';
      else if (restante > 0.004) bloqueio = `Ainda faltam ${R(restante)} para completar o valor da venda. As formas de pagamento somam ${R(informado)} e o total a receber é ${R(t)}. Ajuste o valor da forma de pagamento ou inclua outra forma.`;
      else if (restante < -0.004) bloqueio = `As formas de pagamento somam ${R(informado)}, que é ${R(-restante)} A MAIS que o total a receber (${R(t)}). Reduza o valor da forma de pagamento. Se o cliente deu um valor maior em dinheiro, informe-o no campo "Valor recebido" (o troco é calculado ali), e não no campo "Valor".`;
      else bloqueio = '';
      const mg = $('#recmsg', corpo); mg.classList.toggle('hidden', !bloqueio); mg.innerHTML = bloqueio ? '<b>⚠ Esta venda ainda não pode ser finalizada:</b> ' + esc(bloqueio) : '';
      if (btnOk) btnOk.classList.toggle('blk', !!bloqueio);
    };
    corpo.addEventListener('input', e => {
      const row = e.target.closest('.rec-l');
      if (row) { const i = rowEls().indexOf(row), l = linhas[i];
        if (e.target.matches('[data-v]')) { l.valor = e.target.value; l.manual = true; }
        else if (e.target.matches('[data-r]')) l.recebido = e.target.value; }
      if (e.target.id === 'clibusca') {
        $('#cli', corpo).value = ''; const q = e.target.value.trim().toLowerCase(), box = $('#clisug', corpo);
        if (q.length < 3) { box.innerHTML = q ? '<div class="muted" style="padding:8px">Digite pelo menos 3 letras.</div>' : ''; box.classList.toggle('hidden', !q); }
        else { const l = clientes.filter(c => [c.nome, c.documento, c.telefone].some(v => (v || '').toLowerCase().includes(q))).slice(0, 8);
          box.innerHTML = l.map(c => `<button type="button" data-cl="${c.id}"><b>${esc(c.nome)}</b><span>${esc(c.documento || c.telefone || '')}</span></button>`).join('') || '<div class="muted" style="padding:8px">Nenhum cliente. Use + Novo cliente.</div>'; box.classList.remove('hidden'); }
        return calc();
      }
      calc();
    });
    corpo.addEventListener('change', e => {
      const row = e.target.closest('.rec-l'); if (!row) return; const l = linhas[rowEls().indexOf(row)];
      if (e.target.matches('[data-f]')) { l.forma = e.target.value; l.parcelas = 1; if (fx(l.forma).tipo !== 'dinheiro') l.recebido = ''; desenharLinhas(); }
      else if (e.target.matches('[data-p]')) l.parcelas = Number(e.target.value) || 1;
    });
    const incluir = () => {
      if (linhas.length >= MAX || $('#addpg', corpo).disabled) return;
      const usadas = linhas.map(l => l.forma), prox = (FORMAS.find(f => !usadas.includes(f.codigo) && f.tipo !== 'fiado') || FORMAS.find(f => !usadas.includes(f.codigo)) || FORMAS[0]).codigo;
      linhas.push({ forma: prox, valor: '', manual: false, recebido: '', parcelas: 1 }); desenharLinhas();
      const inp = $('[data-f]', rowEls()[linhas.length - 1]); if (inp) inp.focus();
    };
    const arredondar = () => {
      const mx = k => Number(String(S.cfg[k] ?? '1').replace(',', '.')) || 0, mais = mx('arred_max_mais'), menos = mx('arred_max_menos'), pode = tem('vendas.arredondar');
      formModal({ titulo: 'Arredondamento', valores: { tipo: arred > 0 ? 'mais' : 'menos', valor: arred ? fmt(Math.abs(arred)) : ''},
        campos: [{ k: 'tipo', l: 'Tipo', t: 'select', op: [['menos', 'Para menos (reduz o total)'], ['mais', 'Para mais (acrescenta ao total)']], full: true },
          { k: 'valor', l: `Valor do arredondamento (R$) — máximo: menos R$ ${fmt(menos)} / mais R$ ${fmt(mais)}. Deixe vazio ou 0 para remover`, full: true, ph: '0,00' },
          ...(pode ? [] : camposAut)],
        onSave: async o => {
          const v = Math.abs(numIn(o.valor) || 0), n = v === 0 ? 0 : (o.tipo === 'mais' ? v : -v);
          if (n > mais + 0.001) throw new Error(`Máximo para mais: R$ ${fmt(mais)}.`);
          if (-n > menos + 0.001) throw new Error(`Máximo para menos: R$ ${fmt(menos)}.`);
          if (sub + n < 0) throw new Error('Arredondamento maior que o total.');
          arred = c2(n); arredAut = n !== 0 && !pode ? autDe(o) : null; linhas.forEach(l => { l.manual = false; }); desenharLinhas();
        } });
    };
    corpo.addEventListener('click', seguro(async e => {
      const t = e.target;
      const cl = t.closest('[data-cl]'); if (cl) { const c = clientes.find(x => x.id == cl.dataset.cl); $('#cli', corpo).value = c.id; $('#clibusca', corpo).value = c.nome; $('#clisug', corpo).classList.add('hidden'); return calc(); }
      if (t.id === 'addpg') return incluir();
      if (t.closest('#btarr')) return arredondar();
      if (t.closest('[data-x]')) { linhas.splice(rowEls().indexOf(t.closest('.rec-l')), 1); return desenharLinhas(); }
      if (t.id === 'novocli') formModal({ titulo: 'Novo cliente', campos: [{ k: 'nome', l: 'Nome', req: true, full: true }, { k: 'documento', l: 'CPF/CNPJ' }, { k: 'telefone', l: 'Telefone' }, { k: 'endereco', l: 'Endereço', full: true }],
        onSave: async o => { const c = await api('/clientes/rapido', { method: 'POST', body: o }); clientes.push(c); $('#cli', corpo).value = c.id; $('#clibusca', corpo).value = c.nome; toast('Cliente cadastrado.'); } });
    }));
    const abrirTela = () => {
      desenharLinhas();
      janela.el.addEventListener('keydown', e => {
        if (e.key === 'F2') { e.preventDefault(); if (btnOk && !btnOk.disabled) btnOk.click(); }
        else if (e.key === 'F10') { e.preventDefault(); incluir(); }
        else if (e.key === 'F8') { e.preventDefault(); $('#clibusca', corpo).focus(); }
        else if (e.ctrlKey && e.key.toLowerCase() === 'd') { e.preventDefault(); arredondar(); }
      });
      const v = $('[data-v]', rowEls()[0]); if (v) { v.focus(); v.select(); }
    };
    modal({ titulo: 'Receber — venda ' + pad(P.venda_numero), tam: 'lg', corpo, botoes: [{ txt: 'Voltar' }, { txt: 'Receber [F2]', cls: 'ok', fn: async m => {
      if (bloqueio) { await aviso(bloqueio, 'Esta venda NÃO será finalizada'); return false; }
      const t = total(); const pg = linhas.map(l => ({ forma: l.forma, valor: val(l), parcelas: Number(l.parcelas) || 1 })).filter(p => p.valor > 0);
      if (pg.some(p => fx(p.forma).tipo === 'fiado') && !$('#cli', corpo).value) throw new Error('Venda fiado só pode ser feita com um cliente cadastrado. Busque (3 letras) ou cadastre o cliente.');
      const soma = c2(pg.reduce((s, p) => s + p.valor, 0));
      if (soma + 0.004 < t) throw new Error('Pagamento insuficiente: faltam ' + R(t - soma));
      if (soma > t + 0.004) throw new Error('A soma das formas de pagamento é maior que o valor a receber.');
      // 1) cobra no cartão (TEF) antes de finalizar a venda; cartão sempre no valor exato
      const aprovadas = []; const desfazer = () => (aprovadas.length ? api('/tef/desfazer', { method: 'POST', body: { refs: aprovadas } }).catch(() => {}) : null);
      const tefs = pg.filter(p => fx(p.forma).tef_ativo);
      if (tefs.reduce((s, p) => s + p.valor, 0) > t + 0.001) throw new Error('O valor no cartão (TEF) não pode ser maior que o total da venda. Troco só é permitido em dinheiro.');
      for (const p of tefs) {
        const aguarde = modal({ titulo: 'Aguardando o cartão (TEF)', corpo: `<p>Siga as instruções no PIN-pad.</p><p><b>${esc(fx(p.forma).descricao)}: ${R(p.valor)}</b>${p.parcelas > 1 ? ' em ' + p.parcelas + 'x' : ''}</p><p class="muted">Não feche esta janela até terminar.</p>`, botoes: [] });
        let x; try { x = await api('/tef/transacao', { method: 'POST', body: { forma: p.forma, valor: p.valor, parcelas: p.parcelas, pedido_id: id } }); }
        catch (e) { aguarde.fechar(); await desfazer(); throw e; }
        aguarde.fechar();
        if (!x.aprovado) { await desfazer(); throw new Error('TEF: ' + x.mensagem); }
        p.tef_ref = x.ref; aprovadas.push(x.ref);
      }
      // 2) finaliza a venda
      let r;
      try { r = await api(`/pedidos/${id}/pagar`, { method: 'POST', body: { observacao: $('#obsv', corpo).value.trim() || undefined, arredondamento: arred, autorizacao: arredAut || undefined, pagamentos: pg, cliente_id: $('#cli', corpo).value || undefined, vencimento_fiado: $('#venc', corpo).value || undefined } }); }
      catch (e) { if (aprovadas.length) toast('Transação(ões) TEF desfeita(s) por segurança.', 'aviso'); throw e; }
      m.fechar(); ultimaDoacao = null; let trocoFinal = Math.max(Number(r.troco) || 0, trocoCliente); trocoFinal = await perguntarDoacao(id, trocoFinal);
      if ((r.impressao || []).some(x => !x.ok)) for (const c of r.comprovantes) await aviso(c.linhas.join('\n'), 'Comprovante TEF — ' + c.forma);
      if (r.resumo) resumoFinalizacao(r.resumo, trocoFinal, ultimaDoacao);
      else { // resposta sem resumo (servidor antigo): avisos de antes
        if (trocoFinal > 0) await aviso('TROCO: ' + R(trocoFinal), 'Pagamento recebido'); else toast('Pagamento recebido.');
        (r.impressao || []).filter(x => !x.ok).forEach(x => toast('Comprovante TEF não impresso: ' + x.erro, 'aviso'));
        (r.impressoes || []).forEach(x => (x.ok ? toast('Pedido impresso: ' + x.destino) : toast(`Pedido ${x.destino} não impresso: ${x.erro} (os itens estão na tela da ${x.destino})`, 'aviso')));
      }
      iniciarVenda(el); return false;
    } }], aoAbrir: m => { janela = m; btnOk = $$('.foot button', m.el)[1]; abrirTela(); } });
  };

  const acoes = {
    movcx: movimentoCaixa,
    fechcx: () => fecharPelaVenda(el),
    altfp: alterarPelaVenda,
    fiado: () => consultaFiadoClientes(),
    receber,
    consultar,
    conta: async () => { const r = await api(`/pedidos/${id}/conta`, { method: 'POST' }); r.ok ? toast('Conta impressa.') : toast(r.erro, 'aviso'); },
    reimp: () => formModal({ titulo: 'Reimprimir pedido da cozinha/bar', campos: [{ k: 'destino', l: 'Destino', t: 'select', full: true, op: [['', 'Cozinha e bar'], ['cozinha', 'Só cozinha'], ['bar', 'Só bar']] }],
      onSave: async o => { const r = await api(`/pedidos/${id}/reimprimir`, { method: 'POST', body: o }); r.impressao.forEach(x => (x.ok ? toast('Reimpresso: ' + x.destino) : toast(x.erro, 'aviso'))); if (!r.impressao.length) toast('Nada a reimprimir.', 'aviso'); } }),
    cancelar: () => formModal({ titulo: 'Cancelar a venda inteira', campos: [{ k: 'motivo', l: 'Motivo (opcional)', full: true }],
      onSave: async o => { await api(`/pedidos/${id}/cancelar`, { method: 'POST', body: o }); toast('Venda cancelada.'); iniciarVenda(el); } }),
  };

  el.onclick = seguro(async e => {
    if (e.target.id === 'voltar') { if (S.guarda && S.guarda() && !(await confirmarSaidaVenda())) return; S.guarda = null; return listaVendas(el, 'aberto'); }
    const vt = e.target.closest('[data-vt]'); if (vt) return lancar(+vt.dataset.vt);
    const vc = e.target.closest('[data-vc]'); if (vc) { catSel = vc.dataset.vc; return desenharGrid(); }
    if (e.target.id === 'vgprod') return produzirModal(null, () => recarregarProds(), true);
    if (e.target.id === 'vgedit') { const r = await escolherProdutos([...(cardIds || [])], { ultimos: false }); if (r) { await confirmarCredenciais('Alterar os produtos do caixa', async aut => { await api('/caixa/cardapio', { method: 'PUT', body: { ids: r, autorizacao: aut } }); }); await carregarCardapio(); desenharGrid(); toast('Produtos do caixa atualizados.'); } return; }
    const p = e.target.closest('#sug [data-p]'); if (p) { limparBusca(); return lancar(+p.dataset.p); }
    const a = e.target.closest('[data-a]'); if (a && acoes[a.dataset.a]) return acoes[a.dataset.a]();
    const rm = e.target.closest('[data-rm]');
    if (rm) {
      const it = P.itens.find(i => i.id == rm.dataset.rm);
      if (it.status === 'novo') { if (!await confirmar(`Remover ${it.nome}?`)) return; P = await api(`/pedidos/${id}/itens/${it.id}`, { method: 'DELETE', body: {} }); painel(); recarregarProds(); }
      else formModal({ titulo: `Cancelar item já enviado: ${it.nome}`, campos: [{ k: 'motivo', l: 'Motivo', req: true, full: true }],
        onSave: async o => { P = await api(`/pedidos/${id}/itens/${it.id}`, { method: 'DELETE', body: o }); painel(); recarregarProds(); toast('Item cancelado e cozinha/bar avisados.'); } });
    }
  });
  // busca rápida: sugestões enquanto digita; Enter lança (código/barras exato ou único resultado)
  const achar = txt => prods.filter(p => casa(p, txt));
  const sug = () => { const txt = $('#busca', el).value.trim(), box = $('#sug', el);
    if (!txt) return box.classList.add('hidden');
    const l = achar(txt).slice(0, 8);
    box.innerHTML = l.map(p => `<button type="button" data-p="${p.id}"><b>${esc(p.nome)}</b> <small class="muted">cód ${esc(p.codigo || '')}${(p.codigos_barras || [])[0] ? ' · ' + esc(p.codigos_barras[0]) : ''}</small><span>${R(p.preco_venda)}</span></button>`).join('') || '<div class="muted" style="padding:8px">Nenhum produto.</div>';
    box.classList.remove('hidden'); };
  const limparBusca = () => { $('#busca', el).value = ''; $('#sug', el).classList.add('hidden'); $('#busca', el).focus(); };
  $('#busca', el).oninput = sug;
  $('#busca', el).onkeydown = seguro(async e => {
    if (e.key === 'Escape') return limparBusca();
    if (e.key !== 'Enter') return;
    const txt = e.target.value.trim(); if (!txt) return;
    const l = achar(txt), ex = l.filter(p => exato(p, txt));
    const alvo = ex.length === 1 ? ex[0] : (l.length === 1 ? l[0] : null);
    if (alvo) { limparBusca(); await lancar(alvo.id); } else sug();
  });
  if (window._mdVenda) document.removeEventListener('mousedown', window._mdVenda);
  window._mdVenda = e => { if (!e.target.closest('.vbusca')) $('#sug', el)?.classList.add('hidden'); }; document.addEventListener('mousedown', window._mdVenda);
  if (aberta()) {
    let vends = []; try { vends = await api('/vendedores'); } catch { vends = []; }
    $('#dl-vd', el).innerHTML = vends.map(u => `<option value="${u.codigo} · ${esc(u.nome)}">`).join('');
    $('#f-vd', el).onfocus = e => e.target.select();
    $('#f-vd', el).onchange = async e => {
      const txt = e.target.value.trim(), m = txt.match(/^\d+/); const u = m ? vends.find(x => x.codigo === Number(m[0])) : vends.find(x => x.nome.toLowerCase() === txt.toLowerCase());
      try { if (!u) throw new Error('Vendedor não encontrado. Digite o número do usuário.'); P = await api(`/pedidos/${id}/vendedor`, { method: 'PUT', body: { codigo: u.codigo } }); toast('Vendedor: ' + u.nome); }
      catch (er) { toast(er.message, 'erro'); }
      cab();
    };
  }
  $('#f-cli', el).onchange = seguro(async e => { P = await api(`/pedidos/${id}/cliente`, { method: 'PUT', body: { cliente_id: e.target.value || null } }); painel(); });
  // atalhos: F2 receber, F4 consultar, F8 cliente
  const teclas = e => {
    if (!document.body.contains(el) || !$('#base', el) || document.querySelector('.modal-bg')) return;
    if (e.key === 'F2') { e.preventDefault(); if (aberta() && tem('vendas.receber')) acoes.receber(); }
    else if (e.key === 'F4') { e.preventDefault(); consultar(); }
    else if (e.key === 'F8') { e.preventDefault(); if (aberta()) $('#f-cli', el).focus(); }
  };
  if (window._teclasVenda) document.removeEventListener('keydown', window._teclasVenda);
  window._teclasVenda = seguro(teclas); document.addEventListener('keydown', window._teclasVenda);
  await carregarCardapio(); painel(); desenharGrid(); if (aberta()) $('#busca', el).focus();
}

// ---------------- Cozinha / Bar
registrar({ id: 'producao', titulo: 'Cozinha / Bar', grupo: 'Operação', perm: 'producao.acessar', render: async el => {
  let dest = '';
  el.innerHTML = `<div class="tabs" id="tb"><button data-d="" class="on">Cozinha + Bar</button><button data-d="cozinha">Cozinha</button><button data-d="bar">Bar</button></div><div id="kds"></div>`;
  const desenhar = async () => {
    const d = await api('/producao' + (dest ? '?destino=' + dest : ''));
    const g = {}; d.pendentes.forEach(i => { const k = i.pedido_id + '|' + i.destino; (g[k] = g[k] || { venda: i.venda_numero || i.pedido_id, destino: i.destino, pedido: i.pedido_id, desde: i.enviado_em, atendente: i.atendente, itens: [] }).itens.push(i); });
    const cnt = x => d.pendentes.filter(i => i.destino === x).length;
    const tickets = Object.values(g).map(t => { const min = Math.floor((Date.now() - new Date(t.desde)) / 60000);
      return `<div class="tick ${min >= 15 ? 'late' : ''}"><h4><span>Venda ${String(t.venda || 0).padStart(6, '0')}</span><span>${chip(t.destino, 'enviado')} ${min} min</span></h4>
        ${t.itens.map(i => `<div class="li"><div style="flex:1"><b>${N(i.quantidade)}x</b> ${esc(i.nome)}${i.observacao ? `<br><small class="erro">${esc(i.observacao)}</small>` : ''}</div>${tem('producao.retirar') ? `<button class="btn sm ok" data-r="${i.id}">Retirado</button>` : ''}</div>`).join('')}
        ${tem('producao.retirar') && t.itens.length > 1 ? `<div style="margin-top:6px"><button class="btn sm" data-ra="${t.itens.map(i => i.id).join(',')}">Retirar todos</button></div>` : ''}</div>`; }).join('');
    $('#kds', el).innerHTML = `<div class="cards"><div class="stat">Pendentes na cozinha<b>${cnt('cozinha')}</b></div><div class="stat">Pendentes no bar<b>${cnt('bar')}</b></div><div class="stat">Retirados hoje<b>${d.retirados.length}</b></div></div>
      <div class="kds"><div><h3 style="margin-bottom:8px">Aguardando retirada</h3>${tickets || '<div class="card muted">Nada pendente.</div>'}</div>
      <div><h3 style="margin-bottom:8px">Já retirados hoje</h3>${tabela([{ l: 'Hora', f: r => hr(r.retirado_em) }, { l: 'Destino', k: 'destino' }, { l: 'Venda', f: r => 'Venda ' + String(r.venda_numero || r.pedido_id).padStart(6, '0') }, { l: 'Item', f: r => `${N(r.quantidade)}x ${esc(r.nome)}` }, { l: 'Por', k: 'retirado_por_nome' }], d.retirados, { vazio: 'Nada retirado ainda.' })}</div></div>`;
  };
  el.onclick = seguro(async e => {
    const t = e.target.closest('[data-d]'); if (t) { dest = t.dataset.d; $$('#tb button', el).forEach(b => b.classList.toggle('on', b === t)); return desenhar(); }
    const r = e.target.dataset.r, ra = e.target.dataset.ra;
    if (r || ra) { await api('/producao/retirar', { method: 'POST', body: { ids: (r || ra).split(',').map(Number) } }); desenhar(); }
  });
  await desenhar(); S.timer = setInterval(() => desenhar().catch(() => { }), 5000);
} });

// ---------------- Caixa
function resumoCaixaHtml(rs) {
  const c = rs.caixa;
  return `<div class="card"><b>Caixa ${c.numero ?? c.id}</b> — ${esc(c.usuario)} · aberto ${dt(c.aberto_em)}${c.fechado_em ? ' · fechado ' + dt(c.fechado_em) : ' · ' + chip('ABERTO', 'ok')}</div>
  ${rs.evento ? `<div class="card"><b>Evento: ${esc(rs.evento.nome)}</b><br><small class="muted">Equipe: ${rs.evento.equipe.map(m => esc(m.nome) + (m.ativo ? '' : ' (inativo)') + ' — ' + esc(m.funcao)).join(' · ') || '—'}</small></div>` : ''}
  <div class="cards"><div class="stat">Total vendido<b>${R(rs.total_vendido)}</b></div><div class="stat">Vendas<b>${rs.vendas}</b></div><div class="stat">Ticket médio<b>${R(rs.ticket_medio)}</b></div><div class="stat">Descontos<b>${R(rs.descontos)}</b></div></div>
  <h3 style="margin:6px 0">Recebido por forma de pagamento</h3>${tabela([{ l: 'Forma', k: 'descricao' }, { l: 'Vendas', k: 'vendas', n: 1 }, { l: 'Valor', n: 1, f: r => R(r.total) }], rs.formas, { vazio: 'Sem recebimentos.' })}
  ${rs.linhas && rs.diferenca !== null ? `<h3 style="margin:14px 0 6px">Conferência do fechamento</h3>${tabela([{ l: 'Forma', k: 'descricao' }, { l: 'Calculado (sistema)', n: 1, f: r => R(r.calculado) }, { l: 'Informado', n: 1, f: r => (r.informado != null ? R(r.informado) : '—') }, { l: 'Diferença', n: 1, f: r => `<b class="${r.diferenca ? 'erro' : ''}">${r.diferenca == null ? '—' : (r.diferenca > 0 ? '+' : '') + R(r.diferenca)}</b>` }], rs.linhas)}
  <div class="card"><b>Diferença total: <span class="${rs.diferenca ? 'erro' : ''}">${(rs.diferenca > 0 ? '+' : '') + R(rs.diferenca)}</span></b>${rs.caixa.motivo_divergencia ? `<br>Motivo da divergência: ${esc(rs.caixa.motivo_divergencia)}` : ''}</div>` : ''}
  ${rs.fiado_vendido || rs.fiado_recebido ? `<div class="card">Vendido em fiado (a receber): <b>${R(rs.fiado_vendido)}</b> · Fiado recebido neste caixa: <b>${R(rs.fiado_recebido)}</b></div>` : ''}
  <h3 style="margin:14px 0 6px">Dinheiro em caixa</h3><div class="card"><table style="border:none"><tr><td>Abertura</td><td class="n">${R(c.valor_abertura)}</td></tr>
  <tr><td>+ Vendas em dinheiro</td><td class="n">${R(rs.formas.filter(f => f.tipo === 'dinheiro').reduce((s, f) => s + Number(f.total), 0))}</td></tr><tr><td>+ Suprimentos</td><td class="n">${R(rs.suprimentos)}</td></tr><tr><td>− Sangrias</td><td class="n">${R(rs.sangrias)}</td></tr>
  ${rs.doacoes ? `<tr><td>+ Doações (troco deixado na gaveta)</td><td class="n">${R(rs.doacoes)}</td></tr>` : ''}
  <tr><td><b>Esperado</b></td><td class="n"><b>${R(rs.dinheiro_em_caixa_esperado)}</b></td></tr>${c.status === 'fechado' ? `<tr><td>Contado</td><td class="n">${R(c.valor_informado)}</td></tr>` : ''}</table></div>
  ${rs.doacoes_por_destino && rs.doacoes_por_destino.length ? '<h3 style="margin:14px 0 6px">Doações por local (valor a entregar)</h3>' + tabela([{ l: 'Local', k: 'destino' }, { l: 'Doações', n: 1, k: 'n' }, { l: 'Valor', n: 1, f: r => R(r.total) }], rs.doacoes_por_destino) : ''}${rs.movimentos.length ? '<h3 style="margin:14px 0 6px">Sangrias e suprimentos</h3>' + tabela([{ l: 'Hora', f: r => dt(r.criado_em) }, { l: 'Tipo', k: 'tipo' }, { l: 'Motivo', k: 'motivo' }, { l: 'Valor', n: 1, f: r => R(r.valor) }], rs.movimentos) : ''}`;
}

registrar({ id: 'caixa', titulo: 'Painel de caixa', grupo: 'Operação', perm: 'caixa.acessar', render: el => telaCaixa(el) });

const SITU = { aberto: 'ABERTO', fechado: 'FECHADO', divergente: 'FECHADO DIVERGENTE' };
const situCaixa = c => (c.status === 'aberto' ? 'aberto' : Math.abs(Number(c.diferenca || 0)) > 0.004 ? 'divergente' : 'fechado');

async function comprovanteCaixa(id, numero) {
  const r = await api(`/caixa/${id}/comprovante`, { method: 'POST' });
  modal({ titulo: 'Comprovante de fechamento — caixa ' + numero, tam: 'md', corpo: `<pre style="font:13px/1.35 monospace;white-space:pre-wrap;margin:0">${esc(r.comprovante)}</pre><p class="${r.impressao.ok ? 'muted' : 'erro'}">${r.impressao.ok ? 'Enviado para a impressora.' : 'Não foi possível imprimir: ' + esc(r.impressao.erro)}</p>`,
    botoes: [{ txt: 'Imprimir tela', fn: () => { window.print(); return false; } }, { txt: 'OK', cls: 'primary' }] });
}
function reabrirCaixa(id, numero, depois) {
  formModal({ titulo: 'Reabrir caixa ' + numero, campos: [{ k: 'motivo', l: 'Motivo da reabertura', t: 'textarea', req: true, full: true }, ...camposAut], 
    extra: '<p class="muted">Ao reabrir, o fechamento atual é descartado e o caixa volta a ficar aberto para o operador. Confirme com usuário e senha de quem tem permissão.</p>',
    onSave: async o => { await api(`/caixa/${id}/reabrir`, { method: 'POST', body: { motivo: o.motivo, autorizacao: autDe(o) } }); toast('Caixa reaberto.'); depois(); } });
}

async function telaCaixa(el) {
  limparTimer();
  const [rs, lista] = await Promise.all([api('/caixa/atual'), api('/caixa')]);
  const est = { st: '', q: '', pg: 1, tam: 10, ord: 'numero', dir: -1 };
  const num = c => c.numero ?? c.id;
  const filtrados = () => {
    const q = est.q.toLowerCase();
    const v = { numero: num, usuario: c => c.usuario || '', aberto: c => c.aberto_em || '', fechado: c => c.fechado_em || '', calc: c => Number(c.total_calculado ?? -1e12), inf: c => Number(c.total_informado ?? -1e12),
      dif: c => Number(c.diferenca ?? -1e12), status: situCaixa, conf: c => (c.conferido ? 1 : 0) }[est.ord];
    return lista.filter(c => (!est.st || situCaixa(c) === est.st) && (!q || String(num(c)).includes(q) || (c.usuario || '').toLowerCase().includes(q)))
      .sort((a, b) => (v(a) > v(b) ? 1 : v(a) < v(b) ? -1 : 0) * est.dir);
  };
  const th = (k, l, cls = '') => `<th class="${cls}" data-ord="${k}">${l} <span class="srt">${est.ord === k ? (est.dir > 0 ? '▲' : '▼') : '⇅'}</span></th>`;
  const dinh = (c, k) => (c.status === 'fechado' && c[k] != null ? R(c[k]) : '—');

  el.innerHTML = `<div class="cxp">
    <div class="cxp-f"><label>Status<select id="fst"><option value="">Todos</option><option value="aberto">Aberto</option><option value="fechado">Fechado</option><option value="divergente">Fechado divergente</option></select></label>
      <button class="btn" id="limpar">Limpar</button></div>
    <div class="card cxp-c">
      <div class="cxp-bar"><input id="fq" placeholder="Buscar caixa (número ou usuário)" autocomplete="off">
        <button class="btn primary" id="abrir" ${rs ? 'disabled' : ''}>Abrir caixa [F2]</button>
        <button class="btn primary" id="fechar" ${rs && tem('caixa.fechar') ? '' : 'disabled'}>Fechar caixa [F3]</button>
        <span class="grow"></span><button class="btn" id="atualizar" title="Atualizar">↻</button><button class="btn" id="exportar">Exportar</button></div>
      <div class="rolar" id="cxt"></div><div class="cxp-pg" id="cxpg"></div></div></div>`;

  const desenhar = () => {
    const l = filtrados(), n = l.length, pgs = Math.max(1, Math.ceil(n / est.tam)); est.pg = Math.min(est.pg, pgs);
    const pag = l.slice((est.pg - 1) * est.tam, est.pg * est.tam);
    $('#cxt', el).innerHTML = `<table class="vt cxt"><thead><tr>${th('numero', 'Número')}${th('usuario', 'Usuário responsável')}${th('aberto', 'Data/hora abertura')}${th('fechado', 'Data/hora fechamento')}${th('calc', 'Valor calculado', 'n')}${th('inf', 'Valor informado', 'n')}${th('dif', 'Valor diferença', 'n')}${th('status', 'Status')}${th('conf', 'Conferido')}<th>Ações</th></tr></thead><tbody>` +
      (pag.map(c => { const s = situCaixa(c), d = c.status === 'fechado' && c.diferenca != null ? Number(c.diferenca) : null;
        return `<tr><td><b>${num(c)}</b></td><td>${esc(c.usuario)}</td><td>${dt(c.aberto_em)}</td><td>${c.fechado_em ? dt(c.fechado_em) : '—'}</td><td class="n">${dinh(c, 'total_calculado')}</td><td class="n">${dinh(c, 'total_informado')}</td>
          <td class="n ${d ? 'erro' : ''}">${d == null ? '—' : R(d)}</td><td><span class="st st-${s}">${SITU[s]}</span></td>
          <td><label class="sw" title="${c.conferido ? 'Conferido por ' + esc(c.conferido_por_nome || '') + ' em ' + dt(c.conferido_em) : 'Não conferido'}"><input type="checkbox" data-conf="${c.id}" ${c.conferido ? 'checked' : ''} ${c.status === 'fechado' && tem('caixa.conferir') ? '' : 'disabled'}><i></i></label></td>
          <td><button class="btn sm" data-menu="${c.id}" title="Ações">⋯</button></td></tr>`; }).join('') || '<tr><td colspan="10" class="muted" style="text-align:center;padding:24px">Nenhum caixa encontrado.</td></tr>') + '</tbody></table>';
    const de = n ? (est.pg - 1) * est.tam + 1 : 0, ate = Math.min(n, est.pg * est.tam);
    const nums = []; for (let i = Math.max(1, est.pg - 2); i <= Math.min(pgs, est.pg + 2); i++) nums.push(i);
    $('#cxpg', el).innerHTML = `<span class="muted">${de} – ${ate} de ${n}</span><button class="btn sm" data-pg="1" ${est.pg === 1 ? 'disabled' : ''}>«</button><button class="btn sm" data-pg="${est.pg - 1}" ${est.pg === 1 ? 'disabled' : ''}>‹</button>` +
      nums.map(i => `<button class="btn sm ${i === est.pg ? 'primary' : ''}" data-pg="${i}">${i}</button>`).join('') +
      `<button class="btn sm" data-pg="${est.pg + 1}" ${est.pg === pgs ? 'disabled' : ''}>›</button><button class="btn sm" data-pg="${pgs}" ${est.pg === pgs ? 'disabled' : ''}>»</button>
      <select id="tam">${[10, 25, 50, 100].map(x => `<option ${x === est.tam ? 'selected' : ''}>${x}</option>`).join('')}</select>`;
  };
  desenhar();

  // ---- menu de ações (⋯)
  const fecharMenu = () => document.querySelectorAll('.cxmenu').forEach(m => m.remove());
  const abrirMenu = (btn, c) => {
    fecharMenu();
    const meu = rs && rs.caixa && rs.caixa.id === c.id, ab = c.status === 'aberto', fe = c.status === 'fechado';
    const itens = [
      [meu && ab && tem('caixa.fechar'), 'Fechar caixa', () => fecharCaixa(el, rs, {})],
      [fe && tem('caixa.reabrir'), 'Reabrir caixa', () => reabrirCaixa(c.id, num(c), () => telaCaixa(el))],
      [meu && ab && tem('caixa.movimentar'), 'Realizar movimento (sangria/suprimento)', () => formModal({ titulo: 'Movimento de caixa', campos: [{ k: 'tipo', l: 'Tipo', t: 'select', op: [['sangria', 'Sangria (retirada de dinheiro)'], ['suprimento', 'Suprimento (entrada de dinheiro)']], full: true }, { k: 'valor', l: 'Valor (R$)', t: 'number', step: '0.01', req: true, full: true }, { k: 'motivo', l: 'Motivo', req: true, full: true }],
        onSave: async o => { await api('/caixa/movimento', { method: 'POST', body: o }); toast('Registrado.'); telaCaixa(el); } })],
      [true, 'Resumo do caixa', async () => { const r = await api('/caixa/' + c.id); modal({ titulo: 'Caixa ' + num(c), tam: 'md', corpo: resumoCaixaHtml(r), botoes: [{ txt: 'Imprimir', fn: () => { window.print(); return false; } }, { txt: 'Fechar', cls: 'primary' }] }); }],
      [true, 'Conferência de caixa (movimentações)', () => movimentacoes(c.id)],
      [tem('caixa.alterar_forma'), 'Alterar forma de pagamento', () => alterarForma(c.id)],
      [fe, 'Reimprimir comprovante de fechamento', () => comprovanteCaixa(c.id, num(c))]].filter(i => i[0]);
    const m = document.createElement('div'); m.className = 'cxmenu';
    itens.forEach(([, txt, fn]) => { const b = document.createElement('button'); b.textContent = txt; b.onclick = seguro(async () => { fecharMenu(); await fn(); }); m.appendChild(b); });
    document.body.appendChild(m);
    const r = btn.getBoundingClientRect(), h = m.offsetHeight;
    m.style.top = (r.bottom + h > innerHeight ? Math.max(8, r.top - h) : r.bottom) + 'px'; m.style.left = Math.max(8, r.right - m.offsetWidth) + 'px';
  };
  if (window._mdCaixa) document.removeEventListener('mousedown', window._mdCaixa);
  window._mdCaixa = e => { if (!e.target.closest('.cxmenu') && !e.target.closest('[data-menu]')) fecharMenu(); };
  document.addEventListener('mousedown', window._mdCaixa);

  const abrirCaixa = async () => {
    let ids = []; try { ids = (await api('/caixa/cardapio/ultimo')).ids; } catch { }
    const op = await api('/caixa/equipe-opcoes');
    let equipe = [{ usuario_id: S.user.id, perfil_id: (op.usuarios.find(u => u.id === S.user.id) || {}).perfil_id || '' }];
    const equipeHtml = () => `<table class="tcb"><thead><tr><th>Colaborador</th><th>Função neste evento</th><th></th></tr></thead><tbody>${equipe.map((m, i) => `<tr><td><select data-eu="${i}">${op.usuarios.map(u => `<option value="${u.id}" ${u.id == m.usuario_id ? 'selected' : ''}>${esc(u.nome)}${u.cargo ? ' (' + esc(u.cargo) + ')' : ''}</option>`).join('')}</select></td>
      <td><select data-ef="${i}">${op.funcoes.map(f => `<option value="${f.id}" ${f.id == m.perfil_id ? 'selected' : ''}>${esc(f.nome)}</option>`).join('')}</select></td><td>${i ? `<button class="btn sm danger" type="button" data-ex="${i}">✕</button>` : ''}</td></tr>`).join('')}</tbody></table>`;
    const m = formModal({ titulo: 'Abrir caixa / iniciar evento', tam: 'lg', campos: [{ k: 'evento', l: 'Nome do evento', req: true, full: true, ph: 'Ex.: Festa Junina 2026' }, { k: 'valor_abertura', l: 'Valor de abertura (troco inicial, R$)', t: 'number', step: '0.01', full: true }], valores: { valor_abertura: '0' },
      extra: '<div class="cbarras"><h4>Equipe do evento e função de cada um</h4><p class="muted">Durante este evento cada pessoa só terá liberado o que a <b>função</b> escolhida permite (administradores não são limitados). Quem não estiver na lista continua com o acesso normal do cadastro. Quando o caixa fechar, todos voltam ao perfil de sempre.</p><div id="eqb"></div><button class="btn sm" type="button" id="eqa">+ Adicionar colaborador</button></div><div class="cbarras"><h4>Produtos que serão vendidos neste caixa / evento</h4><p class="muted" id="abpn"></p><button class="btn" type="button" id="abpp">Escolher produtos</button></div>',
      onSave: async o => {
        const vistos = new Set(); for (const e of equipe) { if (!e.perfil_id) throw new Error('Escolha a função de cada colaborador da equipe.'); if (vistos.has(+e.usuario_id)) throw new Error('Há um colaborador repetido na equipe.'); vistos.add(+e.usuario_id); }
        await api('/caixa/abrir', { method: 'POST', body: { valor_abertura: Number(o.valor_abertura) || 0, evento: o.evento, equipe: equipe.map(e => ({ usuario_id: +e.usuario_id, perfil_id: +e.perfil_id })), produtos: ids } });
        toast('Caixa aberto. Evento: ' + o.evento); await sincronizarPerfil();
          if (tem('vendas.acessar')) { location.hash = '#/vendas'; return; }   // caixa aberto: já entra na tela de vendas
          telaCaixa(el); } });
    const desenhaEq = () => { $('#eqb', m.body).innerHTML = equipeHtml(); };
    desenhaEq();
    m.body.addEventListener('change', e => { const t = e.target;
      if (t.dataset.eu !== undefined) { const i = +t.dataset.eu; equipe[i].usuario_id = +t.value; equipe[i].perfil_id = (op.usuarios.find(u => u.id === +t.value) || {}).perfil_id || equipe[i].perfil_id; desenhaEq(); }
      if (t.dataset.ef !== undefined) equipe[+t.dataset.ef].perfil_id = +t.value; });
    m.body.addEventListener('click', e => { const t = e.target;
      if (t.id === 'eqa') { const livre = op.usuarios.find(u => !equipe.some(x => x.usuario_id == u.id)); if (!livre) return toast('Todos os colaboradores ativos já estão na equipe.', 'aviso'); equipe.push({ usuario_id: livre.id, perfil_id: livre.perfil_id || '' }); desenhaEq(); }
      if (t.dataset.ex !== undefined) { equipe.splice(+t.dataset.ex, 1); desenhaEq(); } });
    const txt = () => { $('#abpn', m.body).textContent = ids.length ? `${ids.length} produto(s) escolhido(s) (iguais aos do último caixa; altere se precisar).` : 'Nenhum produto escolhido: a tela de vendas mostrará todos os produtos.'; };
    txt();
    $('#abpp', m.body).onclick = seguro(async () => { const r = await escolherProdutos(ids); if (r) { ids = r; txt(); } });
  };
  const fechar = () => { if (rs && tem('caixa.fechar')) fecharCaixa(el, rs, {}); };

  el.onclick = seguro(async e => {
    const t = e.target;
    if (t.id === 'abrir') return abrirCaixa();
    if (t.id === 'fechar') return fechar();
    if (t.id === 'atualizar') return telaCaixa(el);
    if (t.id === 'limpar') { est.st = ''; est.q = ''; est.pg = 1; $('#fst', el).value = ''; $('#fq', el).value = ''; return desenhar(); }
    if (t.id === 'exportar') {
      const csv = [['Número', 'Usuário', 'Abertura', 'Fechamento', 'Valor calculado', 'Valor informado', 'Diferença', 'Status', 'Conferido']].concat(filtrados().map(c => [num(c), c.usuario, dt(c.aberto_em), c.fechado_em ? dt(c.fechado_em) : '', c.total_calculado ?? '', c.total_informado ?? '', c.diferenca ?? '', SITU[situCaixa(c)], c.conferido ? 'Sim' : 'Não']))
        .map(l => l.map(x => '"' + String(x).replace(/"/g, '""') + '"').join(';')).join('\r\n');
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' })); a.download = 'caixas.csv'; a.click(); return;
    }
    const o = t.closest('[data-ord]'); if (o) { est.dir = est.ord === o.dataset.ord ? -est.dir : 1; est.ord = o.dataset.ord; return desenhar(); }
    const pg = t.closest('[data-pg]'); if (pg) { est.pg = Number(pg.dataset.pg); return desenhar(); }
    const mn = t.closest('[data-menu]'); if (mn) return abrirMenu(mn, lista.find(c => c.id == mn.dataset.menu));
  });
  el.onchange = seguro(async e => {
    const t = e.target;
    if (t.id === 'fst') { est.st = t.value; est.pg = 1; return desenhar(); }
    if (t.id === 'tam') { est.tam = Number(t.value); est.pg = 1; return desenhar(); }
    if (t.dataset.conf) {
      const c = lista.find(x => x.id == t.dataset.conf);
      try { await api(`/caixa/${c.id}/conferido`, { method: 'POST', body: { conferido: t.checked } }); c.conferido = t.checked; c.conferido_por_nome = S.user.nome; c.conferido_em = new Date().toISOString(); toast(t.checked ? 'Caixa marcado como conferido.' : 'Conferência removida.'); }
      catch (er) { t.checked = !t.checked; throw er; }
    }
  });
  $('#fq', el).oninput = e => { est.q = e.target.value.trim(); est.pg = 1; desenhar(); };
  const teclas = e => {
    if (!document.body.contains(el) || !$('#cxt', el) || document.querySelector('.modal-bg')) return;
    if (e.key === 'F2') { e.preventDefault(); if (!rs) abrirCaixa(); } else if (e.key === 'F3') { e.preventDefault(); fechar(); }
  };
  if (window._teclasCaixa) document.removeEventListener('keydown', window._teclasCaixa);
  window._teclasCaixa = seguro(teclas); document.addEventListener('keydown', window._teclasCaixa);
  let auto = false; try { auto = sessionStorage.getItem('abrirCaixaAuto') === '1'; sessionStorage.removeItem('abrirCaixaAuto'); } catch { }
  if (auto && !rs) abrirCaixa();   // veio da tela de vendas sem caixa aberto: já pede a abertura
}

// ---- Fechamento de caixa: informa o total de cada forma; divergência pede confirmação + motivo
async function fecharPelaVenda(el) {
  const rs = await api('/caixa/atual');
  if (!rs) return toast('Você não tem caixa aberto.', 'aviso');
  fecharCaixa(el, rs, {}, () => { location.hash = '#/caixa'; });
}
async function alterarPelaVenda() {
  const rs = await api('/caixa/atual');
  if (!rs) return toast('Você não tem caixa aberto.', 'aviso');
  alterarForma(rs.caixa.id);
}
async function fecharCaixa(el, rs, previos, depois) {
  let ins = []; try { ins = await api('/caixa/insumos-fechamento'); } catch { }
  const extra = rs.comandas_abertas_do_usuario ? `<p class="erro">Atenção: você ainda tem ${rs.comandas_abertas_do_usuario} venda(s) em andamento.</p>` : '';
  const corpo = document.createElement('div');
  corpo.innerHTML = `${extra}<p class="muted">Informe o <b>valor total de cada forma de pagamento</b> usada neste caixa (use 0 se não houve). Em Dinheiro, informe o que foi contado na gaveta.</p>` +
    rs.linhas.map(l => `<label>${esc(l.descricao)} (R$) *<input data-f="${esc(l.forma)}" inputmode="decimal" value="${esc(previos[l.forma] ?? '')}" placeholder="0,00"></label>`).join('') +
    (ins.length ? `<h4 style="margin:16px 0 4px">Sobra de insumos</h4><p class="muted">Conte o que <b>sobrou</b> de cada insumo usado nas produções. O sistema baixa do estoque o que foi realmente usado (estoque − sobra). Se deixar em branco, vale o consumo previsto pela ficha técnica.</p>` +
      tabela([{ l: 'Insumo', k: 'nome' }, { l: 'Estoque atual', n: 1, f: x => N(x.estoque_atual) + ' ' + x.unidade }, { l: 'Uso previsto', n: 1, f: x => N(x.previsto) + ' ' + x.unidade },
        { l: 'Sobrou (contagem)', f: x => `<input data-s="${x.insumo_id}" inputmode="decimal" style="width:110px" placeholder="${N(Math.max(0, x.estoque_atual - x.previsto))}">` }, { l: 'Uso real', n: 1, f: x => `<b data-ur="${x.insumo_id}">—</b>` }], ins) : '');
  const lerSobras = () => { const s = {}; $$('[data-s]', corpo).forEach(i => { if (i.value.trim() !== '') s[i.dataset.s] = numIn(i.value); }); return s; };
  corpo.addEventListener('input', e => { const id = e.target.dataset && e.target.dataset.s; if (!id) return; const x = ins.find(z => z.insumo_id == id), b = $(`[data-ur="${id}"]`, corpo);
    b.textContent = e.target.value.trim() === '' ? '—' : N(Math.round((x.estoque_atual - numIn(e.target.value)) * 1000) / 1000) + ' ' + x.unidade; });
  const ler = () => { const v = {}; $$('[data-f]', corpo).forEach(i => (v[i.dataset.f] = i.value.trim() === '' ? '' : numIn(i.value))); return v; };
  const finalizar = async (valores, extraBody) => {
    const r = await api('/caixa/fechar', { method: 'POST', body: { valores, sobras: lerSobras(), ...extraBody } });
    if (depois) depois(); else await telaCaixa(el);
    const falhou = r.impressao && !r.impressao.ok;
    modal({ titulo: 'Caixa fechado — comprovante', tam: 'md', corpo: `<pre style="font:13px/1.35 monospace;white-space:pre-wrap;margin:0">${esc(r.comprovante)}</pre>${(r.insumos || []).length ? '<h4 style="margin:12px 0 4px">Insumos usados nas produções</h4>' + tabela([{ l: 'Insumo', k: 'nome' }, { l: 'Previsto', n: 1, f: x => N(x.consumo_previsto) + ' ' + x.unidade }, { l: 'Sobrou', n: 1, f: x => (x.sobra_informada == null ? '—' : N(x.sobra_informada)) }, { l: 'Usado (baixado)', n: 1, f: x => N(x.consumo_real) + ' ' + x.unidade }, { l: 'Diferença', n: 1, f: x => `<span class="${Number(x.diferenca) ? 'erro' : ''}">${(x.diferenca > 0 ? '+' : '') + N(x.diferenca)}</span>` }], r.insumos) : ''}${falhou ? `<p class="erro">Não foi possível imprimir: ${esc(r.impressao.erro)}. Use "Imprimir tela" ou reimprima na Conferência de caixas.</p>` : '<p class="muted">Comprovante enviado para a impressora do caixa.</p>'}`,
      botoes: [{ txt: 'Imprimir tela', fn: () => { window.print(); return false; } }, { txt: 'OK', cls: 'primary' }] });
  };
  modal({ titulo: 'Fechar caixa', corpo, botoes: [{ txt: 'Cancelar' }, { txt: 'Conferir e fechar', cls: 'primary', fn: async m => {
    const valores = ler(); const falta = rs.linhas.filter(l => valores[l.forma] === '');
    if (falta.length) throw new Error('Informe o valor de: ' + falta.map(l => l.descricao).join(', '));
    try { await finalizar(valores, {}); }
    catch (e) {
      if (!e.data?.divergencia) throw e;
      m.fechar(); divergencia(el, rs, e.data.linhas, valores, finalizar, depois); return false;
    }
  } }] });
}
function divergencia(el, rs, linhas, valores, finalizar, depois) {
  const total = linhas.reduce((s, l) => s + l.diferenca, 0);
  modal({ titulo: '⚠ Divergência de valores', tam: 'md', corpo: `<p class="erro"><b>Há divergência entre o valor calculado pelo sistema e o valor informado.</b></p>
    ${tabela([{ l: 'Forma', k: 'descricao' }, { l: 'Calculado', n: 1, f: r => R(r.calculado) }, { l: 'Informado', n: 1, f: r => R(r.informado) }, { l: 'Diferença', n: 1, f: r => `<b class="${r.diferenca ? 'erro' : ''}">${(r.diferenca > 0 ? '+' : '') + R(r.diferenca)}</b>` }], linhas)}
    <p>Diferença total: <b class="erro">${(total > 0 ? '+' : '') + R(total)}</b></p><p>O que deseja fazer?</p>`,
    botoes: [{ txt: 'Reconferir valores', fn: () => { fecharCaixa(el, rs, Object.fromEntries(Object.entries(valores).map(([k, v]) => [k, String(v).replace('.', ',')])), depois); } },
      { txt: 'Fechar com divergência', cls: 'danger', fn: () => {
        formModal({ titulo: 'Motivo da divergência', campos: [{ k: 'motivo', l: 'Informe o motivo da divergência', t: 'textarea', req: true, full: true }],
          onSave: async o => { await finalizar(valores, { confirmar_divergencia: true, motivo: o.motivo }); } });
      } }] });
}

// Janela do comprovante de pagamento do fiado: mostra o resultado, o texto impresso e permite reimprimir
function comprovanteFiadoJanela(r) {
  const pg = r.pagamento || {}, im = pg.impressao || {};
  const status = im.ok ? '<p>✅ Comprovante de pagamento <b>impresso</b> para o cliente.</p>' : `<p style="color:#b45309">⚠️ O comprovante <b>não imprimiu</b>${im.erro ? ': ' + esc(im.erro) : ''}. Use "Reimprimir" ou mostre a tela ao cliente.</p>`;
  const resumo = r.quitado ? '<p>✅ Fiado <b>quitado</b>.</p>' : `<p>✅ Recebimento registrado. Restam <b>${R(r.saldo_restante)}</b> nesta venda.</p>`;
  modal({ titulo: 'Pagamento de fiado recebido', tam: 'md', corpo: `${resumo}${status}${pg.texto ? `<pre style="font:13px/1.35 monospace;white-space:pre-wrap;margin:8px 0 0;background:#f6f6f6;padding:10px;border-radius:8px">${esc(pg.texto)}</pre>` : ''}`,
    botoes: [...(pg.id ? [{ txt: 'Reimprimir', fn: async () => { const x = await api(`/fiado/pagamentos/${pg.id}/comprovante`, { method: 'POST' }); x.impressao.ok ? toast('Comprovante reimpresso.') : toast('Não imprimiu: ' + x.impressao.erro, 'aviso'); return false; } }] : []), { txt: 'OK', cls: 'primary' }] });
}
// Consulta de fiado por cliente (tela de vendas): débitos em aberto, itens de cada venda e recebimento
async function consultaFiadoClientes(depois) {
  const d = await api('/fiado/pendentes');
  const box = document.createElement('div');
  const grupos = () => { const m = new Map(); d.titulos.forEach(t => { const g = m.get(t.cliente_id) || { id: t.cliente_id, nome: t.cliente, n: 0, saldo: 0 }; g.n++; g.saldo += Number(t.saldo); m.set(t.cliente_id, g); }); return [...m.values()].sort((a, b) => a.nome.localeCompare(b.nome)); };
  let sel = null, quit = false;
  const hoje = new Date().toISOString().slice(0, 10);
  const desenhaLista = () => {
    const q = ($('#fcq', box) ? $('#fcq', box).value : '').toLowerCase();
    const l = grupos().filter(g => !q || g.nome.toLowerCase().includes(q));
    $('#fclista', box).innerHTML = l.map(g => `<button type="button" class="btn ${sel === g.id ? 'primary' : ''}" data-cli="${g.id}" style="display:flex;justify-content:space-between;gap:8px;width:100%;text-align:left;margin-bottom:6px"><span>${esc(g.nome)}<br><small>${g.n} venda(s)</small></span><b>${R(g.saldo)}</b></button>`).join('') || '<p class="muted">Nenhum cliente com fiado em aberto.</p>';
  };
  const desenhaDetalhe = async () => {
    const dv = $('#fcdet', box);
    if (!sel) { dv.innerHTML = '<p class="muted" style="padding:14px">Escolha um cliente ao lado para ver as vendas em fiado dele.</p>'; return; }
    const r = await api(`/fiado/cliente/${sel}?quitados=${quit ? 1 : 0}`);
    const aberto = r.titulos.filter(t => t.status === 'aberto'), tot = aberto.reduce((s2, t) => s2 + Number(t.saldo), 0);
    dv.innerHTML = `<div class="row" style="align-items:center"><div><b style="font-size:17px">${esc(r.cliente ? r.cliente.nome : '')}</b>${r.cliente && r.cliente.telefone ? ' <span class="muted">· ' + esc(r.cliente.telefone) + '</span>' : ''}</div><div class="grow"></div><div style="text-align:right"><span class="muted">Total em aberto</span><br><b style="font-size:22px">${R(tot)}</b></div></div>
      <label class="chk" style="margin:8px 0"><input type="checkbox" id="fcq2" ${quit ? 'checked' : ''}> Mostrar também as vendas já quitadas</label>
      <div class="rolar" style="max-height:46vh">${tabela([{ l: 'Venda', f: t => pad6(t.num) }, { l: 'Data', f: t => dia(t.criado_em) }, { l: 'Vencimento', f: t => (t.status === 'aberto' && String(t.vencimento).slice(0, 10) < hoje ? `<b class="erro">${dia(t.vencimento)} (vencido)</b>` : dia(t.vencimento)) },
        { l: 'Valor', n: 1, f: t => R(t.valor) }, { l: 'Saldo', n: 1, f: t => (t.status === 'aberto' ? `<b>${R(t.saldo)}</b>` : '<span class="muted">quitado</span>') }], r.titulos,
        { vazio: 'Nenhuma venda em fiado.', acoes: t => `<button class="btn sm" data-itens="${t.pedido_id}" data-num="${t.num}">Itens</button>${t.status === 'aberto' && tem('vendas.receber') ? ` <button class="btn sm primary" data-baixa="${t.id}">Receber</button>` : ''}` })}</div>`;
    dv._t = r.titulos;
  };
  box.innerHTML = `<div style="display:grid;grid-template-columns:minmax(220px,300px) 1fr;gap:14px"><div><input id="fcq" placeholder="Buscar cliente..." style="width:100%;margin-bottom:8px"><div id="fclista" style="max-height:58vh;overflow:auto"></div></div><div id="fcdet"></div></div>`;
  box.onclick = seguro(async e => {
    const b = e.target.closest('button'); const cb = e.target.id === 'fcq2';
    if (cb) { quit = e.target.checked; return desenhaDetalhe(); }
    if (!b) return;
    if (b.dataset.cli) { sel = Number(b.dataset.cli); desenhaLista(); return desenhaDetalhe(); }
    if (b.dataset.itens) return itensDaVenda(b.dataset.itens, b.dataset.num);
    if (b.dataset.baixa) {
      if (!d.caixas.length) return aviso('Para receber fiado é necessário ter um caixa aberto.\nAbra o seu caixa no menu Caixa.', 'Caixa fechado');
      const t = d.titulos.find(x => x.id == b.dataset.baixa); if (!t) return;
      return baixarFiado(t, d, async () => { const n = await api('/fiado/pendentes'); d.titulos = n.titulos; desenhaLista(); await desenhaDetalhe(); if (depois) depois(); });
    }
  });
  const m = modal({ titulo: 'Fiado por cliente — consultar e receber', tam: 'lg', corpo: box, botoes: [{ txt: 'Fechar', cls: 'primary' }] });
  box.addEventListener('input', e => { if (e.target.id === 'fcq') desenhaLista(); });
  desenhaLista(); desenhaDetalhe();
  return m;
}
const pad6 = n => String(n || 0).padStart(6, '0');
// Itens de uma venda (consulta)
async function itensDaVenda(pedidoId, num) {
  const p = await api('/pedidos/' + pedidoId);
  const its = p.itens.filter(i => i.status !== 'cancelado');
  modal({ titulo: 'Itens da venda ' + pad6(num || p.venda_numero || p.id), tam: 'md', corpo: `<p class="muted">${dt(p.aberto_em)}${p.usuario ? ' · operador ' + esc(p.usuario) : ''}${p.cliente ? ' · cliente ' + esc(p.cliente) : ''}</p>` +
    tabela([{ l: 'Produto', f: i => `<b>${esc(i.nome)}</b>${i.observacao ? `<br><small class="muted">obs.: ${esc(i.observacao)}</small>` : ''}` }, { l: 'Qtd', n: 1, f: i => N(i.quantidade) }, { l: 'Unitário', n: 1, f: i => R(i.preco_unit) }, { l: 'Total', n: 1, f: i => R(i.quantidade * i.preco_unit) }], its, { vazio: 'Sem itens.' }) +
    `<p style="text-align:right;margin:10px 0 0">Subtotal ${R(p.subtotal)}${Number(p.desconto) ? ' · desconto −' + R(p.desconto) : ''}${Number(p.arredondamento) ? ' · arredondamento ' + R(p.arredondamento) : ''} · <b>Total ${R(p.status === 'aberto' ? p.subtotal - Number(p.desconto || 0) : p.total)}</b></p>` +
    (p.pagamentos && p.pagamentos.length ? `<p class="muted" style="margin:6px 0 0">Pagamentos: ${p.pagamentos.map(g => esc(g.forma) + ' ' + R(g.valor)).join(' · ')}</p>` : ''), botoes: [{ txt: 'OK', cls: 'primary' }] });
}

// Modal de baixa (recebimento) de um fiado. t = título; d = { caixas }; depois = função chamada após o recebimento
async function baixarFiado(t, d, depois) {
    const formas = (await api('/formas-pagamento?ativas=1')).filter(f => f.tipo !== 'fiado');
    const corpo = document.createElement('div');
    corpo.innerHTML = `<div class="card"><b>${esc(t.cliente)}</b><br><span class="muted">${esc(t.descricao)} · saldo ${R(t.saldo)}</span></div>
      <label>Caixa que receberá o valor<select id="cx">${d.caixas.map(c => `<option value="${c.id}">Caixa ${c.numero ?? c.id} — aberto ${dt(c.aberto_em)}</option>`).join('')}</select></label>
      <label>Forma de pagamento<select id="fp">${formas.map(f => `<option value="${esc(f.codigo)}">${esc(f.descricao)}${f.tef_ativo ? ' (TEF)' : ''}</option>`).join('')}</select></label>
      <label>Valor recebido (R$)<input id="vl" inputmode="decimal" value="${String(Number(t.saldo)).replace('.', ',')}"></label><p class="muted">Pagamento parcial é permitido; o restante continua em aberto.</p>`;
    modal({ titulo: 'Baixar fiado', corpo, botoes: [{ txt: 'Cancelar' }, { txt: 'Confirmar recebimento', cls: 'ok', fn: async m => {
      const f = formas.find(x => x.codigo === $('#fp', corpo).value); const valor = numIn($('#vl', corpo).value);
      if (!(valor > 0)) throw new Error('Informe o valor recebido.');
      let tef_ref;
      if (f.tef_ativo) {
        const aguarde = modal({ titulo: 'Aguardando o cartão (TEF)', corpo: `<p>Siga as instruções no PIN-pad.</p><p><b>${esc(f.descricao)}: ${R(valor)}</b></p>`, botoes: [] });
        let x; try { x = await api('/tef/transacao', { method: 'POST', body: { forma: f.codigo, valor, parcelas: 1 } }); } catch (er) { aguarde.fechar(); throw er; }
        aguarde.fechar(); if (!x.aprovado) throw new Error('TEF: ' + x.mensagem); tef_ref = x.ref;
      }
      let r;
      try { r = await api('/fiado/baixar', { method: 'POST', body: { titulo_id: t.id, caixa_id: Number($('#cx', corpo).value), forma: f.codigo, valor, tef_ref } }); }
      catch (er) { if (tef_ref) await api('/tef/desfazer', { method: 'POST', body: { refs: [tef_ref] } }).catch(() => {}); throw er; }
      m.fechar(); if (depois) await depois(); comprovanteFiadoJanela(r);
      return false;
    } }] });
}

// ---- Receber (baixar) fiado — exige caixa aberto
registrar({ id: 'fiado', titulo: 'Receber fiado', grupo: 'Operação', perm: 'vendas.receber', render: el => telaFiado(el) });
async function telaFiado(el) {
  limparTimer();
  const d = await api('/fiado/pendentes');
  const semCaixa = !d.caixas.length;
  const total = d.titulos.reduce((s, t) => s + Number(t.saldo), 0);
  el.innerHTML = (semCaixa ? `<div class="card" style="border-color:var(--err)"><b class="erro">Para baixar fiados é necessário ter um caixa aberto.</b><p style="margin:6px 0 0">Abra o seu caixa no menu <a href="#/caixa">Caixa</a> e volte a esta tela.</p></div>` : '') +
    `<div class="bar"><input id="bq" placeholder="Buscar cliente..."><div class="grow"></div><span class="muted">Total em aberto: <b>${R(total)}</b></span></div><div id="lista"></div>`;
  const desenhar = () => {
    const q = $('#bq', el).value.toLowerCase();
    const lista = d.titulos.filter(t => !q || t.cliente.toLowerCase().includes(q));
    $('#lista', el).innerHTML = tabela([{ l: 'Cliente', k: 'cliente' }, { l: 'Origem', f: t => esc(t.descricao) }, { l: 'Vencimento', f: t => dia(t.vencimento) }, { l: 'Valor', n: 1, f: t => R(t.valor) }, { l: 'Saldo', n: 1, f: t => `<b>${R(t.saldo)}</b>` }], lista,
      { vazio: 'Nenhum fiado em aberto.', acoes: t => `<button class="btn sm primary" data-b="${t.id}">Baixar</button>` });
  };
  desenhar(); $('#bq', el).oninput = desenhar;
  el.onclick = seguro(async e => {
    const id = e.target.dataset.b; if (!id) return;
    if (semCaixa) return aviso('Para baixar fiados é necessário ter um caixa aberto.\nAbra o seu caixa no menu Caixa.', 'Caixa fechado');
    const t = d.titulos.find(x => x.id == id);
    baixarFiado(t, d, () => telaFiado(el));
  });
}

// ---- Conferência de caixas (abertos e fechados): movimentações, comprovante, reabrir e alterar forma
registrar({ id: 'conferencia', titulo: 'Conferência de caixas', grupo: 'Operação', perm: 'caixa.conferir', render: el => telaConferencia(el) });
const camposAut = [{ k: 'aut_login', l: 'Usuário (autorizador)', req: true }, { k: 'aut_senha', l: 'Senha', t: 'password', req: true }];
const autDe = o => ({ login: o.aut_login, senha: o.aut_senha });
async function telaConferencia(el, filtro = 'todos') {
  limparTimer();
  let lista = await api('/caixa');
  const tab = (s, t) => `<button class="${filtro === s ? 'on' : ''}" data-st="${s}">${t}</button>`;
  if (filtro !== 'todos') lista = lista.filter(c => c.status === filtro);
  el.innerHTML = `<div class="bar"><div class="tabs" style="margin:0">${tab('todos', 'Todos')}${tab('aberto', 'Abertos')}${tab('fechado', 'Fechados')}</div></div>` + tabela([{ l: '#', k: 'id' }, { l: 'Operador', k: 'usuario' }, { l: 'Abertura', f: r => dt(r.aberto_em) }, { l: 'Fechamento', f: r => dt(r.fechado_em) },
    { l: 'Status', f: r => chip(r.status, r.status === 'aberto' ? 'ok' : '') }, { l: 'Dif. no fechamento', n: 1, f: r => (r.diferenca != null ? `<b class="${Number(r.diferenca) ? 'erro' : ''}">${(r.diferenca > 0 ? '+' : '') + R(r.diferenca)}</b>` : '') }], lista,
    { vazio: 'Nenhum caixa.', acoes: r => `<button class="btn sm" data-mov="${r.id}">Movimentações</button> ` +
      (r.status === 'fechado' ? `<button class="btn sm" data-comp="${r.id}">Comprovante</button> ` : '') +
      (r.status === 'fechado' && tem('caixa.reabrir') ? `<button class="btn sm" data-reab="${r.id}">Reabrir</button> ` : '') +
      (tem('caixa.alterar_forma') ? `<button class="btn sm" data-alt="${r.id}">Alterar forma de pagamento</button>` : '') });
  el.onclick = seguro(async e => {
    const d = e.target.dataset;
    if (d.st) return telaConferencia(el, d.st);
    if (d.mov) return movimentacoes(+d.mov);
    if (d.comp) { const r = await api(`/caixa/${d.comp}/comprovante`, { method: 'POST' }); return modal({ titulo: 'Comprovante de fechamento — caixa #' + d.comp, tam: 'md', corpo: `<pre style="font:13px/1.35 monospace;white-space:pre-wrap;margin:0">${esc(r.comprovante)}</pre><p class="${r.impressao.ok ? 'muted' : 'erro'}">${r.impressao.ok ? 'Reimpresso na impressora do caixa.' : 'Não imprimiu: ' + esc(r.impressao.erro)}</p>`, botoes: [{ txt: 'Imprimir tela', fn: () => { window.print(); return false; } }, { txt: 'OK', cls: 'primary' }] }); }
    if (d.reab) return formModal({ titulo: 'Reabrir caixa #' + d.reab, campos: [{ k: 'motivo', l: 'Motivo da reabertura', t: 'textarea', req: true, full: true }, ...camposAut], 
      extra: '<p class="muted">Ao reabrir, o fechamento atual é descartado e o caixa volta a ficar aberto para o operador. Confirme com usuário e senha de quem tem permissão.</p>',
      onSave: async o => { await api(`/caixa/${d.reab}/reabrir`, { method: 'POST', body: { motivo: o.motivo, autorizacao: autDe(o) } }); toast('Caixa reaberto.'); telaConferencia(el, filtro); } });
    if (d.alt) return alterarForma(+d.alt);
  });
}
async function movimentacoes(id) {
  const base = await api(`/caixa/${id}/movimentacoes`);
  const formas = [...new Map(base.movimentos.map(m => [m.forma, m.forma_desc])).entries()];
  const corpo = document.createElement('div');
  corpo.innerHTML = `<div class="bar"><label style="margin:0">Forma de pagamento<select id="ff"><option value="">Todas</option>${formas.map(f => `<option value="${esc(f[0])}">${esc(f[1])}</option>`).join('')}</select></label><div class="grow"></div><b id="tt"></b></div><div id="lm"></div>`;
  const desenhar = d => {
    $('#tt', corpo).textContent = 'Total: ' + R(d.total);
    $('#lm', corpo).innerHTML = tabela([{ l: 'Hora', f: r => dt(r.criado_em) }, { l: 'Tipo', k: 'tipo' }, { l: 'Referência', f: r => esc([r.ref, r.pedido_id ? '#' + r.pedido_id : '', r.cliente, r.motivo].filter(Boolean).join(' · ')) }, { l: 'Forma', k: 'forma_desc' },
      { l: 'Valor', n: 1, f: r => `<span class="${Number(r.valor) < 0 ? 'erro' : ''}">${R(r.valor)}</span>` }], d.movimentos, { vazio: 'Sem movimentações para o filtro.' });
  };
  desenhar(base);
  $('#ff', corpo).onchange = seguro(async ev => desenhar(await api(`/caixa/${id}/movimentacoes?` + qs({ forma: ev.target.value }))));
  modal({ titulo: `Movimentações — caixa #${id}`, tam: 'lg', corpo, botoes: [{ txt: 'Fechar', cls: 'primary' }] });
}
async function alterarForma(id) {
  const corpo = document.createElement('div'); let formas = [];
  const carregar = seguro(async () => {
    const l = await api(`/caixa/${id}/pagamentos`);
    $('#lp', corpo).innerHTML = tabela([{ l: 'Hora', f: r => dt(r.criado_em) }, { l: 'Venda', f: r => esc(r.origem === 'recebimento_fiado' ? 'Recebimento fiado' : `Venda #${r.pedido_id}`) + (r.cliente ? `<br><small class="muted">${esc(r.cliente)}</small>` : '') }, { l: 'Forma atual', k: 'forma_desc' }, { l: 'Valor', n: 1, f: r => R(r.valor) }], l,
      { vazio: 'Nenhum pagamento neste caixa.', acoes: r => (r.tipo === 'fiado' ? '<span class="muted">Fiado — não alterável</span>' : r.tef_nsu ? '<span class="muted">TEF — não alterável</span>' : `<button class="btn sm" data-alt="${r.id}">Alterar</button>`) });
    $('#lp', corpo).onclick = seguro(async e => {
      const pid = e.target.dataset.alt; if (!pid) return; const p = l.find(x => x.id == pid);
      formas = (await api('/formas-pagamento?ativas=1')).filter(f => f.tipo !== 'fiado' && !f.tef_ativo && f.codigo !== p.forma);
      formModal({ titulo: `Alterar forma — ${p.origem === 'recebimento_fiado' ? 'recebimento fiado' : 'venda #' + p.pedido_id} (${R(p.valor)})`, 
        campos: [{ k: 'forma', l: 'Nova forma de pagamento', t: 'select', op: formas.map(f => [f.codigo, f.descricao]), full: true }, { k: 'motivo', l: 'Motivo da alteração', t: 'textarea', req: true, full: true }, ...camposAut],
        extra: '<p class="muted">Confirme com usuário e senha de quem tem permissão. Não é possível alterar para Fiado nem para formas com TEF.</p>',
        onSave: async o => { await api(`/caixa/pagamentos/${pid}/forma`, { method: 'POST', body: { forma: o.forma, motivo: o.motivo, autorizacao: autDe(o) } }); toast('Forma de pagamento alterada.'); carregar(); } });
    });
  });
  corpo.innerHTML = '<p class="muted">Escolha o pagamento que deseja corrigir. Vendas em fiado e pagamentos via TEF não podem ser alterados.</p><div id="lp"></div>';
  modal({ titulo: `Alterar forma de pagamento — caixa #${id}`, tam: 'lg', corpo, botoes: [{ txt: 'Fechar', cls: 'primary' }] });
  carregar();
}
