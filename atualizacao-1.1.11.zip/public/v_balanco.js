// Balanço geral de estoque: conferência de todo o estoque com leitor de código de barras (com ou sem acúmulo).
registrar({ id: 'balanco', titulo: 'Balanço geral', grupo: 'Estoque', perm: 'estoque.ajuste', render: el => telaBalanco(el) });

const BAL_ETAPAS = ['Data de início da Conferência', 'Bipar os produtos', 'Finalizar a Conferência', 'Realizar a Atualização do Estoque'];
const balEtapas = atual => `<div class="bal-et">${BAL_ETAPAS.map((t, i) => `<div class="${i + 1 === atual ? 'on' : i + 1 < atual ? 'ok' : ''}"><span>ETAPA ${i + 1}</span><b>${esc(t)}</b></div>`).join('<i>➜</i>')}</div>`;
if (!document.getElementById('bal-css')) {
  const st = document.createElement('style'); st.id = 'bal-css';
  st.textContent = `.bal-et{display:flex;align-items:stretch;gap:6px;margin:0 0 14px;flex-wrap:wrap}.bal-et>div{flex:1;min-width:130px;border-radius:12px;overflow:hidden;background:var(--b37);color:#5b6573;text-align:center}
.bal-et>div span{display:block;background:#9aa7b6;color:#fff;padding:6px;font-size:12px;letter-spacing:.5px}.bal-et>div b{display:block;padding:8px 6px;font-size:13px;font-weight:600}
.bal-et>div.on span{background:#0f3350}.bal-et>div.on{background:#146a9c;color:#fff}.bal-et>div.ok span{background:#2e7d32}.bal-et>div.ok{background:var(--b38);color:var(--t14)}.bal-et>i{align-self:center;color:#9aa7b6;font-style:normal}
.bal-modo{display:grid;grid-template-columns:1fr 1fr;gap:12px}.bal-modo label{border:2px solid var(--br,var(--e6));border-radius:12px;padding:12px;cursor:pointer;display:block}.bal-modo label.sel{border-color:#146a9c;background:var(--b39)}
.bal-ult{font-size:20px;padding:12px;border-radius:10px;background:var(--b39);margin:10px 0}@media(max-width:700px){.bal-modo{grid-template-columns:1fr}}`;
  document.head.appendChild(st);
}

async function balPdf(id, acao) {
  const w = acao === 'abrir' ? window.open('', '_blank') : null;
  try {
    const r = await fetch(`/api/balancos/${id}/relatorio.pdf`, { headers: S.token ? { Authorization: 'Bearer ' + S.token } : {} });
    if (!r.ok) { let j = {}; try { j = await r.json(); } catch { /* */ } throw new Error(j.erro || 'Erro ' + r.status); }
    const url = URL.createObjectURL(await r.blob());
    if (acao === 'abrir') { if (w) w.location = url; else window.open(url, '_blank'); }
    else { const a = document.createElement('a'); a.href = url; a.download = `balanco-${id}.pdf`; a.click(); }
  } catch (e) { if (w) w.close(); throw e; }
}

const BAL_ST = { andamento: ['EM ANDAMENTO', 'warn'], finalizado: ['FINALIZADO', 'ok'], cancelado: ['CANCELADO', ''] };

async function telaBalanco(el) {
  limparTimer();
  const [cur, hist] = await Promise.all([api('/balancos/atual'), api('/balancos')]);
  const b = cur.balanco;
  const historico = `<h3 style="margin:18px 0 6px">Balanços realizados</h3>` + tabela([{ l: 'Nº', k: 'id' }, { l: 'Início', f: r => dt(r.iniciado_em) }, { l: 'Fim', f: r => (r.finalizado_em ? dt(r.finalizado_em) : '—') }, { l: 'Modo', f: r => (r.acumula ? 'Com acúmulo' : 'Sem acúmulo') },
    { l: 'Situação', f: r => chip(BAL_ST[r.status][0], BAL_ST[r.status][1]) }, { l: 'Conferidos', n: 1, f: r => r.conferidos }, { l: 'Não conferidos', n: 1, f: r => (r.status === 'finalizado' ? `${r.nao_conferidos} <small class="muted">(${r.zerou_nao_conferidos ? 'zerados' : 'mantidos'})</small>` : '—') },
    { l: 'Responsável', f: r => esc(r.finalizado_por || r.iniciado_por || '') }], hist,
    { vazio: 'Nenhum balanço realizado ainda.', acoes: r => (r.status === 'finalizado' ? `<button class="btn sm" data-pdf="${r.id}">Relatório PDF</button> <button class="btn sm" data-imp="${r.id}">Imprimir</button>` : r.status === 'andamento' ? '<span class="muted">em andamento acima</span>' : '') });
  el.onclick = seguro(async e => { const t = e.target.closest('button'); if (!t) return; if (t.dataset.pdf) return balPdf(t.dataset.pdf, 'baixar'); if (t.dataset.imp) return balPdf(t.dataset.imp, 'abrir'); });

  // ---------- sem balanço em andamento: Etapa 1 (iniciar)
  if (!b) {
    el.innerHTML = balEtapas(1) + `<div class="card"><h3 style="margin-top:0">Novo balanço geral de estoque</h3>
      <p class="muted">Escolha como a conferência será feita. Só pode existir um balanço em andamento por vez e, enquanto ele estiver aberto, não é possível dar entrada de mercadoria.</p>
      <div class="bal-modo"><label class="sel"><input type="radio" name="bm" value="0" checked> <b>Sem acúmulo</b><br><span class="muted">Você bipa o produto <b>uma vez</b>, informa a quantidade total (ex.: 10) e salva com <b>F2</b>.</span></label>
      <label><input type="radio" name="bm" value="1"> <b>Com acúmulo</b><br><span class="muted">Você bipa o produto <b>uma vez para cada unidade</b> (ex.: 10 vezes) e <b>não precisa salvar</b> no F2.</span></label></div>
      ${cur.caixas_abertos ? `<p class="aviso-box" style="margin:12px 0 0">⚠️ Há <b>${cur.caixas_abertos} caixa(s) aberto(s)</b>. Você pode fazer o balanço assim mesmo: ao finalizar, o sistema abate do estoque tudo que foi vendido depois da contagem de cada produto.</p>` : ''}
      <div style="margin-top:14px"><button class="btn primary big" id="ini">Iniciar balanço</button></div></div>` + historico;
    $$('input[name=bm]', el).forEach(r => r.onchange = () => $$('.bal-modo label', el).forEach(l => l.classList.toggle('sel', l.querySelector('input').checked)));
    $('#ini', el).onclick = seguro(async () => {
      const acumula = $('input[name=bm]:checked', el).value === '1';
      if (!await confirmar(`Iniciar um balanço ${acumula ? 'COM acúmulo' : 'SEM acúmulo'}?\n\nEnquanto ele estiver aberto não será possível dar entrada de mercadoria.`, 'Iniciar balanço')) return;
      await api('/balancos', { method: 'POST', body: { acumula } }); toast('Balanço iniciado.'); telaBalanco(el);
    });
    return;
  }

  // ---------- balanço em andamento: Etapa 2 (bipar)
  let itens = cur.itens, ultimo = null, prod = null;
  const acum = !!b.acumula;
  const desenhaLista = () => {
    const f = ($('#fl', el) ? $('#fl', el).value : '').toLowerCase();
    const l = itens.filter(i => !f || i.nome.toLowerCase().includes(f) || String(i.codigo).toLowerCase().includes(f)).slice(0, 300);
    $('#bl', el).innerHTML = tabela([{ l: 'Código', k: 'codigo' }, { l: 'Produto', f: i => `<b>${esc(i.nome)}</b>` }, { l: 'Contado', n: 1, f: i => `<b>${N(i.qtd_contada)}</b> ${esc(i.unidade)}` }, { l: 'Leituras', n: 1, f: i => i.leituras }, { l: 'Última leitura', f: i => dt(i.contado_em) }], l,
      { vazio: 'Nenhum produto conferido ainda. Bipe um produto acima.', acoes: i => `<button class="btn sm" data-ed="${i.produto_id}">Corrigir</button> <button class="btn sm danger" data-rm="${i.produto_id}">Remover</button>` });
    $('#cont', el).textContent = `${itens.length} de ${cur.total_produtos} produtos conferidos`;
  };
  const recarrega = async () => { const c = await api('/balancos/atual'); if (!c.balanco) return telaBalanco(el); itens = c.itens; desenhaLista(); };
  const foco = () => setTimeout(() => { const x = $('#bc', el); if (x) x.focus(); }, 50);
  el.innerHTML = balEtapas(2) + `<div class="card"><div class="row" style="align-items:center"><div><b style="font-size:17px">Balanço nº ${b.id}</b> ${chip('EM ANDAMENTO', 'warn')}<br><span class="muted">Iniciado em ${dt(b.iniciado_em)} · modo <b>${acum ? 'COM acúmulo' : 'SEM acúmulo'}</b>${b.caixa_aberto || cur.caixas_abertos ? ' · caixa aberto (as vendas após a contagem serão abatidas no final)' : ''}</span></div><div class="grow"></div>
      <button class="btn danger" id="canc">Cancelar balanço</button> <button class="btn primary big" id="fin">Finalizar balanço</button></div></div>
    <div class="card"><div class="row" style="align-items:flex-end"><label style="flex:3">Leia o código de barras (ou digite código/nome) e tecle Enter<input id="bc" autocomplete="off" placeholder="bipe o produto aqui" style="font-size:20px"></label>
      ${acum ? '<label style="flex:1">Quantidade por leitura<input id="qpl" inputmode="decimal" value="1"></label>' : ''}</div>
      <div id="painel"></div></div>
    <div class="bar"><input id="fl" placeholder="Filtrar produtos conferidos..."><div class="grow"></div><span class="muted" id="cont"></span></div><div id="bl"></div>` + historico;
  desenhaLista(); foco();
  const mostra = (p, extra) => { $('#painel', el).innerHTML = `<div class="bal-ult"><b>${esc(p.nome)}</b> <span class="muted">(${esc(p.unidade)} · cód. ${esc(p.codigo)})</span><br>${extra}</div>`; };
  const salvar = seguro(async () => {
    if (!prod) return; const q = $('#qt', el).value.trim(); if (q === '') throw new Error('Informe a quantidade contada.');
    const r = await api(`/balancos/${b.id}/ler`, { method: 'POST', body: { produto_id: prod.id, quantidade: numIn(q), definir: true } });
    ultimo = r; prod = null; $('#painel', el).innerHTML = `<div class="bal-ult">✅ <b>${esc(r.produto.nome)}</b> salvo: <b>${N(r.qtd_contada)} ${esc(r.produto.unidade)}</b></div>`; $('#bc', el).value = ''; await recarrega(); foco();
  });
  const ler = seguro(async () => {
    const cod = $('#bc', el).value.trim(); if (!cod) return;
    if (acum) {
      const qpl = numIn($('#qpl', el).value) || 1;
      let r; try { r = await api(`/balancos/${b.id}/ler`, { method: 'POST', body: { codigo: cod, quantidade: qpl } }); } catch (e) { $('#bc', el).select(); throw e; }
      $('#painel', el).innerHTML = `<div class="bal-ult">✅ <b>${esc(r.produto.nome)}</b> <span class="muted">(${esc(r.produto.unidade)})</span> · total contado: <b style="font-size:26px">${N(r.qtd_contada)}</b> ${esc(r.produto.unidade)} <span class="muted">(${r.leituras} leitura${r.leituras > 1 ? 's' : ''})</span></div>`;
      $('#bc', el).value = ''; await recarrega(); foco();
    } else {
      let r; try { r = await api(`/balancos/${b.id}/produto?codigo=` + encodeURIComponent(cod)); } catch (e) { $('#bc', el).select(); throw e; }
      prod = r.produto;
      $('#painel', el).innerHTML = `<div class="bal-ult"><b>${esc(prod.nome)}</b> <span class="muted">(${esc(prod.unidade)} · cód. ${esc(prod.codigo)})</span>${r.contada !== null ? `<br><span class="muted">Já contado neste balanço: ${N(r.contada)} — salvar substitui a quantidade.</span>` : ''}
        <div class="row" style="align-items:flex-end;margin-top:8px"><label style="flex:2">Quantidade contada (${esc(prod.unidade)})<input id="qt" inputmode="decimal" value="${r.contada !== null ? N(r.contada) : ''}" style="font-size:22px"></label><button class="btn primary big auto" id="sv">Salvar [F2]</button></div></div>`;
      $('#sv', el).onclick = salvar; $('#qt', el).focus(); $('#qt', el).select();
    }
  });
  el.onkeydown = e => {
    if (e.target.id === 'bc' && e.key === 'Enter') { e.preventDefault(); ler(); }
    else if (e.target.id === 'qt' && e.key === 'Enter') { e.preventDefault(); salvar(); }
    else if (e.key === 'F2' && !acum) { e.preventDefault(); salvar(); }
    else if (e.key === 'Escape' && prod) { prod = null; $('#painel', el).innerHTML = ''; $('#bc', el).value = ''; foco(); }
  };
  $('#fl', el).oninput = desenhaLista;
  el.onclick = seguro(async e => {
    const t = e.target.closest('button'); if (!t) return;
    if (t.dataset.pdf) return balPdf(t.dataset.pdf, 'baixar'); if (t.dataset.imp) return balPdf(t.dataset.imp, 'abrir');
    if (t.dataset.rm) { const i = itens.find(x => x.produto_id == t.dataset.rm); if (!await confirmar(`Remover "${i.nome}" da conferência? Ele passará a contar como não conferido.`)) return; await api(`/balancos/${b.id}/itens/${i.produto_id}`, { method: 'DELETE' }); await recarrega(); return foco(); }
    if (t.dataset.ed) { const i = itens.find(x => x.produto_id == t.dataset.ed); return formModal({ titulo: 'Corrigir contagem: ' + i.nome, campos: [{ k: 'q', l: `Quantidade contada (${i.unidade})`, t: 'number', step: '0.001', req: true, full: true }], valores: { q: Number(i.qtd_contada) }, onSave: async o => { await api(`/balancos/${b.id}/ler`, { method: 'POST', body: { produto_id: i.produto_id, quantidade: Number(o.q), definir: true } }); await recarrega(); } }); }
    if (t.id === 'canc') { if (!await confirmar('Cancelar o balanço?\n\nTodas as contagens feitas serão descartadas e o estoque NÃO será alterado.', 'Cancelar balanço')) return; await api(`/balancos/${b.id}/cancelar`, { method: 'POST' }); toast('Balanço cancelado.'); return telaBalanco(el); }
    if (t.id === 'fin') return finalizarBalanco(b, el);
  });
}

// Etapas 3 e 4: revisão, escolha (zerar ou não os não conferidos), confirmação e atualização do estoque
async function finalizarBalanco(b, el) {
  const pv = await api(`/balancos/${b.id}/previa`, { method: 'POST' });
  if (!pv.conferidos) return aviso('Nenhum produto foi conferido ainda. Bipe ao menos um produto ou cancele o balanço.', 'Balanço vazio');
  const mov = pv.com_movimento_depois ? `<p class="aviso-box">🧾 <b>${pv.com_movimento_depois} produto(s)</b> tiveram movimento (vendas) <b>depois de serem contados</b>. O sistema vai abater isso do estoque para ele ficar correto:<br><small>${pv.vendas_abatidas.slice(0, 8).map(x => esc(x.nome) + ' ' + N(x.mov) + ' ' + esc(x.unidade)).join(' · ')}${pv.com_movimento_depois > 8 ? ' · ...' : ''}</small></p>` : '';
  const corpo = document.createElement('div');
  corpo.innerHTML = balEtapas(3) + `<div class="card"><b>${pv.conferidos}</b> produto(s) conferido(s) · <b>${pv.nao_conferidos}</b> não conferido(s)${pv.nao_conferidos ? ` <span class="muted">(estoque atual deles: ${R(pv.nao_conferidos_valor)} a custo)</span>` : ''}</div>${mov}
    ${pv.caixas_abertos ? '<p class="muted">Há caixa aberto: vendas feitas durante o balanço são consideradas automaticamente.</p>' : ''}
    ${pv.nao_conferidos ? `<h4 style="margin:12px 0 6px">O que fazer com os ${pv.nao_conferidos} produtos NÃO conferidos?</h4>
    <div class="bal-modo"><label class="sel"><input type="radio" name="zr" value="0" checked> <b>Manter o estoque que estava</b><br><span class="muted">Só os conferidos são atualizados.</span></label><label><input type="radio" name="zr" value="1"> <b>Zerar os não conferidos</b><br><span class="muted">O estoque deles vira 0 (considera que acabaram).</span></label></div>` : ''}
    <label style="margin-top:10px">Observação (opcional)<input id="obs" maxlength="200"></label>`;
  $$('input[name=zr]', corpo).forEach(r => r.onchange = () => $$('.bal-modo label', corpo).forEach(l => l.classList.toggle('sel', l.querySelector('input').checked)));
  modal({ titulo: 'Finalizar balanço nº ' + b.id, tam: 'lg', corpo, botoes: [{ txt: 'Voltar' }, { txt: 'Continuar', cls: 'primary', fn: async m => {
    const zerar = pv.nao_conferidos ? $('input[name=zr]:checked', corpo).value === '1' : false;
    const txt = zerar ? `ATENÇÃO: ${pv.nao_conferidos} produto(s) NÃO conferido(s) terão o estoque ZERADO e ${pv.conferidos} produto(s) conferido(s) serão atualizados com a contagem.\n\nEsta ação não pode ser desfeita.\n\nTem certeza que deseja finalizar o balanço?`
      : `O estoque de ${pv.conferidos} produto(s) conferido(s) será atualizado com a contagem. Os ${pv.nao_conferidos} não conferidos manterão o estoque atual.\n\nEsta ação não pode ser desfeita.\n\nTem certeza que deseja finalizar o balanço?`;
    if (!await confirmar(txt, zerar ? 'Zerar não conferidos e finalizar?' : 'Finalizar balanço?')) return false;
    const r = await api(`/balancos/${b.id}/finalizar`, { method: 'POST', body: { zerar, confirmado: true, observacao: $('#obs', corpo).value.trim() || undefined } });
    m.fechar();
    modal({ titulo: 'Balanço nº ' + r.id + ' finalizado', tam: 'md', corpo: balEtapas(5) + `<p>✅ Estoque atualizado: <b>${r.conferidos}</b> produto(s) conferido(s).</p><p>${r.nao_conferidos ? (r.zerou ? `✅ <b>${r.nao_conferidos}</b> não conferido(s) foram <b>zerados</b>.` : `✅ <b>${r.nao_conferidos}</b> não conferido(s) <b>mantiveram</b> o estoque.`) : 'Todos os produtos foram conferidos.'}</p><p class="muted">O relatório em PDF (conferidos e não conferidos) está pronto. Baixar ou imprimir é opcional; ele também fica disponível na lista de balanços.</p>`,
      botoes: [{ txt: 'Baixar PDF', fn: async () => { await balPdf(r.id, 'baixar'); return false; } }, { txt: 'Abrir / Imprimir', fn: async () => { await balPdf(r.id, 'abrir'); return false; } }, { txt: 'Fechar', cls: 'primary' }] });
    telaBalanco(el); return false;
  } }] });
}
