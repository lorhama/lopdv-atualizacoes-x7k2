// Atualização do sistema: aviso de versão nova, confirmação, tela de andamento e tela de novidades após o login.
const NOTA_TIPO = { correcao: 'Correção', melhoria: 'Melhoria' };
const notasHtml = lista => (lista && lista.length ? '<ul class="nv">' + lista.map(n => `<li><b>${esc(NOTA_TIPO[n.tipo] || n.tipo || 'Melhoria')}:</b> ${esc(n.texto)}</li>`).join('') + '</ul>' : '<p class="muted">Sem detalhes.</p>');

async function checarAtualizacao() {
  if (!tem('config.gerenciar')) return;
  let s; try { s = await api('/atualizacao?checar=1'); } catch { return; }
  let b = $('#bannerUpd');
  // indicador fixo na barra superior (ao lado do usuário): sempre visível quando há versão nova
  let pill = $('#topUpd');
  if (s.disponivel) {
    if (!pill) { pill = document.createElement('button'); pill.id = 'topUpd'; pill.className = 'btn sm upd-pill'; $('#quem').parentNode.insertBefore(pill, $('#quem')); }
    pill.textContent = '🔔 Nova versão ' + s.disponivel.versao + ' disponível';
    pill.title = 'Clique para ver o que muda e atualizar';
    pill.onclick = () => modal({ titulo: 'Versão ' + s.disponivel.versao + (s.disponivel.data ? ' — ' + s.disponivel.data : ''), corpo: notasHtml(s.disponivel.notas) + '<p class="muted">Você está na versão ' + esc(s.versao) + '.</p>', botoes: [{ txt: 'Agora não' }, { txt: 'Atualizar agora', cls: 'primary', fn: async () => { confirmarAtualizacao(s); } }] });
  } else if (pill) pill.remove();
  if (!s.disponivel) { // sem versão nova: se a verificação não está funcionando, avisa em vez de ficar em silêncio
    const naoConfig = !s.url && !s.url_padrao, falha = s.erro;
    if ((naoConfig || falha) && !sessionStorage.getItem('updAvisoFechado')) {
      if (!b) { b = document.createElement('div'); b.id = 'bannerUpd'; const top = $('.main .top'); top.parentNode.insertBefore(b, top); }
      b.className = 'banner-upd aviso';
      b.innerHTML = `<span>⚠️ <b>${naoConfig ? 'A atualização automática não está configurada' : 'Não foi possível verificar novas versões'}</b> — ${esc(naoConfig ? 'o sistema não sabe onde procurar versões novas.' : falha)}</span><span class="grow"></span><a class="btn sm primary" href="#/config">Configurar</a><button class="btn sm" id="updX">Dispensar</button>`;
      $('#updX', b).onclick = () => { try { sessionStorage.setItem('updAvisoFechado', '1'); } catch { /* */ } b.remove(); };
    } else if (b) b.remove();
    return;
  }
  if (b) b.remove(); // com versão nova, só o botão da barra superior avisa (sem faixa duplicada)
}

function confirmarAtualizacao(s) {
  modal({ titulo: 'Atualizar para a versão ' + s.disponivel.versao + '?', tam: 'md',
    corpo: `<p><b>O sistema precisa ser fechado para atualizar.</b> Todos os terminais ficarão sem acesso por alguns minutos (normalmente 1 a 3).</p>
      <ul class="nv"><li>Antes de trocar os arquivos o sistema faz o backup do banco de dados.</li><li>Seus dados, vendas e cadastros são mantidos.</li><li>Se algo der errado, o sistema volta sozinho para a versão atual.</li><li>Termine as vendas em andamento antes de confirmar.</li><li>Ao terminar, o sistema abre pedindo usuário e senha, já na versão nova.</li></ul>
      <p>Deseja atualizar agora?</p>`,
    botoes: [{ txt: 'Agora não' }, { txt: 'Sim, atualizar agora', cls: 'primary', fn: async () => { await api('/atualizacao/aplicar', { method: 'POST' }); telaAtualizando(s.disponivel.versao); } }] });
}

// Tela cheia durante a atualização: acompanha o andamento e, quando o sistema volta na versão nova, recarrega no login.
const ETAPAS_UPD = ['Baixando o pacote da nova versão', 'Conferindo a integridade e a assinatura do pacote', 'Fechando o sistema e fazendo o backup do banco de dados', 'Guardando uma cópia de segurança dos arquivos atuais', 'Instalando os arquivos novos', 'Conferindo as bibliotecas', 'Iniciando a nova versão'];
// mostra o log da atualização (data\atualizacao.log) numa janela, com opção de baixar
async function verLogAtualizacao() {
  let r; try { r = await api('/atualizacao/log?linhas=200'); } catch (e) { return toast(e.message, 'erro'); }
  const m = modal({ titulo: 'Log da atualização', tam: 'md', corpo: `<p class="muted">Arquivo no servidor: <code>${esc(r.arquivo)}</code></p><pre id="logtxt" style="max-height:55vh;overflow:auto;background:#0f172a;color:#e2e8f0;padding:12px;border-radius:8px;font-size:12px;white-space:pre-wrap">${esc(r.texto || 'Nenhuma atualização registrada ainda.')}</pre>`,
    botoes: [{ txt: 'Baixar .txt', fn: async () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([r.texto || ''], { type: 'text/plain;charset=utf-8' })); a.download = 'atualizacao-lopdv.log.txt'; a.click(); return false; } }, { txt: 'Fechar', cls: 'primary' }] });
  const pre = $('#logtxt', m.body); if (pre) pre.scrollTop = pre.scrollHeight;
}
// Tela cheia durante a atualização: mostra cada etapa e, quando o sistema volta na versão nova, recarrega no login.
function telaAtualizando(nova) {
  const ov = document.createElement('div'); ov.className = 'upd-ov';
  ov.innerHTML = `<div class="upd-box" style="max-width:560px;text-align:left"><div style="text-align:center"><img src="icon.png" width="64" height="64" alt=""><h2>Atualizando o LoPDV para a versão ${esc(nova)}</h2></div>
    <div class="upd-bar"><i id="updPct"></i></div>
    <ol id="updEt" style="list-style:none;margin:14px 0 6px;padding:0;font-size:15px"></ol>
    <p id="updTxt" style="margin:8px 0 2px;font-weight:600">Preparando...</p><p class="muted" id="updTempo" style="margin:0 0 8px"></p>
    <p class="muted" style="font-size:12.5px">Não desligue o computador. Esta tela se atualiza sozinha. Tudo fica registrado no log da atualização.</p><div id="updErr"></div></div>`;
  document.body.appendChild(ov);
  const t0 = Date.now(); let caiu = false, parou = false, etapa = 0, falhouEm = 0;
  const pctDe = e => Math.round((e - 1) / ETAPAS_UPD.length * 100 + 6);
  const desenhar = (e, detalhe, erro) => {
    $('#updEt', ov).innerHTML = ETAPAS_UPD.map((t, i) => { const n = i + 1, ok = n < e, at = n === e; const ic = erro && at ? '❌' : ok ? '✅' : at ? '⏳' : '⚪'; return `<li style="padding:3px 0;${at ? 'font-weight:700' : ok ? 'color:var(--t15)' : 'color:#9aa0a6'}">${ic} ${esc(t)}</li>`; }).join('');
    if (detalhe) $('#updTxt', ov).textContent = detalhe; $('#updPct', ov).style.width = pctDe(e) + '%';
  };
  const falhou = async (m) => { parou = true; $('#updTempo', ov).textContent = ''; desenhar(falhouEm || etapa || 1, '', true); $('#updTxt', ov).textContent = 'A atualização não foi concluída.';
    $('#updErr', ov).innerHTML = `<div class="erro" style="margin:12px 0">${esc(m)}</div><div style="display:flex;gap:8px;justify-content:center"><button class="btn" id="updLog">Ver log</button><button class="btn primary" id="updFecha">Voltar ao sistema</button></div>`;
    $('#updFecha', ov).onclick = () => { ov.remove(); if (!S.token) mostrarLogin(); else rotear(); }; $('#updLog', ov).onclick = () => verLogAtualizacao(); };
  const volta = () => { try { sessionStorage.removeItem('tk'); } catch { /* */ } location.reload(); };
  const tick = async () => {
    if (parou) return;
    $('#updTempo', ov).textContent = 'Tempo decorrido: ' + Math.round((Date.now() - t0) / 1000) + ' s';
    try {
      const s = await (await fetch('/api/atualizacao/status?ov=1', { cache: 'no-store' })).json();
      if (s.versao === nova) { desenhar(ETAPAS_UPD.length + 1, 'Atualizado! Abrindo o sistema...'); $('#updPct', ov).style.width = '100%'; parou = true; return setTimeout(volta, 800); }
      if (s.fase === 'erro') { falhouEm = s.etapa || 1; return falhou(s.erro || 'Erro ao baixar a atualização.'); }
      if (s.resultado && s.resultado.ok === false && caiu) return falhou(s.resultado.erro);
      if (s.etapa) { etapa = Math.max(etapa, s.etapa); if (s.erro) { falhouEm = s.etapa; } desenhar(etapa, s.fase === 'baixando' ? s.detalhe + ' (' + s.pct + '%)' : s.detalhe); if (s.fase === 'baixando') $('#updPct', ov).style.width = Math.round(s.pct * 0.14) + '%'; }
      else if (caiu) { etapa = Math.max(etapa, 7); desenhar(etapa, 'Iniciando a nova versão...'); }
    } catch { caiu = true; if (etapa < 3) etapa = 3; desenhar(etapa >= 7 ? 7 : etapa, etapa >= 7 ? 'Iniciando a nova versão... (aguarde alguns segundos)' : 'Instalando... (o sistema está fechado e o andamento aparece assim que o atualizador responder)'); }
    setTimeout(tick, 1000);
  };
  desenhar(1, 'Preparando...'); tick();
}

// Novidades: aparece uma vez por usuário depois do login na versão nova.
async function mostrarNovidades() {
  let n; try { n = await api('/novidades'); } catch { return; }
  if (!n.mostrar) return;
  const corpo = n.versoes.map(v => `<h4 style="margin:10px 0 4px">Versão ${esc(v.versao)}${v.data ? ' <small class="muted">— ' + esc(v.data) + '</small>' : ''}</h4>${notasHtml(v.itens)}`).join('');
  modal({ titulo: '🎉 O que há de novo no LoPDV ' + n.versao, tam: 'md', corpo: `<p>O sistema foi atualizado. Veja o que melhorou:</p>${corpo}`,
    botoes: [{ txt: 'Entendi, vamos trabalhar', cls: 'primary', fn: async () => { try { await api('/novidades/visto', { method: 'POST' }); } catch { /* */ } } }] });
}

async function iniciarAtualizacao() {
  mostrarNovidades(); checarAtualizacao();
  if (S.updTimer) clearInterval(S.updTimer); S.updTimer = setInterval(checarAtualizacao, 5 * 60 * 1000);
}
