// Financeiro (contas a pagar/receber) e relatórios.
function tituloView(tipo) {
  const pagar = tipo === 'pagar';
  registrar({ id: 'contas-' + tipo, titulo: pagar ? 'Contas a pagar' : 'Contas a receber', grupo: 'Financeiro', perm: 'financeiro.ver', render: async el => {
    const [forn, cli, FP] = await Promise.all([pagar ? api('/fornecedores?ativos=1') : [], pagar ? [] : api('/clientes?ativos=1'), pagar ? api('/formas-pagamento?uso=pagar') : []]);
    const nomeForma = c => (FP.find(f => f.codigo === c) || {}).descricao || '';
    let lista = [];
    el.innerHTML = `<div class="bar"><select id="st"><option value="aberto">Em aberto</option><option value="pago">${pagar ? 'Pagas' : 'Recebidas'}</option><option value="cancelado">Canceladas</option><option value="">Todas</option></select>
      <label class="chk" style="margin:0">Vencimento de <input type="date" id="de"></label><label class="chk" style="margin:0">até <input type="date" id="ate"></label><button class="btn" id="f">Filtrar</button><div class="grow"></div>
      ${tem('financeiro.editar') ? '<button class="btn primary" id="novo">+ Novo lançamento</button>' : ''}</div><div id="res"></div>`;
    const carregar = seguro(async () => {
      const r = await api('/financeiro/titulos?' + qs({ tipo, status: $('#st', el).value, de: $('#de', el).value, ate: $('#ate', el).value })); lista = r.titulos;
      $('#res', el).innerHTML = `<div class="cards"><div class="stat">Em aberto<b>${R(r.totais.aberto)}</b></div><div class="stat ${r.totais.vencido ? 'err' : ''}">Vencido<b>${R(r.totais.vencido)}</b></div><div class="stat">${pagar ? 'Pago' : 'Recebido'}<b>${R(r.totais.pago)}</b></div></div>` +
        tabela([{ l: 'Vencimento', f: t => dia(t.vencimento) + (t.vencido ? ' ' + chip('vencido', 'err') : '') }, { l: 'Descrição', k: 'descricao' }, { l: pagar ? 'Fornecedor' : 'Cliente', f: t => esc(pagar ? t.fornecedor : t.cliente) }, { l: 'Categoria', k: 'categoria' }, ...(pagar ? [{ l: 'Forma prevista', f: t => esc(nomeForma(t.forma_prevista)) || '<span class="muted">—</span>' }] : []),
          { l: 'Valor', n: 1, f: t => R(t.valor) }, { l: 'Situação', f: t => chip(t.status === 'pago' ? (pagar ? 'pago ' : 'recebido ') + dia(t.pago_em) : t.status, t.status === 'pago' ? 'ok' : t.status === 'cancelado' ? 'cancelado' : '') }], lista,
          { acoes: t => t.status !== 'aberto' ? '' : (tem('financeiro.baixar') ? `<button class="btn sm ok" data-b="${t.id}">${pagar ? 'Pagar' : 'Receber'}</button> ` : '') + (tem('financeiro.editar') ? `<button class="btn sm" data-e="${t.id}">Editar</button> <button class="btn sm danger" data-c="${t.id}">Cancelar</button>` : '') });
    });
    const campos = [{ k: 'descricao', l: 'Descrição', req: true, full: true }, pagar ? { k: 'fornecedor_id', l: 'Fornecedor', t: 'select', op: [['', '—']].concat(forn.map(f => [f.id, f.nome])) } : { k: 'cliente_id', l: 'Cliente', t: 'select', op: [['', '—']].concat(cli.map(c => [c.id, c.nome])) },
      { k: 'categoria', l: 'Categoria', ph: pagar ? 'Aluguel, energia, salários...' : 'Eventos, fiado...' }, { k: 'valor', l: 'Valor (R$)', t: 'number', step: '0.01', req: true }, { k: 'vencimento', l: 'Vencimento', t: 'date', req: true }];
    const form = reg => formModal({ titulo: reg ? 'Editar título' : 'Novo lançamento', campos: reg ? campos : campos.concat([{ k: 'parcelas', l: 'Parcelas mensais', t: 'number', padrao: 1 }]), valores: reg ? { ...reg, vencimento: String(reg.vencimento).slice(0, 10) } : { parcelas: 1 },
      onSave: async o => { await api('/financeiro/titulos' + (reg ? '/' + reg.id : ''), { method: reg ? 'PUT' : 'POST', body: { ...o, tipo } }); toast('Salvo.'); carregar(); } });
    $('#f', el).onclick = carregar; $('#st', el).onchange = carregar;
    if ($('#novo', el)) $('#novo', el).onclick = () => form(null);
    el.onclick = seguro(async e => {
      const d = e.target.dataset, t = id => lista.find(x => x.id == id);
      if (d.e) form(t(d.e));
      if (d.c && await confirmar('Cancelar este título?')) { await api(`/financeiro/titulos/${d.c}/cancelar`, { method: 'POST' }); carregar(); }
      if (d.b) { const x = t(d.b); formModal({ titulo: (pagar ? 'Pagar: ' : 'Receber: ') + x.descricao, campos: [{ k: 'valor', l: 'Valor (R$)', t: 'number', step: '0.01', req: true }, { k: 'data', l: 'Data', t: 'date', req: true }, { k: 'forma', l: 'Forma', t: 'select', op: pagar ? FP.map(f => [f.codigo, f.descricao]) : [['dinheiro', 'Dinheiro'], ['pix', 'PIX'], ['transferencia', 'Transferência'], ['boleto', 'Boleto'], ['cartao', 'Cartão']], full: true }], valores: { valor: x.valor, data: hojeISO(), forma: x.forma_prevista || undefined },
        onSave: async o => { await api(`/financeiro/titulos/${x.id}/baixar`, { method: 'POST', body: o }); toast('Baixado.'); carregar(); } }); }
    });
    await carregar();
  } });
}
tituloView('pagar'); tituloView('receber');

// ---------------- Relatórios
registrar({ id: 'relatorios', titulo: 'Relatórios', grupo: 'Relatórios', perm: ['relatorios.financeiro', 'relatorios.estoque'], render: async el => {
  const fin = tem('relatorios.financeiro'), est = tem('relatorios.estoque');
  const abas = [fin && ['caixa', 'Fechamento de caixa'], fin && ['ticket', 'Ticket médio'], fin && ['lucro', 'Lucratividade'], (est || fin) && ['top', 'Mais vendidos']].filter(Boolean);
  let aba = abas[0][0], ultimo = null;
  el.innerHTML = `<div class="tabs" id="tb">${abas.map(a => `<button data-a="${a[0]}" class="${a[0] === aba ? 'on' : ''}">${a[1]}</button>`).join('')}${est ? '<a class="btn" href="#/movimentos" style="border-radius:99px">Movimentação de estoque →</a>' : ''}</div>
    <div class="bar" id="filtros"><label class="chk" style="margin:0">De <input type="date" id="de" value="${iniMes()}"></label><label class="chk" style="margin:0">Até <input type="date" id="ate" value="${hojeISO()}"></label><button class="btn primary" id="ok">Gerar</button><div class="grow"></div><button class="btn" id="csv">CSV</button><button class="btn" onclick="window.print()">Imprimir</button></div><div id="res"></div>`;
  const per = () => qs({ de: $('#de', el).value, ate: $('#ate', el).value });
  const gerar = seguro(async () => {
    const res = $('#res', el);
    $('#filtros', el).classList.toggle('hidden', aba === 'caixa' && false);
    if (aba === 'caixa') {
      const l = (await api('/caixa')).filter(c => c.status === 'fechado' || true);
      res.innerHTML = '<p class="muted">Escolha um caixa para ver o fechamento completo (por forma de pagamento, sangrias, diferença).</p>' + tabela([{ l: '#', k: 'id' }, { l: 'Usuário', k: 'usuario' }, { l: 'Abertura', f: r => dt(r.aberto_em) }, { l: 'Fechamento', f: r => dt(r.fechado_em) }, { l: 'Status', f: r => chip(r.status, r.status === 'aberto' ? 'ok' : '') }, { l: 'Esperado', n: 1, f: r => (r.valor_esperado != null ? R(r.valor_esperado) : '') }, { l: 'Contado', n: 1, f: r => (r.valor_informado != null ? R(r.valor_informado) : '') },
        { l: 'Diferença', n: 1, f: r => (r.valor_informado != null ? `<b class="${r.valor_informado - r.valor_esperado ? 'erro' : ''}">${R(r.valor_informado - r.valor_esperado)}</b>` : '') }], l, { acoes: r => `<button class="btn sm" data-cx="${r.id}">Abrir</button>` });
      ultimo = { nome: 'caixas', cols: [{ l: '#', k: 'id' }, { l: 'Usuário', k: 'usuario' }, { l: 'Abertura', k: 'aberto_em' }, { l: 'Fechamento', k: 'fechado_em' }, { l: 'Esperado', k: 'valor_esperado' }, { l: 'Contado', k: 'valor_informado' }], rows: l };
    } else if (aba === 'ticket') {
      const r = await api('/relatorios/ticket-medio?' + per());
      res.innerHTML = `<div class="cards"><div class="stat">Faturamento<b>${R(r.total.faturamento)}</b></div><div class="stat">Vendas<b>${r.total.vendas}</b></div><div class="stat">Ticket médio<b>${R(r.total.ticket)}</b></div></div><h3 style="margin:6px 0">Por dia</h3>` +
        tabela([{ l: 'Dia', f: x => dia(x.dia) }, { l: 'Vendas', n: 1, k: 'vendas' }, { l: 'Faturamento', n: 1, f: x => R(x.faturamento) }, { l: 'Ticket médio', n: 1, f: x => R(x.ticket) }], r.por_dia) + `<h3 style="margin:16px 0 6px">Por atendente</h3>` + tabela([{ l: 'Atendente', k: 'usuario' }, { l: 'Vendas', n: 1, k: 'vendas' }, { l: 'Faturamento', n: 1, f: x => R(x.faturamento) }, { l: 'Ticket médio', n: 1, f: x => R(x.ticket) }], r.por_atendente);
      ultimo = { nome: 'ticket-medio', cols: [{ l: 'Dia', k: 'dia' }, { l: 'Vendas', k: 'vendas' }, { l: 'Faturamento', k: 'faturamento' }, { l: 'Ticket médio', k: 'ticket' }], rows: r.por_dia };
    } else if (aba === 'lucro') {
      const r = await api('/relatorios/lucratividade?' + per()), s = r.resumo;
      res.innerHTML = `<div class="cards"><div class="stat">Receita bruta<b>${R(s.receita_bruta)}</b></div><div class="stat">Descontos<b>${R(s.descontos)}</b></div><div class="stat">Custo das mercadorias<b>${R(s.custo_mercadoria)}</b></div><div class="stat"><span>Lucro bruto (${N(s.margem_pct, 1)}%)</span><b>${R(s.lucro_bruto)}</b></div>
        <div class="stat">Despesas pagas no período<b>${R(s.despesas_operacionais_pagas)}</b></div><div class="stat ${s.resultado < 0 ? 'err' : ''}">Resultado<b>${R(s.resultado)}</b></div></div><p class="muted">Custo pelo custo médio vigente no momento da venda. Despesas = contas a pagar baixadas no período (exceto compras de mercadoria, que já entram no custo).</p>` +
        tabela([{ l: 'Produto', k: 'nome' }, { l: 'Qtd', n: 1, f: x => N(x.quantidade) }, { l: 'Receita', n: 1, f: x => R(x.receita) }, { l: 'Custo', n: 1, f: x => R(x.custo) }, { l: 'Lucro', n: 1, f: x => `<b class="${x.lucro < 0 ? 'erro' : ''}">${R(x.lucro)}</b>` }, { l: 'Margem', n: 1, f: x => N(x.margem, 1) + '%' }], r.produtos);
      ultimo = { nome: 'lucratividade', cols: [{ l: 'Produto', k: 'nome' }, { l: 'Qtd', k: 'quantidade' }, { l: 'Receita', k: 'receita' }, { l: 'Custo', k: 'custo' }, { l: 'Lucro', k: 'lucro' }, { l: 'Margem %', k: 'margem' }], rows: r.produtos };
    } else {
      const r = await api('/relatorios/mais-vendidos?' + per() + '&limite=50');
      res.innerHTML = tabela([{ l: '#', f: x => r.produtos.indexOf(x) + 1 }, { l: 'Produto', k: 'nome' }, { l: 'Quantidade', n: 1, f: x => N(x.quantidade) }, { l: 'Vendas', n: 1, k: 'comandas' }, { l: 'Receita', n: 1, f: x => R(x.receita) }], r.produtos, { vazio: 'Sem vendas no período.' });
      ultimo = { nome: 'mais-vendidos', cols: [{ l: 'Produto', k: 'nome' }, { l: 'Quantidade', k: 'quantidade' }, { l: 'Vendas', k: 'comandas' }, { l: 'Receita', k: 'receita' }], rows: r.produtos };
    }
  });
  el.onclick = seguro(async e => {
    const a = e.target.dataset.a; if (a) { aba = a; $$('#tb button', el).forEach(b => b.classList.toggle('on', b.dataset.a === a)); return gerar(); }
    if (e.target.dataset.cx) { const r = await api('/caixa/' + e.target.dataset.cx); modal({ titulo: 'Fechamento do caixa #' + r.caixa.id, tam: 'md', corpo: resumoCaixaHtml(r), botoes: [{ txt: 'Imprimir', fn: () => { window.print(); return false; } }, { txt: 'Fechar', cls: 'primary' }] }); }
  });
  $('#ok', el).onclick = gerar; $('#csv', el).onclick = () => ultimo && csv(ultimo.nome, ultimo.cols, ultimo.rows);
  await gerar();
} });

// ---- Extrato do produto (relatório): toda entrada e saída, com saldo linha a linha
registrar({ id: 'extrato-produto', titulo: 'Extrato do produto', grupo: 'Relatórios', perm: ['relatorios.estoque', 'estoque.ver'], render: async el => {
  const prods = await api('/produtos');
  const { dl, achar } = seletorProduto(prods, 'dl-ex');
  const TIPO = { entrada: 'Entrada', venda: 'Saída (venda)', estorno: 'Estorno de venda', ajuste: 'Ajuste', producao_saida: 'Saída (produção)', producao_entrada: 'Entrada (produção)' };
  el.innerHTML = `<div class="bar">${dl}<input id="pp" list="dl-ex" style="min-width:280px" placeholder="Produto (nome, código ou código de barras)" autocomplete="off"><label class="chk" style="margin:0">De <input type="date" id="de" value="${iniMes()}"></label><label class="chk" style="margin:0">Até <input type="date" id="ate" value="${hojeISO()}"></label>
    <button class="btn primary" id="ok">Ver extrato</button><div class="grow"></div><button class="btn" id="csv">CSV</button><button class="btn" onclick="window.print()">Imprimir</button></div><div id="res"><p class="muted">Escolha um produto para ver toda a movimentação de entrada e saída.</p></div>`;
  let ultimo = null;
  const buscar = seguro(async () => {
    const p = achar($('#pp', el).value); if (!p) throw new Error('Escolha um produto na lista (ou leia o código de barras).');
    $('#pp', el).value = rotuloProd(p);
    const r = await api('/estoque/extrato?' + qs({ produto_id: p.id, de: $('#de', el).value, ate: $('#ate', el).value })); ultimo = r; const un = r.produto.unidade;
    $('#res', el).innerHTML = `<h3 style="margin:6px 0">${esc(r.produto.nome)} <small class="muted">cód. ${esc(r.produto.codigo || '')}</small></h3>
      <div class="cards"><div class="stat">Saldo inicial<b>${N(r.saldo_inicial)} ${un}</b></div><div class="stat">Entradas<b>${N(r.entradas)} ${un}</b></div><div class="stat">Saídas<b>${N(r.saidas)} ${un}</b></div><div class="stat">Saldo final<b>${N(r.saldo_final)} ${un}</b></div><div class="stat">Estoque hoje<b>${N(r.produto.estoque_atual)} ${un}</b></div></div>` +
      tabela([{ l: 'Data', f: x => dt(x.criado_em) }, { l: 'Tipo', f: x => chip(TIPO[x.tipo] || x.tipo, x.quantidade > 0 ? 'ok' : 'warn') }, { l: 'Documento', k: 'documento' },
        { l: 'Entrada', n: 1, f: x => (x.quantidade > 0 ? N(x.quantidade) : '') }, { l: 'Saída', n: 1, f: x => (x.quantidade < 0 ? N(-x.quantidade) : '') }, { l: 'Saldo', n: 1, f: x => `<b>${N(x.saldo_apos)}</b>` },
        { l: 'Custo un.', n: 1, f: x => (x.custo_unit != null ? R(x.custo_unit) : '') }, { l: 'Usuário', k: 'usuario' }, { l: 'Motivo / obs.', k: 'motivo' }], r.linhas, { vazio: 'Nenhuma movimentação no período.' });
  });
  $('#ok', el).onclick = buscar; $('#pp', el).onchange = () => { if (achar($('#pp', el).value)) buscar(); };
  $('#csv', el).onclick = () => ultimo && csv('extrato-' + (ultimo.produto.codigo || ultimo.produto.id), [{ l: 'Data', k: 'criado_em' }, { l: 'Tipo', k: 'tipo' }, { l: 'Documento', k: 'documento' }, { l: 'Quantidade', k: 'quantidade' }, { l: 'Saldo', k: 'saldo_apos' }, { l: 'Custo', k: 'custo_unit' }, { l: 'Usuário', k: 'usuario' }, { l: 'Motivo', k: 'motivo' }], ultimo.linhas);
} });

// ---- Relatório de entradas de mercadoria: filtros por período, tipo e fornecedor; colunas ordenáveis (clique no título)
registrar({ id: 'rel-entradas', titulo: 'Entradas de mercadoria', grupo: 'Relatórios', perm: ['relatorios.estoque', 'estoque.ver'], render: async el => {
  const forn = await api('/fornecedores').catch(() => []);
  const TIPO = { xml: 'Entrada XML', consignado: 'Consignado', manual: 'Manual', doacao: 'Doação' };
  el.innerHTML = `<div class="bar"><label class="chk" style="margin:0">De <input type="date" id="de" value="${iniMes()}"></label><label class="chk" style="margin:0">Até <input type="date" id="ate" value="${hojeISO()}"></label>
    <label class="chk" style="margin:0">Tipo <select id="tp"><option value="">Todos</option><option value="xml">Entrada XML</option><option value="consignado">Entrada consignado</option><option value="manual">Entrada manual</option><option value="doacao">Doação</option></select></label>
    <label class="chk" style="margin:0">Fornecedor <select id="fo"><option value="">Todos</option>${forn.map(f => `<option value="${f.id}">${esc(f.nome)}</option>`).join('')}</select></label>
    <label class="chk" style="margin:0"><input type="checkbox" id="it"> Mostrar itens</label>
    <button class="btn primary" id="ok">Gerar</button><div class="grow"></div><button class="btn" id="csv">CSV</button><button class="btn" onclick="window.print()">Imprimir</button></div><div id="res"></div>`;
  let ultimo = null;
  const gerar = seguro(async () => {
    const d = await api('/estoque/relatorio-entradas?' + qs({ de: $('#de', el).value, ate: $('#ate', el).value, tipo: $('#tp', el).value, fornecedor_id: $('#fo', el).value }));
    const itens = $('#it', el).checked; ultimo = d;
    const pt = Object.entries(d.por_tipo).map(([k, v]) => `<div class="stat">${esc(TIPO[k] || k)}<b>${R(v.valor)}</b><small>${v.entradas} entrada(s)</small></div>`).join('');
    const tipoChip = t => chip(TIPO[t] || t, t === 'consignado' ? 'warn' : t === 'xml' ? 'ok' : '');
    const cols = [{ l: 'Data', f: x => dt(x.criado_em) }, { l: 'Tipo', f: x => tipoChip(x.tipo) + (x.tipo === 'consignado' && x.consig_status ? ` <span class="muted">${x.consig_status === 'acertada' ? 'acertada' : 'em aberto'}</span>` : '') }, { l: 'Fornecedor', f: x => esc(x.fornecedor || '—') }, { l: 'Nº nota', f: x => esc(x.numero || '') },
      { l: 'Itens', n: 1, k: 'qtd_itens' }, { l: 'Qtd. total', n: 1, f: x => N(x.qtd_total) }, { l: 'Valor', n: 1, f: x => R(x.total) }, { l: 'Usuário', f: x => esc(x.usuario || '') }];
    $('#res', el).innerHTML = `<div class="cards"><div class="stat">Entradas no período<b>${d.total.entradas}</b></div><div class="stat">Valor total<b>${R(d.total.valor)}</b></div>${pt}</div>
      <p class="muted">Clique no título de uma coluna para ordenar (como no Excel); use a caixa de filtro para achar uma nota ou fornecedor.</p>` +
      tabela(cols, d.entradas, { vazio: 'Nenhuma entrada nesse filtro.', acoes: itens ? null : x => (x.itens.length ? `<button class="btn sm" data-ver="${x.id}">Itens</button>` : '') }) +
      (itens && d.entradas.length ? `<h3 style="margin:16px 0 6px">Itens das entradas</h3>` + tabela([{ l: 'Data', f: x => dt(x.criado_em) }, { l: 'Tipo', f: x => esc(TIPO[x.tipo] || x.tipo) }, { l: 'Fornecedor', f: x => esc(x.fornecedor || '—') }, { l: 'Nº nota', f: x => esc(x.numero || '') }, { l: 'Produto', f: x => esc(x.produto || '') + (x.doacao ? ' <span class="muted">(doação)</span>' : '') }, { l: 'Qtd.', n: 1, f: x => N(x.quantidade) + ' ' + esc(x.unidade || '') }, { l: 'Custo un.', n: 1, f: x => R(x.custo_unit) }, { l: 'Total', n: 1, f: x => R(x.total) }],
        d.entradas.flatMap(e => e.itens.map(i => ({ ...i, criado_em: e.criado_em, tipo: e.tipo, fornecedor: e.fornecedor, numero: e.numero })))) : '');
  });
  el.onclick = seguro(async e => {
    const v = e.target.dataset.ver; if (!v || !ultimo) return;
    const en = ultimo.entradas.find(x => String(x.id) === v); if (!en) return;
    modal({ titulo: `Itens da entrada ${en.numero ? 'NF ' + en.numero : '#' + en.id}`, tam: 'lg', corpo: `<p class="muted">${esc(TIPO[en.tipo] || en.tipo)} · ${esc(en.fornecedor || 'sem fornecedor')} · ${dt(en.criado_em)}</p>` + tabela([{ l: 'Produto', f: x => esc(x.produto || '') + (x.doacao ? ' <span class="muted">(doação)</span>' : '') }, { l: 'Qtd.', n: 1, f: x => N(x.quantidade) + ' ' + esc(x.unidade || '') }, { l: 'Custo un.', n: 1, f: x => R(x.custo_unit) }, { l: 'Total', n: 1, f: x => R(x.total) }], en.itens), botoes: [{ txt: 'Fechar', cls: 'primary' }] });
  });
  $('#ok', el).onclick = gerar; $('#it', el).onchange = gerar;
  $('#csv', el).onclick = () => ultimo && csv('entradas', [{ l: 'Data', csv: x => x.criado_em }, { l: 'Tipo', csv: x => TIPO[x.tipo] }, { l: 'Fornecedor', k: 'fornecedor' }, { l: 'Nº nota', k: 'numero' }, { l: 'Itens', k: 'qtd_itens' }, { l: 'Qtd total', k: 'qtd_total' }, { l: 'Valor', k: 'total' }, { l: 'Usuário', k: 'usuario' }], ultimo.entradas);
  gerar();
} });
