// Painel (layout A): indicadores no topo + gráfico por hora/dia, top 5, formas de pagamento, contas a pagar e estoque baixo.
// Cada cartão tem o seu próprio período (padrão: hoje ao abrir a tela).
const PN_PERIODOS = [['hoje', 'Hoje'], ['ontem', 'Ontem'], ['7d', 'Últimos 7 dias'], ['30d', 'Últimos 30 dias'], ['mes', 'Este mês'], ['mesant', 'Mês passado'], ['custom', 'Escolher datas…']];
function pnIso(d) { return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); }
function pnIntervalo(per) {
  const h = new Date(); h.setHours(12, 0, 0, 0); const add = n => { const d = new Date(h); d.setDate(d.getDate() + n); return d; };
  switch (per.preset) {
    case 'ontem': return [pnIso(add(-1)), pnIso(add(-1))];
    case '7d': return [pnIso(add(-6)), pnIso(h)];
    case '30d': return [pnIso(add(-29)), pnIso(h)];
    case 'mes': return [pnIso(new Date(h.getFullYear(), h.getMonth(), 1, 12)), pnIso(h)];
    case 'mesant': return [pnIso(new Date(h.getFullYear(), h.getMonth() - 1, 1, 12)), pnIso(new Date(h.getFullYear(), h.getMonth(), 0, 12))];
    case 'custom': return [per.de || pnIso(h), per.ate || pnIso(h)];
    default: return [pnIso(h), pnIso(h)];
  }
}
const pnDia = s => s.split('-').reverse().slice(0, 2).join('/');
const pnRotulo = (de, ate) => (de === ate ? pnDia(de) : pnDia(de) + ' a ' + pnDia(ate));
const pnVar = (a, b) => (b > 0 ? (a - b) / b * 100 : (a > 0 ? 100 : 0));
const pnVarHtml = (a, b, inverso) => { const v = pnVar(a, b), bom = inverso ? v <= 0 : v >= 0; return `<div class="pa-var ${bom ? 'up' : 'dn'}">${v >= 0 ? '▲' : '▼'} ${Math.abs(v).toFixed(1).replace('.', ',')}% <span>vs período anterior</span></div>`; };

function pnAreaChart(serie) {
  const W = 720, H = 250, m = { l: 58, r: 12, t: 12, b: 26 }, iw = W - m.l - m.r, ih = H - m.t - m.b;
  const vs = serie.map(s => s.v), mx = Math.max(10, ...vs);
  const exp = Math.pow(10, Math.floor(Math.log10(mx))), f = mx / exp, passo = exp * (f > 5 ? 2 : f > 2 ? 1 : 0.5), top = Math.ceil(mx / passo) * passo;
  const x = i => m.l + (serie.length > 1 ? i * iw / (serie.length - 1) : iw / 2), y = v => m.t + ih - (v / top) * ih;
  let g = '';
  for (let v = 0; v <= top + 0.001; v += passo) g += `<line x1="${m.l}" x2="${W - m.r}" y1="${y(v)}" y2="${y(v)}" class="gl"/><text x="${m.l - 6}" y="${y(v) + 4}" text-anchor="end" class="gt">${R(v).replace(',00', '')}</text>`;
  const cada = Math.ceil(serie.length / 12);
  serie.forEach((s, i) => { if (i % cada === 0 || i === serie.length - 1) g += `<text x="${x(i)}" y="${H - 6}" text-anchor="middle" class="gt">${esc(s.rotulo)}</text>`; });
  const linha = serie.map((s, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)} ${y(s.v).toFixed(1)}`).join(' ');
  const area = `${linha} L${x(serie.length - 1).toFixed(1)} ${y(0)} L${x(0).toFixed(1)} ${y(0)} Z`;
  return `<svg viewBox="0 0 ${W} ${H}" class="pa-svg"><defs><linearGradient id="pag" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#b4472b" stop-opacity=".30"/><stop offset="1" stop-color="#b4472b" stop-opacity="0"/></linearGradient></defs>${g}
    <path d="${area}" fill="url(#pag)"/><path d="${linha}" class="lin"/>${serie.map((s, i) => `<circle cx="${x(i)}" cy="${y(s.v)}" r="${serie.length > 20 ? 2.5 : 4}" class="pt"><title>${esc(s.rotulo)}: ${R(s.v)} · ${s.n} venda(s)</title></circle>`).join('')}</svg>`;
}
const PN_CORES = ['#b4472b', '#1f8a4c', '#c98a06', '#2b6cb0', '#7c4dbd', '#8b93a7'];
function pnDonut(formas) {
  if (!formas.length) return '<p class="muted">Sem pagamentos no período.</p>';
  let acc = 0; const arcos = formas.map((f, i) => { const a = `<circle cx="21" cy="21" r="15.9" fill="none" stroke="${PN_CORES[i % PN_CORES.length]}" stroke-width="6" stroke-dasharray="${f.pct.toFixed(2)} ${(100 - f.pct).toFixed(2)}" stroke-dashoffset="${(-acc).toFixed(2)}" transform="rotate(-90 21 21)"/>`; acc += f.pct; return a; }).join('');
  return `<div class="pa-donut"><svg viewBox="0 0 42 42" width="130" height="130"><circle cx="21" cy="21" r="15.9" fill="none" stroke="#eceef3" stroke-width="6"/>${arcos}</svg>
    <div class="pa-leg">${formas.map((f, i) => `<div><span style="color:${PN_CORES[i % PN_CORES.length]}">●</span> ${esc(f.nome)} <b>${f.pct.toFixed(1).replace('.', ',')}%</b> <small class="muted">${R(f.v)}</small></div>`).join('')}</div></div>`;
}

registrar({ id: 'painel', titulo: 'Painel', grupo: 'Início', render: async el => {
  const per = {};   // período de cada cartão (padrão: hoje)
  const CARDS = ['venda', 'atend', 'ticket', 'compras', 'hora', 'top', 'pagto', 'pagar'];
  CARDS.forEach(c => { per[c] = { preset: 'hoje' }; });
  const SEM_PER = ['estoque'];
  const seletor = c => { const p = per[c], [de, ate] = pnIntervalo(p);
    return `<div class="pa-per"><select data-per="${c}">${PN_PERIODOS.map(([k, t]) => `<option value="${k}" ${p.preset === k ? 'selected' : ''}>${t}</option>`).join('')}</select>
      ${p.preset === 'custom' ? `<span class="pa-cust"><input type="date" data-de="${c}" value="${de}"><input type="date" data-ate="${c}" value="${ate}"><button class="btn sm primary" data-ok="${c}">OK</button></span>` : `<small class="muted">${pnRotulo(de, ate)}</small>`}</div>`; };
  const moldura = (c, titulo, extra = '') => `<div class="pa-card ${extra}" data-card="${c}"><div class="pa-h"><h3>${titulo}</h3>${SEM_PER.includes(c) ? '' : seletor(c)}</div><div class="pa-b"><p class="muted">Carregando...</p></div></div>`;
  el.innerHTML = `<div class="pa-top"><div><div class="pa-t">Painel</div><div class="pa-sub" id="pa-sub"></div></div><div class="pa-acts"><button class="btn sm" id="pa-hoje">Todos para hoje</button><button class="btn sm" id="pa-rec" title="Atualizar">⟳ Atualizar</button></div></div>
    <div class="pa-kpis">${moldura('venda', 'Venda líquida', 'k1')}${moldura('atend', 'Atendimentos', 'k2')}${moldura('ticket', 'Ticket médio', 'k3')}${moldura('compras', 'Compras x Vendas', 'k4')}</div>
    <div class="pa-mid">${moldura('hora', 'Venda por hora / dia', 'grande')}${moldura('top', 'Top 5 produtos')}</div>
    <div class="pa-bot">${moldura('pagto', 'Formas de pagamento')}${moldura('pagar', 'Contas a pagar')}${moldura('estoque', 'Estoque baixo')}</div>`;
  const corpo = c => $(`[data-card="${c}"] .pa-b`, el);
  const desenhar = {
    venda: d => `<div class="pa-big">${R(d.atual.v)}</div>${pnVarHtml(d.atual.v, d.anterior.v)}<small class="muted">Anterior: ${R(d.anterior.v)} (${pnRotulo(d.ant.de, d.ant.ate)})</small>`,
    atend: d => `<div class="pa-big">${d.atual.n}</div>${pnVarHtml(d.atual.n, d.anterior.n)}<small class="muted">Anterior: ${d.anterior.n}</small>`,
    ticket: d => `<div class="pa-big">${R(d.atual.t)}</div>${pnVarHtml(d.atual.t, d.anterior.t)}<small class="muted">Anterior: ${R(d.anterior.t)}</small>`,
    compras: d => `<div class="pa-big">${d.pct.toFixed(1).replace('.', ',')}%</div>${pnVarHtml(d.pct, d.pct_ant, true)}<small class="muted">Compras ${R(d.compras)} · Vendas ${R(d.vendas)}</small>`,
    hora: d => (d.serie.some(s => s.v > 0) ? pnAreaChart(d.serie) : '<p class="muted" style="padding:40px 0;text-align:center">Sem vendas no período.</p>'),
    top: d => (d.top.length ? d.top.map((p, i) => `<div class="pa-rk"><div class="pa-rk-l"><span>${i + 1}. ${esc(p.nome)}</span><b>${R(p.venda)}</b></div><div class="pa-bar"><i style="width:${Math.max(3, p.part).toFixed(1)}%"></i></div><small class="muted">${p.un.toLocaleString('pt-BR')} un. · ${p.part.toFixed(1).replace('.', ',')}%</small></div>`).join('') : '<p class="muted">Sem vendas no período.</p>'),
    pagto: d => pnDonut(d.formas),
    pagar: d => `<div class="pa-big">${R(d.periodo)}</div><small class="muted">${d.n_periodo} título(s) vencendo no período</small>
      <div class="pa-l"><span>Vencidos</span><b class="${d.vencidos ? 'neg' : ''}">${R(d.vencidos)}</b></div><div class="pa-l"><span>Total em aberto</span><b>${R(d.total)}</b></div>`,
    estoque: d => (d.baixo.length ? d.baixo.map(p => `<div class="pa-l"><span>${esc(p.nome)}</span><b class="neg">${N(p.estoque_atual)} ${esc(p.unidade)}</b></div>`).join('') + '<small class="muted">Abaixo do estoque mínimo</small>' : '<p class="muted">Nenhum produto abaixo do mínimo. 👍</p>'),
  };
  const carregarCard = async c => {
    const [de, ate] = SEM_PER.includes(c) ? ['', ''] : pnIntervalo(per[c]);
    try { const d = await api(`/relatorios/painel-card?card=${c}&de=${de}&ate=${ate}`); const b = corpo(c); if (b) b.innerHTML = desenhar[c](d); }
    catch (e) { const b = corpo(c); if (b) b.innerHTML = `<p class="erro">${esc(e.message)}</p>`; }
  };
  const recarregarSeletor = c => { const h = $(`[data-card="${c}"] .pa-per`, el); if (h) h.outerHTML = seletor(c); };
  const todos = () => Promise.all(CARDS.concat(SEM_PER).map(carregarCard));
  api('/caixa/atual').then(r => { if (r && r.caixa) $('#pa-sub', el).textContent = (r.evento ? r.evento.nome + ' · ' : '') + 'caixa ' + String(r.caixa.numero ?? r.caixa.id).padStart(6, '0') + ' aberto'; }).catch(() => { });
  el.onchange = seguro(async e => {
    const c = e.target.dataset.per; if (!c) return;
    per[c].preset = e.target.value; if (per[c].preset === 'custom') { const [de, ate] = pnIntervalo({ preset: 'hoje' }); per[c].de = per[c].de || de; per[c].ate = per[c].ate || ate; }
    recarregarSeletor(c); if (per[c].preset !== 'custom') await carregarCard(c);
  });
  el.onclick = seguro(async e => {
    const t = e.target;
    if (t.id === 'pa-rec') return todos();
    if (t.id === 'pa-hoje') { CARDS.forEach(c => { per[c] = { preset: 'hoje' }; recarregarSeletor(c); }); return todos(); }
    if (t.dataset.ok) { const c = t.dataset.ok, de = $(`[data-de="${c}"]`, el).value, ate = $(`[data-ate="${c}"]`, el).value; if (!de || !ate) throw new Error('Informe as duas datas.'); per[c].de = de; per[c].ate = ate; recarregarSeletor(c); return carregarCard(c); }
  });
  await todos();
  S.timer = setInterval(() => { if (location.hash === '' || location.hash === '#/painel') todos().catch(() => { }); }, 60000);
} });
