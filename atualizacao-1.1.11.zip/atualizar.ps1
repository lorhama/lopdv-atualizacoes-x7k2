# Atualizador do LoPDV. Chamado pelo proprio sistema depois que o cliente confirma. Roda escondido; registra tudo em data\atualizacao.log
param([string]$Zip, [string]$Dir, [string]$Versao, [string]$Anterior, [int]$Porta = 3737, [switch]$Elevado, [string]$Self = '')
$ErrorActionPreference = 'Continue'
$dataDir = Join-Path $Dir 'data'; $pasta = Join-Path $dataDir 'atualizacao'
New-Item -ItemType Directory -Force -Path $pasta -ErrorAction SilentlyContinue | Out-Null
$log = Join-Path $dataDir 'atualizacao.log'
function G($t) { $l = '[' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '] ' + $t; try { Add-Content -Path $log -Value $l -Encoding UTF8 -ErrorAction Stop } catch { try { Add-Content -Path (Join-Path $env:TEMP 'lopdv-atualizacao.log') -Value $l -Encoding UTF8 } catch { } } }
# avisa ao sistema que o atualizador esta rodando (ele so se fecha depois disso)
try { [IO.File]::WriteAllText((Join-Path $pasta 'iniciado.txt'), (Get-Date).ToString('o')) } catch { }
$t0 = Get-Date
$est = [hashtable]::Synchronized(@{ etapa = 3; detalhe = 'Fechando o sistema'; pct = 75; erro = '' })
function Etapa($n, $d, $p) { $est.etapa = $n; $est.detalhe = $d; $est.pct = $p; G ('[etapa ' + $n + '/7] ' + $d) }
$script:ls = $null; $script:ps = $null
# enquanto o sistema esta fechado, este script responde no mesmo endereco (so neste computador) para a tela de atualizacao mostrar o andamento
function IniciarAndamento {
  try {
    $script:ls = New-Object Net.HttpListener; $script:ls.Prefixes.Add('http://127.0.0.1:' + $Porta + '/'); $script:ls.Prefixes.Add('http://localhost:' + $Porta + '/'); $script:ls.Start()
    $rs = [runspacefactory]::CreateRunspace(); $rs.Open(); $rs.SessionStateProxy.SetVariable('est', $est); $rs.SessionStateProxy.SetVariable('ls', $script:ls); $rs.SessionStateProxy.SetVariable('ant', $Anterior)
    $script:ps = [powershell]::Create(); $script:ps.Runspace = $rs
    [void]$script:ps.AddScript({
      while ($ls.IsListening) {
        try { $c = $ls.GetContext() } catch { break }
        try {
          if ($c.Request.Url.AbsolutePath -like '*/saude') { $j = (@{ ok = $true; banco = $false; versao = $ant } | ConvertTo-Json -Compress) }
          else { $j = (@{ versao = $ant; fase = 'reiniciando'; etapa = $est.etapa; detalhe = $est.detalhe; pct = $est.pct; erro = $est.erro; resultado = $null; acompanhado = $true } | ConvertTo-Json -Compress) }
          $b = [Text.Encoding]::UTF8.GetBytes($j); $c.Response.ContentType = 'application/json; charset=utf-8'; $c.Response.Headers.Add('Cache-Control', 'no-store'); $c.Response.OutputStream.Write($b, 0, $b.Length); $c.Response.Close()
        } catch { }
      }
    })
    [void]$script:ps.BeginInvoke()
  } catch { G ('Andamento na tela indisponivel: ' + $_.Exception.Message) }
}
function PararAndamento { try { if ($script:ls) { $script:ls.Stop(); $script:ls.Close() } } catch { }; try { if ($script:ps) { $script:ps.Dispose() } } catch { }; $script:ls = $null }
function Resultado($ok, $erro) {
  $o = @{ ok = $ok; versao = $Versao; anterior = $Anterior; erro = $erro; quando = (Get-Date).ToString('o') } | ConvertTo-Json -Compress
  try { [IO.File]::WriteAllText((Join-Path $pasta 'resultado.json'), $o, (New-Object Text.UTF8Encoding($false))) } catch { }
}
function NodesDoSistema { @(Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and $_.CommandLine -like ('*' + $Dir + '*server*index.js*') }) }
function Iniciar {
  # inicia o servidor escondido (o mesmo comando do atalho); a tela que esta aberta recarrega sozinha
  $cmd = Join-Path $Dir 'servidor.cmd'
  if (Test-Path $cmd) { Start-Process -FilePath $cmd -WorkingDirectory $Dir -WindowStyle Hidden }
}
function PortaAberta($s) { $fim = (Get-Date).AddSeconds($s); while ((Get-Date) -lt $fim) { try { $c = New-Object Net.Sockets.TcpClient; $c.Connect('127.0.0.1', $Porta); $c.Close(); return $true } catch { Start-Sleep -Milliseconds 500 } }; return $false }

G ('===== Atualizacao ' + $Anterior + ' -> ' + $Versao + ' (inicio) =====')
# 1) permissao de escrita na pasta do sistema; se faltar, pede ao Windows (UAC) uma vez
$teste = Join-Path $Dir ('.escrita-' + [guid]::NewGuid().ToString('N')); $escreve = $true
try { [IO.File]::WriteAllText($teste, 'x'); Remove-Item $teste -Force } catch { $escreve = $false }
if (-not $escreve -and -not $Elevado) {
  G 'Sem permissao de escrita; pedindo elevacao.'
  try { Start-Process powershell.exe -Verb RunAs -WindowStyle Hidden -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "$p = Get-Content -Raw -Encoding UTF8 ''' + (Join-Path $pasta 'params.json') + '''  | ConvertFrom-Json; & ([scriptblock]::Create([IO.File]::ReadAllText($p.ps1))) -Zip $p.zip -Dir $p.dir -Versao $p.versao -Anterior $p.anterior -Porta ([int]$p.porta) -Self $p.ps1 -Elevado"'); exit } catch { G ('Elevacao recusada: ' + $_.Exception.Message); Resultado $false 'O Windows nao autorizou a atualizacao (permissao de administrador).'; Iniciar; exit }
}
# 1b) extrai o pacote novo ja agora, enquanto o sistema ainda esta fechando (ganha tempo). tar.exe do Windows e bem mais rapido que Expand-Archive
$tmp = Join-Path $env:TEMP ('lopdv-upd-' + $Versao); $extraiu = $false
try {
  if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
  New-Item -ItemType Directory -Force -Path $tmp | Out-Null
  $tar = Join-Path $env:SystemRoot 'System32\tar.exe'
  if (Test-Path $tar) { & $tar -xf $Zip -C $tmp 2>$null; if ($LASTEXITCODE -eq 0 -and (Test-Path (Join-Path $tmp 'package.json'))) { $extraiu = $true } }
} catch { }
# 2) espera o sistema fechar (ele faz o backup de fechamento); depois forca se precisar
Etapa 3 'Fechando o sistema e fazendo o backup do banco de dados' 75
for ($i = 0; $i -lt 90; $i++) { if ((NodesDoSistema).Count -eq 0) { break }; if ($i -gt 0 -and $i % 5 -eq 0) { $est.detalhe = 'Aguardando o sistema fechar (' + $i + ' s)...' }; Start-Sleep -Seconds 1 }
NodesDoSistema | ForEach-Object { G ('Forcando encerramento do processo ' + $_.ProcessId); Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and $_.Name -match '^(cmd|wscript|cscript)\.exe$' -and $_.CommandLine -like ('*' + $Dir + '*') -and $_.ProcessId -ne $PID } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
G ('Sistema fechado apos ' + [int]((Get-Date) - $t0).TotalSeconds + ' s.')
Start-Sleep -Milliseconds 500
IniciarAndamento
$falha = ''
$rb = Join-Path $dataDir ('rollback\' + $Anterior)
try {
  # 3) copia de seguranca dos arquivos atuais (para voltar se algo der errado). O banco ja tem backup do fechamento.
  Etapa 4 'Guardando uma copia de seguranca dos arquivos atuais' 80
  if (Test-Path $rb) { Remove-Item $rb -Recurse -Force -ErrorAction SilentlyContinue }
  New-Item -ItemType Directory -Force -Path $rb | Out-Null
  & robocopy $Dir $rb /E /XD data node_modules logs /NFL /NDL /NJH /NJS /NP | Out-Null
  G ('Copia de seguranca dos arquivos em ' + $rb)
  # 4) extrai o pacote novo e copia por cima (nunca toca em data\ nem node_modules\)
  Etapa 5 'Instalando os arquivos novos' 85
  if (-not $extraiu) { if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }; Expand-Archive -Path $Zip -DestinationPath $tmp -Force }
  # as bibliotecas so precisam ser reinstaladas se a lista de dependencias mudou
  $deps = { param($f) try { (Get-Content $f -Raw -Encoding UTF8 | ConvertFrom-Json).dependencies | ConvertTo-Json -Compress } catch { 'x' + [guid]::NewGuid() } }
  $mudouDeps = (& $deps (Join-Path $Dir 'package.json')) -ne (& $deps (Join-Path $tmp 'package.json')) -or -not (Test-Path (Join-Path $Dir 'node_modules\express'))
  & robocopy $tmp $Dir /E /XD data node_modules /NFL /NDL /NJH /NJS /NP | Out-Null
  if ($LASTEXITCODE -ge 8) { throw ('Falha ao copiar os arquivos novos (robocopy ' + $LASTEXITCODE + ').') }
  Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
  G 'Arquivos novos copiados.'
  # 5) bibliotecas
  $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
  Etapa 6 $(if ($mudouDeps) { 'Instalando bibliotecas novas (pode demorar)' } else { 'Conferindo bibliotecas (nada a instalar)' }) 90
  if ($mudouDeps) {
  $nlog = Join-Path $env:TEMP 'lopdv-npm-upd.log'; Remove-Item $nlog -Force -ErrorAction SilentlyContinue
  $p = Start-Process cmd.exe -ArgumentList ('/c npm.cmd install --omit=dev --no-audit --no-fund > "' + $nlog + '" 2>&1') -WorkingDirectory $Dir -WindowStyle Hidden -PassThru -Wait
  if ($p.ExitCode -ne 0) { if (Test-Path $nlog) { Get-Content $nlog -Tail 15 | ForEach-Object { G ('npm> ' + $_) } }; throw ('npm install falhou (codigo ' + $p.ExitCode + ').') }
  G 'Bibliotecas instaladas.'
  } else { G 'Bibliotecas inalteradas (npm install dispensado).' }
  # 6) registro do Windows (se tiver permissao)
  try { Set-ItemProperty 'HKLM:\SOFTWARE\LoPDV' -Name Versao -Value $Versao -ErrorAction Stop; Set-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\LoPDV' -Name DisplayVersion -Value $Versao -ErrorAction Stop } catch { }
  # 7) liga o sistema novo e confere se subiu na versao certa
  Etapa 7 'Iniciando a nova versao do sistema' 95
  PararAndamento
  Iniciar
  if (-not (PortaAberta 120)) { throw 'O sistema novo nao iniciou.' }
  $ver = ''; try { $ver = (Invoke-RestMethod -Uri ('http://127.0.0.1:' + $Porta + '/api/saude') -TimeoutSec 10).versao } catch { }
  if ($ver -ne $Versao) { throw ('O sistema iniciou na versao ' + $ver + ' em vez de ' + $Versao + '.') }
  Resultado $true ''
  G ('RESULTADO: CONCLUIDA - ' + $Anterior + ' -> ' + $Versao + ' em ' + [int]((Get-Date) - $t0).TotalSeconds + ' s.')
} catch {
  $falha = $_.Exception.Message; $est.erro = $falha; G ('FALHA: ' + $falha)
  # volta para a versao anterior
  try {
    NodesDoSistema | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }; Start-Sleep -Seconds 2
    if (Test-Path $rb) { & robocopy $rb $Dir /E /XD data node_modules /NFL /NDL /NJH /NJS /NP | Out-Null; G 'Arquivos da versao anterior restaurados.' }
  } catch { G ('Erro ao restaurar: ' + $_.Exception.Message) }
  Resultado $false ('A atualizacao falhou e o sistema voltou para a versao ' + $Anterior + '. Motivo: ' + $falha)
  G ('RESULTADO: FALHA - ' + $Anterior + ' -> ' + $Versao + ' (sistema voltou para a versao anterior). Motivo: ' + $falha)
  PararAndamento
  Iniciar
}
# 8) se ninguem estava com a tela aberta acompanhando (ela recarrega sozinha), abre o sistema
Start-Sleep -Seconds 3
$acomp = $false; try { $acomp = (Invoke-RestMethod -Uri ('http://127.0.0.1:' + $Porta + '/api/atualizacao/status') -TimeoutSec 5).acompanhado } catch { }
if (-not $acomp) { $lnk = Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'LoPDV.lnk'; if (Test-Path $lnk) { Start-Process explorer.exe -ArgumentList ('"' + $lnk + '"') } }
