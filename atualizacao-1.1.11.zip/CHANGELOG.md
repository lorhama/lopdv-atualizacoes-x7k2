# Histórico de versões — LoPDV

Formato: [versão semântica](https://semver.org/lang/pt-BR/) `MAIOR.MENOR.CORREÇÃO`.
Para lançar uma nova versão: `python3 scripts/nova-versao.py 1.0.1 "o que mudou"`.

## 1.1.11 — 02/11/2026
- Correção: O aviso de nova versão aparecia duas vezes (faixa no topo e botão na barra). Agora aparece só o botão da barra superior, que abre as novidades e permite atualizar.
- Melhoria: O LoPDV não abre mais duas vezes no mesmo computador: se já houver uma janela aberta, o atalho avisa "O LoPDV já está aberto neste computador" e não abre outra. Uma segunda cópia do servidor também não inicia.
- Melhoria: Ao finalizar a venda, abre uma janela com tudo que foi feito: pagamento por forma (com NSU/autorização do cartão), troco a entregar, desconto/arredondamento, fiado lançado, pedido enviado e impresso na cozinha/bar, baixa de estoque, doação do troco e comprovante do cartão.
- Melhoria: Venda fiado imprime uma via com os débitos em aberto do cliente: valor de cada venda (a de hoje marcada), vencimentos e o total em aberto, com linha de assinatura. O resultado aparece na janela de finalização.
- Melhoria: Ao receber um fiado, imprime o comprovante de pagamento para o cliente (venda de origem, forma, valor pago, saldo restante ou quitada e total que o cliente ainda deve). Janela mostra o resultado, com botão Reimprimir.
- Melhoria: Botão "Receber fiado" na tela de vendas: abre a consulta de fiado por cliente (lista de clientes com débito, vendas em aberto com vencimento e vencidas em destaque, opção de ver quitadas), botão Itens para ver os itens de cada venda e botão Receber para dar baixa ali mesmo.
- Melhoria: Ajuste de estoque agora tem motivos cadastrados: escolha na lista (mais observação opcional) e cadastre, renomeie, inative ou exclua motivos pelo botão da própria tela. Já vêm cadastrados: ACERTO ESTOQUE, DEVOLUCAO P/FORNEC., DOACAO, PRODUTO VENCIDO, QUEBRAS, ROUBO e USO INTERNO.
- Melhoria: Nova tela Balanço geral (menu Estoque): conferência de todo o estoque com leitor de código de barras, sem acúmulo (informa o total e salva no F2) ou com acúmulo (cada leitura soma). Só um balanço em andamento por vez; lista dos balanços com a situação; ao finalizar pergunta se zera os não conferidos (com confirmação), abate do estoque o que foi vendido depois de cada contagem (caixa aberto), bloqueia entrada de mercadoria enquanto houver balanço aberto e gera relatório PDF dos conferidos e não conferidos (baixar ou imprimir).
- Melhoria: O menu lateral recolhe sozinho ao clicar em qualquer lugar fora dele (no celular, fecha). O recolhimento acontece depois do clique, para o botão clicado não sair do lugar e o clique não se perder.
- Melhoria: A importação de XML só aceita nota emitida para o CNPJ da empresa em uso (o destinatário da nota precisa ser a empresa). Nota de outro CNPJ é recusada com aviso claro.
- Melhoria: No cadastro da empresa, CNPJ/CPF, telefone e CEP ganham máscara automática enquanto digita, e os documentos são validados (dígitos verificadores) antes de salvar.
- Melhoria: Entrada manual: botão "Entrada por foto da nota". Lê a foto da nota aqui no computador, sem internet (OCR offline), mostra os itens para conferência (produto, quantidade, valor, com alerta de "conferir") e passa os marcados para a entrada. A leitura de foto pode errar: sempre conferir.
- Melhoria: Novo relatório "Entradas de mercadoria" (menu Relatórios): filtros por período, tipo (Entrada XML, Entrada consignado, manual, doação) e fornecedor; totais por tipo, opção de mostrar os itens, CSV e impressão.
- Melhoria: Todas as tabelas do sistema agora ordenam ao clicar no título da coluna (crescente/decrescente, como no Excel; reconhece números, valores em R$ e datas) e têm caixa de filtro para achar linhas por qualquer texto. A coluna de data passou a mostrar o ano.
- Melhoria: Itens da nota (XML) sem cadastro agora geram cadastro automático SUSPENSO: código provisório (AUTO-n) que não gasta o sequencial, produto não vendável, marcado como "Pendente" em Produtos até alguém confirmar (aí recebe o código sequencial) ou amarrar. Botão "Amarrar ao cadastro" na importação do XML (e em Produtos, para pendentes já lançados): liga a entrada a um produto existente, aprende o código de barras novo/código do fornecedor e descarta o cadastro automático (estoque e histórico vão para o produto existente).
- Melhoria: O cabeçalho superior (título da tela, empresa, usuário, Minha senha e Sair) fica fixo no topo: continua visível por mais que a página seja rolada para baixo.
- Melhoria: Modo noturno: chave "🌙 Noturno" na barra superior deixa o sistema escuro (tela, tabelas, janelas, avisos). A escolha fica guardada no computador e vale já na próxima abertura. Na impressão continua claro.

## 1.1.10 — 02/11/2026
- Correção: Atualização: o plano B de início do atualizador usa um método que sobrevive ao fechamento do sistema.
- Melhoria: Backups em pasta própria (padrão C:\LoPDV-Backups), que o cliente pode trocar em Configurações.
- Melhoria: Limpeza automática de sobras no computador do cliente (pacotes antigos, cópias de segurança antigas, notas e arquivos de desenvolvimento).
- Melhoria: Botões da base da tela de Vendas com tamanho padrão e nomes abreviados.

## 1.1.9 — 02/11/2026
- Correção: Atualização pela tela travava: o atualizador agora inicia de forma independente do sistema, o sistema só fecha depois que ele confirma, e qualquer erro aparece na tela e no log.
- Melhoria: A atualização mostra cada etapa do que está acontecendo e grava log com resultado (concluída ou falha); botão Ver log da atualização em Configurações.

## 1.1.8 — 02/11/2026
- Correção: Aviso de e-mail com Gmail: explica a senha de app e permite cadastrar usuário e senha.
- Melhoria: Cadastros em LETRAS MAIÚSCULAS (digitação e gravação); cadastros existentes são convertidos uma vez.
- Melhoria: Várias empresas (CNPJs): tela Empresas lista, cadastra, edita, inativa e exclui; uma fica em uso.
- Melhoria: Instalador de atalhos dos terminais pergunta qual empresa o terminal usa; a venda guarda a empresa.
- Melhoria: Mensagens de aviso aparecem no topo da tela.
- Melhoria: E-mail: seletor de provedor (Gmail, Outlook, Yahoo) com passo a passo da senha de app.

## 1.1.7 — 02/11/2026
- Correção: Sair da tela de Vendas com venda em andamento não congela mais: ao confirmar, a venda fica pendente e a tela escolhida abre.
- Correção: Ficha técnica do produto: o campo Unidade agora lista as unidades.
- Correção: Autorização por usuário e senha nunca vem preenchida.
- Melhoria: Aviso de nova versão na barra superior.
- Melhoria: Fechamento do caixa: uma linha por forma de pagamento no comprovante.
- Melhoria: Vendas e entrada de mercadoria exigem empresa cadastrada.
- Melhoria: Ao abrir o caixa, o sistema vai direto para Vendas.
- Melhoria: Lançar produção e Produtos do caixa exigem usuário e senha, com permissões próprias em Equipe → Perfis.
- Melhoria: Atualização automática mais rápida.

## 1.1.6 — 02/11/2026
- Melhoria: Número do usuário sem zeros à esquerda (tela de login, lista de usuários e vendedor na venda); digitar 1 ou 000001 continua funcionando

## 1.1.5 — 02/11/2026
- Correção: Aviso de nova versão: o sistema confere ao abrir e de hora em hora, e avisa os administradores quando a atualização automática não está configurada ou falha
- Correção: Painel de caixa: a tabela não fica mais cortada à direita
- Correção: Tela de vendas: a lista de itens não corta mais as colunas Total e Situação; produtos e barra inferior mais compactos
- Melhoria: Controle de patrimônio: bens não imobilizados recebem número de patrimônio; nova tela Patrimônio com busca, novo bem, edição, baixa, etiqueta e CSV
- Melhoria: Entrada de mercadoria (manual e automática): opção de nota de doação (por nota e por item), nota mista com revenda, doação e patrimônio; doação entra no estoque sem custo e sem conta a pagar
- Melhoria: Consignação: nota consignada entra no estoque sem conta a pagar; nova tela Consignações para devoluções e acerto com a nota final, que gera o contas a pagar do que ficou
- Melhoria: Vendas: venda pendente (ao sair com itens lançados pergunta, salva como pendente e oferece resgatar ou excluir com usuário e senha)
- Melhoria: Painel inicial com novo layout, período por cartão (padrão: hoje) e sem previsão de vendas do mês
- Melhoria: Menu lateral fixo (acompanha a rolagem só quando não cabe na tela) e telas ajustadas ao tamanho do monitor
- Melhoria: Telas de entrada renomeadas: Entrada de mercadoria (Manual) e (Automática)
- Melhoria: Empresa: guia em PDF para configurar o envio de e-mails (Gmail, Hotmail e outros)
- Melhoria: Atualização automática com endereço de atualizações já configurado e travado; o cliente não precisa informar nada

## 1.1.4 — 02/11/2026
- Correção: Receber não exige mais enviar os itens antes: ao finalizar o recebimento, os itens são enviados automaticamente para a cozinha e o bar (aparecem na tela de produção e o pedido é impresso)

## 1.1.3 — 02/11/2026
- Correção: Clientes e Fornecedores agora aparecem no menu Cadastros
- Correção: Busca de XML na SEFAZ: nunca faz duas consultas com menos de 1h00min02s entre elas (evita bloqueio); intervalo mínimo do agendamento passou a 61 minutos
- Correção: Tela de Vendas ajustada ao tamanho da tela do cliente, sem barras de rolagem desnecessárias
- Melhoria: Painel com gráficos: venda líquida, ticket médio, previsão do mês, top 10 produtos, participação por categoria, compras x vendas e contas a pagar
- Melhoria: Menu reorganizado: Caixa, Conferência de caixa e Receber fiado agora ficam no Financeiro; menu esquerdo pode ser recolhido (botão ☰)
- Melhoria: Tela de vendas: botões Movimento de caixa (entrada/saída de valores), Fechar caixa e Alterar forma de pagamento
- Melhoria: Vendas: com caixa aberto entra direto na venda; sem caixa, já pede a abertura
- Melhoria: Nº da venda só é gerado ao lançar o primeiro produto; botão Cancelar venda sempre visível
- Melhoria: Vendedor da venda editável pelo número do usuário
- Melhoria: Observação no item: produtos podem permitir observação (padrão em porções, pratos e sobremesas); o sistema pergunta ao lançar e mostra no painel de itens
- Melhoria: Doação do troco: antes de entregar o troco, pergunta se o cliente quer doar as moedinhas aos locais definidos nas configurações
- Melhoria: Abertura de caixa pede o nome do evento, a equipe e a função de cada colaborador; durante o evento cada um só acessa o que a função permite
- Melhoria: Usuários: código sequencial, login pelo número com lista de usuários ativos (a partir de 2 letras) e ativar/inativar colaborador sem perder o histórico
- Melhoria: Recuperação de senha por e-mail e novo cadastro da Empresa (e-mail padrão e SMTP)
- Melhoria: Produtos: ficha técnica com unidades (kg/g, L/ml); produto com histórico não pode ser excluído, só inativado; configuração de estoque negativo (com autorização na venda)
- Melhoria: Entrada de mercadoria: a lista mostra se a nota entrou por busca automática de XML, busca manual, serviço por chave, arquivo ou digitação manual
- Melhoria: O instalador fecha sozinho quando tudo ocorre bem

## 1.1.2 — 02/11/2026
- Melhoria: Campos sequenciais (código interno do produto) ficam travados na tela e o número é gerado pelo sistema ao gravar o cadastro
- Melhoria: Códigos de barras e códigos do fornecedor no cadastro de produto agora aparecem em tabela, com o título de cada coluna
- Melhoria: Nenhuma tela do sistema (login, autorização, troca de senha, usuários) deixa o navegador oferecer ou gravar usuário e senha; campos de senha sem preenchimento automático
- Melhoria: Comandas da cozinha e do bar passam a ser impressas somente ao receber o pagamento do cliente (enviar a comanda só libera os itens na tela da cozinha/bar)
- Melhoria: Receber: remover forma de pagamento agora é uma lixeirinha
- Melhoria: Receber: botão Desconto geral trocado por Arredondamento (modal com valor em R$, para mais ou para menos); limites máximos configuráveis em Configurações; permissão própria (ou usuário e senha de quem tem); registrado na auditoria e no pedido
- Melhoria: Venda direta: sem comanda, mesa ou identificação. A tela de Vendas abre direto numa venda nova; pedido da cozinha/bar vai e imprime ao receber; "Vendas anteriores" lista em andamento/finalizadas/canceladas; textos "comanda" trocados por "venda" no sistema
- Melhoria: Observações da venda no campo da tela Receber (grava na venda e sai impressa no pedido da cozinha/bar)
- Melhoria: Estoque só baixa depois que a venda foi paga e TODOS os itens foram entregues (retirados) na cozinha e no bar; até lá o saldo fica reservado para não vender além do estoque
- Melhoria: Na abertura do caixa (e depois, em "Produtos do caixa") escolhe-se quais produtos serão vendidos no evento; a tela de Vendas mostra só esses produtos como botões grandes com imagem, nome e valor; clicar lança na venda (sem digitar nome nem ler código de barras)
- Melhoria: Imagem do produto no cadastro (reduzida automaticamente) para aparecer no botão da tela de vendas
- Melhoria: Produção: tela Estoque → Produção lança o produto preparado (ex.: pipoca) em estoque; a venda baixa só o produto; permissão própria; histórico e Extrato do produto
- Melhoria: Lançar produção em qualquer momento: botão "Produzir" na lista de produtos, campo "Produzir agora" no cadastro do prato e botão "Lançar produção" na tela de Vendas
- Melhoria: Insumos da produção só baixam no fechamento do caixa: a tela de fechar pede a sobra de cada insumo; o sistema baixa (estoque − sobra) e mostra previsto × usado × diferença; sem contagem vale o previsto pela ficha técnica
- Melhoria: Só um caixa aberto por vez no sistema inteiro (abrir e reabrir bloqueiam se já houver outro aberto; trava também no banco)
- Melhoria: Forma de pagamento: taxa da máquina em % e taxa fixa em R$ por transação (aparece na lista).
- Melhoria: Receber: mensagem em destaque quando a venda não pode ser finalizada; o botão fica liberado e abre uma janela explicando o motivo.
- Melhoria: Integração fiscal: cadastro do certificado digital A1, agendamento (por intervalo ou diário) e botão para buscar XMLs na SEFAZ, com painel de notas pendentes de entrada e já importadas no estoque.
- Melhoria: Integração com serviço pago de busca de nota por chave de acesso (inclusive cupom de consumidor), configurável.
- Melhoria: Menu lateral em grupos suspensos (Vendas e caixa, Estoque, Cadastros, Financeiro, Relatórios, Equipe, Configurações); todos os relatórios no mesmo grupo.
- Melhoria: Atualização automática: o sistema do cliente avisa quando há versão nova, pede confirmação, fecha, atualiza (com backup e volta sozinho se falhar), reabre no login e mostra as novidades. Pacote assinado.

## 1.1.1 — 02/11/2026
- Correção: Corrigido: o sistema 1.1.0 não iniciava depois da instalação (erro ao carregar a entrada de mercadoria)
- Melhoria: Instalador/atualizador encerra tudo do sistema antes de atualizar e, se o sistema não responder, mostra as últimas linhas do servidor.log
- Melhoria: Nova tela do instalador (passo atual, barra de progresso, andamento do download e registro colorido em tempo real)
- Melhoria: Ao concluir mostra 'Sistema instalado com sucesso' ou 'Deu erro' com o caminho dos logs, e deixa fechar a janela para procurar o log

## 1.1.0 — 02/11/2026
- Melhoria: Vendas/Comandas: botões Receber fiado e Nova comanda no rodapé; tela de venda no layout de balcão (caixa, nº da venda, vendedor, cliente, busca por nome, código interno ou código de barras)
- Melhoria: Numeração sequencial própria para caixas e vendas (tabelas caixas e vendas)
- Melhoria: Painel de caixa em tabela: filtros, ordenação, conferido, menu de ações, paginação e CSV
- Melhoria: Tela Receber nova: até 3 formas de pagamento, valor recebido e troco em dinheiro, cliente com busca (3 letras) e cadastro rápido, desconto geral, totais, atalhos F2/F10/Ctrl+D
- Melhoria: Códigos de barras em tabela própria (vários por produto, cada um com fator) e código interno automático do produto; códigos do produto em cada fornecedor
- Melhoria: Entrada de mercadoria: fator (unidades por embalagem) divide o custo e multiplica o estoque; entrada manual com busca e cadastro rápido de produto; importação de XML de NF-e, NFC-e e cupom SAT ligando ao cadastro existente sem duplicar
- Melhoria: Ao finalizar a entrada abre o lançamento da despesa (parcelas, vencimento e forma de pagamento) e gera as contas a pagar; nova forma de pagamento Consignado
- Melhoria: Nova tela Ajuste de estoque (avulso), com permissão própria, registrada na tabela ajustes_estoque; novo relatório Extrato do produto
- Melhoria: Impressoras: lista as instaladas no Windows e permite o setor Todos os setores

## 1.0.3 — 02/11/2026
- Correção: Instalador/atualizador falhava no passo 4 (npm) mesmo com o npm concluido com sucesso: o codigo de saida nao era lido
- Melhoria: Botoes com o nome da funcao (Atualizar/Reparar, Desinstalar, Cancelar; Remover banco/Manter banco) no lugar de Sim/Nao
- Melhoria: Log de instalacao em um unico arquivo (pasta\logs\instalacao.log), com data e hora em cada linha, do mais antigo ao mais recente, mostrando o que deu certo e o que deu errado; saida do npm dentro dele; logs com mais de 30 dias sao apagados

## 1.0.2 — 02/11/2026
- Correção: Erro ao entrar no sistema ("(cli || db).query is not a function"): o login nao conseguia gravar o registro de auditoria
- Melhoria: Tela de login abre em janela pequena, so com o cartao arredondado
- Melhoria: Depois de entrar com usuario e senha, a janela se ajusta ao tamanho da tela do cliente
- Melhoria: Atalho dos terminais tambem abre a janela de login pequena

## 1.0.1 — 02/11/2026
- Melhoria: Instalador mostra o andamento (tempo decorrido e ultima linha do log) durante a instalacao do PostgreSQL, Node.js e bibliotecas, para nao parecer travado
- Melhoria: Log da instalacao gravado na pasta escolhida (pasta\logs), incluindo a saida do npm
- Melhoria: Se a instalacao falhar, a pasta e mantida, o log abre no Bloco de Notas e uma nova execucao continua de onde parou
- Melhoria: Download do PostgreSQL com barra de progresso

## 1.0.0 — 02/11/2026
Primeira versão.
- Vendas/comandas com envio para cozinha e bar, controle de itens retirados e bloqueio de estoque negativo (com autorização por usuário e senha).
- Caixa: abertura, sangria/suprimento, fechamento por forma de pagamento com divergência e motivo, conferência, reabertura e alteração de forma de pagamento (com senha).
- Receber fiado (exige caixa aberto), formas de pagamento cadastráveis e integração TEF por pastas (padrão SITEF/TEF_DIAL).
- Cadastros (produtos com ficha técnica, categorias, clientes, fornecedores), estoque com entrada por XML ou manual, financeiro (contas a pagar/receber) e relatórios.
- Usuários, perfis e permissões por tela e por função, com auditoria.
- Backup automático ao abrir e ao fechar (guarda 3 dias), com pasta extra opcional.
- Instalador sem `.exe` (`Instalar-LoPDV-1.0.0.bat`), instalador de atalho para terminais e instalador `.exe` (Electron) a ser gerado.
