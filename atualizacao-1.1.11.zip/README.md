# LoPDV — gestão para bar e restaurante

Sistema desktop + rede para bar/restaurante: vendas por comanda com impressão para **cozinha** e **bar**, controle do que
já foi retirado, estoque (insumos em KG, entrada por XML ou manual, **sem estoque negativo**), financeiro, equipe com
permissões por tela/função e relatórios. Banco **PostgreSQL** (gratuito).

## Como funciona
- **Computador servidor** (o do caixa/escritório): instala o `.exe`. Ele roda o sistema e o banco.
- **Terminais** (garçom, cozinha, bar, outros PCs/tablets): só abrem um atalho para `http://IP-DO-SERVIDOR:3737`. Nada para instalar.
- O servidor precisa estar ligado e com o programa aberto (menu *Sistema → Iniciar com o Windows* ajuda).

## Instalação (passo a passo)
O instalador **já traz tudo**: o sistema, o banco PostgreSQL e o Microsoft Visual C++ Runtime. Não precisa instalar mais nada.
1. **Gerar o instalador** (uma vez, em um Windows com internet e Node.js LTS): execute `build-windows.bat`.
   Ele baixa o PostgreSQL portátil e o runtime do Visual C++ e monta `dist\LoPDV Setup.exe`.
   Alternativa: suba a pasta no GitHub e rode o workflow *Gerar instalador Windows* (Actions) → baixe o `.exe` em *Artifacts*.
   Se algum link de download mudar, ajuste `PG_ZIP_URL` / `VC_REDIST_URL` ou coloque os arquivos manualmente em `vendor/` (`vendor/pgsql/bin/postgres.exe` e `vendor/vc_redist.x64.exe`).
2. Execute o `.exe` no computador servidor. Ele instala o sistema, o Visual C++ e libera a porta **3737** no firewall.
3. Abra o programa. Na primeira vez ele cria o banco sozinho (até 1 minuto). Banco: usuário **postgres**, senha **postgres123**, só acessível no próprio servidor (127.0.0.1, porta 54329).
4. Entre com **admin / admin123** e troque a senha (botão *Minha senha*).
5. **Terminais:** em cada computador, abra o navegador em `http://IP-DO-SERVIDOR:3737/instalar`, baixe e execute o instalador do atalho. Ele cria o ícone **LoPDV** na área de trabalho (abre como programa, sem barra do navegador, no Edge). Também dá para salvar esse instalador em *Sistema → Salvar instalador de atalho para terminais* e levar em pen drive. Dica: fixe o IP do servidor no roteador.
6. Cadastre as impressoras (cozinha/bar/caixa) em *Impressoras e configurações* — térmicas 80 mm ESC/POS em rede, porta 9100.

Dados e **backups automáticos diários** (últimos 14) ficam em *Sistema → Abrir pasta de dados e backups*.
Desinstalar o programa não apaga os dados. Os dados pertencem ao usuário do Windows que abriu o sistema: use sempre o mesmo usuário no servidor.

## Módulos
| Módulo | O que faz |
|---|---|
| Vendas / Comandas | Abre comandas (mesa/balcão/delivery), lança itens, envia p/ cozinha/bar (imprime), recebe com várias formas de pagamento, desconto, fiado |
| Cozinha / Bar | Painel em tempo real: o que está **aguardando** e o que **já foi retirado** (hora e quem retirou) |
| Caixa | Abertura, sangria/suprimento, fechamento com conferência (esperado × contado) |
| Cadastros | Produtos/insumos (com **ficha técnica**), clientes, **fornecedores**, categorias |
| Estoque | Posição, entrada **manual** ou por **XML de NF-e**, ajuste/inventário, movimentação |
| Financeiro | Contas a pagar (geradas pela entrada de nota) e a receber (fiado) |
| Relatórios | Fechamento de caixa, ticket médio, lucratividade, mais vendidos, movimentação de estoque (CSV/impressão) |
| Equipe | Usuários e **perfis**: quais telas e quais funções cada um acessa |

## Estoque
- Tipos: **revenda** (cerveja), **insumo** (carne em KG, óleo em L) e **preparado** (prato com ficha técnica: ao vender 1 hambúrguer baixa 0,2 kg de carne e 1 pão).
- A baixa ocorre ao **lançar o item** na comanda; cancelar o item devolve o estoque.
- **Estoque negativo é bloqueado.** Se a venda deixaria negativo, a tela pede **usuário e senha** de quem tem a permissão
  `Autorizar venda com estoque negativo` (ex.: Ana). A autorização fica gravada na auditoria e no item.
- XML: o sistema lê itens, custos, fornecedor e duplicatas; vincula produtos por código do fornecedor/EAN (e **lembra o vínculo**),
  aceita *fator* (1 caixa com 12 → fator 12), cadastra produtos novos e gera as contas a pagar. Não importa a mesma nota duas vezes.
- Custo médio ponderado atualizado a cada entrada (base da lucratividade).

## Permissões
Cada perfil marca o que pode: acessar cada tela e funções como dar desconto, cancelar item enviado, reimprimir, autorizar estoque
negativo, sangria, fechar caixa, ajustar estoque, ver financeiro... Perfis iniciais: Administrador, Gerente, Caixa, Garçom, Cozinha/Bar, Estoquista.

## Backup
O sistema grava um backup por dia (pasta `backups`). Copie essa pasta periodicamente para um pen drive ou nuvem.

## Desenvolvimento
`npm install` → `npm start` (abre em http://localhost:3737) → `node test/smoke.js` (teste da API contra um banco de teste).
Variáveis opcionais: `DATABASE_HOST/PORT/USER/PASSWORD/NAME`, `GESTAO_PORT`, `GESTAO_DATA_DIR`.

## Limites desta versão
- **Não emite NFC-e/NF-e** (só importa XML de compra). Os recibos/contas impressos são de conferência, sem valor fiscal.
- Impressão apenas ESC/POS por rede (IP). Se a impressora falhar, o item continua visível no painel Cozinha/Bar e pode ser reimpresso.
- Entradas lançadas não têm "estorno" pela tela (use ajuste de estoque com motivo).


## Gerar o instalador sem instalar nada (recomendado)
Use o GitHub Actions: envie esta pasta para um repositório no GitHub, abra **Actions → Gerar instalador Windows (.exe) → Run workflow**
e baixe o `.exe` pronto em *Artifacts*. Não precisa de Node.js nem de nada no seu computador.

Alternativa local: dê dois cliques em `build-windows.bat` — ele instala o Node.js sozinho (via winget ou download oficial) e gera o `.exe` em `dist`.

O `.exe` gerado já instala tudo no computador final: o sistema, o PostgreSQL embutido, o runtime do Visual C++, a regra de firewall e o atalho.

## Regras do instalador (.exe)
- Instala o LoPDV com o **PostgreSQL embutido** (porta 54329, usuário `postgres`, senha `postgres123`) e o **runtime do Visual C++**.
- O Node.js já vem dentro do programa (Electron), então **não é preciso instalar o Node.js** no computador do servidor.
- Se o computador **já tiver PostgreSQL instalado** (instalação oficial ou serviço do Windows), o instalador **para** e avisa, sem instalar nada.
- O instalador deixa escolher a pasta/disco de instalação. Se o LoPDV já estiver instalado (em qualquer disco), ele pergunta: **Reparar** (reinstala os arquivos mantendo os dados), **Desinstalar** ou **Sair**. Desinstalar não apaga o banco de dados nem os backups.

## Formas de pagamento e TEF por pastas
Menu **Cadastros → Formas de pagamento** (permissão "Gerenciar formas de pagamento e integração TEF"). Abas: Geral, Financeiro (parcelas, taxa, prazo) e Configurações TEF (pastas de envio, retorno, status, temporário e executável, com botão **Procurar…**, **Preencher padrão** e **Testar pastas**).
- A cobrança no cartão é feita **antes** de fechar a comanda; se o fechamento falhar, a transação é desfeita (NCN). Após gravar a venda, é enviada a confirmação (CNF) e o comprovante é impresso no caixa.
- As pastas são lidas pelo **servidor**. TEF em outro computador: compartilhe a pasta e use o caminho de rede (`\\CAIXA01\TEF_DIAL\REQ`).
- O layout de arquivos (`IntPos.001` / `.sts`, padrão SITEF / TEF_DIAL) segue o padrão mais comum de troca de arquivos; **valide com o manual e o suporte do seu provedor de TEF** antes de usar em produção. Cancelamento/estorno de venda já paga no TEF ainda não está implementado.

## Caixa, fiado e conferência
- **Vendas:** ao entrar, o sistema exige caixa aberto do usuário. Se houver, mostra o caixa e pergunta se quer usá-lo; se não houver, bloqueia a tela (e o servidor também recusa criar comanda/lançar item sem caixa).
- **Receber fiado:** botão na tela de Vendas e menu próprio. Sem caixa aberto, avisa que é necessário abrir. Na baixa escolhe-se o caixa e a forma de pagamento (nunca Fiado); aceita pagamento parcial e cartão via TEF. A baixa de fiado não é mais permitida pelo Financeiro.
- **Fechamento:** o operador informa o total de cada forma de pagamento usada. Se houver diferença entre o calculado e o informado, o sistema avisa e oferece **Reconferir** ou **Fechar com divergência** (exige motivo). O comprovante mostra calculado − informado = diferença por forma e no total.
- **Conferência de caixas** (permissão `caixa.conferir`): lista caixas abertos e fechados, com **Movimentações** (filtro por forma de pagamento), **Comprovante** (reimpressão), **Reabrir** (`caixa.reabrir`) e **Alterar forma de pagamento** (`caixa.alterar_forma`). Reabrir e alterar pedem usuário e senha de quem tem a permissão, exigem motivo e ficam na auditoria. Vendas em fiado e pagamentos via TEF não podem ser alterados, e não se pode alterar para Fiado.
- Perfis já existentes precisam receber as novas permissões em *Administração → Perfis*.

## Instalador do atalho para terminais (sem instalar nada)
`terminais/Instalar-Atalho-LoPDV.bat` é um arquivo único, com o ícone embutido. Copie para o computador do terminal (pen drive ou rede), dê dois cliques e informe o IP do servidor (ex.: `192.168.0.10:3737`). Ele testa a conexão e cria o atalho **LoPDV** na área de trabalho (abre como programa no Edge ou Chrome). Rodando de novo, permite atualizar ou remover o atalho. Para regenerar: `python3 scripts/gerar-instalador-atalho.py`.

## Instalador sem .exe (para instalar e testar no Windows)
`Instalar-LoPDV-<versão>.bat` (ex.: `Instalar-LoPDV-1.0.0.bat`) é um arquivo único com o sistema dentro. Dois cliques (aceite o pedido de administrador):
instala o Node.js e o PostgreSQL (usuário `postgres`, senha `postgres123`) se faltarem, deixa escolher a pasta, cria o banco `gestao`, instala as dependências, abre a porta 3737 no firewall, cria o atalho **LoPDV** (o sistema **não** inicia junto com o Windows: o atalho liga o servidor se estiver desligado e abre a tela; `Parar-LoPDV.bat` desliga). Se já houver PostgreSQL no computador, a instalação é bloqueada. Rodando de novo com o sistema instalado, oferece **Reparar** ou **Desinstalar** (a desinstalação também aparece em Configurações > Aplicativos). Rodando uma versão mais nova sobre uma instalada, oferece **Atualizar** (faz um backup antes e mantém o banco). Regenerar: `python3 scripts/gerar-instalador-teste.py`.

## Backup automático
O sistema faz o backup do banco (`pg_dump`) **ao abrir** e **ao fechar**, e guarda apenas os últimos **3 dias** (hoje e os 2 anteriores; nunca apaga se restarem menos de 2 arquivos), em `data\backups`. Em *Sistema → Impressoras e configurações* há **Fazer backup agora**, o botão **Encerrar o sistema** (faz o backup de fechamento e desliga o servidor) e uma **pasta extra** para cópia (pen drive, outro disco, OneDrive; a mesma regra dos 3 dias vale ali). O `Parar-LoPDV.bat` também encerra com backup. Restaurar: com o sistema parado, arraste o arquivo `.dump` sobre `Restaurar-Backup.bat`. Observação: se o computador for desligado à força, o backup de fechamento não acontece (o de abertura do dia seguinte continua valendo).

## Versões
A versão fica em `package.json` (hoje **1.0.0**) e aparece na tela de login, no rodapé do menu, em *Sistema → configurações* (com o histórico de versões que já rodaram naquele banco) e no instalador (`Instalar-LoPDV-1.0.0.bat`; Aplicativos do Windows mostra a versão instalada). Histórico de mudanças em `CHANGELOG.md`.
Nova versão: `python3 scripts/nova-versao.py 1.0.1 "o que mudou"` — atualiza o `package.json`, o `CHANGELOG.md` e gera o novo instalador.
