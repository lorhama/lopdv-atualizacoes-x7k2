@echo off
setlocal
chcp 65001 >nul
set "ORIGEM=%~dp0"
set "TRAB=%SystemDrive%\LoPDV-build"
echo ==============================================
echo   LoPDV - gerando o instalador (.exe)
echo   Tudo que for necessario sera instalado sozinho.
echo ==============================================

REM 1) Node.js: instala automaticamente se nao existir
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo [1/3] Instalando o Node.js automaticamente... aguarde.
  where winget >nul 2>nul
  if not errorlevel 1 (
    winget install -e --id OpenJS.NodeJS.LTS --silent --accept-package-agreements --accept-source-agreements
  )
  where node >nul 2>nul
  if errorlevel 1 if not exist "%ProgramFiles%\nodejs\node.exe" (
    echo Baixando o Node.js direto do site oficial...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; $i=Invoke-RestMethod 'https://nodejs.org/dist/index.json' | Where-Object { $_.lts } | Select-Object -First 1; $v=$i.version; Invoke-WebRequest ('https://nodejs.org/dist/'+$v+'/node-'+$v+'-x64.msi') -OutFile \"$env:TEMP\node-lts.msi\""
    if exist "%TEMP%\node-lts.msi" msiexec /i "%TEMP%\node-lts.msi" /qb /norestart
  )
  set "PATH=%PATH%;%ProgramFiles%\nodejs;%APPDATA%\npm"
)
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo Nao foi possivel instalar o Node.js automaticamente.
  echo Verifique a conexao com a internet e execute este arquivo novamente.
  pause & exit /b 1
)
echo Node.js OK:
node -v

echo.
echo Copiando o projeto para %TRAB% (pasta curta, fora do OneDrive)...
robocopy "%ORIGEM%." "%TRAB%" /E /XD node_modules dist data .git /NFL /NDL /NJH /NJS /NP >nul
cd /d "%TRAB%"

echo.
echo [2/3] Instalando dependencias do sistema...
call npm install || (echo Falha no npm install & pause & exit /b 1)

echo.
echo [3/3] Gerando o instalador (baixa PostgreSQL e VC++ e monta o .exe; pode levar varios minutos)...
call npm run dist || (echo Falha ao gerar o instalador & pause & exit /b 1)

echo.
robocopy "%TRAB%\dist" "%ORIGEM%dist" *.exe /NFL /NDL /NJH /NJS /NP >nul
echo Pronto! O instalador esta na pasta "dist" (ao lado deste arquivo).
explorer "%ORIGEM%dist"
pause
