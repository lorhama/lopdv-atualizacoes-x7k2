
// Lançamento da despesa ao finalizar a entrada: parcelas, vencimento e forma de pagamento de cada uma
async function lancarDespesa({ total, fornecedor, duplicatas, descricao }) {
  const FP = await api('/formas-pagamento?uso=pagar');
  const base = (duplicatas && duplicatas.length ? duplicatas : [{ valor: total, vencimento: new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10) }])
    .map(d => ({ vencimento: String(d.vencimento || '').slice(0, 10), valor: Number(d.valor) || 0, forma: (FP.find(f => f.tipo === 'pix') || FP[0] || {}).codigo, pago: false }));
  return new Promise(res => {
    const corpo = document.createElement('div'); let fin = false;
    const linhas = base.slice();
    const opt = l => FP.map(f => `<option value="${esc(f.codigo)}" ${f.codigo === l.forma ? 'selected' : ''}>${esc(f.descricao)}</option>`).join('');
    const calc = () => { const s = Math.round(linhas.reduce((a, l) => a + (Number(l.valor) || 0), 0) * 100) / 100, dif = Math.round((total - s) * 100) / 100;
      $('#dsp-s', corpo).innerHTML = `Soma das parcelas: <b>${R(s)}</b> · Total da compra: <b>${R(total)}</b> ` + (Math.abs(dif) < 0.011 ? chip('confere', 'ok') : `<span class="erro">diferença de ${R(dif)}</span>`); return Math.abs(dif) < 0.011; };
    const desenhar = () => { $('#dsp-l', corpo).innerHTML = linhas.map((l, i) => `<div class="row tt"><label>Vencimento<input type="date" data-vc value="${esc(l.vencimento)}"></label><label>Valor (R$)<input data-vl value="${esc(String(l.valor).replace('.', ','))}" inputmode="decimal"></label>
      <label>Forma de pagamento<select data-fp>${opt(l)}</select></label><label class="chk" style="align-self:end"><input type="checkbox" data-pg ${l.pago ? 'checked' : ''}> Já pago</label>${linhas.length > 1 ? `<button class="btn sm danger auto" data-x="${i}" type="button">✕</button>` : ''}</div>`).join(''); calc(); };
    corpo.innerHTML = `<p>Despesa da compra${fornecedor ? ' de <b>' + esc(fornecedor) + '</b>' : ''}: <b>${R(total)}</b></p>
      <label>Categoria da despesa<input id="dsp-cat" value="Compra de mercadoria"></label><div id="dsp-l"></div><button class="btn sm" id="dsp-add" type="button">+ parcela</button><p id="dsp-s" style="margin-top:8px"></p>
      <p class="muted">Cada parcela vira uma conta a pagar com a forma escolhida. Marque "Já pago" para o que foi pago na hora. Consignado: a conta fica em aberto até o acerto com o fornecedor.</p>`;
    corpo.addEventListener('input', e => { const r = e.target.closest('.tt'); if (!r) return; const i = $$('.tt', corpo).indexOf(r), l = linhas[i];
      if (e.target.matches('[data-vc]')) l.vencimento = e.target.value; if (e.target.matches('[data-vl]')) l.valor = numIn(e.target.value); calc(); });
    corpo.addEventListener('change', e => { const r = e.target.closest('.tt'); if (!r) return; const l = linhas[$$('.tt', corpo).indexOf(r)];
      if (e.target.matches('[data-fp]')) l.forma = e.target.value; if (e.target.matches('[data-pg]')) l.pago = e.target.checked; });
    corpo.addEventListener('click', e => { if (e.target.id === 'dsp-add') { const falta = Math.max(0, Math.round((total - linhas.reduce((a, l) => a + (Number(l.valor) || 0), 0)) * 100) / 100);
        linhas.push({ vencimento: new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10), valor: falta, forma: linhas[linhas.length - 1].forma, pago: false }); desenhar(); }
      if (e.target.dataset.x !== undefined) { linhas.splice(+e.target.dataset.x, 1); desenhar(); } });
    desenhar();
    modal({ titulo: 'Lançamento da despesa', tam: 'md', corpo, botoes: [{ txt: 'Voltar', fn: () => { if (!fin) { fin = true; res(null); } } },
      { txt: 'Confirmar entrada e despesa', cls: 'primary', fn: () => {
        if (!calc()) throw new Error('A soma das parcelas precisa ser igual ao total da compra.');
        if (linhas.some(l => !l.vencimento || !(l.valor > 0) || !l.forma)) throw new Error('Informe vencimento, valor e forma de pagamento em todas as parcelas.');
        fin = true; res({ titulos: linhas.map(l => ({ vencimento: l.vencimento, valor: l.valor, forma: l.forma, pago: l.pago })), categoria: $('#dsp-cat', corpo).value.trim() }); } }] });
  });
}
// Estoque: posição, entrada de mercadoria (manual e XML de NF-e) e movimentação.
registrar({ id: 'posicao', titulo: 'Posição de estoque', grupo: 'Relatórios', perm: 'estoque.ver', render: async el => {
  let d = [];
  const desenhar = () => {
    const q = $('#bq', el).value.toLowerCase(), so = $('#baixo', el).checked;
    const l = d.filter(p => (!so || p.abaixo_minimo) && (!q || (p.nome + (p.codigo || '')).toLowerCase().includes(q)));
    const tot = l.reduce((s, p) => s + p.valor_estoque, 0);
    $('#lista', el).innerHTML = `<div class="cards"><div class="stat">Itens listados<b>${l.length}</b></div><div class="stat ${d.filter(p => p.abaixo_minimo).length ? 'warn' : ''}">Abaixo do mínimo<b>${d.filter(p => p.abaixo_minimo).length}</b></div><div class="stat">Valor em estoque (custo)<b>${R(tot)}</b></div></div>` +
      tabela([{ l: 'Produto', k: 'nome' }, { l: 'Categoria', k: 'categoria' }, { l: 'Tipo', k: 'tipo' }, { l: 'Estoque', n: 1, f: p => `<b class="${p.estoque_atual < 0 ? 'erro' : ''}">${N(p.estoque_atual)} ${p.unidade}</b>` }, { l: 'Mínimo', n: 1, f: p => N(p.estoque_minimo) }, { l: 'Custo médio', n: 1, f: p => R(p.custo_medio) }, { l: 'Valor', n: 1, f: p => R(p.valor_estoque) }], l,
        { rowCls: p => (p.abaixo_minimo ? 'low' : ''), });
  };
  const carregar = seguro(async () => { d = await api('/estoque/posicao'); desenhar(); });
  el.innerHTML = `<div class="bar"><input id="bq" placeholder="Buscar..."><label class="chk" style="margin:0"><input type="checkbox" id="baixo"> só abaixo do mínimo</label><div class="grow"></div><button class="btn" id="csv">Exportar CSV</button></div><div id="lista"></div>`;
  $('#bq', el).oninput = desenhar; $('#baixo', el).onchange = desenhar;
  $('#csv', el).onclick = () => csv('posicao-estoque', [{ l: 'Produto', k: 'nome' }, { l: 'Unidade', k: 'unidade' }, { l: 'Estoque', k: 'estoque_atual' }, { l: 'Mínimo', k: 'estoque_minimo' }, { l: 'Custo médio', k: 'custo_medio' }, { l: 'Valor', k: 'valor_estoque' }], d);
  el.onclick = seguro(async e => {
    const id = e.target.dataset.aj; if (!id) return; const p = d.find(x => x.id == id);
    const mot = await api('/estoque/motivos');
    if (!mot.length) return toast('Cadastre ao menos um motivo de ajuste (menu Estoque > Ajuste de estoque).', 'aviso');
    const m = formModal({ titulo: 'Ajuste de estoque: ' + p.nome, campos: [{ k: 'nova_qtd', l: `Quantidade contada (${p.unidade})`, t: 'number', step: '0.001', req: true, full: true }, { k: 'motivo', l: 'Motivo', t: 'select', op: mot.map(x => [x.descricao, x.descricao]), req: true, full: true }, { k: 'obs', l: 'Observação (opcional)', full: true }],
      extra: `<p class="muted">Saldo atual no sistema: <b>${N(p.estoque_atual)} ${p.unidade}</b></p><p><button type="button" class="btn sm" id="gmot">Cadastrar / editar motivos</button></p>`,
      onSave: async o => { const r = await api('/estoque/ajuste', { method: 'POST', body: { produto_id: p.id, nova_qtd: o.nova_qtd, motivo: o.motivo + (o.obs ? ' — ' + o.obs : '') } }); toast(r.delta ? `Ajustado em ${N(r.delta)} ${p.unidade}.` : 'Sem diferença.'); carregar(); } });
    $('#gmot', m.body).onclick = () => gerenciarMotivos(async () => { const n = await api('/estoque/motivos'); const sel = $('[data-k=motivo]', m.body); if (sel) { const v = sel.value; sel.innerHTML = n.map(x => `<option value="${esc(x.descricao)}" ${x.descricao === v ? 'selected' : ''}>${esc(x.descricao)}</option>`).join(''); } });
  });
  await carregar();
} });

registrar({ id: 'entrada', titulo: 'Entrada de mercadoria (Manual)', grupo: 'Estoque', perm: 'estoque.entrada', render: async el => {
  if (await semEmpresa(el, 'dar entrada de mercadoria')) return;
  const [prods, forn] = await Promise.all([api('/produtos?ativos=1'), api('/fornecedores?ativos=1')]);
  const estocaveis = prods.filter(p => p.tipo !== 'preparado');
  const dl = `<datalist id="dl-prod">${estocaveis.filter(p => !p.suspenso).map(p => `<option value="${esc(rotuloProd(p))}">`).join('')}</datalist>`;
  const optForn = '<option value="">— sem fornecedor —</option>' + forn.map(f => `<option value="${f.id}">${esc(f.nome)}</option>`).join('');
  let aba = sessionStorage.getItem('xmlChave') || sessionStorage.getItem('xmlTexto') ? 'xml' : (sessionStorage.getItem('entradaAba') === 'pend' ? 'pend' : 'manual'); try { sessionStorage.removeItem('entradaAba'); } catch { /* */ }
  const abas = () => `<div class="tabs"><button data-ab="manual" class="${aba === 'manual' ? 'on' : ''}">Entrada manual</button><button data-ab="xml" class="${aba === 'xml' ? 'on' : ''}">Importar XML (NF-e / cupom)</button><button data-ab="foto" title="Lê a nota por foto ou PDF, sem internet">📷 Foto / PDF da nota</button><button data-ab="pend" class="${aba === 'pend' ? 'on' : ''}" title="Cadastros automáticos vindos das entradas: confirme ou amarre a um produto existente">⚠ Cadastros pendentes</button><button data-ab="hist" class="${aba === 'hist' ? 'on' : ''}">Histórico</button></div>`;

  // bloco de contas a pagar reutilizado nas duas entradas
  const blocoTitulos = (total, dups) => `<div class="card"><label class="chk"><input type="checkbox" id="gt" ${dups?.length ? 'checked' : ''}> Gerar contas a pagar</label><div id="tit">${dups?.length ? '' : ''}</div></div>`;
  const desenharTitulos = (box, total, dups) => {
    const linhas = dups?.length ? dups : [{ valor: total, vencimento: new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10) }];
    box.innerHTML = linhas.map(t => `<div class="row tt"><label>Vencimento<input type="date" data-vc value="${esc(t.vencimento || '')}"></label><label>Valor<input data-vl value="${t.valor || ''}" inputmode="decimal"></label><button class="btn sm danger auto" data-x type="button">✕</button></div>`).join('') + '<button class="btn sm" type="button" data-addt>+ parcela</button>';
  };
  const lerTitulos = root => ($('#gt', root).checked ? $$('.tt', root).map(r => ({ vencimento: $('[data-vc]', r).value, valor: numIn($('[data-vl]', r).value) })).filter(t => t.vencimento && t.valor > 0) : []);

  // alterar o nome de um produto já cadastrado, direto da entrada (vale para o cadastro todo)
  const renomearProd = campo => {
    const id = idDoRotulo(campo.value), p = id && estocaveis.find(x => x.id === id);
    if (!p) throw new Error('Escolha primeiro o produto na lista; depois altere o nome.');
    const corpo = document.createElement('div');
    corpo.innerHTML = `<p class="muted">Isso muda o nome no <b>cadastro do produto</b> (vale para vendas, estoque e relatórios).</p><label>Nome do produto<input id="rn" value="${esc(p.nome)}" maxlength="120"></label>`;
    modal({ titulo: 'Alterar nome do produto', corpo, botoes: [{ txt: 'Cancelar' }, { txt: 'Salvar nome', cls: 'primary', fn: async () => {
      const nome = $('#rn', corpo).value.trim(); if (nome.length < 2) throw new Error('Informe o nome.');
      if (nome === p.nome) return;
      const antigo = rotuloProd(p), r = await api('/estoque/produto-renomear', { method: 'POST', body: { produto_id: p.id, nome } });
      p.nome = r.nome; const novo = rotuloProd(p);
      $$('#dl-prod option', el).forEach(o => { if (o.value === antigo) o.value = novo; });
      $$('[data-p],[data-pp]', el).forEach(i => { if (idDoRotulo(i.value) === p.id) i.value = novo; });
      document.querySelectorAll('.modal-bg [data-pp]').forEach(i => { if (idDoRotulo(i.value) === p.id) i.value = novo; });
      toast('Nome do produto alterado.');
    } }] });
  };
  let abrirFotoFn = null;
  const manual = () => {
    el.innerHTML = abas() + dl + `<div class="card"><div class="row"><label>Fornecedor<select id="fo">${optForn}</select></label><label style="max-width:110px">Série<input id="ns" maxlength="10" placeholder="ex.: 1"></label><label>Nº da nota / documento<input id="nf"></label></div>
      <label class="chk" title="Mercadoria deixada pelo fornecedor para acerto no fim do evento: entra no estoque, mas não gera conta a pagar. O pagamento é feito no Acerto, depois das devoluções."><input type="checkbox" id="cs"> <b>Nota consignada</b> <span class="muted">(entra no estoque, só será paga no acerto após as devoluções — veja em Estoque ▸ Consignações)</span></label>
      <label class="chk" title="Marca todos os itens como doação. Depois você pode desmarcar os que foram comprados."><input type="checkbox" id="dn"> <b>Esta nota é de doação</b> <span class="muted">(marca todos os itens; desmarque os que foram comprados)</span></label>
      <h4>Itens</h4><div id="its"></div><button class="btn sm" id="addit" type="button">+ item</button> <button class="btn sm" id="foto" type="button" title="Tira uma foto da nota e lê os itens aqui no computador, sem internet">📷 Entrada por foto / PDF da nota</button> <button class="btn sm" id="novoprod" type="button" title="Produto que ainda não está no cadastro">+ Cadastrar produto novo</button>
      <div class="totais" style="margin-top:10px"><span id="lbltt">Total a pagar</span>: <b id="tt">${R(0)}</b> <span class="muted" id="ttd"></span></div></div><button class="btn primary big" id="salvar">Finalizar entrada (lançar despesa)</button>`;
    const item = () => `<div class="row it2"><label title="Estoque: revenda/insumo. Patrimônio: bem durável (mesa, geladeira, som...), recebe nº de patrimônio e não entra no estoque.">Destino<select data-d><option value="e">Estoque</option><option value="p">Patrimônio</option></select></label><label style="flex:3" data-lp>Produto / insumo<input data-p list="dl-prod" placeholder="digite para buscar" autocomplete="off"><a href="#" data-ren style="font-size:12px" title="Alterar o nome deste produto no cadastro">✏ alterar nome</a></label><label style="flex:3;display:none" data-ld>Descrição do bem<input data-ds placeholder="ex.: Geladeira vertical 2 portas"></label><label class="chk" style="margin:0 6px;align-self:flex-end" title="Item recebido de doação: entra sem custo e não gera conta a pagar"><input type="checkbox" data-dc> Doação</label><label>Qtd. comprada<input data-q inputmode="decimal"></label><label>Custo da embalagem (R$)<input data-c inputmode="decimal"></label><label data-lf title="Quantas unidades vêm em cada embalagem. Fardo com 12 un → 12. Se já compra unitário, 1.">Fator (un. por embalagem)<input data-f value="1" inputmode="decimal"></label><button class="btn sm danger auto" data-x type="button">✕</button><div class="muted" data-pv style="flex-basis:100%"></div></div>`;
    $('#its', el).innerHTML = item();
    const vlr = r => numIn($('[data-q]', r).value) * numIn($('[data-c]', r).value);
    const total = () => $$('.it2', el).filter(r => !$('[data-dc]', r).checked).reduce((s, r) => s + vlr(r), 0);
    const totalDoado = () => $$('.it2', el).filter(r => $('[data-dc]', r).checked).reduce((s, r) => s + vlr(r), 0);
    const atualizaTotal = () => { $('#tt', el).textContent = R(total()); const d = totalDoado(); $('#ttd', el).textContent = d > 0 ? `· doado (sem pagamento): ${R(d)}` : ''; };
    const destino = r => { const pat = $('[data-d]', r).value === 'p'; $('[data-lp]', r).style.display = pat ? 'none' : ''; $('[data-lf]', r).style.display = pat ? 'none' : ''; $('[data-ld]', r).style.display = pat ? '' : 'none'; prev(r); };
    // acha o produto pelo rótulo da lista, código interno ou código de barras (inclusive lido pelo leitor)
    const acharProd = txt => { const id = idDoRotulo(txt); if (id) return { p: estocaveis.find(x => x.id === id), barras: '' };
      const s = String(txt || '').trim(); if (!s) return {};
      const p = estocaveis.find(x => (x.codigos_barras || []).includes(s)); if (p) return { p, barras: s };
      const q = estocaveis.find(x => String(x.codigo || '').toLowerCase() === s.toLowerCase()); return q ? { p: q, barras: '' } : {}; };
    const fatorDe = async r => { const { p, barras } = acharProd($('[data-p]', r).value); if (!p) return;
      const x = await api(`/estoque/fator?produto_id=${p.id}&fornecedor_id=${$('#fo', el).value || ''}&barras=${encodeURIComponent(barras)}`); $('[data-f]', r).value = x.fator; prev(r); };
    const prev = r => { const q = numIn($('[data-q]', r).value), c = numIn($('[data-c]', r).value), f = numIn($('[data-f]', r).value), pv = $('[data-pv]', r);
      const dc = $('[data-dc]', r).checked;
      if ($('[data-d]', r).value === 'p') { pv.innerHTML = q > 0 ? `Vai para o <b>Patrimônio</b>: ${q} bem(ns) com número próprio${dc ? ' · <b>doação</b>' : ` · ${R(c)} cada`}` : ''; return; }
      const pr = acharProd($('[data-p]', r).value).p, un = pr ? pr.unidade : 'un';
      pv.innerHTML = f > 0 && q > 0 ? `Entra no estoque: <b>${N(q * f)} ${esc(un)}</b> · ${dc ? '<b>doação</b> (custo zero, sem conta a pagar)' : `custo unitário: <b>${R(c / f)}</b>`}` : (f > 0 ? '' : '<span class="erro">Informe o fator (use 1 se já é unitário).</span>'); };
    // ---- Entrada por foto da nota: OCR offline no servidor; o operador confere e os itens vão para a grade
    const prepararFoto = file => new Promise((ok, err) => {
      const url = URL.createObjectURL(file), im = new Image();
      im.onload = () => {
        const max = 2400, k = Math.min(2, max / Math.max(im.width, im.height)), c = document.createElement('canvas'); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
        const g = c.getContext('2d'); g.drawImage(im, 0, 0, c.width, c.height);
        const d = g.getImageData(0, 0, c.width, c.height), px = d.data; // tons de cinza + contraste para ajudar a leitura
        for (let i = 0; i < px.length; i += 4) { let v = Math.max(px[i], px[i + 1], px[i + 2]); /* canal mais claro: some a caneta azul por cima da impressão */ v = Math.max(0, Math.min(255, (v - 128) * 1.35 + 128 + 10)); px[i] = px[i + 1] = px[i + 2] = v; }
        g.putImageData(d, 0, 0); URL.revokeObjectURL(url); c.toBlob(b => (b ? ok(b) : err(new Error('Não foi possível preparar a imagem.'))), 'image/jpeg', 0.88);
      };
      im.onerror = () => err(new Error('Não foi possível abrir essa imagem. Use JPG ou PNG.')); im.src = url;
    });
    const entradaPorFoto = abrirFotoFn = () => {
      const corpo = document.createElement('div'); let linhas = [];
      corpo.innerHTML = `<p class="muted">Tire uma foto da nota, escolha a imagem ou o <b>PDF</b> da nota (DANFE). A leitura é feita <b>neste computador, sem internet</b>. PDF com texto (o que vem por e-mail) é lido com mais precisão que foto. Depois você confere cada item antes de passar para a entrada. Dicas: boa luz, nota reta, sem sombra, letras nítidas.</p>
        <div class="row" style="align-items:flex-end"><label style="flex:3">Foto, imagem ou PDF da nota<input type="file" id="fn" accept="image/*,application/pdf,.pdf"></label><button class="btn primary auto" id="flr" type="button">Ler a nota</button></div><div id="fres" style="margin-top:10px"></div>`;
      const limparNome = d => String(d || '').replace(/^[A-ZÀ-Ú]{1,3}\s+(?=\d)/, '').replace(/^(?:\d+[.,]?\d*\s+)+/, '').replace(/\s+\d+([.,]\d+)?\s*(UN|UND|KG|G|L|ML|CX|PCT)\b.*$/i, '').replace(/\s+/g, ' ').trim();
      let ultimaLeitura = {};
      const desenha = r => {
        linhas = r.itens; ultimaLeitura = r;
        if (!r.itens.length) { $('#fres', corpo).innerHTML = `<p class="erro">Não consegui identificar itens nessa nota. Se for foto, tente de novo com mais luz/nitidez; se puder, use o PDF ou o XML. Ou digite os itens manualmente.</p><details><summary>Ver texto lido</summary><pre style="white-space:pre-wrap;font-size:12px">${esc(r.texto || '')}</pre></details>`; return; }
        $('#fres', corpo).innerHTML = (r.xml_disponivel ? `<p class="card" style="border-left:4px solid var(--ok)">✅ O XML completo desta nota já está no sistema (Notas da SEFAZ). Use <b>Importar XML</b>: é exato, sem risco de erro de leitura. <button class="btn sm primary" type="button" data-xmlchave="${esc(r.chave)}">Importar pelo XML</button></p>` : '') + `<p>${r.itens.length} item(ns) encontrado(s) <span class="muted">(leitor: ${esc(r.motor)})</span>. <b>Confira</b> produto, quantidade e valor: a leitura de foto pode errar. Item sem cadastro vira <b>cadastro automático pendente</b> (confirme depois em Produtos) ou use <b>🔗 Amarrar ao cadastro</b> se o produto já existe. Desmarque o que não for item.</p>
          <div class="row" style="align-items:flex-end;margin:6px 0"><label style="max-width:260px">Nº da nota / documento <small class="muted">(lido da nota; pode corrigir)</small><input data-nn value="${esc(r.numero_nota || '')}" placeholder="não consegui ler: digite"></label><label style="max-width:110px">Série<input data-ns value="${esc(r.serie_nota || '')}" maxlength="10" placeholder="ex.: 1"></label></div>
          ${(() => { const cj = r.cnpj_emitente || '', fmt = c => c.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5'), sel = r.fornecedor_id ? String(r.fornecedor_id) : (cj ? 'novo' : '');
            return `<div class="card" style="margin:6px 0;border-left:4px solid ${sel ? 'var(--ok)' : 'var(--erro,#c0392b)'}"><div class="row" style="align-items:flex-end"><label style="flex:2">Fornecedor desta nota ${sel ? '' : '<b class="erro">(obrigatório: a nota não traz o CNPJ do fornecedor, escolha um cadastrado)</b>'}<select data-forn><option value="">— selecione o fornecedor —</option>${cj && !r.fornecedor_id ? `<option value="novo" ${sel === 'novo' ? 'selected' : ''}>➕ Cadastrar novo (CNPJ ${esc(fmt(cj))})</option>` : ''}${$$('#fo option', el).filter(o => o.value).map(o => `<option value="${o.value}" ${sel === o.value ? 'selected' : ''}>${esc(o.textContent)}</option>`).join('')}</select></label>
              <label data-fnovo style="flex:2" class="${sel === 'novo' ? '' : 'hidden'}">Nome do fornecedor novo <small class="muted">(será cadastrado ao passar os itens)</small><input data-fnome value="${esc(r.fornecedor_nome_sugerido || '')}" placeholder="razão social / nome do fornecedor"></label></div>
              ${r.fornecedor_id ? `<small class="muted">Reconhecido pelo CNPJ ${esc(fmt(cj))}: <b>${esc(r.fornecedor_nome || '')}</b></small>` : (cj ? `<small class="muted">CNPJ do emitente lido: ${esc(fmt(cj))} — não está em Fornecedores; será cadastrado automaticamente (ou escolha outro cadastrado).</small>` : '')}</div>`; })()}
          ${(() => { const lt = r.itens.reduce((a, x) => a + (x.qtd > 0 ? x.total || x.qtd * x.valor_unit : 0), 0), lq = r.itens.reduce((a, x) => a + (x.qtd > 0 ? x.qtd : 0), 0), m = [];
            if (r.total_nota && r.total_nota - lt > 0.05) m.push(`<b>${R(r.total_nota - lt)}</b> em valor (a nota diz ${R(r.total_nota)}; os itens lidos somam ${R(lt)})`);
            if (r.qtd_nota && r.qtd_nota - lq > 0.5) m.push(`<b>${N(r.qtd_nota - lq)}</b> unidade(s) (a nota diz ${N(r.qtd_nota)}; lidas ${N(lq)})`);
            return m.length ? `<p class="card" style="border-left:4px solid var(--erro,#c0392b)">⚠ <b>Faltam itens na leitura.</b> Pelo rodapé da nota, faltam ${m.join(' e ')}. Alguma linha não foi lida (letra apagada, rasura ou caneta). Confira com a nota e use <b>＋ Incluir item não lido</b>.</p>` : ''; })()}
          <p style="margin:4px 0"><button class="btn sm" type="button" id="addlinha">＋ Incluir item não lido</button></p>
          <p class="muted" style="margin:4px 0">Linhas iguais com o mesmo código são juntadas sozinhas. Se alguma ficou separada, marque em <b>Unir</b> e <button class="btn sm" type="button" id="unir">Unificar linhas marcadas</button></p>
          <div class="tw"><table><thead><tr><th></th><th title="Marque 2 ou mais linhas que são o mesmo produto e clique em Unificar">Unir</th><th>Lido na nota</th><th>Produto do cadastro</th><th class="n">Qtd</th><th class="n">Valor unit.</th><th class="n">Total lido</th></tr></thead><tbody>` +
          r.itens.map((x, i) => { const casado = !!x.produto_id, nm = x.nome_edit || limparNome(x.descricao); return `<tr data-i="${i}"><td><input type="checkbox" data-ok checked></td><td><input type="checkbox" data-un></td><td>${esc(x.descricao)}${x.codigo ? `<br><small class="muted">cód. ${esc(x.codigo)}</small>` : ''}${x.linhas ? `<br><small style="color:var(--ok)">🔗 ${x.linhas} linhas iguais juntadas num item só</small>` : ''}${x.desconto ? `<br><small class="muted">desconto de ${R(x.desconto)} já abatido</small>` : ''}${x.sem_qtd ? '<br><small class="erro">⚠ quantidade ilegível (rasura/caneta): digite a quantidade conforme a nota</small>' : (x.conferir ? '<br><small class="erro">⚠ conferir valores</small>' : '')}</td>
          <td style="min-width:260px"><select data-ac><option value="existente" ${casado ? 'selected' : ''}>Produto do cadastro</option><option value="novo-revenda" ${casado ? '' : 'selected'}>Cadastrar como novo (revenda)</option><option value="novo-insumo">Cadastrar como novo (insumo)</option></select>
            <input data-pp list="dl-prod" value="${casado ? esc(rotuloProd({ id: x.produto_id, nome: x.produto_nome })) : ''}" placeholder="digite o produto do cadastro para amarrar" style="margin-top:4px" class="${casado ? '' : 'hidden'}">
            <input data-nm value="${esc(nm)}" placeholder="nome do produto novo" style="margin-top:4px" class="${casado ? 'hidden' : ''}">
            <div style="margin-top:4px"><button class="btn sm ${casado ? 'hidden' : ''}" type="button" data-amarrar title="Já tem no cadastro? Amarre a este item ao produto existente (nenhum cadastro novo é criado)">🔗 Amarrar ao cadastro</button><button class="btn sm ${casado ? '' : 'hidden'}" type="button" data-novo>↩ Cadastrar como novo</button> <button class="btn sm" type="button" data-ren title="Alterar o nome do produto já cadastrado (o escolhido acima)">✏ Alterar nome do produto</button></div></td>
          <td class="n"><input data-qq value="${x.qtd > 0 ? x.qtd : ''}" placeholder="?" style="width:70px;text-align:right" inputmode="decimal"></td><td class="n"><input data-uu value="${x.valor_unit}" style="width:80px;text-align:right" inputmode="decimal"></td><td class="n">${R(x.total)}</td></tr>`; }).join('') +
          `</tbody></table></div><details style="margin-top:8px"><summary>Ver texto lido</summary><pre style="white-space:pre-wrap;font-size:12px">${esc(r.texto || '')}</pre></details>`;
      };
      const modoLinha = (tr, existente) => { $('[data-ac]', tr).value = existente ? 'existente' : ($('[data-ac]', tr).value === 'novo-insumo' ? 'novo-insumo' : 'novo-revenda'); $('[data-pp]', tr).classList.toggle('hidden', !existente); $('[data-nm]', tr).classList.toggle('hidden', existente); $('[data-amarrar]', tr).classList.toggle('hidden', existente); $('[data-novo]', tr).classList.toggle('hidden', !existente); if (existente) $('[data-pp]', tr).focus(); };
      corpo.addEventListener('change', e => { if (e.target.matches && e.target.matches('[data-forn]')) $('[data-fnovo]', corpo).classList.toggle('hidden', e.target.value !== 'novo'); });
      corpo.addEventListener('change', e => { const tr = e.target.closest && e.target.closest('tr[data-i]'); if (tr && e.target.matches('[data-ac]')) modoLinha(tr, e.target.value === 'existente'); });
      const sincroniza = () => $$('#fres tbody tr', corpo).forEach(t => { const x = linhas[+t.dataset.i]; if (!x) return; const q = numIn($('[data-qq]', t).value), u = numIn($('[data-uu]', t).value); if (q > 0) { x.qtd = q; x.valor_unit = u; x.total = Math.round(q * u * 100) / 100; } const pr = acharProd($('[data-pp]', t).value).p; if (pr && $('[data-ac]', t).value === 'existente') { x.produto_id = pr.id; x.produto_nome = pr.nome; } x.nome_edit = $('[data-nm]', t).value; });
      corpo.onclick = seguro(async e => {
        const trL = e.target.closest('tr[data-i]');
        if (e.target.id === 'addlinha') { sincroniza(); linhas.push({ codigo: '', descricao: '(item digitado por você)', un: 'UN', qtd: 0, valor_unit: 0, total: 0, produto_id: null, produto_nome: null, confianca: 0, nome_edit: '', manual: true }); return desenha({ ...ultimaLeitura, itens: linhas }); }
        if (trL && e.target.dataset.ren !== undefined) return renomearProd($('[data-pp]', trL));
        if (e.target.id === 'unir') {
          const trs = $$('#fres tbody tr', corpo), sel = trs.filter(t => $('[data-un]', t).checked);
          if (sel.length < 2) throw new Error('Marque em "Unir" duas ou mais linhas que são o mesmo produto.');
          trs.forEach(t => { const x = linhas[+t.dataset.i], q = numIn($('[data-qq]', t).value), u = numIn($('[data-uu]', t).value); if (q > 0) { x.qtd = q; x.valor_unit = u; x.total = Math.round(q * u * 100) / 100; } const pr = acharProd($('[data-pp]', t).value).p; if (pr && $('[data-ac]', t).value === 'existente') { x.produto_id = pr.id; x.produto_nome = pr.nome; } x.nome_edit = $('[data-nm]', t).value; });
          const alvo = linhas[+sel[0].dataset.i], resto = sel.slice(1).map(t => linhas[+t.dataset.i]);
          const tot = [alvo, ...resto].reduce((a, x) => a + x.qtd * x.valor_unit, 0), qt = [alvo, ...resto].reduce((a, x) => a + x.qtd, 0);
          alvo.linhas = (alvo.linhas || 1) + resto.reduce((a, x) => a + (x.linhas || 1), 0); alvo.qtd = Math.round(qt * 1000) / 1000; alvo.total = Math.round(tot * 100) / 100; alvo.valor_unit = Math.round(tot / qt * 10000) / 10000;
          if (!alvo.produto_id) { const o = resto.find(x => x.produto_id); if (o) { alvo.produto_id = o.produto_id; alvo.produto_nome = o.produto_nome; } }
          return desenha({ ...ultimaLeitura, itens: linhas.filter(x => !resto.includes(x)) });
        }
        if (trL && e.target.dataset.amarrar !== undefined) return modoLinha(trL, true);
        if (trL && e.target.dataset.novo !== undefined) return modoLinha(trL, false);
        if (e.target.dataset.xmlchave) { sessionStorage.setItem('xmlChave', e.target.dataset.xmlchave); mFoto.fechar(); aba = 'xml'; return desenharAba(); }
        if (e.target.id !== 'flr') return;
        const f = $('#fn', corpo).files[0]; if (!f) throw new Error('Escolha ou tire a foto da nota primeiro.');
        const bt = e.target; bt.disabled = true; $('#fres', corpo).innerHTML = '<p>⏳ Lendo a nota... (pode levar alguns segundos)</p>';
        try {
          const ehPdf = /pdf$/i.test(f.type) || /\.pdf$/i.test(f.name), blob = ehPdf ? f : await prepararFoto(f);
          const rsp = await fetch('/api/estoque/ocr-nota', { method: 'POST', headers: { 'Content-Type': ehPdf ? 'application/pdf' : 'image/jpeg', ...(S.token ? { Authorization: 'Bearer ' + S.token } : {}) }, body: blob });
          let j = {}; try { j = await rsp.json(); } catch { /* */ }
          if (!rsp.ok) throw new Error(j.erro || 'Erro ' + rsp.status);
          desenha(j);
        } catch (er) { $('#fres', corpo).innerHTML = `<p class="erro">${esc(er.message)}</p>`; } finally { bt.disabled = false; }
      });
      const mFoto = modal({ titulo: 'Entrada por foto ou PDF da nota', tam: 'lg', corpo, botoes: [{ txt: 'Cancelar' }, { txt: 'Passar os itens marcados para a entrada', cls: 'primary', fn: async m => {
        if (!linhas.length) throw new Error('Leia a nota primeiro.');
        // número da nota e fornecedor vindos da foto/PDF vão para a entrada manual
        const nn = ($('[data-nn]', corpo) || {}).value; if (nn && nn.trim()) $('#nf', el).value = nn.trim();
        const ns = ($('[data-ns]', corpo) || {}).value; if (ns && ns.trim()) $('#ns', el).value = ns.trim();
        const fs = $('[data-forn]', corpo);   // fornecedor: obrigatório; novo (CNPJ lido) é cadastrado automaticamente
        if (fs) {
          if (!fs.value) throw new Error('Selecione o fornecedor desta nota (a lista mostra os cadastrados).');
          if (fs.value === 'novo') {
            const nm = $('[data-fnome]', corpo).value.trim(); if (nm.length < 3) throw new Error('Informe o nome do fornecedor novo (CNPJ ' + ultimaLeitura.cnpj_emitente + ').');
            const nf2 = await api('/estoque/fornecedor-rapido', { method: 'POST', body: { nome: nm, documento: ultimaLeitura.cnpj_emitente } });
            if (!$('#fo', el).querySelector(`option[value="${nf2.id}"]`)) $('#fo', el).insertAdjacentHTML('beforeend', `<option value="${nf2.id}">${esc(nf2.nome)}</option>`);
            $('#fo', el).value = String(nf2.id); toast(nf2.ja_existia ? 'Fornecedor já cadastrado: ' + nf2.nome : 'Fornecedor cadastrado: ' + nf2.nome, 'ok');
          } else $('#fo', el).value = fs.value;
        }
        let n = 0, ign = 0, novos = 0; const pend = [];
        for (const tr of $$('#fres tbody tr', corpo)) {
          if (!$('[data-ok]', tr).checked) continue;
          const q = numIn($('[data-qq]', tr).value), u = numIn($('[data-uu]', tr).value), ac = $('[data-ac]', tr).value, x = linhas[+tr.dataset.i];
          if (!(q > 0)) { ign++; continue; }
          if (ac === 'existente') { const pr = acharProd($('[data-pp]', tr).value).p; if (!pr) throw new Error('Escolha na lista o produto para amarrar em: ' + x.descricao + ' (ou mude para "Cadastrar como novo").'); pend.push({ pr, q, u, cf: x.codigo }); }
          else { const nome = $('[data-nm]', tr).value.trim(); if (nome.length < 2) throw new Error('Informe o nome do produto novo em: ' + x.descricao); pend.push({ nome, tipo: ac === 'novo-insumo' ? 'insumo' : 'revenda', un: ['KG', 'G', 'L', 'ML'].includes(String(x.un).toUpperCase()) ? x.un : 'UN', q, u, cf: x.codigo }); }
        }
        for (const it of pend) {
          let pr = it.pr;
          if (!pr) { pr = await api('/estoque/produto-automatico', { method: 'POST', body: { nome: it.nome, tipo: it.tipo, unidade: it.un, fornecedor_id: $('#fo', el).value || null, codigo_fornecedor: it.cf || '', origem: `NF ${$('#ns', el).value.trim() ? $('#ns', el).value.trim() + '/' : ''}${$('#nf', el).value.trim() || 's/n'} · ${(($('#fo', el).selectedOptions[0] || {}).textContent || '').replace(/^—.*/, '')} · foto/PDF`.replace(/ · +·/, ' ·') } }); estocaveis.push(pr); novos++; }
          if (it.pr && it.cf && $('#fo', el).value) { try { await api('/estoque/vincular-fornecedor', { method: 'POST', body: { produto_id: it.pr.id, fornecedor_id: $('#fo', el).value, codigo_fornecedor: it.cf } }); } catch { /* o vínculo é só conveniência */ } }
          let row = $$('.it2', el).find(r => !$('[data-p]', r).value.trim() && !$('[data-q]', r).value.trim());
          if (!row) { $('#its', el).insertAdjacentHTML('beforeend', item()); if ($('#dn', el).checked) $$('[data-dc]', el).pop().checked = true; row = $$('.it2', el).pop(); }
          $('[data-p]', row).value = rotuloProd(pr); $('[data-q]', row).value = String(it.q).replace('.', ','); $('[data-c]', row).value = String(it.u).replace('.', ','); n++;
          await fatorDe(row); prev(row);
        }
        atualizaTotal();
        if (!n) throw new Error('Nenhum item marcado com quantidade válida.');
        toast(`${n} item(ns) passados para a entrada. Confira e finalize.` + (novos ? ` ${novos} cadastro(s) automático(s) criado(s) como pendente(s) (confirme em Produtos).` : '') + (ign ? ` ${ign} linha(s) sem quantidade foram ignoradas.` : ''), 'ok');
      } }] });
    };
    el.oninput = e => { if (e.target.matches('[data-q],[data-c],[data-f],[data-p]')) { const r = e.target.closest('.it2'); if (r) prev(r); }
      if (e.target.matches('[data-q],[data-c]')) atualizaTotal(); };
    el.onchange = seguro(async e => {
      if (e.target.matches('[data-p]')) { const r = e.target.closest('.it2'), a = acharProd(e.target.value);
        if (a.p) { e.target.value = rotuloProd(a.p); await fatorDe(r); } else if (e.target.value.trim()) toast('Produto não encontrado. Use "+ Cadastrar produto novo".', 'aviso'); }
      if (e.target.id === 'fo') for (const r of $$('.it2', el)) await fatorDe(r);
      if (e.target.matches('[data-d]')) destino(e.target.closest('.it2'));
      if (e.target.matches('[data-dc]')) { prev(e.target.closest('.it2')); atualizaTotal(); }
      if (e.target.id === 'dn') { $$('[data-dc]', el).forEach(x => { x.checked = e.target.checked; }); $$('.it2', el).forEach(prev); atualizaTotal(); }
    });
    el.onclick = seguro(async e => {
      const ab = e.target.dataset.ab; if (ab) { aba = ab; return desenharAba(); }
      if (e.target.id === 'novoprod') {
        const fid = $('#fo', el).value, fnome = fid ? $('#fo', el).selectedOptions[0].textContent : null;
        formModal({ titulo: 'Cadastrar produto novo', tam: 'md', valores: { fator: 1, unidade: 'UN', tipo: 'revenda' },
          extra: `<p class="muted">${fnome ? 'Fornecedor desta entrada: <b>' + esc(fnome) + '</b> (o código abaixo fica ligado a ele).' : 'Nenhum fornecedor escolhido na entrada: o código do fornecedor não será gravado. Escolha o fornecedor acima antes, se quiser.'}</p>`,
          campos: [{ k: 'codigo_fornecedor', l: 'Código do produto no fornecedor' }, { k: 'nome', l: 'Nome do produto', req: true, full: true }, { k: 'codigo_barras', l: 'Código de barras' },
            { k: 'fator', l: 'Fator deste código de barras (un. na embalagem; fardo com 5 → 5)', t: 'number', step: '0.0001', req: true },
            { k: 'unidade', l: 'Unidade do estoque', t: 'select', op: ['UN', 'KG', 'G', 'L', 'ML', 'CX', 'PCT'].map(u => [u, u]) },
            { k: 'tipo', l: 'Tipo', t: 'select', op: [['revenda', 'Revenda'], ['insumo', 'Insumo / matéria-prima']] }],
          onSave: async o => {
            const np = await api('/estoque/produto-rapido', { method: 'POST', body: { ...o, fornecedor_id: fid || null } });
            estocaveis.push(np); $('#dl-prod', el).insertAdjacentHTML('beforeend', `<option value="${esc(rotuloProd(np))}">`);
            const livre = $$('.it2', el).find(r => !$('[data-p]', r).value.trim()) || ($('#addit', el).click(), $$('.it2', el).pop());
            $('[data-p]', livre).value = rotuloProd(np); $('[data-f]', livre).value = np.fator; prev(livre); $('[data-q]', livre).focus();
            toast('Produto cadastrado e selecionado.');
          } });
        return;
      }
      if (e.target.dataset.ren !== undefined) { e.preventDefault(); return renomearProd($('[data-p]', e.target.closest('.it2'))); }
      if (e.target.id === 'foto') return entradaPorFoto();
      if (e.target.id === 'addit') { $('#its', el).insertAdjacentHTML('beforeend', item()); if ($('#dn', el).checked) $$('[data-dc]', el).pop().checked = true; }
      if (e.target.dataset.x !== undefined) { const r = e.target.closest('.it2,.tt'); if (r) r.remove(); atualizaTotal(); }
      if (e.target.dataset.addt !== undefined) e.target.insertAdjacentHTML('beforebegin', `<div class="row tt"><label>Vencimento<input type="date" data-vc></label><label>Valor<input data-vl inputmode="decimal"></label><button class="btn sm danger auto" data-x type="button">✕</button></div>`);
      if (e.target.id === 'salvar') {
        const itens = $$('.it2', el).map(r => $('[data-d]', r).value === 'p'
          ? { patrimonio: true, descricao: $('[data-ds]', r).value.trim(), quantidade: numIn($('[data-q]', r).value), custo_unit: numIn($('[data-c]', r).value), doacao: $('[data-dc]', r).checked }
          : { produto_id: (acharProd($('[data-p]', r).value).p || {}).id, quantidade: numIn($('[data-q]', r).value), custo_unit: numIn($('[data-c]', r).value), fator: numIn($('[data-f]', r).value), doacao: $('[data-dc]', r).checked })
          .filter(i => (i.patrimonio ? i.descricao : i.produto_id) && i.quantidade > 0);
        if (itens.some(i => i.patrimonio && (i.quantidade !== Math.floor(i.quantidade) || i.quantidade > 500))) throw new Error('Bens de patrimônio: informe a quantidade em unidades inteiras.');
        if (itens.some(i => !i.patrimonio && !(i.fator > 0))) throw new Error('Informe o fator de cada item (quantas unidades vêm na embalagem; 1 se já é unitário).');
        if (!itens.length) throw new Error('Informe ao menos um item (escolha o produto na lista).');
        const tot = itens.filter(i => !i.doacao).reduce((s, i) => s + i.quantidade * i.custo_unit, 0), fo = $('#fo', el);
        const cons = $('#cs', el).checked;
        if (cons && itens.some(i => i.patrimonio || i.doacao)) throw new Error('Nota consignada não pode ter itens de doação ou patrimônio. Lance essa parte em outra entrada.');
        if (cons && !fo.value) throw new Error('Escolha o fornecedor da consignação.');
        const dsp = tot > 0 && !cons ? await lancarDespesa({ total: Math.round(tot * 100) / 100, fornecedor: fo.value ? fo.selectedOptions[0].textContent : '' }) : { titulos: [] };
        if (!dsp) return;
        const r = await api('/estoque/entrada', { method: 'POST', body: { fornecedor_id: fo.value || null, numero: $('#nf', el).value, serie: $('#ns', el).value, itens, doacao: $('#dn', el).checked, consignada: cons, titulos: dsp.titulos, categoria_despesa: dsp.categoria } });
        toast(cons ? `Consignação #${r.id} lançada (${R(r.total)} a acertar no fim do evento).` : `Entrada #${r.id} lançada (${R(r.total)}).` + (r.patrimonios?.length ? ` Patrimônio nº ${r.patrimonios.map(n => String(n).padStart(5, '0')).join(', ')}.` : '') + (r.valor_doacao > 0 ? ` Doação: ${R(r.valor_doacao)}.` : '')); manual();
      }
    });
  };

  const xml = () => {
    el.innerHTML = abas() + dl + `<div class="card"><label>Arquivo XML da NF-e, NFC-e ou cupom fiscal (CF-e SAT)<input type="file" id="arq" accept=".xml,text/xml"></label><p class="muted">O sistema lê itens, quantidades, custos, fornecedor e duplicatas. Se o código de barras (ou o código do fornecedor) já estiver no cadastro, o item é ligado ao produto existente, sem duplicar. O que ainda não existe é cadastrado automaticamente (com o nome da nota, o código de barras e o código do fornecedor) como cadastro <b>pendente</b>: sem código sequencial e não vendável, até você confirmar em Cadastros → Produtos. Se o produto já existe e o fornecedor mandou um código de barras novo (ou nenhum), use <b>🔗 Amarrar ao cadastro</b>: o cadastro automático não é criado. Confira o fator de cada item: o fornecedor pode mandar errado.</p></div><div id="nfbox"></div>`;
    el.onclick = e => { const ab = e.target.dataset.ab; if (ab) { aba = ab; desenharAba(); } };
    const carregarXml = seguro(async texto => {
      const nf = await api('/estoque/xml/ler', { method: 'POST', body: { xml: texto } });
      const un = u => ['KG', 'G', 'L', 'ML'].includes(u);
      const box = $('#nfbox', el);
      box.innerHTML = `<div class="card"><b>${esc(nf.tipo_doc || 'NF-e')} ${nf.serie ? 'série ' + esc(nf.serie) + ' · nº ' : ''}${esc(nf.numero)}</b> · emitida ${dia(nf.data_emissao)} · Total ${R(nf.total_nf)}<br>Fornecedor: <b>${esc(nf.fornecedor.nome)}</b> (${esc(nf.fornecedor.documento)}) ${nf.fornecedor_id ? chip('já cadastrado', 'ok') : chip('será cadastrado', 'warn')}
        <label class="chk" style="margin-top:8px" title="A nota entra no estoque, mas não gera conta a pagar; o pagamento é feito no Acerto da consignação."><input type="checkbox" id="csx"> <b>Nota consignada</b> <span class="muted">(só será paga no acerto, após as devoluções)</span></label>
        <label class="chk" style="margin-top:4px"><input type="checkbox" id="dnx"> <b>Esta nota é de doação</b> <span class="muted">(marca todos os itens; desmarque os que foram comprados)</span></label>
        ${nf.ja_importada ? `<p class="erro"><b>Atenção:</b> esta nota já foi importada em ${dt(nf.ja_importada.criado_em)} (entrada #${nf.ja_importada.id}). Não será possível importar de novo.</p>` : ''}</div>
        <div class="tw"><table><thead><tr><th>Item da nota</th><th class="n">Qtd (${'XML'})</th><th class="n">Custo un.</th><th title="Unidades por embalagem">Fator (un. por emb.)</th><th title="Item recebido de doação: entra sem custo e não gera conta a pagar">Doação</th><th>Ação / produto do sistema</th></tr></thead><tbody>
        ${nf.itens.map((i, n) => { const m = estocaveis.find(p => p.id === i.produto_id); return `<tr data-n="${n}"><td>${esc(i.nome)}<br><small class="muted">cód ${esc(i.codigo_fornecedor)}${i.ean ? ' · EAN ' + esc(i.ean) : ''}</small><br>${i.origem_match === 'vinculo' ? chip('código do fornecedor já vinculado', 'ok') : i.origem_match === 'ean' ? chip('código de barras já cadastrado', 'ok') : chip('novo: cadastro automático (fica pendente de confirmação)', 'warn')}${i.linhas_agrupadas > 1 ? ' ' + chip(i.linhas_agrupadas + ' linhas iguais juntadas', 'ok') : ''}</td><td class="n">${N(i.quantidade)} ${esc(i.unidade_xml)}</td><td class="n">${R(i.custo_unit)}</td>
          <td style="width:90px"><input data-f value="${i.fator || 1}" class="${i.origem_match === 'novo' ? 'pedir' : ''}" title="Quantas unidades vêm em cada embalagem: fardo com 12 un → 12 (1 se já é unitário). O estoque entra multiplicado e o custo é dividido pelo fator." inputmode="decimal"></td>
          <td style="text-align:center"><input type="checkbox" data-dc></td>
          <td style="min-width:280px"><select data-a><option value="existente" ${m ? 'selected' : ''}>Produto existente</option><option value="novo-revenda" ${!m && !un(i.unidade) ? 'selected' : ''}>Cadastro automático (revenda)</option><option value="novo-insumo" ${!m && un(i.unidade) ? 'selected' : ''}>Cadastro automático (insumo)</option><option value="patrimonio">Patrimônio (bem durável, sem estoque)</option><option value="ignorar">Ignorar item</option></select>
          <input data-p list="dl-prod" value="${m ? esc(rotuloProd(m)) : ''}" placeholder="digite o produto do cadastro para amarrar" style="margin-top:4px" autocomplete="off" class="${m ? '' : 'hidden'}"><input data-nm value="${esc(i.nome)}" placeholder="nome do produto novo (pode corrigir)" style="margin-top:4px" class="${m ? 'hidden' : ''}" title="Nome com que o produto será cadastrado. Pode alterar."><div style="margin-top:4px">${m ? '' : '<button class="btn sm" type="button" data-amarrar title="O fornecedor mandou um código novo (ou sem código de barras) de um produto que você já tem? Amarre à entrada ao produto existente: o cadastro automático não será criado.">🔗 Amarrar ao cadastro</button>'}<button class="btn sm hidden" type="button" data-desamarrar>↩ Voltar ao cadastro automático</button> <button class="btn sm" type="button" data-ren title="Alterar o nome do produto já cadastrado (o escolhido acima)">✏ Alterar nome do produto</button></div></td></tr>`; }).join('')}</tbody></table></div>
        <button class="btn primary big" id="conf" ${nf.ja_importada ? 'disabled' : ''}>Finalizar entrada (lançar despesa)</button>`;
      box.addEventListener('change', ev => { const tr = ev.target.closest && ev.target.closest('tr[data-n]'); if (!tr || !ev.target.matches('[data-a]')) return; const ex = ev.target.value === 'existente'; $('[data-p]', tr).classList.toggle('hidden', !ex); $('[data-nm]', tr)?.classList.toggle('hidden', ex || ['patrimonio', 'ignorar'].includes(ev.target.value)); $('[data-amarrar]', tr)?.classList.toggle('hidden', ex); $('[data-desamarrar]', tr).classList.toggle('hidden', !ex || !$('[data-amarrar]', tr)); });
      box.onclick = seguro(async ev => {
        const trA = ev.target.closest('tr[data-n]');
        if (trA && ev.target.dataset.ren !== undefined) return renomearProd($('[data-p]', trA));
        if (trA && ev.target.dataset.amarrar !== undefined) { $('[data-a]', trA).value = 'existente'; $('[data-p]', trA).classList.remove('hidden'); $('[data-nm]', trA)?.classList.add('hidden'); ev.target.classList.add('hidden'); $('[data-desamarrar]', trA).classList.remove('hidden'); $('[data-p]', trA).focus(); return; }
        if (trA && ev.target.dataset.desamarrar !== undefined) { const i = nf.itens[+trA.dataset.n]; $('[data-a]', trA).value = ['KG', 'G', 'L', 'ML'].includes(i.unidade) ? 'novo-insumo' : 'novo-revenda'; $('[data-p]', trA).value = ''; $('[data-p]', trA).classList.add('hidden'); $('[data-nm]', trA)?.classList.remove('hidden'); ev.target.classList.add('hidden'); $('[data-amarrar]', trA)?.classList.remove('hidden'); return; }
        if (ev.target.dataset.x !== undefined) ev.target.closest('.tt')?.remove();
        if (ev.target.dataset.addt !== undefined) ev.target.insertAdjacentHTML('beforebegin', `<div class="row tt"><label>Vencimento<input type="date" data-vc></label><label>Valor<input data-vl inputmode="decimal"></label><button class="btn sm danger auto" data-x type="button">✕</button></div>`);
        if (ev.target.id === 'dnx') $$('[data-dc]', box).forEach(x => { x.checked = ev.target.checked; });
        if (ev.target.id === 'conf') {
          const itens = $$('tbody tr', box).map(tr => { const i = nf.itens[+tr.dataset.n], a = $('[data-a]', tr).value; if (a === 'ignorar') return null;
            const dc = $('[data-dc]', tr).checked;
            if (a === 'patrimonio') { if (i.quantidade !== Math.floor(i.quantidade)) throw new Error('Patrimônio: a quantidade deve ser inteira em: ' + i.nome); return { patrimonio: true, descricao: i.nome, quantidade: i.quantidade, custo_unit: i.custo_unit, doacao: dc }; }
            const base = { quantidade: i.quantidade, custo_unit: i.custo_unit, fator: numIn($('[data-f]', tr).value), doacao: dc, codigo_fornecedor: i.codigo_fornecedor, nome: ($('[data-nm]', tr)?.value || '').trim() || i.nome, ean: i.ean, ean_trib: i.ean_trib, unidade: i.unidade, unidade_trib: i.unidade_trib };
            if (!(base.fator > 0)) throw new Error('Informe o fator (unidades por embalagem; 1 se já é unitário) para: ' + i.nome);
            if (a === 'existente') { const id = idDoRotulo($('[data-p]', tr).value); if (!id) throw new Error('Escolha o produto na lista para: ' + i.nome); return { ...base, produto_id: id }; }
            return { ...base, criar: true, tipo: a === 'novo-insumo' ? 'insumo' : 'revenda' }; }).filter(Boolean);
          if (!itens.length) throw new Error('Nenhum item para lançar.');
          // doação não gera conta a pagar: com itens doados, o valor a pagar é só o dos itens comprados (sem usar as duplicatas da nota)
          const temDoacao = itens.some(x => x.doacao), semDoacao = itens.filter(x => !x.doacao).reduce((t, x) => t + x.quantidade * x.custo_unit, 0);
          const aPagar = temDoacao ? Math.round(semDoacao * 100) / 100 : nf.total_nf, cons = $('#csx', box).checked;
          if (cons && itens.some(x => x.patrimonio || x.doacao)) throw new Error('Nota consignada não pode ter itens de doação ou patrimônio.');
          const dsp = aPagar > 0 && !cons ? await lancarDespesa({ total: aPagar, fornecedor: nf.fornecedor.nome, duplicatas: temDoacao ? null : nf.duplicatas }) : { titulos: [] };
          if (!dsp) return;
          const r = await api('/estoque/xml/confirmar', { method: 'POST', body: { chave: nf.chave, destinatario: nf.destinatario, numero: nf.numero, serie: nf.serie, data_emissao: nf.data_emissao, fornecedor: nf.fornecedor, fornecedor_id: nf.fornecedor_id, itens, doacao: $('#dnx', box).checked, consignada: cons, titulos: dsp.titulos, categoria_despesa: dsp.categoria } });
          toast(`NF importada: entrada #${r.id}, ${R(r.total)}${r.titulos ? ', ' + r.titulos + ' conta(s) a pagar' : ''}.` + (r.patrimonios?.length ? ` Patrimônio nº ${r.patrimonios.map(n => String(n).padStart(5, '0')).join(', ')}.` : '') + (r.valor_doacao > 0 ? ` Doação: ${R(r.valor_doacao)}.` : '')); xml();
        }
      });
    });
    $('#arq', el).onchange = seguro(async e => { const f = e.target.files[0]; if (!f) return; await carregarXml(await f.text()); });
    // vindo do painel "Notas da SEFAZ": abre direto o XML da nota escolhida
    const xt = sessionStorage.getItem('xmlTexto'); if (xt) { sessionStorage.removeItem('xmlTexto'); carregarXml(xt); }
    const ch = sessionStorage.getItem('xmlChave');
    if (ch) { sessionStorage.removeItem('xmlChave'); seguro(async () => { const d = await api('/fiscal/doc/' + ch + '/xml'); await carregarXml(d.xml); })(); }
  };

  const hist = async () => {
    const h = await api('/estoque/entradas');
    el.innerHTML = abas() + tabela([{ l: '#', k: 'id' }, { l: 'Data', f: r => dt(r.criado_em) }, { l: 'Como entrou', f: r => { const t = { manual: 'Manual (digitada)', busca_auto: 'XML — busca automática', busca_botao: 'XML — busca manual (botão)', servico: 'XML — serviço por chave', arquivo: 'XML — arquivo importado' }; return chip(t[r.via] || r.origem, r.via === 'busca_auto' ? 'retirado' : r.via === 'manual' ? '' : 'novo'); } }, { l: 'NF', k: 'numero' }, { l: 'Fornecedor', k: 'fornecedor' }, { l: 'Usuário', k: 'usuario' }, { l: 'Doação / patrimônio', f: r => { const t = []; if (r.qtd_doacao > 0) t.push(chip(r.qtd_doacao === r.qtd_itens ? 'Doação' : `Doação parcial (${r.qtd_doacao}/${r.qtd_itens})`, 'warn') + (r.valor_doacao > 0 ? ' ' + R(r.valor_doacao) : '')); if (r.qtd_patrimonio > 0) t.push(chip(r.qtd_patrimonio + ' patrimônio', 'novo')); return t.join(' '); } }, { l: 'Total pago', n: 1, f: r => r.consig === 'aberta' ? chip('Consignada · a acertar', 'warn') + `<br><small class="muted">${R(r.total)} recebido</small>` : R(r.total) + (r.consig === 'acertada' ? '<br><small class="muted">consignação acertada</small>' : '') }], h, { vazio: 'Nenhuma entrada ainda.' });
    el.onclick = e => { const ab = e.target.dataset.ab; if (ab) { aba = ab; desenharAba(); } };
  };
  // ---- Cadastros pendentes: a confirmação e a amarração dos cadastros automáticos acontecem SÓ aqui, na entrada de mercadoria
  const pendentes = async () => {
    const todos = await api('/produtos'), pend = todos.filter(p => p.suspenso), pode = tem('cadastros.editar');
    el.innerHTML = abas() + `<div class="card"><p class="muted" style="margin:0 0 6px">Produtos criados automaticamente pelas entradas (XML, foto/PDF). Eles ainda não têm código sequencial nem são vendáveis. <b>Confirme</b> o cadastro (o produto recebe o código e passa a valer) ou <b>amarre</b> a um produto que já existe (o automático é descartado e o estoque vai para o existente).</p></div>` +
      (pend.length ? tabela([{ l: 'Produto', f: p => `<b>${esc(p.nome)}</b><br><small class="muted">${esc(p.auto_origem || '')}</small>` }, { l: 'Tipo', k: 'tipo' }, { l: 'Código de barras', f: p => (p.codigos_barras || []).map(esc).join('<br>') || '<span class="muted">—</span>' }, { l: 'Custo', n: 1, f: p => R(p.custo_medio) }, { l: 'Estoque', n: 1, f: p => N(p.estoque_atual) + ' ' + esc(p.unidade) }], pend,
        { acoes: p => (pode ? `<button class="btn sm primary" data-conf="${p.id}" title="Confirma o cadastro: o produto recebe o código sequencial">Confirmar cadastro</button> <button class="btn sm" data-amar="${p.id}" title="Já existe no cadastro? Amarre: o automático é descartado e o estoque vai para o existente">🔗 Amarrar</button>` : '<span class="muted">sem permissão</span>') })
        : '<div class="card"><p>✅ Nenhum cadastro pendente.</p></div>');
    el.onclick = seguro(async e => {
      const ab = e.target.dataset.ab; if (ab) { aba = ab; return desenharAba(); }
      if (e.target.dataset.conf) {
        const p = pend.find(d => d.id == e.target.dataset.conf);
        if (!await confirmar(`Confirmar o cadastro de "${p.nome}"? Ele recebe o código sequencial e passa a valer no cadastro de produtos.`, 'Confirmar cadastro')) return;
        await api('/produtos/' + p.id + '/confirmar-cadastro', { method: 'POST' }); toast('Cadastro confirmado.'); return pendentes();
      }
      if (e.target.dataset.amar) {
        const p = pend.find(d => d.id == e.target.dataset.amar), cand = todos.filter(x => !x.suspenso && x.tipo !== 'preparado' && x.id !== p.id);
        const corpo = document.createElement('div');
        corpo.innerHTML = `<p>Amarrar <b>${esc(p.nome)}</b> (cadastro automático${p.auto_origem ? ' — ' + esc(p.auto_origem) : ''}) a um produto que já existe no cadastro.</p><p class="muted">O estoque (${N(p.estoque_atual)} ${esc(p.unidade)}), o histórico, os códigos de barras e o código do fornecedor passam para o produto escolhido, e o cadastro automático é <b>descartado</b>.</p>
          <label>Produto do cadastro<input id="amd" list="dl-amar" placeholder="digite nome, código ou código de barras" autocomplete="off"></label><datalist id="dl-amar">${cand.map(x => `<option value="${esc(rotuloProd(x))}">`).join('')}</datalist>`;
        modal({ titulo: 'Amarrar ao cadastro do produto', corpo, botoes: [{ txt: 'Cancelar' }, { txt: 'Amarrar e descartar o automático', cls: 'primary', fn: async () => {
          const id = idDoRotulo($('#amd', corpo).value); if (!id) throw new Error('Escolha o produto na lista.');
          const alvo = todos.find(x => x.id === id); if (!await confirmar(`Amarrar "${p.nome}" a "${alvo.nome}"? Não dá para desfazer.`, 'Amarrar')) return false;
          const r = await api('/produtos/' + p.id + '/amarrar', { method: 'POST', body: { destino_id: id } }); toast(`Amarrado a "${r.nome}"` + (r.estoque_transferido ? ` (${N(r.estoque_transferido)} em estoque transferido).` : '.')); pendentes();
        } }] });
      }
    });
  };
  const desenharAba = () => seguro(async () => { if (aba === 'foto') { aba = 'manual'; manual(); return abrirFotoFn && abrirFotoFn(); } if (aba === 'manual') manual(); else if (aba === 'xml') xml(); else if (aba === 'pend') await pendentes(); else await hist(); })();
  desenharAba();
} });

registrar({ id: 'movimentos', titulo: 'Movimentação de estoque', grupo: 'Relatórios', perm: ['estoque.ver', 'relatorios.estoque'], render: async el => {
  const prods = await api('/produtos?ativos=1');
  el.innerHTML = `<div class="bar"><label class="chk" style="margin:0">De <input type="date" id="de" value="${iniMes()}"></label><label class="chk" style="margin:0">Até <input type="date" id="ate" value="${hojeISO()}"></label>
    <input id="pp" list="dl-m" placeholder="Produto (opcional)" autocomplete="off"><datalist id="dl-m">${prods.map(p => `<option value="${esc(rotuloProd(p))}">`).join('')}</datalist>
    <select id="tp"><option value="">Todos os tipos</option><option value="entrada">Entrada</option><option value="venda">Venda (saída)</option><option value="estorno">Estorno</option><option value="ajuste">Ajuste</option></select>
    <button class="btn primary" id="ok">Filtrar</button><div class="grow"></div><button class="btn" id="csv">CSV</button><button class="btn" onclick="window.print()">Imprimir</button></div><div id="res"></div>`;
  let ultimo = null;
  const buscar = seguro(async () => {
    const r = await api('/estoque/movimentos?' + qs({ de: $('#de', el).value, ate: $('#ate', el).value, produto_id: idDoRotulo($('#pp', el).value), tipo: $('#tp', el).value })); ultimo = r;
    $('#res', el).innerHTML = `<h3 style="margin:6px 0">Resumo por produto</h3>` + tabela([{ l: 'Produto', k: 'nome' }, { l: 'Entradas', n: 1, f: x => N(x.entradas) + ' ' + x.unidade }, { l: 'Saídas', n: 1, f: x => N(x.saidas) + ' ' + x.unidade }, { l: 'Saldo atual', n: 1, f: x => N(x.estoque_atual) + ' ' + x.unidade }], r.resumo, { vazio: 'Sem movimento no período.' }) +
      `<h3 style="margin:16px 0 6px">Movimentos</h3>` + tabela([{ l: 'Data', f: x => dt(x.criado_em) }, { l: 'Produto', k: 'produto' }, { l: 'Tipo', f: x => chip(x.tipo, x.quantidade > 0 ? 'ok' : 'warn') }, { l: 'Qtd', n: 1, f: x => (x.quantidade > 0 ? '+' : '') + N(x.quantidade) + ' ' + x.unidade }, { l: 'Saldo', n: 1, f: x => N(x.saldo_apos) }, { l: 'Motivo', k: 'motivo' }, { l: 'Usuário', k: 'usuario' }], r.movimentos, { vazio: 'Sem movimentos.' });
  });
  $('#ok', el).onclick = buscar;
  $('#csv', el).onclick = () => ultimo && csv('movimentacao-estoque', [{ l: 'Data', k: 'criado_em' }, { l: 'Produto', k: 'produto' }, { l: 'Tipo', k: 'tipo' }, { l: 'Quantidade', k: 'quantidade' }, { l: 'Saldo', k: 'saldo_apos' }, { l: 'Motivo', k: 'motivo' }, { l: 'Usuário', k: 'usuario' }], ultimo.movimentos);
  await buscar();
} });

// Cadastro de motivos de ajuste de estoque (adicionar, renomear, inativar/reativar, excluir)
async function gerenciarMotivos(aoMudar) {
  const box = document.createElement('div');
  const desenhar = async () => {
    const l = await api('/estoque/motivos?todos=1');
    box.innerHTML = `<div class="row" style="align-items:flex-end"><label style="flex:3">Novo motivo<input id="nm" maxlength="60" placeholder="ex.: AMOSTRA GRATIS"></label><button class="btn primary auto" id="addm">Adicionar</button></div>` +
      tabela([{ l: 'Motivo', f: x => `<span class="${x.ativo ? '' : 'muted'}">${esc(x.descricao)}</span>` }, { l: 'Situação', f: x => chip(x.ativo ? 'ATIVO' : 'INATIVO', x.ativo ? 'ok' : '') }], l,
        { vazio: 'Nenhum motivo cadastrado.', acoes: x => `<button class="btn sm" data-ren="${x.id}">Renomear</button> <button class="btn sm" data-at="${x.id}" data-v="${x.ativo ? 0 : 1}">${x.ativo ? 'Inativar' : 'Reativar'}</button> <button class="btn sm danger" data-del="${x.id}">Excluir</button>` });
    box._l = l;
  };
  box.onclick = seguro(async e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.id === 'addm') { const v = $('#nm', box).value.trim(); if (!v) throw new Error('Digite o motivo.'); await api('/estoque/motivos', { method: 'POST', body: { descricao: v } }); toast('Motivo cadastrado.'); await desenhar(); return aoMudar && aoMudar(); }
    if (b.dataset.ren) { const x = box._l.find(y => y.id == b.dataset.ren); return formModal({ titulo: 'Renomear motivo', campos: [{ k: 'descricao', l: 'Motivo', req: true, full: true }], valores: { descricao: x.descricao }, onSave: async o => { await api('/estoque/motivos/' + x.id, { method: 'PUT', body: { descricao: o.descricao } }); await desenhar(); if (aoMudar) aoMudar(); } }); }
    if (b.dataset.at) { await api('/estoque/motivos/' + b.dataset.at, { method: 'PUT', body: { ativo: b.dataset.v === '1' } }); await desenhar(); return aoMudar && aoMudar(); }
    if (b.dataset.del) { const x = box._l.find(y => y.id == b.dataset.del); if (!await confirmar(`Excluir o motivo "${x.descricao}"? Os ajustes já lançados não são alterados.`)) return; await api('/estoque/motivos/' + x.id, { method: 'DELETE' }); await desenhar(); return aoMudar && aoMudar(); }
  });
  await desenhar();
  return modal({ titulo: 'Motivos de ajuste de estoque', tam: 'md', corpo: box, botoes: [{ txt: 'Fechar', cls: 'primary' }] });
}

// ---- Busca de produto por nome, código interno ou código de barras (telas de ajuste e extrato)
function seletorProduto(prods, idLista) {
  const dl = `<datalist id="${idLista}">${prods.map(p => `<option value="${esc(rotuloProd(p))}">`).join('')}</datalist>`;
  const achar = txt => { const id = idDoRotulo(txt); if (id) return prods.find(x => x.id === id); const s = String(txt || '').trim(); if (!s) return null;
    return prods.find(x => (x.codigos_barras || []).includes(s)) || prods.find(x => String(x.codigo || '').toLowerCase() === s.toLowerCase()) || null; };
  return { dl, achar };
}

registrar({ id: 'ajuste-avulso', titulo: 'Ajuste de estoque (avulso)', grupo: 'Estoque', perm: 'estoque.ajuste', render: async el => {
  const prods = (await api('/produtos?ativos=1')).filter(p => p.controla_estoque);
  const { dl, achar } = seletorProduto(prods, 'dl-aj');
  let atual = null;
  const lista = seguro(async () => {
    const h = await api('/estoque/ajustes');
    $('#hist', el).innerHTML = tabela([{ l: '#', k: 'id' }, { l: 'Data', f: r => dt(r.criado_em) }, { l: 'Produto', k: 'produto' }, { l: 'No sistema', n: 1, f: r => N(r.estoque_sistema) + ' ' + r.unidade }, { l: 'Informado', n: 1, f: r => N(r.estoque_informado) + ' ' + r.unidade },
      { l: 'Diferença', n: 1, f: r => `<b class="${r.diferenca < 0 ? 'erro' : ''}">${r.diferenca > 0 ? '+' : ''}${N(r.diferenca)}</b>` }, { l: 'Motivo', k: 'motivo' }, { l: 'Usuário', k: 'usuario' }], h, { vazio: 'Nenhum ajuste lançado ainda.' });
  });
  el.innerHTML = `<div class="card" style="max-width:640px">${dl}<p class="muted">Use para corrigir o estoque quando a contagem física for diferente do sistema. Cada ajuste fica registrado com usuário, data, motivo e diferença, e aparece no Extrato do produto.</p>
    <label>Produto (nome, código interno ou código de barras)<input id="pp" list="dl-aj" autocomplete="off" placeholder="digite ou leia o código de barras"></label>
    <div class="row"><label>Como lançar<select id="md"><option value="sobrepor">Sobrepor: informar o total contado (substitui o estoque)</option><option value="somar">Somar: informar quanto acrescentar ao estoque existente</option></select></label></div>
    <div class="row"><label>Estoque no sistema<input id="es" readonly placeholder="—"></label><label><span id="erl">Estoque real (contado) *</span><input id="er" inputmode="decimal" disabled></label><label>Ficará com<input id="df" readonly placeholder="—"></label></div>
    <div class="row" style="align-items:flex-end"><label style="flex:2">Motivo *<select id="mo"></select></label><button class="btn auto" id="gmot" type="button">Cadastrar / editar motivos</button></div><label>Observação (opcional)<input id="mobs" maxlength="120"></label><button class="btn primary big" id="lan" disabled style="margin-top:10px">Lançar ajuste</button></div>
    <h3 style="margin:18px 0 6px">Últimos ajustes</h3><div id="hist"></div>`;
  const carregaMotivos = async () => { const m = await api('/estoque/motivos'); const sel = $('#mo', el), v = sel.value; sel.innerHTML = '<option value="">— escolha o motivo —</option>' + m.map(x => `<option value="${esc(x.descricao)}" ${x.descricao === v ? 'selected' : ''}>${esc(x.descricao)}</option>`).join(''); };
  $('#gmot', el).onclick = seguro(() => gerenciarMotivos(carregaMotivos)); await carregaMotivos();
  const somando = () => $('#md', el).value === 'somar';
  const dif = () => { if (!atual) return; const v = numIn($('#er', el).value), d = $('#df', el); if ($('#er', el).value.trim() === '') { d.value = ''; return; } const fim = somando() ? atual.estoque_atual + v : v; const x = Math.round((fim - atual.estoque_atual) * 1000) / 1000; d.value = N(Math.round(fim * 1000) / 1000) + ' ' + atual.unidade + ' (' + (x > 0 ? '+' : '') + N(x) + ')'; };
  $('#md', el).onchange = () => { $('#erl', el).textContent = somando() ? 'Quantidade a somar *' : 'Estoque real (contado) *'; dif(); };
  const escolher = seguro(async () => {
    const p = achar($('#pp', el).value); atual = null; $('#es', el).value = ''; $('#er', el).value = ''; $('#df', el).value = ''; $('#er', el).disabled = true; $('#lan', el).disabled = true;
    if (!p) { if ($('#pp', el).value.trim()) toast('Produto não encontrado.', 'aviso'); return; }
    $('#pp', el).value = rotuloProd(p);
    atual = await api('/estoque/saldo?produto_id=' + p.id); atual.estoque_atual = Number(atual.estoque_atual);
    $('#es', el).value = N(atual.estoque_atual) + ' ' + atual.unidade; $('#er', el).disabled = false; $('#lan', el).disabled = false; $('#er', el).focus();
  });
  $('#pp', el).onchange = escolher; $('#er', el).oninput = dif;
  $('#lan', el).onclick = seguro(async () => {
    if (!atual) return; if ($('#er', el).value.trim() === '') throw new Error('Informe o estoque real (quantidade contada).'); if (!$('#mo', el).value) throw new Error('Escolha o motivo do ajuste.');
    const v = numIn($('#er', el).value), so = somando(), fim = Math.round((so ? atual.estoque_atual + v : v) * 1000) / 1000;
    if (fim < 0) throw new Error('O estoque não pode ficar negativo.');
    if (!await confirmar(so ? `Somar ${N(v)} ${atual.unidade} ao estoque de ${atual.nome}? (de ${N(atual.estoque_atual)} para ${N(fim)})` : `Ajustar ${atual.nome} de ${N(atual.estoque_atual)} para ${N(v)} ${atual.unidade}?`)) return;
    const r = await api('/estoque/ajuste', { method: 'POST', body: { produto_id: atual.id, nova_qtd: v, modo: so ? 'somar' : 'sobrepor', motivo: $('#mo', el).value + ($('#mobs', el).value.trim() ? ' — ' + $('#mobs', el).value.trim() : '') } });
    toast(r.delta ? `Ajuste #${r.id} lançado (${r.delta > 0 ? '+' : ''}${N(r.delta)} ${atual.unidade}).` : 'Estoque já confere; nada a ajustar.');
    $('#pp', el).value = ''; $('#mo', el).value = ''; $('#mobs', el).value = ''; atual = null; $('#es', el).value = ''; $('#er', el).value = ''; $('#df', el).value = ''; $('#er', el).disabled = true; $('#lan', el).disabled = true; lista();
  });
  await lista();
} });

// ---- Produção: gasta os insumos pela ficha técnica e coloca o produto preparado (ex.: pipoca) no estoque
registrar({ id: 'producao-estoque', titulo: 'Produção (insumos → produto)', grupo: 'Estoque', perm: 'estoque.producao', render: async el => {
  const prods = (await api('/produtos?ativos=1')).filter(p => p.tipo === 'preparado' && p.controla_estoque);
  const { dl, achar } = seletorProduto(prods, 'dl-prd');
  let atual = null, prev = null;
  const hist = seguro(async () => {
    const h = await api('/estoque/producoes');
    $('#hist', el).innerHTML = tabela([{ l: '#', k: 'id' }, { l: 'Data', f: r => dt(r.criado_em) }, { l: 'Produto', k: 'produto' }, { l: 'Quantidade produzida', n: 1, f: r => N(r.quantidade) + ' ' + r.unidade },
      { l: 'Custo total', n: 1, f: r => R(r.custo_total) }, { l: 'Custo unitário', n: 1, f: r => R(r.custo_unit) }, { l: 'Usuário', k: 'usuario' }, { l: 'Obs.', f: r => esc(r.observacao || '') }], h, { vazio: 'Nenhuma produção registrada ainda.' });
  });
  el.innerHTML = `<div class="card" style="max-width:760px">${dl}
    <p class="muted">Use quando o produto é feito <b>antes</b> da venda (ex.: pipoca). Ao registrar a produção, o sistema <b>coloca a quantidade produzida no estoque do produto</b> e já reserva o uso previsto dos insumos (pela ficha técnica). Os insumos só <b>baixam do estoque no fechamento do caixa</b>, quando você informa o que sobrou. Na venda, só o estoque do produto diminui.</p>
    <div class="row"><label style="flex:3">Produto preparado *<input id="pp" list="dl-prd" autocomplete="off" placeholder="digite o nome (só aparecem pratos que controlam estoque)"></label><label>Quantidade produzida *<input id="qt" inputmode="decimal" disabled></label></div>
    <div id="pv"></div>
    <label>Observação<input id="ob" placeholder="ex: lote da manhã"></label>
    <button class="btn primary big" id="reg" disabled style="margin-top:10px">Registrar produção</button></div>
    <h3 style="margin:18px 0 6px">Últimas produções</h3><div id="hist"></div>`;
  const previa = seguro(async () => {
    $('#reg', el).disabled = true; if (!atual) { $('#pv', el).innerHTML = ''; return; }
    const q = numIn($('#qt', el).value); if (!(q > 0)) { $('#pv', el).innerHTML = '<p class="muted">Informe a quantidade para ver quanto de cada insumo será gasto.</p>'; return; }
    prev = await api(`/estoque/producao/previa?produto_id=${atual.id}&quantidade=${q}`);
    const falta = prev.itens.some(x => x.disponivel - x.necessario < -0.0005);
    $('#pv', el).innerHTML = tabela([{ l: 'Insumo', k: 'nome' }, { l: 'Por unidade', n: 1, f: x => N(x.por_unidade) + ' ' + x.unidade }, { l: 'Uso previsto', n: 1, f: x => `<b>${N(x.necessario)} ${x.unidade}</b>` },
      { l: 'Disponível', n: 1, f: x => `<span class="${x.disponivel - x.necessario < -0.0005 ? 'erro' : ''}">${N(x.disponivel)} ${x.unidade}</span>` }, { l: 'Custo', n: 1, f: x => R(x.custo) }], prev.itens)
      + `<p>Custo total: <b>${R(prev.custo_total)}</b> · custo por unidade: <b>${R(prev.custo_total / q)}</b></p>${falta ? '<p class="erro">Há insumo insuficiente em estoque. Dê entrada na compra ou ajuste o estoque antes.</p>' : ''}`;
    $('#reg', el).disabled = falta;
  });
  const escolher = seguro(async () => {
    const p = achar($('#pp', el).value); atual = null; $('#qt', el).disabled = true; $('#qt', el).value = ''; $('#pv', el).innerHTML = ''; $('#reg', el).disabled = true;
    if (!p) { if ($('#pp', el).value.trim()) toast('Produto não encontrado (precisa ser Prato / preparado com "Controla estoque" marcado e ficha técnica).', 'aviso'); return; }
    $('#pp', el).value = rotuloProd(p); atual = p; $('#qt', el).disabled = false; $('#qt', el).focus();
  });
  $('#pp', el).onchange = escolher; $('#qt', el).oninput = previa;
  $('#reg', el).onclick = seguro(async () => {
    if (!atual) return; const q = numIn($('#qt', el).value);
    if (!await confirmar(`Registrar a produção de ${N(q)} ${atual.unidade} de ${atual.nome}? Os insumos serão baixados no fechamento do caixa.`)) return;
    const r = await api('/estoque/producao', { method: 'POST', body: { produto_id: atual.id, quantidade: q, observacao: $('#ob', el).value } });
    toast(`Produção #${r.id} registrada. Estoque de ${atual.nome} atualizado (insumos baixam no fechamento do caixa).`);
    $('#pp', el).value = ''; $('#ob', el).value = ''; atual = null; $('#qt', el).value = ''; $('#qt', el).disabled = true; $('#pv', el).innerHTML = ''; $('#reg', el).disabled = true; hist();
  });
  await hist();
} });

// Lançar produção rápida (usada na lista de produtos, no cadastro e na tela de vendas): baixa os insumos e soma ao estoque do produto
async function produzirModal(prodId, depois, exigirAut = false) {
  if (S.user && S.user.perms.includes('*')) exigirAut = false;   // Administrador não valida senha
  const prods = (await api('/produtos?ativos=1')).filter(p => p.tipo === 'preparado' && p.controla_estoque);
  if (!prods.length) return toast('Nenhum prato preparado com "Controla estoque" marcado. Ajuste o cadastro do produto.', 'aviso');
  const corpo = document.createElement('div');
  corpo.innerHTML = `<p class="muted">Informe quantas unidades foram feitas. A quantidade entra no estoque do produto para venda. Os insumos serão baixados no fechamento do caixa (pela sobra que você contar).</p>
    <div class="row"><label style="flex:3">Produto<select id="pz">${prods.map(p => `<option value="${p.id}" ${p.id == prodId ? 'selected' : ''}>${esc(p.nome)} (estoque ${N(p.estoque_atual)} ${p.unidade})</option>`).join('')}</select></label>
    <label>Quantidade feita *<input id="pq" inputmode="decimal" placeholder="ex: 10"></label></div><div id="pv"></div>
    <label>Observação<input id="po" placeholder="ex: lote da tarde"></label>`;
  let falta = false;
  const previa = seguro(async () => {
    const q = numIn($('#pq', corpo).value); if (!(q > 0)) { $('#pv', corpo).innerHTML = ''; falta = false; return; }
    const v = await api(`/estoque/producao/previa?produto_id=${$('#pz', corpo).value}&quantidade=${q}`);
    falta = v.itens.some(x => x.disponivel - x.necessario < -0.0005);
    $('#pv', corpo).innerHTML = tabela([{ l: 'Insumo', k: 'nome' }, { l: 'Uso previsto', n: 1, f: x => `<b>${N(x.necessario)} ${x.unidade}</b>` }, { l: 'Disponível', n: 1, f: x => `<span class="${x.disponivel - x.necessario < -0.0005 ? 'erro' : ''}">${N(x.disponivel)} ${x.unidade}</span>` }], v.itens)
      + (falta ? '<p class="erro">Insumo insuficiente em estoque.</p>' : '');
  });
  if (exigirAut) corpo.insertAdjacentHTML('beforeend', '<p class="muted" style="margin-top:10px">Confirme com usuário e senha de quem tem permissão para lançar produção:</p><div class="row"><label>Usuário<input id="pal" data-cred autocomplete="off"></label><label>Senha<input id="pas" type="password" data-cred autocomplete="new-password"></label></div>');
  corpo.oninput = previa; corpo.onchange = previa;
  modal({ titulo: 'Lançar produção', tam: 'md', corpo, botoes: [{ txt: 'Cancelar' }, { txt: 'Lançar produção', cls: 'primary', fn: async () => {
    const q = numIn($('#pq', corpo).value); if (!(q > 0)) throw new Error('Informe a quantidade feita.'); if (falta) throw new Error('Insumo insuficiente em estoque.');
    if (exigirAut && (!$('#pal', corpo).value.trim() || !$('#pas', corpo).value)) throw new Error('Informe usuário e senha para autorizar.');
    let r; try { r = await api('/estoque/producao', { method: 'POST', body: { produto_id: +$('#pz', corpo).value, quantidade: q, observacao: $('#po', corpo).value, ...(exigirAut ? { exigir_autorizacao: true, autorizacao: { login: $('#pal', corpo).value.trim(), senha: $('#pas', corpo).value } } : {}) } }); }
    catch (e) { if (exigirAut) { $('#pas', corpo).value = ''; } throw e; }
    toast(`Produção #${r.id} lançada: ${N(q)} un. no estoque (insumos baixam no fechamento do caixa).`); if (depois) depois();
  } }] });
}

// ---- Controle de patrimônio: bens não imobilizados (nem revenda nem consumo), comprados ou doados
registrar({ id: 'patrimonio', titulo: 'Patrimônio', grupo: 'Estoque', perm: 'patrimonio.ver', render: async el => {
  const gerir = tem('patrimonio.gerenciar'), empr = tem('patrimonio.emprestar');
  let lista = [], modo = 'bens', emps = [], clis = null;
  const camposBem = [{ k: 'descricao', l: 'Descrição do bem', req: true, full: true }, { k: 'marca', l: 'Marca' }, { k: 'modelo', l: 'Modelo' }, { k: 'serie', l: 'Nº de série' },
    { k: 'valor', l: 'Valor (R$)', t: 'number', step: '0.01' }, { k: 'local', l: 'Local (onde está)' }, { k: 'responsavel', l: 'Responsável' }, { k: 'observacao', l: 'Observações', full: true }];
  const nPat = n => String(n).padStart(5, '0');
  const etiqueta = bs => { // etiqueta para colar no bem (uma ou várias)
    const w = window.open('', '_blank', 'width=520,height=640'); if (!w) return toast('Libere pop-ups para imprimir a etiqueta.', 'aviso');
    w.document.write(`<html><head><meta charset="utf-8"><title>Etiquetas de patrimônio</title><style>body{font-family:Arial,sans-serif;margin:8px}.e{border:2px solid #000;border-radius:6px;padding:8px 12px;margin:6px 0;width:300px;page-break-inside:avoid}.t{font-size:11px;letter-spacing:1px;text-transform:uppercase}.n{font-size:34px;font-weight:bold;letter-spacing:2px}.d{font-size:13px}</style></head><body>${
      bs.map(b => `<div class="e"><div class="t">Patrimônio</div><div class="n">${nPat(b.numero)}</div><div class="d">${esc(b.descricao)}${b.local ? '<br><small>' + esc(b.local) + '</small>' : ''}</div></div>`).join('')}<script>window.onload=()=>setTimeout(()=>window.print(),200)<\/script></body></html>`);
    w.document.close();
  };
  const termo = e => { // termo de empréstimo: imprime ou salva em PDF pelo diálogo de impressão
    const w = window.open('', '_blank', 'width=820,height=900'); if (!w) return toast('Libere pop-ups para imprimir o termo.', 'aviso');
    const L = (t, v) => `<tr><th>${t}</th><td>${esc(v || '—')}</td></tr>`;
    w.document.write(`<html><head><meta charset="utf-8"><title>Termo de empréstimo nº ${e.id}</title><style>body{font-family:Arial,sans-serif;margin:32px;text-transform:uppercase;font-size:13px}h1{font-size:18px;text-align:center;margin:0 0 4px}h2{font-size:13px;margin:18px 0 6px;border-bottom:1px solid #000}table{width:100%;border-collapse:collapse}th{text-align:left;width:34%;padding:4px 0;vertical-align:top}td{padding:4px 0}.ass{display:flex;gap:40px;margin-top:60px}.ass div{flex:1;border-top:1px solid #000;text-align:center;padding-top:4px;font-size:11px}p{line-height:1.5}</style></head><body>
      <h1>Termo de empréstimo de bem</h1><div style="text-align:center;font-size:11px">Nº ${e.id}</div>
      <h2>Bem emprestado</h2><table>${L('Patrimônio nº', nPat(e.patrimonio_numero))}${L('Descrição', e.patrimonio_descricao)}${L('Marca / modelo', [e.marca, e.modelo].filter(Boolean).join(' · '))}${L('Nº de série', e.serie)}${L('Valor de reposição', R(e.valor))}${L('Estado na saída', e.estado_saida)}</table>
      <h2>Quem levou</h2><table>${L('Nome', e.pessoa_nome)}${L('Telefone', e.pessoa_telefone)}${L('Documento', e.pessoa_documento)}</table>
      <h2>Prazo</h2><table>${L('Data da saída', dia(e.saida_em))}${L('Devolução prevista', e.prevista_em ? dia(e.prevista_em) : 'Sem data definida')}${L('Devolvido em', e.devolvido_em ? dia(e.devolvido_em) : '')}${L('Estado na devolução', e.estado_devolucao)}${e.observacao ? L('Observações', e.observacao) : ''}</table>
      <p style="margin-top:18px">O(a) responsável acima declara ter recebido o bem descrito, em perfeito estado salvo o que foi anotado, e se compromete a cuidar dele e devolvê-lo na data combinada, respondendo por perda ou dano.</p>
      <div class="ass"><div>Responsável por receber o bem</div><div>Quem emprestou</div></div>
      <script>window.onload=()=>setTimeout(()=>window.print(),200)<\/script></body></html>`);
    w.document.close();
  };
  const empChip = e => e.devolvido_em ? chip('Devolvido', 'ok') : e.atrasado ? chip(`Atrasado ${e.dias_atraso} dia(s)`, 'erro') : chip('Emprestado', 'warn');
  const desenharEmp = () => {
    const ab = emps.filter(e => !e.devolvido_em);
    $('#res', el).innerHTML = `<div class="cards"><div class="stat">Emprestados agora<b>${ab.length}</b></div><div class="stat ${ab.some(e => e.atrasado) ? 'err' : ''}">Atrasados<b>${ab.filter(e => e.atrasado).length}</b></div></div>` +
      tabela([{ l: 'Bem', f: e => `<b>${nPat(e.patrimonio_numero)}</b> ${esc(e.patrimonio_descricao)}` }, { l: 'Quem levou', f: e => esc(e.pessoa_nome) + (e.pessoa_telefone ? `<br><small class="muted">${esc(e.pessoa_telefone)}</small>` : '') },
        { l: 'Saída', f: e => dia(e.saida_em) + (e.estado_saida ? `<br><small class="muted">${esc(e.estado_saida)}</small>` : '') }, { l: 'Prevista', f: e => (e.prevista_em ? dia(e.prevista_em) : '—') },
        { l: 'Devolução', f: e => (e.devolvido_em ? dia(e.devolvido_em) + (e.estado_devolucao ? `<br><small class="muted">${esc(e.estado_devolucao)}</small>` : '') : '') }, { l: 'Situação', f: empChip }],
      emps, { vazio: 'Nenhum empréstimo encontrado.', rowCls: e => (e.atrasado ? 'low' : ''),
        acoes: e => `<button class="btn sm" data-tm="${e.id}">Termo</button>` + (empr && !e.devolvido_em ? ` <button class="btn sm primary" data-dv="${e.id}">Devolver</button>` : '') });
  };
  const emprestar = async bem0 => { // bem0 = bem já escolhido (botão da linha); null = escolher na janela (botão "+ Novo empréstimo")
    if (!clis) clis = await api('/clientes?ativos=1');
    let livres = [];
    if (!bem0) { livres = (await api('/patrimonio?situacao=ativo')).filter(x => !x.emprestimo_id); if (!livres.length) return toast('Não há bens livres para emprestar. Cadastre um bem em "Bens" (ou devolva algum).', 'aviso'); }
    return formModal({ titulo: bem0 ? `Emprestar — ${nPat(bem0.numero)} ${bem0.descricao}` : 'Novo empréstimo', tam: 'md', valores: { saida_em: hojeISO() },
      campos: [...(bem0 ? [] : [{ k: 'patrimonio_id', l: 'Bem a emprestar', t: 'select', req: true, op: [['', '— escolha o bem —'], ...livres.map(x => [x.id, `${nPat(x.numero)} · ${x.descricao}`])], full: true }]),
        { k: 'cliente_id', l: 'Cliente cadastrado (ou deixe em branco e digite abaixo)', t: 'select', op: [['', '— pessoa avulsa —'], ...clis.map(c => [c.id, c.nome])], full: true }, { k: 'pessoa_nome', l: 'Nome de quem vai levar (se não for cliente)' }, { k: 'pessoa_telefone', l: 'Telefone' }, { k: 'pessoa_documento', l: 'CPF / documento' },
        { k: 'saida_em', l: 'Data da saída', t: 'date', req: true }, { k: 'prevista_em', l: 'Devolução prevista', t: 'date' }, { k: 'estado_saida', l: 'Estado do bem na saída (ok, riscado, faltando peça...)', full: true }, { k: 'observacao', l: 'Observações', full: true }],
      onSave: async o => { const bid = bem0 ? bem0.id : o.patrimonio_id; if (!bid) throw new Error('Escolha o bem a emprestar.');
        const r = await api(`/patrimonio/${bid}/emprestar`, { method: 'POST', body: o }); toast('Empréstimo registrado.'); await carregar(); const lst = await api('/patrimonio/emprestimos?situacao=aberto'); const novo = lst.find(x => x.id === r.id); if (novo && await confirmar('Imprimir o termo de empréstimo agora?')) termo(novo); } });
  };
  const devolver = e => formModal({ titulo: `Devolução — ${nPat(e.patrimonio_numero)} ${e.patrimonio_descricao}`, valores: { data: hojeISO() },
    campos: [{ k: 'data', l: 'Data da devolução', t: 'date', req: true }, { k: 'estado_devolucao', l: 'Estado do bem na devolução (ok, riscado, faltando peça...)', full: true }, { k: 'observacao', l: 'Observações', full: true }],
    onSave: async o => { await api(`/patrimonio/emprestimos/${e.id}/devolver`, { method: 'POST', body: o }); toast('Devolução registrada.'); carregar(); } });
  const desenhar = () => {
    if (modo === 'emp') return desenharEmp();
    const tot = lista.filter(b => b.situacao === 'ativo').reduce((s, b) => s + Number(b.valor), 0);
    $('#res', el).innerHTML = `<div class="cards"><div class="stat">Bens ativos<b>${lista.filter(b => b.situacao === 'ativo').length}</b></div><div class="stat">Valor dos ativos<b>${R(tot)}</b></div><div class="stat">Doados (ativos)<b>${lista.filter(b => b.situacao === 'ativo' && b.origem === 'doacao').length}</b></div></div>` +
      tabela([{ l: 'Nº', f: b => `<b>${nPat(b.numero)}</b>` }, { l: 'Descrição', f: b => `${esc(b.descricao)}${b.marca || b.modelo ? `<br><small class="muted">${esc([b.marca, b.modelo].filter(Boolean).join(' · '))}${b.serie ? ' · série ' + esc(b.serie) : ''}</small>` : ''}` },
        { l: 'Local / responsável', f: b => esc([b.local, b.responsavel].filter(Boolean).join(' · ')) }, { l: 'Origem', f: b => b.origem === 'doacao' ? chip('Doação', 'warn') : chip('Compra') },
        { l: 'Aquisição', f: b => dia(b.data_aquisicao) + (b.nota ? `<br><small class="muted">NF ${esc(b.nota)}</small>` : '') + (b.fornecedor ? `<br><small class="muted">${esc(b.fornecedor)}</small>` : '') },
        { l: 'Valor', n: 1, f: b => R(b.valor) }, { l: 'Situação', f: b => (b.situacao === 'ativo' ? chip('Ativo', 'ok') : chip('Baixado', 'erro') + `<br><small class="muted">${dia(b.baixa_em)} · ${esc(b.baixa_motivo || '')}</small>`) + (b.emprestimo_id ? '<br>' + (b.emprestimo_atrasado ? chip('Emprestado · ATRASADO', 'erro') : chip('Emprestado', 'warn')) + `<br><small class="muted">${esc(b.emprestado_para)}${b.emprestimo_prevista ? ' · devolve ' + dia(b.emprestimo_prevista) : ''}</small>` : '') }],
      lista, { vazio: 'Nenhum bem encontrado. Os bens entram pela Entrada de mercadoria (destino Patrimônio) ou pelo botão "+ Novo bem".', rowCls: b => b.situacao === 'baixado' ? 'low' : '',
        acoes: b => `<button class="btn sm" data-et="${b.id}">Etiqueta</button>` + (empr && b.situacao === 'ativo' ? (b.emprestimo_id ? ` <button class="btn sm primary" data-dv="${b.emprestimo_id}">Devolver</button>` : ` <button class="btn sm" data-em="${b.id}">Emprestar</button>`) : '') + ` <button class="btn sm" data-hi="${b.id}">Histórico</button>` + (gerir ? ` <button class="btn sm" data-ed="${b.id}">Editar</button>` + (b.situacao === 'ativo' ? ` <button class="btn sm danger" data-bx="${b.id}">Baixar</button>` : ` <button class="btn sm" data-re="${b.id}">Reativar</button>`) : '') });
  };
  const carregar = seguro(async () => { if (modo === 'emp') { emps = await api('/patrimonio/emprestimos?' + qs({ situacao: $('#es', el).value, q: $('#eq', el).value })); return desenhar(); } lista = await api('/patrimonio?' + qs({ q: $('#bq', el).value, situacao: $('#bs', el).value, origem: $('#bo', el).value })); desenhar(); });
  el.innerHTML = `<div class="tabs" id="tbp"><button data-m="bens" class="on">Bens</button><button data-m="emp">Empréstimos</button></div>
    <div class="bar hidden" id="barE"><input id="eq" placeholder="Buscar por bem ou pessoa..."><select id="es"><option value="aberto">Emprestados agora</option><option value="atrasado">Só atrasados</option><option value="devolvido">Já devolvidos</option><option value="">Todos</option></select><div class="grow"></div>${empr ? '<button class="btn primary" data-ne="1">+ Novo empréstimo</button>' : ''}</div>
    <div class="bar" id="barB"><input id="bq" placeholder="Buscar por nº, descrição, local, série..."><select id="bs"><option value="ativo">Só ativos</option><option value="baixado">Só baixados</option><option value="">Todos</option></select>
    <select id="bo"><option value="">Compra e doação</option><option value="compra">Só compra</option><option value="doacao">Só doação</option></select><div class="grow"></div>
    ${empr ? '<button class="btn" data-ne="1">+ Novo empréstimo</button>' : ''}${gerir ? '<button class="btn primary" id="novo">+ Novo bem</button>' : ''}<button class="btn" id="csv">CSV</button><button class="btn" id="etall">Etiquetas da lista</button></div><div id="res"></div>`;
  let t; $('#eq', el).oninput = () => { clearTimeout(t); t = setTimeout(carregar, 300); }; $('#es', el).onchange = carregar; $('#bq', el).oninput = () => { clearTimeout(t); t = setTimeout(carregar, 300); }; $('#bs', el).onchange = $('#bo', el).onchange = carregar;
  $('#csv', el).onclick = () => csv('patrimonio', [{ l: 'Nº', k: 'numero' }, { l: 'Descrição', k: 'descricao' }, { l: 'Marca', k: 'marca' }, { l: 'Modelo', k: 'modelo' }, { l: 'Série', k: 'serie' }, { l: 'Local', k: 'local' }, { l: 'Responsável', k: 'responsavel' }, { l: 'Origem', k: 'origem' }, { l: 'Valor', k: 'valor' }, { l: 'Aquisição', k: 'data_aquisicao' }, { l: 'Situação', k: 'situacao' }, { l: 'Baixa', k: 'baixa_em' }, { l: 'Motivo da baixa', k: 'baixa_motivo' }], lista);
  $('#etall', el).onclick = () => lista.length ? etiqueta(lista) : toast('Nada na lista.', 'aviso');
  if (gerir) $('#novo', el).onclick = () => formModal({ titulo: 'Novo bem (já existente na casa, sem nota)', tam: 'md', valores: { quantidade: 1, origem: 'compra' },
    campos: [{ k: 'numero_auto', l: 'Nº do patrimônio (automático)', ro: true, ph: 'Gerado sozinho ao gravar (sequencial: 00001, 00002...)', full: true }, { k: 'quantidade', l: 'Quantidade (um nº para cada)', t: 'number', step: '1' }, { k: 'origem', l: 'Origem', t: 'select', op: [['compra', 'Compra'], ['doacao', 'Doação']] }, ...camposBem],
    onSave: async o => { const r = await api('/patrimonio', { method: 'POST', body: o }); toast('Cadastrado: patrimônio nº ' + r.numeros.map(nPat).join(', ') + '.'); carregar(); } });
  el.onclick = seguro(async e => {
    const d = e.target.dataset;
    if (d.m) { modo = d.m; $$('#tbp button', el).forEach(x => x.classList.toggle('on', x.dataset.m === modo)); $('#barE', el).classList.toggle('hidden', modo !== 'emp'); $('#barB', el).classList.toggle('hidden', modo === 'emp'); return carregar(); }
    if (d.tm) return termo(emps.find(x => x.id == d.tm));
    if (d.dv) { const em = modo === 'emp' ? emps.find(x => x.id == d.dv) : (await api('/patrimonio/emprestimos?situacao=aberto')).find(x => x.id == d.dv); return em && devolver(em); }
    if (d.hi) { const bem = lista.find(x => x.id == d.hi), h = await api('/patrimonio/emprestimos?patrimonio_id=' + d.hi);
      return modal({ titulo: `Histórico de empréstimos — ${nPat(bem.numero)} ${bem.descricao}`, tam: 'md', corpo: tabela([{ l: 'Quem levou', f: x => esc(x.pessoa_nome) }, { l: 'Saída', f: x => dia(x.saida_em) + (x.estado_saida ? `<br><small class="muted">${esc(x.estado_saida)}</small>` : '') }, { l: 'Devolução', f: x => (x.devolvido_em ? dia(x.devolvido_em) + (x.estado_devolucao ? `<br><small class="muted">${esc(x.estado_devolucao)}</small>` : '') : empChip(x)) }, { l: '', f: x => `<button class="btn sm" data-tm2="${x.id}">Termo</button>` }], h, { vazio: 'Este bem nunca foi emprestado.' }), botoes: [{ txt: 'Fechar', cls: 'primary' }], aoAbrir: bd => { bd.onclick = ev => { const id = ev.target.dataset && ev.target.dataset.tm2; if (id) termo(h.find(x => x.id == id)); }; } }); }
    if (d.em) return emprestar(lista.find(x => x.id == d.em));
    if (d.ne) return emprestar(null);
    const b = lista.find(x => x.id == (d.et || d.ed || d.bx || d.re)); if (!b) return;
    if (d.et) return etiqueta([b]);
    if (d.ed) return formModal({ titulo: `Editar patrimônio nº ${nPat(b.numero)}`, tam: 'md', valores: b, campos: camposBem, onSave: async o => { await api('/patrimonio/' + b.id, { method: 'PUT', body: o }); toast('Salvo.'); carregar(); } });
    if (d.bx) return formModal({ titulo: `Baixar patrimônio nº ${nPat(b.numero)} — ${b.descricao}`, valores: { data: hojeISO() },
      campos: [{ k: 'data', l: 'Data da baixa', t: 'date', req: true }, { k: 'motivo', l: 'Motivo (venda, perda, quebra, descarte, devolução...)', req: true, full: true }],
      onSave: async o => { await api(`/patrimonio/${b.id}/baixar`, { method: 'POST', body: o }); toast('Baixa registrada.'); carregar(); } });
    if (d.re) { await api(`/patrimonio/${b.id}/reativar`, { method: 'POST' }); toast('Bem reativado.'); carregar(); }
  });
  await carregar();
} });

// ---- Consignações: mercadoria que entra no estoque sem pagar; devolve-se o que não foi usado e o acerto gera o contas a pagar
registrar({ id: 'consignacoes', titulo: 'Consignações', grupo: 'Estoque', perm: 'estoque.ver', render: async el => {
  const gerir = tem('estoque.entrada');
  let status = 'aberta', lista = [];
  const pendentes = card => $$('[data-dv]', card).map(i => ({ item_id: +i.dataset.dv, qtd: numIn(i.value) })).filter(d => d.qtd > 0);
  const aPagar = (c, pend) => c.itens.reduce((s, i) => s + (Number(i.quantidade) - Number(i.qtd_devolvida) - (pend.find(d => d.item_id === i.id)?.qtd || 0)) * Number(i.custo_unit), 0);
  const desenhar = () => {
    $('#res', el).innerHTML = lista.length ? lista.map(c => `<div class="card" data-c="${c.id}"><div class="bar" style="margin:0 0 8px"><b>Consignação #${c.id}</b> · ${esc(c.fornecedor || 'sem fornecedor')}${c.numero ? ' · doc. ' + (c.serie ? 'série ' + esc(c.serie) + ' nº ' : '') + esc(c.numero) : ''} · recebida em ${dt(c.criado_em)}
      ${c.consig_status === 'acertada' ? chip('Acertada', 'ok') + ` <span class="muted">NF ${esc(c.acerto_nf)} · ${dt(c.acerto_em)} · pago ${R(c.acerto_total)}</span>` : chip('Em aberto', 'warn')}</div>
      ${tabela([{ l: 'Produto', k: 'produto' }, { l: 'Recebido', n: 1, f: i => N(i.quantidade) + ' ' + i.unidade }, { l: 'Devolvido', n: 1, f: i => N(i.qtd_devolvida) }, { l: 'Fica com a casa', n: 1, f: i => `<b>${N(Number(i.quantidade) - Number(i.qtd_devolvida))}</b>` },
        { l: 'Custo un.', n: 1, f: i => R(i.custo_unit) }, { l: 'Estoque atual', n: 1, f: i => N(i.estoque_atual) },
        ...(c.consig_status === 'aberta' && gerir ? [{ l: 'Devolver agora', n: 1, f: i => `<input data-dv="${i.id}" inputmode="decimal" style="width:90px" placeholder="0">` }] : [])], c.itens)}
      ${c.consig_status === 'aberta' && gerir ? `<div class="bar" style="margin-top:8px"><span class="muted">A pagar no acerto: <b data-ap>${R(aPagar(c, []))}</b></span><div class="grow"></div><button class="btn" data-dev="${c.id}">Registrar devolução (sem acertar)</button><button class="btn primary" data-ace="${c.id}">Acertar com a nota final</button></div>` : ''}</div>`).join('')
      : `<div class="card muted">${status === 'aberta' ? 'Nenhuma consignação em aberto. Na Entrada de mercadoria marque "Nota consignada".' : 'Nenhuma consignação acertada.'}</div>`;
  };
  const carregar = seguro(async () => { lista = await api('/estoque/consignacoes?status=' + status); desenhar(); });
  el.innerHTML = `<div class="tabs"><button data-st="aberta" class="on">Em aberto</button><button data-st="acertada">Acertadas</button></div>
    <p class="muted">Mercadoria consignada entra no estoque sem gerar conta a pagar. Registre as devoluções do que não foi usado; no fim, o <b>acerto</b> usa a nota final do fornecedor e gera as parcelas a pagar só do que ficou (recebido − devolvido). O que ficar sobrando no estoque passa a ser da casa.</p><div id="res"></div>`;
  el.oninput = e => { if (!e.target.matches('[data-dv]')) return; const card = e.target.closest('[data-c]'), c = lista.find(x => x.id == card.dataset.c); $('[data-ap]', card).textContent = R(aPagar(c, pendentes(card))); };
  el.onclick = seguro(async e => {
    const d = e.target.dataset;
    if (d.st) { status = d.st; $$('[data-st]', el).forEach(b => b.classList.toggle('on', b === e.target)); return carregar(); }
    const id = d.dev || d.ace; if (!id) return;
    const card = e.target.closest('[data-c]'), c = lista.find(x => x.id == id), pend = pendentes(card);
    if (d.dev) { if (!pend.length) throw new Error('Informe a quantidade devolvida de ao menos um item.'); await api(`/estoque/consignacoes/${id}/devolver`, { method: 'POST', body: { devolucoes: pend } }); toast('Devolução registrada (saiu do estoque).'); return carregar(); }
    const total = Math.round(aPagar(c, pend) * 100) / 100;
    formModal({ titulo: `Acertar consignação #${c.id} — ${c.fornecedor || ''}`, tam: 'md',
      extra: `<p>Devolvendo agora: <b>${pend.length}</b> item(ns). Valor a pagar ao fornecedor: <b>${R(total)}</b>.</p><p class="muted">Depois de salvar você escolhe vencimentos e parcelas. Esta nota final <b>não</b> deve ser importada de novo pelo XML (o sistema bloqueia se a chave for informada aqui).</p>`,
      campos: [{ k: 'serie', l: 'Série da nota final' }, { k: 'numero', l: 'Nº da nota final do fornecedor', req: true }, { k: 'chave', l: 'Chave de acesso da nota (44 dígitos, opcional)', full: true }],
      onSave: async o => {
        const dsp = total > 0 ? await lancarDespesa({ total, fornecedor: c.fornecedor || '' }) : { titulos: [] };
        if (!dsp) return false;
        const r = await api(`/estoque/consignacoes/${id}/acerto`, { method: 'POST', body: { ...o, devolucoes: pend, titulos: dsp.titulos, categoria_despesa: dsp.categoria } });
        toast(`Consignação acertada: ${R(r.total)}${r.titulos ? ', ' + r.titulos + ' conta(s) a pagar' : ''}.`); carregar();
      } });
  });
  await carregar();
} });
