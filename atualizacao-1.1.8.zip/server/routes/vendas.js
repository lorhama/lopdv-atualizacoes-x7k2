// Vendas diretas: itens, envio para cozinha/bar (ao receber), controle de retirada, pagamento.
const express = require('express');
const db = require('../db');
const { auth, can, verificarAutorizacao, auditar } = require('../auth');
const { HttpError, wrap, num, r2, hoje } = require('../util');
const est = require('../estoque_lib');
const prn = require('../printer');
const r = express.Router();

const tef = require('../tef');

async function pedidoCompleto(id) {
  const p = (await db.q(`select p.*, u.nome usuario, coalesce(vd.nome,u.nome) vendedor, coalesce(vd.codigo,u.codigo) vendedor_codigo, c.nome cliente, v.numero venda_numero, cx.numero caixa_numero
    from pedidos p left join usuarios u on u.id=p.usuario_id left join usuarios vd on vd.id=p.vendedor_id left join clientes c on c.id=p.cliente_id
    left join vendas v on v.pedido_id=p.id left join caixas cx on cx.id=coalesce(p.caixa_id, v.caixa_id, (select id from caixas where usuario_id=p.usuario_id and status='aberto' order by id desc limit 1)) where p.id=$1`, [id])).rows[0];
  if (!p) throw new HttpError(404, 'Venda não encontrada.');
  const run = (s, a) => db.q(s, a);
  p.itens = (await run(`select i.*, u.nome usuario, rp.nome retirado_por_nome from pedido_itens i
    left join usuarios u on u.id=i.usuario_id left join usuarios rp on rp.id=i.retirado_por where i.pedido_id=$1 order by i.id`, [id])).rows;
  p.pagamentos = (await run('select * from pagamentos where pedido_id=$1 order by id', [id])).rows;
  p.subtotal = r2(p.itens.filter(i => i.status !== 'cancelado').reduce((s, i) => s + Number(i.quantidade) * Number(i.preco_unit), 0));
  if (p.status === 'aberto') p.total = r2(p.subtotal - Number(p.desconto || 0));
  return p;
}

// O que sai do estoque por um item vendido (o próprio produto ou, se preparado, os insumos da ficha técnica)
async function linhasDoItem(c, prod, qtd) {
  const linhas = []; let custo = 0;
  if (prod.tipo === 'preparado' && prod.controla_estoque) {
    // preparado com estoque próprio (ex.: pipoca feita antes na Produção): a venda baixa só o produto, não os insumos
    const pp = (await c.query('select * from produtos where id=$1 for update', [prod.id])).rows[0];
    custo = Number(pp.custo_medio); linhas.push({ p: pp, q: qtd });
  } else if (prod.tipo === 'preparado') {
    const rec = await c.query(`select p.*, r.quantidade rq from receitas r join produtos p on p.id=r.insumo_id
      where r.produto_id=$1 order by p.id for update of p`, [prod.id]);
    for (const i of rec.rows) { custo += Number(i.rq) * Number(i.custo_medio); if (i.controla_estoque) linhas.push({ p: i, q: Number(i.rq) * qtd }); }
  } else {
    const pp = (await c.query('select * from produtos where id=$1 for update', [prod.id])).rows[0];
    custo = Number(pp.custo_medio);
    if (pp.controla_estoque) linhas.push({ p: pp, q: qtd });
  }
  return { linhas, custo };
}

// Baixa o estoque da venda SOMENTE quando ela foi finalizada (paga) e todos os itens foram entregues (retirados) na cozinha/bar.
async function baixarEstoqueVenda(pedidoId, userId) {
  return db.tx(async c => {
    const ped = (await c.query('select * from pedidos where id=$1 for update', [pedidoId])).rows[0];
    if (!ped || ped.status !== 'fechado' || ped.estoque_baixado_em) return false;
    const itens = (await c.query("select * from pedido_itens where pedido_id=$1 and status<>'cancelado' order by id", [ped.id])).rows;
    if (!itens.length || itens.some(i => i.status !== 'retirado')) return false;
    for (const it of itens) {
      if ((await c.query("select 1 from mov_estoque where origem='pedido_item' and ref_id=$1 and tipo='venda'", [it.id])).rowCount) continue; // já baixado (vendas antigas)
      const prod = (await c.query('select * from produtos where id=$1', [it.produto_id])).rows[0];
      if (!prod) continue;
      const { linhas } = await linhasDoItem(c, prod, Number(it.quantidade));
      for (const l of linhas)
        await est.mover(c, { produto_id: l.p.id, tipo: 'venda', quantidade: -l.q, custo_unit: l.p.custo_medio, origem: 'pedido_item', ref_id: it.id, motivo: `Venda #${ped.id}`, usuario_id: userId });
    }
    await c.query('update pedidos set estoque_baixado_em=now() where id=$1', [ped.id]);
    return true;
  });
}

// Devolve ao estoque tudo que foi baixado por um item (inclusive insumos da ficha técnica)
async function devolverEstoque(c, itemId, userId, motivo) {
  const m = await c.query("select * from mov_estoque where origem='pedido_item' and ref_id=$1 and tipo='venda'", [itemId]);
  for (const x of m.rows)
    await est.mover(c, { produto_id: x.produto_id, tipo: 'estorno', quantidade: -Number(x.quantidade), custo_unit: x.custo_unit, origem: 'pedido_item', ref_id: itemId, motivo, usuario_id: userId });
}

// ---- Lista de vendas
r.get('/pedidos', auth('vendas.acessar'), wrap(async (req, res) => {
  const status = ['aberto', 'fechado', 'cancelado'].includes(req.query.status) ? req.query.status : 'aberto';
  const x = await db.q(`select p.*, v.numero venda_numero, u.nome usuario, coalesce(s.sub,0) subtotal, coalesce(s.n,0) itens, coalesce(s.novos,0) novos, coalesce(s.pend,0) pendentes
    from pedidos p left join usuarios u on u.id=p.usuario_id left join vendas v on v.pedido_id=p.id
    left join lateral (select sum(quantidade*preco_unit) sub, count(*)::int n,
      count(*) filter (where status='novo')::int novos, count(*) filter (where status='enviado')::int pend
      from pedido_itens where pedido_id=p.id and status<>'cancelado') s on true
    where p.status=$1 order by p.id desc limit 200`, [status]);
  res.json(x.rows);
}));

async function exigirCaixa(user) {
  if (!(await db.q("select 1 from caixas where usuario_id=$1 and status='aberto'", [user.id])).rowCount)
    throw new HttpError(400, 'Você precisa ter um caixa aberto para vender. Abra o caixa no menu Caixa.', { sem_caixa: true });
}

// Venda direta: abre uma nova venda (sem mesa/identificação). Se o usuário já tem uma venda aberta e vazia, reaproveita.
const exigeEmpresa = require('../exige_empresa');
r.post('/pedidos', auth('vendas.acessar'), wrap(async (req, res) => {
  await exigeEmpresa();
  await exigirCaixa(req.user);
  const vazia = await db.q(`select id from pedidos p where status='aberto' and usuario_id=$1 and not exists (select 1 from pedido_itens i where i.pedido_id=p.id and i.status<>'cancelado') order by id limit 1`, [req.user.id]);
  // empresa do terminal (cabeçalho X-Empresa-Id, definido no instalador do atalho); se não houver/for inválida, a empresa em uso
  const eid = +req.get('x-empresa-id') || 0;
  const emp = (eid ? (await db.q('select id from empresas where id=$1 and ativo', [eid])).rows[0] : null) || (await db.q('select id from empresas where em_uso limit 1')).rows[0];
  if (vazia.rowCount) { await db.q('update pedidos set empresa_id=$2 where id=$1', [vazia.rows[0].id, emp ? emp.id : null]); return res.json(await pedidoCompleto(vazia.rows[0].id)); }
  const x = await db.q("insert into pedidos(tipo,usuario_id,empresa_id) values('balcao',$1,$2) returning id", [req.user.id, emp ? emp.id : null]);
  res.json(await pedidoCompleto(x.rows[0].id));
}));

// Troca o cliente da venda em andamento
r.put('/pedidos/:id/cliente', auth('vendas.acessar'), wrap(async (req, res) => {
  const ped = (await db.q('select status from pedidos where id=$1', [req.params.id])).rows[0];
  if (!ped) throw new HttpError(404, 'Venda não encontrada.');
  if (ped.status !== 'aberto') throw new HttpError(400, 'Só é possível trocar o cliente de uma venda aberta.');
  const cid = req.body?.cliente_id ? Number(req.body.cliente_id) : null;
  if (cid && !(await db.q('select 1 from clientes where id=$1', [cid])).rowCount) throw new HttpError(400, 'Cliente não encontrado.');
  await db.q('update pedidos set cliente_id=$1 where id=$2', [cid, req.params.id]);
  res.json(await pedidoCompleto(req.params.id));
}));

r.get('/pedidos/:id', auth('vendas.acessar'), wrap(async (req, res) => res.json(await pedidoCompleto(req.params.id))));

// ---- Lançar item (confere o estoque e bloqueia estoque negativo; a baixa é feita só após a entrega de tudo)
r.post('/pedidos/:id/itens', auth('vendas.acessar'), wrap(async (req, res) => {
  await exigirCaixa(req.user);
  const b = req.body || {};
  const qtd = num(b.quantidade, 1);
  if (qtd <= 0) throw new HttpError(400, 'Quantidade inválida.');
  await db.tx(async c => {
    const ped = (await c.query('select * from pedidos where id=$1 for update', [req.params.id])).rows[0];
    if (!ped) throw new HttpError(404, 'Venda não encontrada.');
    if (ped.status !== 'aberto') throw new HttpError(400, 'Esta venda não está aberta.');
    const prod = (await c.query('select * from produtos where id=$1', [b.produto_id])).rows[0];
    if (!prod || !prod.ativo || !prod.vendavel) throw new HttpError(400, 'Produto indisponível para venda.');

    // o que vai sair do estoque (a baixa só acontece depois que a venda for paga e todos os itens entregues)
    const { linhas, custo } = await linhasDoItem(c, prod, qtd);
    // como a baixa só ocorre na entrega, desconta do saldo o que já está vendido/lançado e ainda não baixado
    for (const l of linhas) {
      const rs = (await c.query(`select coalesce(sum(x.q),0) q from (
          select i.quantidade q from pedido_itens i join pedidos pd on pd.id=i.pedido_id
            where i.produto_id=$1 and i.status<>'cancelado' and pd.estoque_baixado_em is null and pd.status in ('aberto','fechado')
              and not exists (select 1 from mov_estoque m where m.origem='pedido_item' and m.ref_id=i.id and m.tipo='venda')
          union all
          select i.quantidade*r.quantidade from pedido_itens i join pedidos pd on pd.id=i.pedido_id join receitas r on r.produto_id=i.produto_id join produtos pr on pr.id=i.produto_id
            where pr.controla_estoque=false and r.insumo_id=$1 and i.status<>'cancelado' and pd.estoque_baixado_em is null and pd.status in ('aberto','fechado')
              and not exists (select 1 from mov_estoque m where m.origem='pedido_item' and m.ref_id=i.id and m.tipo='venda')) x`, [l.p.id])).rows[0].q;
      l.reservado = Number(rs); l.disp = Number(l.p.estoque_atual) - l.reservado;
    }
    const faltas = linhas.filter(l => l.disp - l.q < -0.0005)
      .map(l => ({ produto: l.p.nome, unidade: l.p.unidade, atual: l.disp, necessario: l.q }));

    let autorizado = null;
    if (faltas.length) {
      const neg = (await c.query("select valor from config where chave='estoque_negativo'")).rows[0]?.valor;
      if (neg === 'nao') throw new HttpError(400, 'Estoque insuficiente (o sistema não permite vender com estoque negativo): ' + faltas.map(f => `${f.produto}: disponível ${Number(f.atual).toLocaleString('pt-BR')} ${f.unidade}, necessário ${Number(f.necessario).toLocaleString('pt-BR')}`).join('; ') + '.');
      if (!b.autorizacao) throw new HttpError(409, 'Estoque insuficiente: a venda deixaria o estoque negativo.', { codigo: 'ESTOQUE_NEGATIVO', faltas });
      autorizado = await verificarAutorizacao(c, b.autorizacao, 'vendas.estoque_negativo');
      await auditar(c, { id: autorizado.id, nome: autorizado.nome }, 'venda_estoque_negativo', { pedido: ped.id, produto: prod.nome, quantidade: qtd, faltas, lancado_por: req.user.nome });
    }

    const it = await c.query(`insert into pedido_itens(pedido_id,produto_id,nome,quantidade,preco_unit,custo_unit,destino,observacao,usuario_id,autorizado_por)
      values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) returning id`,
      [ped.id, prod.id, prod.nome, qtd, prod.preco_venda, custo, prod.destino, b.observacao || null, req.user.id, autorizado?.id || null]);

  });
  res.json(await pedidoCompleto(req.params.id));
}));

// ---- Cancelar item
r.delete('/pedidos/:id/itens/:itemId', auth('vendas.acessar'), wrap(async (req, res) => {
  const motivo = (req.body || {}).motivo || null;
  let aviso = null;
  await db.tx(async c => {
    const ped = (await c.query('select * from pedidos where id=$1 for update', [req.params.id])).rows[0];
    if (!ped || ped.status !== 'aberto') throw new HttpError(400, 'Venda não está aberta.');
    const it = (await c.query('select * from pedido_itens where id=$1 and pedido_id=$2 for update', [req.params.itemId, ped.id])).rows[0];
    if (!it || it.status === 'cancelado') throw new HttpError(404, 'Item não encontrado.');
    if (it.status !== 'novo') {
      if (!can(req.user, 'vendas.cancelar')) throw new HttpError(403, 'Item já enviado: apenas quem tem permissão de cancelamento pode cancelar.');
      if (!motivo) throw new HttpError(400, 'Informe o motivo do cancelamento.');
    }
    await devolverEstoque(c, it.id, req.user.id, 'Cancelamento item venda #' + ped.id);
    await c.query(`update pedido_itens set status='cancelado', cancelado_em=now(), cancelado_por=$1, motivo_cancelamento=$2 where id=$3`, [req.user.id, motivo, it.id]);
    if (it.status !== 'novo') { await auditar(c, req.user, 'item_cancelado', { pedido: ped.id, item: it.nome, status: it.status, motivo }); if (it.impresso_em) aviso = { ped, it }; }
  });
  if (aviso && aviso.it.destino !== 'nenhum') { // avisa a cozinha/bar do cancelamento
    prn.imprimirDestino(db, aviso.it.destino, { pedido: aviso.ped, usuario: req.user.nome, itens: [aviso.it], cancelado: true }).catch(() => { });
  }
  res.json(await pedidoCompleto(req.params.id));
}));

// ---- Enviar itens novos para cozinha/bar (libera na tela de produção; imprime só ao receber)
r.post('/pedidos/:id/enviar', auth('vendas.acessar'), wrap(async (req, res) => {
  const { ped, itens } = await db.tx(async c => {
    const ped = (await c.query('select * from pedidos where id=$1 for update', [req.params.id])).rows[0];
    if (!ped || ped.status !== 'aberto') throw new HttpError(400, 'Venda não está aberta.');
    const novos = (await c.query("select * from pedido_itens where pedido_id=$1 and status='novo' order by id", [ped.id])).rows;
    if (!novos.length) throw new HttpError(400, 'Não há itens novos para enviar.');
    await c.query(`update pedido_itens set status = case when destino='nenhum' then 'retirado' else 'enviado' end,
      enviado_em=now(), retirado_em = case when destino='nenhum' then now() end where pedido_id=$1 and status='novo'`, [ped.id]);
    return { ped, itens: novos };
  });
  // o pedido NÃO é impresso aqui: a impressão sai somente ao receber o pagamento
  const impressao = [];
  res.json({ pedido: await pedidoCompleto(ped.id), impressao });
}));

r.post('/pedidos/:id/reimprimir', auth('vendas.reimprimir'), wrap(async (req, res) => {
  const ped = (await db.q('select p.*, v.numero venda_numero from pedidos p left join vendas v on v.pedido_id=p.id where p.id=$1', [req.params.id])).rows[0];
  if (!ped) throw new HttpError(404, 'Venda não encontrada.');
  const dest = req.body?.destino;
  const itens = (await db.q("select * from pedido_itens where pedido_id=$1 and status in ('enviado','retirado') and destino = any($2) order by id",
    [ped.id, dest ? [dest] : ['cozinha', 'bar']])).rows;
  const impressao = [];
  for (const d of ['cozinha', 'bar']) {
    const lote = itens.filter(i => i.destino === d);
    if (lote.length) impressao.push(await prn.imprimirDestino(db, d, { pedido: ped, usuario: req.user.nome, itens: lote, reimpressao: true }));
  }
  await auditar(null, req.user, 'reimpressao', { pedido: ped.id, destino: dest || 'todos' });
  res.json({ impressao });
}));

// ---- Painel de produção (cozinha/bar) e controle de retirada
r.get('/producao', auth('producao.acessar'), wrap(async (req, res) => {
  const dest = ['cozinha', 'bar'].includes(req.query.destino) ? [req.query.destino] : ['cozinha', 'bar'];
  const base = `select i.id, i.pedido_id, i.nome, i.quantidade, i.observacao, i.destino, i.status, i.enviado_em, i.retirado_em,
    v.numero venda_numero, ua.nome atendente, ur.nome retirado_por_nome
    from pedido_itens i join pedidos p on p.id=i.pedido_id left join vendas v on v.pedido_id=p.id left join usuarios ua on ua.id=i.usuario_id left join usuarios ur on ur.id=i.retirado_por`;
  const pendentes = (await db.q(`${base} where i.status='enviado' and i.destino = any($1) order by i.enviado_em`, [dest])).rows;
  const retirados = (await db.q(`${base} where i.status='retirado' and i.destino = any($1) and i.retirado_em >= current_date and i.enviado_em is not null
    and i.destino<>'nenhum' order by i.retirado_em desc limit 150`, [dest])).rows;
  res.json({ pendentes, retirados });
}));

r.post('/producao/retirar', auth('producao.retirar'), wrap(async (req, res) => {
  const ids = (req.body?.ids || []).map(Number).filter(Boolean);
  if (!ids.length) throw new HttpError(400, 'Nenhum item selecionado.');
  const x = await db.q(`update pedido_itens set status='retirado', retirado_em=now(), retirado_por=$1
    where id = any($2) and status='enviado' returning id, pedido_id`, [req.user.id, ids]);
  // se com isso todos os itens da venda foram entregues (cozinha e bar), baixa o estoque
  const baixadas = [];
  for (const pid of [...new Set(x.rows.map(i => i.pedido_id))]) if (await baixarEstoqueVenda(pid, req.user.id)) baixadas.push(pid);
  res.json({ retirados: x.rowCount, estoque_baixado_vendas: baixadas });
}));

// ---- Pagamento / fechamento
// Doação do troco: depois de recebida a venda em dinheiro, o cliente pode deixar as moedinhas (ou o troco) para um dos destinos cadastrados nas configurações.
// Vendedor da venda: o operador informa o NÚMERO (código) do vendedor; por padrão é quem abriu a venda
r.put('/pedidos/:id/vendedor', auth('vendas.receber'), wrap(async (req, res) => {
  const p = (await db.q('select id, status from pedidos where id=$1', [req.params.id])).rows[0];
  if (!p) throw new HttpError(404, 'Venda não encontrada.');
  if (p.status !== 'aberto') throw new HttpError(400, 'Só é possível trocar o vendedor de uma venda em andamento.');
  const cod = Number(String(req.body?.codigo || '').replace(/\D/g, ''));
  const u = cod ? (await db.q('select id, nome, codigo from usuarios where codigo=$1 and ativo', [cod])).rows[0] : null;
  if (!u) throw new HttpError(400, 'Vendedor não encontrado ou inativo. Confira o número do usuário.');
  await db.q('update pedidos set vendedor_id=$1 where id=$2', [u.id, p.id]);
  await auditar(null, req.user, 'venda_vendedor', { pedido: p.id, vendedor: u.nome, codigo: u.codigo });
  res.json(await pedidoCompleto(p.id));
}));

r.post('/pedidos/:id/doacao', auth('vendas.receber'), wrap(async (req, res) => {
  const cfg = {}; (await db.q("select chave, valor from config where chave in ('doacao_ativa','doacao_destinos')")).rows.forEach(x => { cfg[x.chave] = x.valor; });
  const destinos = String(cfg.doacao_destinos || '').split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  if (cfg.doacao_ativa !== '1' || !destinos.length) throw new HttpError(400, 'Doações não estão ativas nas configurações.');
  const destino = String(req.body?.destino || '').trim(), valor = r2(Number(String(req.body?.valor).replace(',', '.')));
  if (!destinos.includes(destino)) throw new HttpError(400, 'Local de doação inválido.');
  if (!(valor > 0) || valor > 500) throw new HttpError(400, 'Valor da doação inválido.');
  const p = (await db.q("select id, caixa_id, status from pedidos where id=$1", [req.params.id])).rows[0];
  if (!p || p.status !== 'fechado' || !p.caixa_id) throw new HttpError(400, 'A doação só vale para uma venda já finalizada.');
  if ((await db.q('select 1 from doacoes where pedido_id=$1', [p.id])).rowCount) throw new HttpError(400, 'Esta venda já tem uma doação registrada.');
  await db.q('insert into doacoes(pedido_id,caixa_id,destino,valor,usuario_id) values($1,$2,$3,$4,$5)', [p.id, p.caixa_id, destino, valor, req.user.id]);
  await auditar(null, req.user, 'doacao', { pedido: p.id, destino, valor });
  res.json({ ok: true });
}));

r.post('/pedidos/:id/pagar', auth('vendas.receber'), wrap(async (req, res) => {
  const b = req.body || {};
  const formas = new Map((await db.q('select codigo, descricao, tipo, tef_ativo, tef_vias, max_parcelas from formas_pagamento where ativo')).rows.map(f => [f.codigo, f]));
  const refs = (b.pagamentos || []).map(p => p.tef_ref).filter(Boolean);
  let comprovantes = [];
  try {
  await db.tx(async c => {
    const cx = (await c.query("select id from caixas where usuario_id=$1 and status='aberto' order by id desc limit 1", [req.user.id])).rows[0];
    if (!cx) throw new HttpError(400, 'Abra o seu caixa antes de receber pagamentos.');
    const ped = (await c.query('select * from pedidos where id=$1 for update', [req.params.id])).rows[0];
    if (!ped || ped.status !== 'aberto') throw new HttpError(400, 'Venda não está aberta.');
    const itens = (await c.query("select * from pedido_itens where pedido_id=$1 and status<>'cancelado'", [ped.id])).rows;
    if (!itens.length) throw new HttpError(400, 'Venda sem itens. Cancele-a se não for usada.');
    // venda direta: ao receber, os itens vão para a cozinha/bar (aparecem na tela de produção e imprimem o pedido)
    if (itens.some(i => i.status === 'novo')) await c.query(`update pedido_itens set status = case when destino='nenhum' then 'retirado' else 'enviado' end,
      enviado_em=now(), retirado_em = case when destino='nenhum' then now() end where pedido_id=$1 and status='novo'`, [ped.id]);
    const subtotal = r2(itens.reduce((s, i) => s + Number(i.quantidade) * Number(i.preco_unit), 0));
    const desconto = r2(num(b.desconto));
    if (desconto < 0 || desconto > subtotal) throw new HttpError(400, 'Desconto inválido.');
    if (desconto > 0 && !can(req.user, 'vendas.desconto')) throw new HttpError(403, 'Você não tem permissão para dar desconto.');
    // arredondamento: valor em R$ (+ acrescenta, - reduz); exige permissão (ou usuário/senha de quem tenha) e respeita o limite configurado
    let arred = r2(num(b.arredondamento)), arredPor = null;
    if (arred !== 0) {
      const cfg = {}; (await c.query("select chave, valor from config where chave in ('arred_max_mais','arred_max_menos')")).rows.forEach(x => { cfg[x.chave] = Number(String(x.valor).replace(',', '.')) || 0; });
      const maxMais = cfg.arred_max_mais ?? 1, maxMenos = cfg.arred_max_menos ?? 1;
      if (arred > 0 && arred > maxMais + 0.001) throw new HttpError(400, `Arredondamento para mais acima do limite configurado (máximo R$ ${maxMais.toFixed(2).replace('.', ',')}).`);
      if (arred < 0 && -arred > maxMenos + 0.001) throw new HttpError(400, `Arredondamento para menos acima do limite configurado (máximo R$ ${maxMenos.toFixed(2).replace('.', ',')}).`);
      if (can(req.user, 'vendas.arredondar')) arredPor = req.user.id;
      else arredPor = (await verificarAutorizacao(c, b.autorizacao, 'vendas.arredondar')).id;
      if (subtotal - desconto + arred < 0) throw new HttpError(400, 'Arredondamento maior que o total da venda.');
    }
    const total = r2(subtotal - desconto + arred);
    const pgs = (b.pagamentos || []).map(p => ({ forma: p.forma, valor: r2(num(p.valor)), parcelas: Math.max(1, Math.round(num(p.parcelas) || 1)), tef_ref: p.tef_ref })).filter(p => p.valor > 0);
    if (pgs.some(p => !formas.has(p.forma))) throw new HttpError(400, 'Forma de pagamento inválida ou inativa.');
    const tipoDe = p => formas.get(p.forma).tipo;
    for (const p of pgs) {
      const f = formas.get(p.forma);
      if (f.tef_ativo) { const t = tef.reservar(p.tef_ref, p.forma, p.valor, req.user.id); p.tef = t; }
      else if (p.tef_ref) throw new HttpError(400, 'Forma sem TEF recebeu uma transação TEF.');
      if (p.parcelas > (f.max_parcelas || 1)) p.parcelas = f.max_parcelas || 1;
    }
    const soma = r2(pgs.reduce((s, p) => s + p.valor, 0));
    if (soma + 0.001 < total) throw new HttpError(400, `Pagamento insuficiente: faltam ${r2(total - soma).toFixed(2)}.`);
    const troco = r2(soma - total);
    const dinheiro = r2(pgs.filter(p => tipoDe(p) === 'dinheiro').reduce((s, p) => s + p.valor, 0));
    if (troco > 0.001 && troco > dinheiro + 0.001) throw new HttpError(400, 'Valor pago excede o total; só é possível dar troco em dinheiro.');
    if (troco > 0.001 && pgs.some(p => p.tef)) { /* troco só sai do dinheiro; cartão TEF sempre no valor exato */ }
    let clienteId = b.cliente_id || ped.cliente_id || null;
    const fiado = r2(pgs.filter(p => tipoDe(p) === 'fiado').reduce((s, p) => s + p.valor, 0));
    if (fiado > 0 && !clienteId) throw new HttpError(400, 'Venda fiado só pode ser feita com um cliente cadastrado. Selecione ou cadastre o cliente.');
    if (fiado > 0 && !(await c.query('select 1 from clientes where id=$1 and ativo', [clienteId])).rowCount) throw new HttpError(400, 'Cliente não encontrado ou inativo.');
    let trocoRest = troco;
    for (const p of pgs) {
      let v = p.valor;
      if (tipoDe(p) === 'dinheiro' && trocoRest > 0) { const d = Math.min(v, trocoRest); v = r2(v - d); trocoRest = r2(trocoRest - d); }
      if (v > 0) await c.query('insert into pagamentos(pedido_id,caixa_id,forma,valor,parcelas,tef_nsu,tef_autorizacao,tef_rede) values($1,$2,$3,$4,$5,$6,$7,$8)',
        [ped.id, cx.id, p.forma, v, p.parcelas > 1 ? p.parcelas : null, p.tef?.nsu || null, p.tef?.autorizacao || null, p.tef?.rede || null]);
      if (p.tef) comprovantes.push({ vias: formas.get(p.forma).tef_vias || 1, linhas: p.tef.comprovante, forma: formas.get(p.forma).descricao });
    }
    if (fiado > 0) {
      const venc = b.vencimento_fiado || new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10);
      await c.query(`insert into titulos(tipo,descricao,categoria,cliente_id,pedido_id,valor,vencimento) values('receber',$1,'Venda fiado',$2,$3,$4,$5)`,
        [`Fiado venda #${ped.id}`, clienteId, ped.id, fiado, venc]);
    }
    await c.query("update pedidos set status='fechado', total=$1, desconto=$2, caixa_id=$3, cliente_id=$4, fechado_em=now(), arredondamento=$6, arredondamento_por=$7 where id=$5", [total, desconto, cx.id, clienteId, ped.id, arred, arredPor]);
    if (arred !== 0) await auditar(c, req.user, 'arredondamento', { pedido: ped.id, valor: arred, autorizado_por: arredPor, subtotal, total });
    if (desconto > 0) await auditar(c, req.user, 'desconto', { pedido: ped.id, desconto, subtotal });
    if (b.observacao && String(b.observacao).trim()) await c.query('update pedidos set observacao=$1 where id=$2', [String(b.observacao).trim().slice(0, 500), ped.id]);
    res.locals.troco = troco;
  });
  } catch (e) { for (const ref of refs) await tef.finalizar(ref, false); throw e; }
  // venda gravada: confirma as transações TEF e imprime os comprovantes
  for (const ref of refs) await tef.finalizar(ref, true);
  const imp = [];
  for (const cp of comprovantes) {
    if (!cp.linhas.length) continue;
    for (let i = 0; i < cp.vias; i++) imp.push(await prn.imprimirTexto(db, 'caixa', '', cp.linhas.join('\n') + (cp.vias > 1 ? `\n\n(via ${i + 1}/${cp.vias})` : '')));
  }
  // itens sem cozinha/bar (entregues na hora): se a venda já está toda entregue, baixa o estoque
  try { await baixarEstoqueVenda(Number(req.params.id), req.user.id); } catch (e) { console.error('baixa de estoque:', e.message); }
  // pagamento recebido: agora sim imprime os pedidos da cozinha e do bar (itens ainda não impressos)
  const impressoes = [];
  try {
    const ped = (await db.q('select p.*, v.numero venda_numero from pedidos p left join vendas v on v.pedido_id=p.id where p.id=$1', [req.params.id])).rows[0];
    const its = (await db.q("select * from pedido_itens where pedido_id=$1 and status in ('enviado','retirado') and impresso_em is null and destino in ('cozinha','bar') order by id", [ped.id])).rows;
    for (const dest of ['cozinha', 'bar']) {
      const lote = its.filter(i => i.destino === dest);
      if (!lote.length) continue;
      const rs = await prn.imprimirDestino(db, dest, { pedido: ped, usuario: req.user.nome, itens: lote });
      impressoes.push(rs);
      if (rs && rs.ok) await db.q('update pedido_itens set impresso_em=now() where id = any($1)', [lote.map(i => i.id)]);
    }
  } catch (e) { impressoes.push({ ok: false, destino: 'pedido', erro: e.message }); }
  const p = await pedidoCompleto(req.params.id);
  res.json({ pedido: p, impressoes, troco: res.locals.troco, comprovantes: comprovantes.map(c => ({ forma: c.forma, linhas: c.linhas })), impressao: imp });
}));

// ---- Conta para conferência (imprime no caixa)
r.post('/pedidos/:id/conta', auth('vendas.acessar'), wrap(async (req, res) => {
  const p = await pedidoCompleto(req.params.id);
  const L = [`Venda: ${String(p.venda_numero || p.id).padStart(6, '0')}`, prn.linha(42)];
  p.itens.filter(i => i.status !== 'cancelado').forEach(i => {
    const t = (Number(i.quantidade) * Number(i.preco_unit)).toFixed(2);
    L.push(`${Number(i.quantidade)}x ${i.nome}`.slice(0, 32).padEnd(32) + t.padStart(10));
  });
  L.push(prn.linha(42), 'TOTAL'.padEnd(32) + p.subtotal.toFixed(2).padStart(10), '', 'Conferencia - nao e documento fiscal');
  res.json(await prn.imprimirTexto(db, 'caixa', 'CONTA', L.join('\n')));
}));

// ---- Cancelar a venda inteira
r.post('/pedidos/:id/cancelar', auth('vendas.acessar'), wrap(async (req, res) => {
  const motivo = (req.body || {}).motivo || null;
  await db.tx(async c => {
    const ped = (await c.query('select * from pedidos where id=$1 for update', [req.params.id])).rows[0];
    if (!ped || ped.status !== 'aberto') throw new HttpError(400, 'Venda não está aberta.');
    if ((req.body || {}).pendente) {   // exclusão de venda pendente: pede usuário e senha (do próprio operador ou de quem pode cancelar)
      const aut = req.body.autorizacao;
      const meu = aut && aut.login && String(aut.login).toLowerCase() === String(req.user.login || '').toLowerCase();
      if (meu) { const u = (await c.query('select senha_hash from usuarios where id=$1', [req.user.id])).rows[0]; if (!u || !require('./../auth').bcrypt.compareSync(String(aut.senha || ''), u.senha_hash)) throw new HttpError(403, 'Usuário ou senha inválidos.', { codigo: 'AUTORIZACAO_INVALIDA' }); }
      else await verificarAutorizacao(c, aut, 'vendas.cancelar');
    }
    const itens = (await c.query("select * from pedido_itens where pedido_id=$1 and status<>'cancelado' for update", [ped.id])).rows;
    if (itens.some(i => i.status !== 'novo')) {
      if (!can(req.user, 'vendas.cancelar')) throw new HttpError(403, 'Há itens já enviados: apenas quem tem permissão de cancelamento pode cancelar a venda.');
      if (!motivo) throw new HttpError(400, 'Informe o motivo do cancelamento.');
    }
    for (const i of itens) {
      await devolverEstoque(c, i.id, req.user.id, 'Cancelamento venda #' + ped.id);
      await c.query("update pedido_itens set status='cancelado', cancelado_em=now(), cancelado_por=$1, motivo_cancelamento=$2 where id=$3", [req.user.id, motivo, i.id]);
    }
    await c.query("update pedidos set status='cancelado', motivo_cancelamento=$1, fechado_em=now() where id=$2", [motivo, ped.id]);
    if (itens.length) await auditar(c, req.user, 'venda_cancelada', { pedido: ped.id, itens: itens.length, motivo });
  });
  res.json({ ok: true });
}));

module.exports = r;
