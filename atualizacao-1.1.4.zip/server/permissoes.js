// Catálogo de permissões: controla quem acessa cada tela e cada função dentro dela.
const GRUPOS = [
  { grupo: 'Vendas', itens: [
    ['vendas.acessar', 'Acessar tela de vendas e lançar itens'],
    ['vendas.receber', 'Receber pagamento / finalizar a venda'],
    ['vendas.desconto', 'Dar desconto'],
    ['vendas.arredondar', 'Arredondamento no recebimento (para mais ou para menos, dentro do limite configurado)'],
    ['vendas.cancelar', 'Cancelar item já enviado e cancelar venda'],
    ['vendas.estoque_negativo', 'Autorizar venda com estoque negativo (usuário e senha na tela)'],
    ['vendas.reimprimir', 'Reimprimir pedidos da cozinha/bar']] },
  { grupo: 'Cozinha / Bar', itens: [
    ['producao.acessar', 'Acessar painel de produção'],
    ['producao.retirar', 'Marcar itens como retirados']] },
  { grupo: 'Caixa', itens: [
    ['caixa.acessar', 'Acessar caixa (abrir)'],
    ['caixa.movimentar', 'Sangria e suprimento'],
    ['caixa.fechar', 'Fechar caixa'],
    ['caixa.ver_todos', 'Ver caixas de outros usuários'],
    ['caixa.conferir', 'Tela de conferência de caixas (todos, abertos e fechados) e movimentações'],
    ['caixa.reabrir', 'Reabrir caixa fechado (pede senha)'],
    ['caixa.alterar_forma', 'Alterar forma de pagamento de vendas de um caixa (pede senha)']] },
  { grupo: 'Cadastros', itens: [
    ['cadastros.ver', 'Ver produtos, clientes e fornecedores'],
    ['cadastros.editar', 'Criar e editar cadastros'],
    ['cadastros.excluir', 'Excluir cadastros'],
    ['formas.gerenciar', 'Gerenciar formas de pagamento e integração TEF']] },
  { grupo: 'Estoque', itens: [
    ['estoque.ver', 'Ver posição e movimentação'],
    ['estoque.entrada', 'Dar entrada de mercadoria (XML / manual)'],
    ['estoque.ajuste', 'Ajuste de estoque (avulso): informar a quantidade real de um produto'],
    ['estoque.producao', 'Produção: transformar insumos em produto preparado (ex.: pipoca) com estoque próprio']] },
  { grupo: 'Financeiro', itens: [
    ['financeiro.ver', 'Ver contas a pagar e receber'],
    ['financeiro.editar', 'Lançar e editar títulos'],
    ['financeiro.baixar', 'Dar baixa em títulos']] },
  { grupo: 'Relatórios', itens: [
    ['relatorios.financeiro', 'Relatórios financeiros'],
    ['relatorios.estoque', 'Relatórios de estoque e vendas']] },
  { grupo: 'Administração', itens: [
    ['equipe.gerenciar', 'Gerenciar usuários e perfis'],
    ['config.gerenciar', 'Configurações, impressoras e auditoria']] },
];
const TODAS = GRUPOS.flatMap(g => g.itens.map(i => i[0]));
const PERFIS_PADRAO = {
  'Administrador': ['*'],
  'Gerente': TODAS.filter(p => p !== 'config.gerenciar' && p !== 'equipe.gerenciar').concat(['equipe.gerenciar']),
  'Caixa': ['vendas.acessar', 'vendas.receber', 'vendas.reimprimir', 'caixa.acessar', 'caixa.movimentar', 'caixa.fechar', 'producao.acessar', 'cadastros.ver'],
  'Garçom': ['vendas.acessar', 'producao.acessar', 'cadastros.ver'],
  'Cozinha/Bar': ['producao.acessar', 'producao.retirar'],
  'Estoquista': ['cadastros.ver', 'cadastros.editar', 'estoque.ver', 'estoque.entrada', 'estoque.ajuste', 'estoque.producao', 'relatorios.estoque'],
};
module.exports = { GRUPOS, TODAS, PERFIS_PADRAO };
