
// Lançamento da despesa ao finalizar a entrada: parcelas, vencimento e forma de pagamento de cada uma
async function lancarDespesa({ total, fornecedor, duplicatas, descricao }) {
  const FP = await api('/formas-pagamento?uso=pagar');
  const base = (duplicatas && duplicatas.length ? duplicatas : [{ valor: total, vencimento: new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10) }])
    .map(d => ({ vencimento: String(d.vencimento || '').slice(0, 10), valor: Number(d.valor) || 0, forma: (FP.find(f => f.tipo === 'pix') || FP[0] || {}).codigo, pago: false }));
  return new Promise(res => {
    const corpo = document.createElement('div'); let fin = false;
    const linhas = base.slice();
    const opt = l => FP.map(f => `<option value="${esc(f.codigo)}" ${f.codigo === l.forma ? 'selected' : ''}>${esc(f.descricao)}</option>`).join('');
    const calc = () => { const s = Math.round(linhas.reduce((a, l) => a + (Number(l.valor) || 0), 0) * 100) / 100, dif = Math.round((total - s) * 100) / 100;
      $('#dsp-s', corpo).innerHTML = `Soma das parcelas: <b>${R(s)}</b> · Total da compra: <b>${R(total)}</b> ` + (Math.abs(dif) < 0.011 ? chip('confere', 'ok') : `<span class="erro">diferença de ${R(dif)}</span>`); return Math.abs(dif) < 0.011; };
    const desenhar = () => { $('#dsp-l', corpo).innerHTML = linhas.map((l, i) => `<div class="row tt"><label>Vencimento<input type="date" data-vc value="${esc(l.vencimento)}"></label><label>Valor (R$)<input data-vl value="${esc(String(l.valor).replace('.', ','))}" inputmode="decimal"></label>
      <label>Forma de pagamento<select data-fp>${opt(l)}</select></label><label class="chk" style="align-self:end"><input type="checkbox" data-pg ${l.pago ? 'checked' : ''}> Já pago</label>${linhas.length > 1 ? `<button class="btn sm danger auto" data-x="${i}" type="button">✕</button>` : ''}</div>`).join(''); calc(); };
    corpo.innerHTML = `<p>Despesa da compra${fornecedor ? ' de <b>' + esc(fornecedor) + '</b>' : ''}: <b>${R(total)}</b></p>
      <label>Categoria da despesa<input id="dsp-cat" value="Compra de mercadoria"></label><div id="dsp-l"></div><button class="btn sm" id="dsp-add" type="button">+ parcela</button><p id="dsp-s" style="margin-top:8px"></p>
      <p class="muted">Cada parcela vira uma conta a pagar com a forma escolhida. Marque "Já pago" para o que foi pago na hora. Consignado: a conta fica em aberto até o acerto com o fornecedor.</p>`;
    corpo.addEventListener('input', e => { const r = e.target.closest('.tt'); if (!r) return; const i = $$('.tt', corpo).indexOf(r), l = linhas[i];
      if (e.target.matches('[data-vc]')) l.vencimento = e.target.value; if (e.target.matches('[data-vl]')) l.valor = numIn(e.target.value); calc(); });
    corpo.addEventListener('change', e => { const r = e.target.closest('.tt'); if (!r) return; const l = linhas[$$('.tt', corpo).indexOf(r)];
      if (e.target.matches('[data-fp]')) l.forma = e.target.value; if (e.target.matches('[data-pg]')) l.pago = e.target.checked; });
    corpo.addEventListener('click', e => { if (e.target.id === 'dsp-add') { const falta = Math.max(0, Math.round((total - linhas.reduce((a, l) => a + (Number(l.valor) || 0), 0)) * 100) / 100);
        linhas.push({ vencimento: new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10), valor: falta, forma: linhas[linhas.length - 1].forma, pago: false }); desenhar(); }
      if (e.target.dataset.x !== undefined) { linhas.splice(+e.target.dataset.x, 1); desenhar(); } });
    desenhar();
    modal({ titulo: 'Lançamento da despesa', tam: 'md', corpo, botoes: [{ txt: 'Voltar', fn: () => { if (!fin) { fin = true; res(null); } } },
      { txt: 'Confirmar entrada e despesa', cls: 'primary', fn: () => {
        if (!calc()) throw new Error('A soma das parcelas precisa ser igual ao total da compra.');
        if (linhas.some(l => !l.vencimento || !(l.valor > 0) || !l.forma)) throw new Error('Informe vencimento, valor e forma de pagamento em todas as parcelas.');
        fin = true; res({ titulos: linhas.map(l => ({ vencimento: l.vencimento, valor: l.valor, forma: l.forma, pago: l.pago })), categoria: $('#dsp-cat', corpo).value.trim() }); } }] });
  });
}
// Estoque: posição, entrada de mercadoria (manual e XML de NF-e) e movimentação.
registrar({ id: 'posicao', titulo: 'Posição de estoque', grupo: 'Estoque', perm: 'estoque.ver', render: async el => {
  let d = [];
  const desenhar = () => {
    const q = $('#bq', el).value.toLowerCase(), so = $('#baixo', el).checked;
    const l = d.filter(p => (!so || p.abaixo_minimo) && (!q || (p.nome + (p.codigo || '')).toLowerCase().includes(q)));
    const tot = l.reduce((s, p) => s + p.valor_estoque, 0);
    $('#lista', el).innerHTML = `<div class="cards"><div class="stat">Itens listados<b>${l.length}</b></div><div class="stat ${d.filter(p => p.abaixo_minimo).length ? 'warn' : ''}">Abaixo do mínimo<b>${d.filter(p => p.abaixo_minimo).length}</b></div><div class="stat">Valor em estoque (custo)<b>${R(tot)}</b></div></div>` +
      tabela([{ l: 'Produto', k: 'nome' }, { l: 'Categoria', k: 'categoria' }, { l: 'Tipo', k: 'tipo' }, { l: 'Estoque', n: 1, f: p => `<b class="${p.estoque_atual < 0 ? 'erro' : ''}">${N(p.estoque_atual)} ${p.unidade}</b>` }, { l: 'Mínimo', n: 1, f: p => N(p.estoque_minimo) }, { l: 'Custo médio', n: 1, f: p => R(p.custo_medio) }, { l: 'Valor', n: 1, f: p => R(p.valor_estoque) }], l,
        { rowCls: p => (p.abaixo_minimo ? 'low' : ''), });
  };
  const carregar = seguro(async () => { d = await api('/estoque/posicao'); desenhar(); });
  el.innerHTML = `<div class="bar"><input id="bq" placeholder="Buscar..."><label class="chk" style="margin:0"><input type="checkbox" id="baixo"> só abaixo do mínimo</label><div class="grow"></div><button class="btn" id="csv">Exportar CSV</button></div><div id="lista"></div>`;
  $('#bq', el).oninput = desenhar; $('#baixo', el).onchange = desenhar;
  $('#csv', el).onclick = () => csv('posicao-estoque', [{ l: 'Produto', k: 'nome' }, { l: 'Unidade', k: 'unidade' }, { l: 'Estoque', k: 'estoque_atual' }, { l: 'Mínimo', k: 'estoque_minimo' }, { l: 'Custo médio', k: 'custo_medio' }, { l: 'Valor', k: 'valor_estoque' }], d);
  el.onclick = seguro(async e => {
    const id = e.target.dataset.aj; if (!id) return; const p = d.find(x => x.id == id);
    formModal({ titulo: 'Ajuste de estoque: ' + p.nome, campos: [{ k: 'nova_qtd', l: `Quantidade contada (${p.unidade})`, t: 'number', step: '0.001', req: true, full: true }, { k: 'motivo', l: 'Motivo (inventário, perda, quebra...)', req: true, full: true }],
      extra: `<p class="muted">Saldo atual no sistema: <b>${N(p.estoque_atual)} ${p.unidade}</b></p>`,
      onSave: async o => { const r = await api('/estoque/ajuste', { method: 'POST', body: { produto_id: p.id, ...o } }); toast(r.delta ? `Ajustado em ${N(r.delta)} ${p.unidade}.` : 'Sem diferença.'); carregar(); } });
  });
  await carregar();
} });

registrar({ id: 'entrada', titulo: 'Entrada de mercadoria', grupo: 'Estoque', perm: 'estoque.entrada', render: async el => {
  const [prods, forn] = await Promise.all([api('/produtos?ativos=1'), api('/fornecedores?ativos=1')]);
  const estocaveis = prods.filter(p => p.tipo !== 'preparado');
  const dl = `<datalist id="dl-prod">${estocaveis.map(p => `<option value="${esc(rotuloProd(p))}">`).join('')}</datalist>`;
  const optForn = '<option value="">— sem fornecedor —</option>' + forn.map(f => `<option value="${f.id}">${esc(f.nome)}</option>`).join('');
  let aba = sessionStorage.getItem('xmlChave') ? 'xml' : 'manual';
  const abas = () => `<div class="tabs"><button data-ab="manual" class="${aba === 'manual' ? 'on' : ''}">Entrada manual</button><button data-ab="xml" class="${aba === 'xml' ? 'on' : ''}">Importar XML (NF-e / cupom)</button><button data-ab="hist" class="${aba === 'hist' ? 'on' : ''}">Histórico</button></div>`;

  // bloco de contas a pagar reutilizado nas duas entradas
  const blocoTitulos = (total, dups) => `<div class="card"><label class="chk"><input type="checkbox" id="gt" ${dups?.length ? 'checked' : ''}> Gerar contas a pagar</label><div id="tit">${dups?.length ? '' : ''}</div></div>`;
  const desenharTitulos = (box, total, dups) => {
    const linhas = dups?.length ? dups : [{ valor: total, vencimento: new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10) }];
    box.innerHTML = linhas.map(t => `<div class="row tt"><label>Vencimento<input type="date" data-vc value="${esc(t.vencimento || '')}"></label><label>Valor<input data-vl value="${t.valor || ''}" inputmode="decimal"></label><button class="btn sm danger auto" data-x type="button">✕</button></div>`).join('') + '<button class="btn sm" type="button" data-addt>+ parcela</button>';
  };
  const lerTitulos = root => ($('#gt', root).checked ? $$('.tt', root).map(r => ({ vencimento: $('[data-vc]', r).value, valor: numIn($('[data-vl]', r).value) })).filter(t => t.vencimento && t.valor > 0) : []);

  const manual = () => {
    el.innerHTML = abas() + dl + `<div class="card"><div class="row"><label>Fornecedor<select id="fo">${optForn}</select></label><label>Nº da nota / documento<input id="nf"></label></div>
      <h4>Itens</h4><div id="its"></div><button class="btn sm" id="addit" type="button">+ item</button> <button class="btn sm" id="novoprod" type="button" title="Produto que ainda não está no cadastro">+ Cadastrar produto novo</button>
      <div class="totais" style="margin-top:10px">Total: <b id="tt">${R(0)}</b></div></div><button class="btn primary big" id="salvar">Finalizar entrada (lançar despesa)</button>`;
    const item = () => `<div class="row it2"><label style="flex:3">Produto / insumo<input data-p list="dl-prod" placeholder="digite para buscar" autocomplete="off"></label><label>Qtd. comprada<input data-q inputmode="decimal"></label><label>Custo da embalagem (R$)<input data-c inputmode="decimal"></label><label title="Quantas unidades vêm em cada embalagem. Fardo com 12 un → 12. Se já compra unitário, 1.">Fator (un. por embalagem)<input data-f value="1" inputmode="decimal"></label><button class="btn sm danger auto" data-x type="button">✕</button><div class="muted" data-pv style="flex-basis:100%"></div></div>`;
    $('#its', el).innerHTML = item();
    const total = () => $$('.it2', el).reduce((s, r) => s + numIn($('[data-q]', r).value) * numIn($('[data-c]', r).value), 0);
    // acha o produto pelo rótulo da lista, código interno ou código de barras (inclusive lido pelo leitor)
    const acharProd = txt => { const id = idDoRotulo(txt); if (id) return { p: estocaveis.find(x => x.id === id), barras: '' };
      const s = String(txt || '').trim(); if (!s) return {};
      const p = estocaveis.find(x => (x.codigos_barras || []).includes(s)); if (p) return { p, barras: s };
      const q = estocaveis.find(x => String(x.codigo || '').toLowerCase() === s.toLowerCase()); return q ? { p: q, barras: '' } : {}; };
    const fatorDe = async r => { const { p, barras } = acharProd($('[data-p]', r).value); if (!p) return;
      const x = await api(`/estoque/fator?produto_id=${p.id}&fornecedor_id=${$('#fo', el).value || ''}&barras=${encodeURIComponent(barras)}`); $('[data-f]', r).value = x.fator; prev(r); };
    const prev = r => { const q = numIn($('[data-q]', r).value), c = numIn($('[data-c]', r).value), f = numIn($('[data-f]', r).value), pv = $('[data-pv]', r);
      const pr = acharProd($('[data-p]', r).value).p, un = pr ? pr.unidade : 'un';
      pv.innerHTML = f > 0 && q > 0 ? `Entra no estoque: <b>${N(q * f)} ${esc(un)}</b> · custo unitário: <b>${R(c / f)}</b>` : (f > 0 ? '' : '<span class="erro">Informe o fator (use 1 se já é unitário).</span>'); };
    el.oninput = e => { if (e.target.matches('[data-q],[data-c],[data-f],[data-p]')) { const r = e.target.closest('.it2'); if (r) prev(r); }
      if (e.target.matches('[data-q],[data-c]')) { $('#tt', el).textContent = R(total()); } };
    el.onchange = seguro(async e => {
      if (e.target.matches('[data-p]')) { const r = e.target.closest('.it2'), a = acharProd(e.target.value);
        if (a.p) { e.target.value = rotuloProd(a.p); await fatorDe(r); } else if (e.target.value.trim()) toast('Produto não encontrado. Use "+ Cadastrar produto novo".', 'aviso'); }
      if (e.target.id === 'fo') for (const r of $$('.it2', el)) await fatorDe(r);
    });
    el.onclick = seguro(async e => {
      const ab = e.target.dataset.ab; if (ab) { aba = ab; return desenharAba(); }
      if (e.target.id === 'novoprod') {
        const fid = $('#fo', el).value, fnome = fid ? $('#fo', el).selectedOptions[0].textContent : null;
        formModal({ titulo: 'Cadastrar produto novo', tam: 'md', valores: { fator: 1, unidade: 'UN', tipo: 'revenda' },
          extra: `<p class="muted">${fnome ? 'Fornecedor desta entrada: <b>' + esc(fnome) + '</b> (o código abaixo fica ligado a ele).' : 'Nenhum fornecedor escolhido na entrada: o código do fornecedor não será gravado. Escolha o fornecedor acima antes, se quiser.'}</p>`,
          campos: [{ k: 'codigo_fornecedor', l: 'Código do produto no fornecedor' }, { k: 'nome', l: 'Nome do produto', req: true, full: true }, { k: 'codigo_barras', l: 'Código de barras' },
            { k: 'fator', l: 'Fator deste código de barras (un. na embalagem; fardo com 5 → 5)', t: 'number', step: '0.0001', req: true },
            { k: 'unidade', l: 'Unidade do estoque', t: 'select', op: ['UN', 'KG', 'G', 'L', 'ML', 'CX', 'PCT'].map(u => [u, u]) },
            { k: 'tipo', l: 'Tipo', t: 'select', op: [['revenda', 'Revenda'], ['insumo', 'Insumo / matéria-prima']] }],
          onSave: async o => {
            const np = await api('/estoque/produto-rapido', { method: 'POST', body: { ...o, fornecedor_id: fid || null } });
            estocaveis.push(np); $('#dl-prod', el).insertAdjacentHTML('beforeend', `<option value="${esc(rotuloProd(np))}">`);
            const livre = $$('.it2', el).find(r => !$('[data-p]', r).value.trim()) || ($('#addit', el).click(), $$('.it2', el).pop());
            $('[data-p]', livre).value = rotuloProd(np); $('[data-f]', livre).value = np.fator; prev(livre); $('[data-q]', livre).focus();
            toast('Produto cadastrado e selecionado.');
          } });
        return;
      }
      if (e.target.id === 'addit') $('#its', el).insertAdjacentHTML('beforeend', item());
      if (e.target.dataset.x !== undefined) { const r = e.target.closest('.it2,.tt'); if (r) r.remove(); $('#tt', el).textContent = R(total()); }
      if (e.target.dataset.addt !== undefined) e.target.insertAdjacentHTML('beforebegin', `<div class="row tt"><label>Vencimento<input type="date" data-vc></label><label>Valor<input data-vl inputmode="decimal"></label><button class="btn sm danger auto" data-x type="button">✕</button></div>`);
      if (e.target.id === 'salvar') {
        const itens = $$('.it2', el).map(r => ({ produto_id: (acharProd($('[data-p]', r).value).p || {}).id, quantidade: numIn($('[data-q]', r).value), custo_unit: numIn($('[data-c]', r).value), fator: numIn($('[data-f]', r).value) })).filter(i => i.produto_id && i.quantidade > 0);
        if (itens.some(i => !(i.fator > 0))) throw new Error('Informe o fator de cada item (quantas unidades vêm na embalagem; 1 se já é unitário).');
        if (!itens.length) throw new Error('Informe ao menos um item (escolha o produto na lista).');
        const tot = itens.reduce((s, i) => s + i.quantidade * i.custo_unit, 0), fo = $('#fo', el);
        const dsp = tot > 0 ? await lancarDespesa({ total: Math.round(tot * 100) / 100, fornecedor: fo.value ? fo.selectedOptions[0].textContent : '' }) : { titulos: [] };
        if (!dsp) return;
        const r = await api('/estoque/entrada', { method: 'POST', body: { fornecedor_id: fo.value || null, numero: $('#nf', el).value, itens, titulos: dsp.titulos, categoria_despesa: dsp.categoria } });
        toast(`Entrada #${r.id} lançada (${R(r.total)}).`); manual();
      }
    });
  };

  const xml = () => {
    el.innerHTML = abas() + dl + `<div class="card"><label>Arquivo XML da NF-e, NFC-e ou cupom fiscal (CF-e SAT)<input type="file" id="arq" accept=".xml,text/xml"></label><p class="muted">O sistema lê itens, quantidades, custos, fornecedor e duplicatas. Se o código de barras (ou o código do fornecedor) já estiver no cadastro, o item é ligado ao produto existente, sem duplicar. O que ainda não existe é cadastrado automaticamente com o nome da nota, o código de barras e o código do fornecedor. Confira o fator de cada item: o fornecedor pode mandar errado.</p></div><div id="nfbox"></div>`;
    el.onclick = e => { const ab = e.target.dataset.ab; if (ab) { aba = ab; desenharAba(); } };
    const carregarXml = seguro(async texto => {
      const nf = await api('/estoque/xml/ler', { method: 'POST', body: { xml: texto } });
      const un = u => ['KG', 'G', 'L', 'ML'].includes(u);
      const box = $('#nfbox', el);
      box.innerHTML = `<div class="card"><b>${esc(nf.tipo_doc || 'NF-e')} ${esc(nf.numero)}</b> · emitida ${dia(nf.data_emissao)} · Total ${R(nf.total_nf)}<br>Fornecedor: <b>${esc(nf.fornecedor.nome)}</b> (${esc(nf.fornecedor.documento)}) ${nf.fornecedor_id ? chip('já cadastrado', 'ok') : chip('será cadastrado', 'warn')}
        ${nf.ja_importada ? `<p class="erro"><b>Atenção:</b> esta nota já foi importada em ${dt(nf.ja_importada.criado_em)} (entrada #${nf.ja_importada.id}). Não será possível importar de novo.</p>` : ''}</div>
        <div class="tw"><table><thead><tr><th>Item da nota</th><th class="n">Qtd (${'XML'})</th><th class="n">Custo un.</th><th title="Unidades por embalagem">Fator (un. por emb.)</th><th>Ação / produto do sistema</th></tr></thead><tbody>
        ${nf.itens.map((i, n) => { const m = estocaveis.find(p => p.id === i.produto_id); return `<tr data-n="${n}"><td>${esc(i.nome)}<br><small class="muted">cód ${esc(i.codigo_fornecedor)}${i.ean ? ' · EAN ' + esc(i.ean) : ''}</small><br>${i.origem_match === 'vinculo' ? chip('código do fornecedor já vinculado', 'ok') : i.origem_match === 'ean' ? chip('código de barras já cadastrado', 'ok') : chip('novo: será cadastrado', 'warn')}</td><td class="n">${N(i.quantidade)} ${esc(i.unidade_xml)}</td><td class="n">${R(i.custo_unit)}</td>
          <td style="width:90px"><input data-f value="${i.fator || 1}" class="${i.origem_match === 'novo' ? 'pedir' : ''}" title="Quantas unidades vêm em cada embalagem: fardo com 12 un → 12 (1 se já é unitário). O estoque entra multiplicado e o custo é dividido pelo fator." inputmode="decimal"></td>
          <td style="min-width:280px"><select data-a><option value="existente" ${m ? 'selected' : ''}>Produto existente</option><option value="novo-revenda" ${!m && !un(i.unidade) ? 'selected' : ''}>Cadastrar novo (revenda)</option><option value="novo-insumo" ${!m && un(i.unidade) ? 'selected' : ''}>Cadastrar novo (insumo)</option><option value="ignorar">Ignorar item</option></select>
          <input data-p list="dl-prod" value="${m ? esc(rotuloProd(m)) : ''}" placeholder="buscar produto" style="margin-top:4px" autocomplete="off"></td></tr>`; }).join('')}</tbody></table></div>
        <button class="btn primary big" id="conf" ${nf.ja_importada ? 'disabled' : ''}>Finalizar entrada (lançar despesa)</button>`;
      box.onclick = seguro(async ev => {
        if (ev.target.dataset.x !== undefined) ev.target.closest('.tt')?.remove();
        if (ev.target.dataset.addt !== undefined) ev.target.insertAdjacentHTML('beforebegin', `<div class="row tt"><label>Vencimento<input type="date" data-vc></label><label>Valor<input data-vl inputmode="decimal"></label><button class="btn sm danger auto" data-x type="button">✕</button></div>`);
        if (ev.target.id === 'conf') {
          const itens = $$('tbody tr', box).map(tr => { const i = nf.itens[+tr.dataset.n], a = $('[data-a]', tr).value; if (a === 'ignorar') return null;
            const base = { quantidade: i.quantidade, custo_unit: i.custo_unit, fator: numIn($('[data-f]', tr).value), codigo_fornecedor: i.codigo_fornecedor, nome: i.nome, ean: i.ean, ean_trib: i.ean_trib, unidade: i.unidade, unidade_trib: i.unidade_trib };
            if (!(base.fator > 0)) throw new Error('Informe o fator (unidades por embalagem; 1 se já é unitário) para: ' + i.nome);
            if (a === 'existente') { const id = idDoRotulo($('[data-p]', tr).value); if (!id) throw new Error('Escolha o produto na lista para: ' + i.nome); return { ...base, produto_id: id }; }
            return { ...base, criar: true, tipo: a === 'novo-insumo' ? 'insumo' : 'revenda' }; }).filter(Boolean);
          if (!itens.length) throw new Error('Nenhum item para lançar.');
          const dsp = nf.total_nf > 0 ? await lancarDespesa({ total: nf.total_nf, fornecedor: nf.fornecedor.nome, duplicatas: nf.duplicatas }) : { titulos: [] };
          if (!dsp) return;
          const r = await api('/estoque/xml/confirmar', { method: 'POST', body: { chave: nf.chave, numero: nf.numero, data_emissao: nf.data_emissao, fornecedor: nf.fornecedor, fornecedor_id: nf.fornecedor_id, itens, titulos: dsp.titulos, categoria_despesa: dsp.categoria } });
          toast(`NF importada: entrada #${r.id}, ${R(r.total)}${r.titulos ? ', ' + r.titulos + ' conta(s) a pagar' : ''}.`); xml();
        }
      });
    });
    $('#arq', el).onchange = seguro(async e => { const f = e.target.files[0]; if (!f) return; await carregarXml(await f.text()); });
    // vindo do painel "Notas da SEFAZ": abre direto o XML da nota escolhida
    const ch = sessionStorage.getItem('xmlChave');
    if (ch) { sessionStorage.removeItem('xmlChave'); seguro(async () => { const d = await api('/fiscal/doc/' + ch + '/xml'); await carregarXml(d.xml); })(); }
  };

  const hist = async () => {
    const h = await api('/estoque/entradas');
    el.innerHTML = abas() + tabela([{ l: '#', k: 'id' }, { l: 'Data', f: r => dt(r.criado_em) }, { l: 'Como entrou', f: r => { const t = { manual: 'Manual (digitada)', busca_auto: 'XML — busca automática', busca_botao: 'XML — busca manual (botão)', servico: 'XML — serviço por chave', arquivo: 'XML — arquivo importado' }; return chip(t[r.via] || r.origem, r.via === 'busca_auto' ? 'retirado' : r.via === 'manual' ? '' : 'novo'); } }, { l: 'NF', k: 'numero' }, { l: 'Fornecedor', k: 'fornecedor' }, { l: 'Usuário', k: 'usuario' }, { l: 'Total', n: 1, f: r => R(r.total) }], h, { vazio: 'Nenhuma entrada ainda.' });
    el.onclick = e => { const ab = e.target.dataset.ab; if (ab) { aba = ab; desenharAba(); } };
  };
  const desenharAba = () => seguro(async () => { if (aba === 'manual') manual(); else if (aba === 'xml') xml(); else await hist(); })();
  desenharAba();
} });

registrar({ id: 'movimentos', titulo: 'Movimentação de estoque', grupo: 'Estoque', perm: ['estoque.ver', 'relatorios.estoque'], render: async el => {
  const prods = await api('/produtos?ativos=1');
  el.innerHTML = `<div class="bar"><label class="chk" style="margin:0">De <input type="date" id="de" value="${iniMes()}"></label><label class="chk" style="margin:0">Até <input type="date" id="ate" value="${hojeISO()}"></label>
    <input id="pp" list="dl-m" placeholder="Produto (opcional)" autocomplete="off"><datalist id="dl-m">${prods.map(p => `<option value="${esc(rotuloProd(p))}">`).join('')}</datalist>
    <select id="tp"><option value="">Todos os tipos</option><option value="entrada">Entrada</option><option value="venda">Venda (saída)</option><option value="estorno">Estorno</option><option value="ajuste">Ajuste</option></select>
    <button class="btn primary" id="ok">Filtrar</button><div class="grow"></div><button class="btn" id="csv">CSV</button><button class="btn" onclick="window.print()">Imprimir</button></div><div id="res"></div>`;
  let ultimo = null;
  const buscar = seguro(async () => {
    const r = await api('/estoque/movimentos?' + qs({ de: $('#de', el).value, ate: $('#ate', el).value, produto_id: idDoRotulo($('#pp', el).value), tipo: $('#tp', el).value })); ultimo = r;
    $('#res', el).innerHTML = `<h3 style="margin:6px 0">Resumo por produto</h3>` + tabela([{ l: 'Produto', k: 'nome' }, { l: 'Entradas', n: 1, f: x => N(x.entradas) + ' ' + x.unidade }, { l: 'Saídas', n: 1, f: x => N(x.saidas) + ' ' + x.unidade }, { l: 'Saldo atual', n: 1, f: x => N(x.estoque_atual) + ' ' + x.unidade }], r.resumo, { vazio: 'Sem movimento no período.' }) +
      `<h3 style="margin:16px 0 6px">Movimentos</h3>` + tabela([{ l: 'Data', f: x => dt(x.criado_em) }, { l: 'Produto', k: 'produto' }, { l: 'Tipo', f: x => chip(x.tipo, x.quantidade > 0 ? 'ok' : 'warn') }, { l: 'Qtd', n: 1, f: x => (x.quantidade > 0 ? '+' : '') + N(x.quantidade) + ' ' + x.unidade }, { l: 'Saldo', n: 1, f: x => N(x.saldo_apos) }, { l: 'Motivo', k: 'motivo' }, { l: 'Usuário', k: 'usuario' }], r.movimentos, { vazio: 'Sem movimentos.' });
  });
  $('#ok', el).onclick = buscar;
  $('#csv', el).onclick = () => ultimo && csv('movimentacao-estoque', [{ l: 'Data', k: 'criado_em' }, { l: 'Produto', k: 'produto' }, { l: 'Tipo', k: 'tipo' }, { l: 'Quantidade', k: 'quantidade' }, { l: 'Saldo', k: 'saldo_apos' }, { l: 'Motivo', k: 'motivo' }, { l: 'Usuário', k: 'usuario' }], ultimo.movimentos);
  await buscar();
} });

// ---- Busca de produto por nome, código interno ou código de barras (telas de ajuste e extrato)
function seletorProduto(prods, idLista) {
  const dl = `<datalist id="${idLista}">${prods.map(p => `<option value="${esc(rotuloProd(p))}">`).join('')}</datalist>`;
  const achar = txt => { const id = idDoRotulo(txt); if (id) return prods.find(x => x.id === id); const s = String(txt || '').trim(); if (!s) return null;
    return prods.find(x => (x.codigos_barras || []).includes(s)) || prods.find(x => String(x.codigo || '').toLowerCase() === s.toLowerCase()) || null; };
  return { dl, achar };
}

registrar({ id: 'ajuste-avulso', titulo: 'Ajuste de estoque (avulso)', grupo: 'Estoque', perm: 'estoque.ajuste', render: async el => {
  const prods = (await api('/produtos?ativos=1')).filter(p => p.controla_estoque);
  const { dl, achar } = seletorProduto(prods, 'dl-aj');
  let atual = null;
  const lista = seguro(async () => {
    const h = await api('/estoque/ajustes');
    $('#hist', el).innerHTML = tabela([{ l: '#', k: 'id' }, { l: 'Data', f: r => dt(r.criado_em) }, { l: 'Produto', k: 'produto' }, { l: 'No sistema', n: 1, f: r => N(r.estoque_sistema) + ' ' + r.unidade }, { l: 'Informado', n: 1, f: r => N(r.estoque_informado) + ' ' + r.unidade },
      { l: 'Diferença', n: 1, f: r => `<b class="${r.diferenca < 0 ? 'erro' : ''}">${r.diferenca > 0 ? '+' : ''}${N(r.diferenca)}</b>` }, { l: 'Motivo', k: 'motivo' }, { l: 'Usuário', k: 'usuario' }], h, { vazio: 'Nenhum ajuste lançado ainda.' });
  });
  el.innerHTML = `<div class="card" style="max-width:640px">${dl}<p class="muted">Use para corrigir o estoque quando a contagem física for diferente do sistema. Cada ajuste fica registrado com usuário, data, motivo e diferença, e aparece no Extrato do produto.</p>
    <label>Produto (nome, código interno ou código de barras)<input id="pp" list="dl-aj" autocomplete="off" placeholder="digite ou leia o código de barras"></label>
    <div class="row"><label>Estoque no sistema<input id="es" readonly placeholder="—"></label><label>Estoque real (contado) *<input id="er" inputmode="decimal" disabled></label><label>Diferença<input id="df" readonly placeholder="—"></label></div>
    <label>Motivo * (inventário, perda, quebra...)<input id="mo"></label><button class="btn primary big" id="lan" disabled style="margin-top:10px">Lançar ajuste</button></div>
    <h3 style="margin:18px 0 6px">Últimos ajustes</h3><div id="hist"></div>`;
  const dif = () => { if (!atual) return; const v = numIn($('#er', el).value), d = $('#df', el); if ($('#er', el).value.trim() === '') { d.value = ''; return; } const x = Math.round((v - atual.estoque_atual) * 1000) / 1000; d.value = (x > 0 ? '+' : '') + N(x) + ' ' + atual.unidade; };
  const escolher = seguro(async () => {
    const p = achar($('#pp', el).value); atual = null; $('#es', el).value = ''; $('#er', el).value = ''; $('#df', el).value = ''; $('#er', el).disabled = true; $('#lan', el).disabled = true;
    if (!p) { if ($('#pp', el).value.trim()) toast('Produto não encontrado.', 'aviso'); return; }
    $('#pp', el).value = rotuloProd(p);
    atual = await api('/estoque/saldo?produto_id=' + p.id); atual.estoque_atual = Number(atual.estoque_atual);
    $('#es', el).value = N(atual.estoque_atual) + ' ' + atual.unidade; $('#er', el).disabled = false; $('#lan', el).disabled = false; $('#er', el).focus();
  });
  $('#pp', el).onchange = escolher; $('#er', el).oninput = dif;
  $('#lan', el).onclick = seguro(async () => {
    if (!atual) return; if ($('#er', el).value.trim() === '') throw new Error('Informe o estoque real (quantidade contada).'); if (!$('#mo', el).value.trim()) throw new Error('Informe o motivo do ajuste.');
    const v = numIn($('#er', el).value);
    if (!await confirmar(`Ajustar ${atual.nome} de ${N(atual.estoque_atual)} para ${N(v)} ${atual.unidade}?`)) return;
    const r = await api('/estoque/ajuste', { method: 'POST', body: { produto_id: atual.id, nova_qtd: v, motivo: $('#mo', el).value } });
    toast(r.delta ? `Ajuste #${r.id} lançado (${r.delta > 0 ? '+' : ''}${N(r.delta)} ${atual.unidade}).` : 'Estoque já confere; nada a ajustar.');
    $('#pp', el).value = ''; $('#mo', el).value = ''; atual = null; $('#es', el).value = ''; $('#er', el).value = ''; $('#df', el).value = ''; $('#er', el).disabled = true; $('#lan', el).disabled = true; lista();
  });
  await lista();
} });

// ---- Produção: gasta os insumos pela ficha técnica e coloca o produto preparado (ex.: pipoca) no estoque
registrar({ id: 'producao-estoque', titulo: 'Produção (insumos → produto)', grupo: 'Estoque', perm: 'estoque.producao', render: async el => {
  const prods = (await api('/produtos?ativos=1')).filter(p => p.tipo === 'preparado' && p.controla_estoque);
  const { dl, achar } = seletorProduto(prods, 'dl-prd');
  let atual = null, prev = null;
  const hist = seguro(async () => {
    const h = await api('/estoque/producoes');
    $('#hist', el).innerHTML = tabela([{ l: '#', k: 'id' }, { l: 'Data', f: r => dt(r.criado_em) }, { l: 'Produto', k: 'produto' }, { l: 'Quantidade produzida', n: 1, f: r => N(r.quantidade) + ' ' + r.unidade },
      { l: 'Custo total', n: 1, f: r => R(r.custo_total) }, { l: 'Custo unitário', n: 1, f: r => R(r.custo_unit) }, { l: 'Usuário', k: 'usuario' }, { l: 'Obs.', f: r => esc(r.observacao || '') }], h, { vazio: 'Nenhuma produção registrada ainda.' });
  });
  el.innerHTML = `<div class="card" style="max-width:760px">${dl}
    <p class="muted">Use quando o produto é feito <b>antes</b> da venda (ex.: pipoca). Ao registrar a produção, o sistema <b>coloca a quantidade produzida no estoque do produto</b> e já reserva o uso previsto dos insumos (pela ficha técnica). Os insumos só <b>baixam do estoque no fechamento do caixa</b>, quando você informa o que sobrou. Na venda, só o estoque do produto diminui.</p>
    <div class="row"><label style="flex:3">Produto preparado *<input id="pp" list="dl-prd" autocomplete="off" placeholder="digite o nome (só aparecem pratos que controlam estoque)"></label><label>Quantidade produzida *<input id="qt" inputmode="decimal" disabled></label></div>
    <div id="pv"></div>
    <label>Observação<input id="ob" placeholder="ex: lote da manhã"></label>
    <button class="btn primary big" id="reg" disabled style="margin-top:10px">Registrar produção</button></div>
    <h3 style="margin:18px 0 6px">Últimas produções</h3><div id="hist"></div>`;
  const previa = seguro(async () => {
    $('#reg', el).disabled = true; if (!atual) { $('#pv', el).innerHTML = ''; return; }
    const q = numIn($('#qt', el).value); if (!(q > 0)) { $('#pv', el).innerHTML = '<p class="muted">Informe a quantidade para ver quanto de cada insumo será gasto.</p>'; return; }
    prev = await api(`/estoque/producao/previa?produto_id=${atual.id}&quantidade=${q}`);
    const falta = prev.itens.some(x => x.disponivel - x.necessario < -0.0005);
    $('#pv', el).innerHTML = tabela([{ l: 'Insumo', k: 'nome' }, { l: 'Por unidade', n: 1, f: x => N(x.por_unidade) + ' ' + x.unidade }, { l: 'Uso previsto', n: 1, f: x => `<b>${N(x.necessario)} ${x.unidade}</b>` },
      { l: 'Disponível', n: 1, f: x => `<span class="${x.disponivel - x.necessario < -0.0005 ? 'erro' : ''}">${N(x.disponivel)} ${x.unidade}</span>` }, { l: 'Custo', n: 1, f: x => R(x.custo) }], prev.itens)
      + `<p>Custo total: <b>${R(prev.custo_total)}</b> · custo por unidade: <b>${R(prev.custo_total / q)}</b></p>${falta ? '<p class="erro">Há insumo insuficiente em estoque. Dê entrada na compra ou ajuste o estoque antes.</p>' : ''}`;
    $('#reg', el).disabled = falta;
  });
  const escolher = seguro(async () => {
    const p = achar($('#pp', el).value); atual = null; $('#qt', el).disabled = true; $('#qt', el).value = ''; $('#pv', el).innerHTML = ''; $('#reg', el).disabled = true;
    if (!p) { if ($('#pp', el).value.trim()) toast('Produto não encontrado (precisa ser Prato / preparado com "Controla estoque" marcado e ficha técnica).', 'aviso'); return; }
    $('#pp', el).value = rotuloProd(p); atual = p; $('#qt', el).disabled = false; $('#qt', el).focus();
  });
  $('#pp', el).onchange = escolher; $('#qt', el).oninput = previa;
  $('#reg', el).onclick = seguro(async () => {
    if (!atual) return; const q = numIn($('#qt', el).value);
    if (!await confirmar(`Registrar a produção de ${N(q)} ${atual.unidade} de ${atual.nome}? Os insumos serão baixados no fechamento do caixa.`)) return;
    const r = await api('/estoque/producao', { method: 'POST', body: { produto_id: atual.id, quantidade: q, observacao: $('#ob', el).value } });
    toast(`Produção #${r.id} registrada. Estoque de ${atual.nome} atualizado (insumos baixam no fechamento do caixa).`);
    $('#pp', el).value = ''; $('#ob', el).value = ''; atual = null; $('#qt', el).value = ''; $('#qt', el).disabled = true; $('#pv', el).innerHTML = ''; $('#reg', el).disabled = true; hist();
  });
  await hist();
} });

// Lançar produção rápida (usada na lista de produtos, no cadastro e na tela de vendas): baixa os insumos e soma ao estoque do produto
async function produzirModal(prodId, depois) {
  const prods = (await api('/produtos?ativos=1')).filter(p => p.tipo === 'preparado' && p.controla_estoque);
  if (!prods.length) return toast('Nenhum prato preparado com "Controla estoque" marcado. Ajuste o cadastro do produto.', 'aviso');
  const corpo = document.createElement('div');
  corpo.innerHTML = `<p class="muted">Informe quantas unidades foram feitas. A quantidade entra no estoque do produto para venda. Os insumos serão baixados no fechamento do caixa (pela sobra que você contar).</p>
    <div class="row"><label style="flex:3">Produto<select id="pz">${prods.map(p => `<option value="${p.id}" ${p.id == prodId ? 'selected' : ''}>${esc(p.nome)} (estoque ${N(p.estoque_atual)} ${p.unidade})</option>`).join('')}</select></label>
    <label>Quantidade feita *<input id="pq" inputmode="decimal" placeholder="ex: 10"></label></div><div id="pv"></div>
    <label>Observação<input id="po" placeholder="ex: lote da tarde"></label>`;
  let falta = false;
  const previa = seguro(async () => {
    const q = numIn($('#pq', corpo).value); if (!(q > 0)) { $('#pv', corpo).innerHTML = ''; falta = false; return; }
    const v = await api(`/estoque/producao/previa?produto_id=${$('#pz', corpo).value}&quantidade=${q}`);
    falta = v.itens.some(x => x.disponivel - x.necessario < -0.0005);
    $('#pv', corpo).innerHTML = tabela([{ l: 'Insumo', k: 'nome' }, { l: 'Uso previsto', n: 1, f: x => `<b>${N(x.necessario)} ${x.unidade}</b>` }, { l: 'Disponível', n: 1, f: x => `<span class="${x.disponivel - x.necessario < -0.0005 ? 'erro' : ''}">${N(x.disponivel)} ${x.unidade}</span>` }], v.itens)
      + (falta ? '<p class="erro">Insumo insuficiente em estoque.</p>' : '');
  });
  corpo.oninput = previa; corpo.onchange = previa;
  modal({ titulo: 'Lançar produção', tam: 'md', corpo, botoes: [{ txt: 'Cancelar' }, { txt: 'Lançar produção', cls: 'primary', fn: async () => {
    const q = numIn($('#pq', corpo).value); if (!(q > 0)) throw new Error('Informe a quantidade feita.'); if (falta) throw new Error('Insumo insuficiente em estoque.');
    const r = await api('/estoque/producao', { method: 'POST', body: { produto_id: +$('#pz', corpo).value, quantidade: q, observacao: $('#po', corpo).value } });
    toast(`Produção #${r.id} lançada: ${N(q)} un. no estoque (insumos baixam no fechamento do caixa).`); if (depois) depois();
  } }] });
}
