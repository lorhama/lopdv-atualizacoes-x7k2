// Painel com gráficos (SVG puro, funciona sem internet): venda líquida, atendimento, ticket médio, previsão, top 10, participação, compras x vendas e contas a pagar.
const pctTxt = (a, b) => (b > 0 ? ((a - b) / b * 100) : (a > 0 ? 100 : 0));
const fPct = v => (v >= 0 ? '' : '−') + Math.abs(v).toFixed(2).replace('.', ',') + '%';
function setaBox(atual, ref) {
  const sobe = atual >= ref && atual > 0;
  return `<div class="pn-seta ${sobe ? 'up' : 'dn'}">${sobe ? '↑' : '↓'}</div>`;
}
function linhaComp(rotulo, valor, ref, fmt) {
  const d = pctTxt(ref.hoje === undefined ? valor : ref.hoje, ref.base);
  return `<div class="pn-l"><span>${rotulo}</span><span class="v">${fmt(ref.base)}</span><span class="p ${d < 0 ? 'neg' : 'pos'}">${fPct(d)}</span></div>`;
}
// gráfico de linha com linha tracejada da média
function graficoLinha(serie) {
  const W = 640, H = 240, m = { l: 62, r: 14, t: 14, b: 26 }, iw = W - m.l - m.r, ih = H - m.t - m.b;
  const vs = serie.map(s => s.v), mx = Math.max(10, ...vs), passo = Math.pow(10, Math.floor(Math.log10(mx))) * (mx / Math.pow(10, Math.floor(Math.log10(mx))) > 5 ? 2 : mx / Math.pow(10, Math.floor(Math.log10(mx))) > 2 ? 1 : 0.5), top = Math.ceil(mx / passo) * passo;
  const x = i => m.l + (serie.length > 1 ? i * iw / (serie.length - 1) : iw / 2), y = v => m.t + ih - (v / top) * ih;
  const media = vs.reduce((a, b) => a + b, 0) / (vs.length || 1);
  let g = '';
  for (let v = 0; v <= top + 0.001; v += passo) g += `<line x1="${m.l}" x2="${W - m.r}" y1="${y(v)}" y2="${y(v)}" class="gl"/><text x="${m.l - 6}" y="${y(v) + 4}" text-anchor="end" class="gt">${R(v).replace(',00', '')}</text>`;
  const cada = Math.ceil(serie.length / 10);
  serie.forEach((s, i) => { if (i % cada === 0 || i === serie.length - 1) g += `<text x="${x(i)}" y="${H - 6}" text-anchor="middle" class="gt">${esc(s.rotulo)}</text>`; });
  const pts = serie.map((s, i) => `${x(i)},${y(s.v)}`).join(' ');
  return `<svg viewBox="0 0 ${W} ${H}" class="pn-svg">${g}<line x1="${m.l}" x2="${W - m.r}" y1="${y(media)}" y2="${y(media)}" class="media"/><polyline points="${pts}" class="lin"/>${serie.map((s, i) => `<circle cx="${x(i)}" cy="${y(s.v)}" r="4" class="pt"><title>${esc(s.rotulo)}: ${R(s.v)} (${s.n} venda(s))</title></circle>`).join('')}</svg>
    <div class="pn-leg"><span><i class="l1"></i>Venda líquida</span><span><i class="l2"></i>Média do período (${R(media)})</span></div>`;
}
function barrasH(lista) {
  if (!lista.length) return '<p class="muted">Sem vendas no período.</p>';
  const mx = Math.max(...lista.map(l => l.part), 1);
  return `<div class="pn-bars">${lista.map(l => `<div class="pn-b"><span class="n" title="${esc(l.nome)}">${esc(l.nome)}</span><div class="t"><i style="width:${(l.part / mx * 100).toFixed(1)}%"></i></div><span class="p">${l.part.toFixed(2).replace('.', ',')}%</span></div>`).join('')}</div>`;
}

registrar({ id: 'painel', titulo: 'Painel', grupo: 'Início', render: async el => {
  let de = '', ate = '';
  const hojeStr = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  const carregar = async () => {
    const [d, op] = await Promise.all([api('/relatorios/dashboard' + (de ? `?de=${de}&ate=${ate}` : '')), api('/relatorios/painel').catch(() => null)]);
    de = d.de; ate = d.ate;
    const quando = (rot, base, atual) => `<div class="pn-l"><span>${rot}</span><span class="v">${typeof base === 'number' && rot.includes('Atend') ? base : ''}</span></div>`;
    const bloco = (titulo, atual, fmt, linhas) => `<div class="pn-card"><div class="pn-h"><h3>${titulo}</h3><button class="pn-ic" data-rec title="Atualizar">⟳</button></div>
      <div class="pn-top">${setaBox(atual, linhas[0][1])}<div><small class="muted">Hoje</small><div class="pn-big">${fmt(atual)}</div></div></div>
      ${linhas.map(([r, b]) => `<div class="pn-l"><span>${r}</span><span class="v">${fmt(b)}</span><span class="p ${atual < b ? 'neg' : 'pos'}">${fPct(pctTxt(atual, b))}</span></div>`).join('')}</div>`;
    const n0 = x => String(x);
    const m = d.mes, pctMeta = m.previsao ? Math.min(100, m.v / m.previsao * 100) : 0;
    const cv = d.mes.v ? d.compras / d.mes.v * 100 : 0;
    const cp = d.contas_pagar;
    el.innerHTML = `<div class="pn-grid">
      <div class="pn-col">
        <div class="pn-card"><div class="pn-h"><h3>Venda líquida</h3><button class="pn-ic" data-rec title="Atualizar">⟳</button></div>
          <div class="pn-top">${setaBox(d.hoje.v, d.ontemMH.v)}<div><small class="muted">Hoje</small><div class="pn-big">${R(d.hoje.v)}</div></div></div>
          <div class="pn-l"><span>Ontem (mesmo horário):</span><span class="v">${R(d.ontemMH.v)}</span><span class="p ${d.hoje.v < d.ontemMH.v ? 'neg' : 'pos'}">${fPct(pctTxt(d.hoje.v, d.ontemMH.v))}</span></div>
          <div class="pn-l"><span>Mesmo dia da última semana (mesmo horário):</span><span class="v">${R(d.semMH.v)}</span><span class="p ${d.hoje.v < d.semMH.v ? 'neg' : 'pos'}">${fPct(pctTxt(d.hoje.v, d.semMH.v))}</span></div>
          <div class="pn-l"><span>Média diária do mês atual:</span><span class="v">${R(m.media)}</span><span class="p ${d.hoje.v < m.media ? 'neg' : 'pos'}">${fPct(pctTxt(d.hoje.v, m.media))}</span></div>
          <div class="pn-l"><span>Média diária no mês atual do ano anterior:</span><span class="v">${R(d.mediaAnoAnt)}</span><span class="p ${d.hoje.v < d.mediaAnoAnt ? 'neg' : 'pos'}">${fPct(pctTxt(d.hoje.v, d.mediaAnoAnt))}</span></div>
          <h4 style="margin:14px 0 6px">Gráfico de venda líquida no período</h4>
          <div class="pn-per"><label>De<input type="date" id="pde" value="${de}" max="${hojeStr}"></label><label>até<input type="date" id="pate" value="${ate}" max="${hojeStr}"></label><button class="btn sm primary" id="pfil">Filtrar</button></div>
          ${graficoLinha(d.serie)}</div>
        <div class="pn-card"><div class="pn-h"><h3>Previsão de vendas do mês atual</h3></div>
          <small class="muted">Venda líquida prevista (projeção pela média diária):</small><div class="pn-big">${R(m.previsao)}</div>
          <div class="pn-prog"><i style="width:${pctMeta.toFixed(1)}%"></i><span>${pctMeta.toFixed(2).replace('.', ',')}%</span></div>
          <div class="pn-l"><span>Venda líquida no mês atual:</span><span class="v">${R(m.v)}</span></div>
          <div class="pn-l"><span>Dias restantes:</span><span class="v">${m.restantes} dias</span></div></div>
        <div class="pn-card"><div class="pn-h"><h3>Compras X Vendas (mês atual)</h3></div>
          <div class="pn-cv"><div><small class="muted">Compras / vendas</small><div class="pn-big">${cv.toFixed(2).replace('.', ',')}%</div></div><div><small class="muted">Compras</small><div class="pn-big">${R(d.compras)}</div></div><div><small class="muted">Vendas</small><div class="pn-big">${R(m.v)}</div></div></div></div>
      </div>
      <div class="pn-col">
        <div class="pn-card"><div class="pn-h"><h3>Atendimento</h3></div>
          <div class="pn-top">${setaBox(d.hoje.n, d.ontemMH.n)}<div><small class="muted">Hoje</small><div class="pn-big">${d.hoje.n}</div></div></div>
          <div class="pn-l"><span>Ontem (mesmo horário)</span><span class="v">${d.ontemMH.n}</span><span class="p ${d.hoje.n < d.ontemMH.n ? 'neg' : 'pos'}">${fPct(pctTxt(d.hoje.n, d.ontemMH.n))}</span></div>
          <div class="pn-l"><span>Ontem:</span><span class="v">${d.ontem.n}</span><span class="p ${d.hoje.n < d.ontem.n ? 'neg' : 'pos'}">${fPct(pctTxt(d.hoje.n, d.ontem.n))}</span></div>
          <div class="pn-l"><span>Mesmo dia da última semana (mesmo horário):</span><span class="v">${d.semMH.n}</span><span class="p ${d.hoje.n < d.semMH.n ? 'neg' : 'pos'}">${fPct(pctTxt(d.hoje.n, d.semMH.n))}</span></div>
          <div class="pn-l"><span>Mesmo dia da última semana:</span><span class="v">${d.sem.n}</span><span class="p ${d.hoje.n < d.sem.n ? 'neg' : 'pos'}">${fPct(pctTxt(d.hoje.n, d.sem.n))}</span></div></div>
        <div class="pn-card"><div class="pn-h"><h3>Ticket médio</h3></div>
          <div class="pn-top">${setaBox(d.hoje.t, d.ontemMH.t)}<div><small class="muted">Hoje</small><div class="pn-big">${R(d.hoje.t)}</div></div></div>
          <div class="pn-l"><span>Ontem (mesmo horário):</span><span class="v">${R(d.ontemMH.t)}</span><span class="p ${d.hoje.t < d.ontemMH.t ? 'neg' : 'pos'}">${fPct(pctTxt(d.hoje.t, d.ontemMH.t))}</span></div>
          <div class="pn-l"><span>Ontem:</span><span class="v">${R(d.ontem.t)}</span><span class="p ${d.hoje.t < d.ontem.t ? 'neg' : 'pos'}">${fPct(pctTxt(d.hoje.t, d.ontem.t))}</span></div>
          <div class="pn-l"><span>Mesmo dia da última semana:</span><span class="v">${R(d.sem.t)}</span><span class="p ${d.hoje.t < d.sem.t ? 'neg' : 'pos'}">${fPct(pctTxt(d.hoje.t, d.sem.t))}</span></div></div>
        <div class="pn-card"><div class="pn-h"><h3>Top 10 vendas</h3><small class="muted">${dia(d.de)} a ${dia(d.ate)}</small></div>
          ${d.top.length ? `<div class="pn-top10">${d.top.map((p, i) => `<div class="pn-t"><span class="num">${i + 1}</span><div class="info"><b>${esc(p.nome)}</b><small class="muted">${p.un.toLocaleString('pt-BR')} un. · participação ${p.part.toFixed(2).replace('.', ',')}% · CMV ${p.cmv.toFixed(1).replace('.', ',')}%</small></div><b>${R(p.venda)}</b></div>`).join('')}</div>` : '<p class="muted">Sem vendas no período.</p>'}</div>
        <div class="pn-card"><div class="pn-h"><h3>Participação das vendas no período</h3><small class="muted">por categoria · venda líquida</small></div>${barrasH(d.grupos)}</div>
        <div class="pn-card"><div class="pn-h"><h3>Contas a pagar</h3></div><small class="muted">Total em aberto</small><div class="pn-big">${R(cp.total)}</div>
          <div class="pn-l"><span>Vencendo hoje</span><span class="v">${R(cp.hoje)}</span></div><div class="pn-l"><span>A vencer (mês atual)</span><span class="v">${R(cp.mes)}</span></div>
          <div class="pn-l"><span>Vencidos</span><span class="v ${cp.vencidos ? 'neg' : ''}">${R(cp.vencidos)}</span></div><div class="pn-l"><span>A vencer (próximos meses)</span><span class="v">${R(cp.proximos)}</span></div></div>
      </div></div>
      ${op ? `<div class="cards" style="margin-top:6px">${[['cozinha', 'Aguardando na cozinha'], ['bar', 'Aguardando no bar']].map(([k, t]) => { const n = op.pendentes_producao.find(p => p.destino === k)?.n || 0; return `<div class="stat ${n ? 'warn' : ''}">${t}<b>${n}</b></div>`; }).join('')}</div>
      ${op.estoque_baixo.length ? `<h3 style="margin:6px 0">Estoque abaixo do mínimo</h3>${tabela([{ l: 'Produto', k: 'nome' }, { l: 'Estoque', n: 1, f: p => N(p.estoque_atual) + ' ' + p.unidade }, { l: 'Mínimo', n: 1, f: p => N(p.estoque_minimo) + ' ' + p.unidade }], op.estoque_baixo)}` : ''}` : ''}`;
  };
  el.onclick = seguro(async e => {
    if (e.target.dataset.rec !== undefined) return carregar();
    if (e.target.id === 'pfil') { de = $('#pde', el).value; ate = $('#pate', el).value; if (!de || !ate) throw new Error('Informe as duas datas.'); return carregar(); }
  });
  await carregar();
  S.timer = setInterval(() => { if (location.hash === '' || location.hash === '#/painel') carregar().catch(() => { }); }, 60000);
} });
