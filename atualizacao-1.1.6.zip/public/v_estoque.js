
// Lançamento da despesa ao finalizar a entrada: parcelas, vencimento e forma de pagamento de cada uma
async function lancarDespesa({ total, fornecedor, duplicatas, descricao }) {
  const FP = await api('/formas-pagamento?uso=pagar');
  const base = (duplicatas && duplicatas.length ? duplicatas : [{ valor: total, vencimento: new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10) }])
    .map(d => ({ vencimento: String(d.vencimento || '').slice(0, 10), valor: Number(d.valor) || 0, forma: (FP.find(f => f.tipo === 'pix') || FP[0] || {}).codigo, pago: false }));
  return new Promise(res => {
    const corpo = document.createElement('div'); let fin = false;
    const linhas = base.slice();
    const opt = l => FP.map(f => `<option value="${esc(f.codigo)}" ${f.codigo === l.forma ? 'selected' : ''}>${esc(f.descricao)}</option>`).join('');
    const calc = () => { const s = Math.round(linhas.reduce((a, l) => a + (Number(l.valor) || 0), 0) * 100) / 100, dif = Math.round((total - s) * 100) / 100;
      $('#dsp-s', corpo).innerHTML = `Soma das parcelas: <b>${R(s)}</b> · Total da compra: <b>${R(total)}</b> ` + (Math.abs(dif) < 0.011 ? chip('confere', 'ok') : `<span class="erro">diferença de ${R(dif)}</span>`); return Math.abs(dif) < 0.011; };
    const desenhar = () => { $('#dsp-l', corpo).innerHTML = linhas.map((l, i) => `<div class="row tt"><label>Vencimento<input type="date" data-vc value="${esc(l.vencimento)}"></label><label>Valor (R$)<input data-vl value="${esc(String(l.valor).replace('.', ','))}" inputmode="decimal"></label>
      <label>Forma de pagamento<select data-fp>${opt(l)}</select></label><label class="chk" style="align-self:end"><input type="checkbox" data-pg ${l.pago ? 'checked' : ''}> Já pago</label>${linhas.length > 1 ? `<button class="btn sm danger auto" data-x="${i}" type="button">✕</button>` : ''}</div>`).join(''); calc(); };
    corpo.innerHTML = `<p>Despesa da compra${fornecedor ? ' de <b>' + esc(fornecedor) + '</b>' : ''}: <b>${R(total)}</b></p>
      <label>Categoria da despesa<input id="dsp-cat" value="Compra de mercadoria"></label><div id="dsp-l"></div><button class="btn sm" id="dsp-add" type="button">+ parcela</button><p id="dsp-s" style="margin-top:8px"></p>
      <p class="muted">Cada parcela vira uma conta a pagar com a forma escolhida. Marque "Já pago" para o que foi pago na hora. Consignado: a conta fica em aberto até o acerto com o fornecedor.</p>`;
    corpo.addEventListener('input', e => { const r = e.target.closest('.tt'); if (!r) return; const i = $$('.tt', corpo).indexOf(r), l = linhas[i];
      if (e.target.matches('[data-vc]')) l.vencimento = e.target.value; if (e.target.matches('[data-vl]')) l.valor = numIn(e.target.value); calc(); });
    corpo.addEventListener('change', e => { const r = e.target.closest('.tt'); if (!r) return; const l = linhas[$$('.tt', corpo).indexOf(r)];
      if (e.target.matches('[data-fp]')) l.forma = e.target.value; if (e.target.matches('[data-pg]')) l.pago = e.target.checked; });
    corpo.addEventListener('click', e => { if (e.target.id === 'dsp-add') { const falta = Math.max(0, Math.round((total - linhas.reduce((a, l) => a + (Number(l.valor) || 0), 0)) * 100) / 100);
        linhas.push({ vencimento: new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10), valor: falta, forma: linhas[linhas.length - 1].forma, pago: false }); desenhar(); }
      if (e.target.dataset.x !== undefined) { linhas.splice(+e.target.dataset.x, 1); desenhar(); } });
    desenhar();
    modal({ titulo: 'Lançamento da despesa', tam: 'md', corpo, botoes: [{ txt: 'Voltar', fn: () => { if (!fin) { fin = true; res(null); } } },
      { txt: 'Confirmar entrada e despesa', cls: 'primary', fn: () => {
        if (!calc()) throw new Error('A soma das parcelas precisa ser igual ao total da compra.');
        if (linhas.some(l => !l.vencimento || !(l.valor > 0) || !l.forma)) throw new Error('Informe vencimento, valor e forma de pagamento em todas as parcelas.');
        fin = true; res({ titulos: linhas.map(l => ({ vencimento: l.vencimento, valor: l.valor, forma: l.forma, pago: l.pago })), categoria: $('#dsp-cat', corpo).value.trim() }); } }] });
  });
}
// Estoque: posição, entrada de mercadoria (manual e XML de NF-e) e movimentação.
registrar({ id: 'posicao', titulo: 'Posição de estoque', grupo: 'Estoque', perm: 'estoque.ver', render: async el => {
  let d = [];
  const desenhar = () => {
    const q = $('#bq', el).value.toLowerCase(), so = $('#baixo', el).checked;
    const l = d.filter(p => (!so || p.abaixo_minimo) && (!q || (p.nome + (p.codigo || '')).toLowerCase().includes(q)));
    const tot = l.reduce((s, p) => s + p.valor_estoque, 0);
    $('#lista', el).innerHTML = `<div class="cards"><div class="stat">Itens listados<b>${l.length}</b></div><div class="stat ${d.filter(p => p.abaixo_minimo).length ? 'warn' : ''}">Abaixo do mínimo<b>${d.filter(p => p.abaixo_minimo).length}</b></div><div class="stat">Valor em estoque (custo)<b>${R(tot)}</b></div></div>` +
      tabela([{ l: 'Produto', k: 'nome' }, { l: 'Categoria', k: 'categoria' }, { l: 'Tipo', k: 'tipo' }, { l: 'Estoque', n: 1, f: p => `<b class="${p.estoque_atual < 0 ? 'erro' : ''}">${N(p.estoque_atual)} ${p.unidade}</b>` }, { l: 'Mínimo', n: 1, f: p => N(p.estoque_minimo) }, { l: 'Custo médio', n: 1, f: p => R(p.custo_medio) }, { l: 'Valor', n: 1, f: p => R(p.valor_estoque) }], l,
        { rowCls: p => (p.abaixo_minimo ? 'low' : ''), });
  };
  const carregar = seguro(async () => { d = await api('/estoque/posicao'); desenhar(); });
  el.innerHTML = `<div class="bar"><input id="bq" placeholder="Buscar..."><label class="chk" style="margin:0"><input type="checkbox" id="baixo"> só abaixo do mínimo</label><div class="grow"></div><button class="btn" id="csv">Exportar CSV</button></div><div id="lista"></div>`;
  $('#bq', el).oninput = desenhar; $('#baixo', el).onchange = desenhar;
  $('#csv', el).onclick = () => csv('posicao-estoque', [{ l: 'Produto', k: 'nome' }, { l: 'Unidade', k: 'unidade' }, { l: 'Estoque', k: 'estoque_atual' }, { l: 'Mínimo', k: 'estoque_minimo' }, { l: 'Custo médio', k: 'custo_medio' }, { l: 'Valor', k: 'valor_estoque' }], d);
  el.onclick = seguro(async e => {
    const id = e.target.dataset.aj; if (!id) return; const p = d.find(x => x.id == id);
    formModal({ titulo: 'Ajuste de estoque: ' + p.nome, campos: [{ k: 'nova_qtd', l: `Quantidade contada (${p.unidade})`, t: 'number', step: '0.001', req: true, full: true }, { k: 'motivo', l: 'Motivo (inventário, perda, quebra...)', req: true, full: true }],
      extra: `<p class="muted">Saldo atual no sistema: <b>${N(p.estoque_atual)} ${p.unidade}</b></p>`,
      onSave: async o => { const r = await api('/estoque/ajuste', { method: 'POST', body: { produto_id: p.id, ...o } }); toast(r.delta ? `Ajustado em ${N(r.delta)} ${p.unidade}.` : 'Sem diferença.'); carregar(); } });
  });
  await carregar();
} });

registrar({ id: 'entrada', titulo: 'Entrada de mercadoria (Manual)', grupo: 'Estoque', perm: 'estoque.entrada', render: async el => {
  const [prods, forn] = await Promise.all([api('/produtos?ativos=1'), api('/fornecedores?ativos=1')]);
  const estocaveis = prods.filter(p => p.tipo !== 'preparado');
  const dl = `<datalist id="dl-prod">${estocaveis.map(p => `<option value="${esc(rotuloProd(p))}">`).join('')}</datalist>`;
  const optForn = '<option value="">— sem fornecedor —</option>' + forn.map(f => `<option value="${f.id}">${esc(f.nome)}</option>`).join('');
  let aba = sessionStorage.getItem('xmlChave') ? 'xml' : 'manual';
  const abas = () => `<div class="tabs"><button data-ab="manual" class="${aba === 'manual' ? 'on' : ''}">Entrada manual</button><button data-ab="xml" class="${aba === 'xml' ? 'on' : ''}">Importar XML (NF-e / cupom)</button><button data-ab="hist" class="${aba === 'hist' ? 'on' : ''}">Histórico</button></div>`;

  // bloco de contas a pagar reutilizado nas duas entradas
  const blocoTitulos = (total, dups) => `<div class="card"><label class="chk"><input type="checkbox" id="gt" ${dups?.length ? 'checked' : ''}> Gerar contas a pagar</label><div id="tit">${dups?.length ? '' : ''}</div></div>`;
  const desenharTitulos = (box, total, dups) => {
    const linhas = dups?.length ? dups : [{ valor: total, vencimento: new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10) }];
    box.innerHTML = linhas.map(t => `<div class="row tt"><label>Vencimento<input type="date" data-vc value="${esc(t.vencimento || '')}"></label><label>Valor<input data-vl value="${t.valor || ''}" inputmode="decimal"></label><button class="btn sm danger auto" data-x type="button">✕</button></div>`).join('') + '<button class="btn sm" type="button" data-addt>+ parcela</button>';
  };
  const lerTitulos = root => ($('#gt', root).checked ? $$('.tt', root).map(r => ({ vencimento: $('[data-vc]', r).value, valor: numIn($('[data-vl]', r).value) })).filter(t => t.vencimento && t.valor > 0) : []);

  const manual = () => {
    el.innerHTML = abas() + dl + `<div class="card"><div class="row"><label>Fornecedor<select id="fo">${optForn}</select></label><label>Nº da nota / documento<input id="nf"></label></div>
      <label class="chk" title="Mercadoria deixada pelo fornecedor para acerto no fim do evento: entra no estoque, mas não gera conta a pagar. O pagamento é feito no Acerto, depois das devoluções."><input type="checkbox" id="cs"> <b>Nota consignada</b> <span class="muted">(entra no estoque, só será paga no acerto após as devoluções — veja em Estoque ▸ Consignações)</span></label>
      <label class="chk" title="Marca todos os itens como doação. Depois você pode desmarcar os que foram comprados."><input type="checkbox" id="dn"> <b>Esta nota é de doação</b> <span class="muted">(marca todos os itens; desmarque os que foram comprados)</span></label>
      <h4>Itens</h4><div id="its"></div><button class="btn sm" id="addit" type="button">+ item</button> <button class="btn sm" id="novoprod" type="button" title="Produto que ainda não está no cadastro">+ Cadastrar produto novo</button>
      <div class="totais" style="margin-top:10px"><span id="lbltt">Total a pagar</span>: <b id="tt">${R(0)}</b> <span class="muted" id="ttd"></span></div></div><button class="btn primary big" id="salvar">Finalizar entrada (lançar despesa)</button>`;
    const item = () => `<div class="row it2"><label title="Estoque: revenda/insumo. Patrimônio: bem durável (mesa, geladeira, som...), recebe nº de patrimônio e não entra no estoque.">Destino<select data-d><option value="e">Estoque</option><option value="p">Patrimônio</option></select></label><label style="flex:3" data-lp>Produto / insumo<input data-p list="dl-prod" placeholder="digite para buscar" autocomplete="off"></label><label style="flex:3;display:none" data-ld>Descrição do bem<input data-ds placeholder="ex.: Geladeira vertical 2 portas"></label><label class="chk" style="margin:0 6px;align-self:flex-end" title="Item recebido de doação: entra sem custo e não gera conta a pagar"><input type="checkbox" data-dc> Doação</label><label>Qtd. comprada<input data-q inputmode="decimal"></label><label>Custo da embalagem (R$)<input data-c inputmode="decimal"></label><label data-lf title="Quantas unidades vêm em cada embalagem. Fardo com 12 un → 12. Se já compra unitário, 1.">Fator (un. por embalagem)<input data-f value="1" inputmode="decimal"></label><button class="btn sm danger auto" data-x type="button">✕</button><div class="muted" data-pv style="flex-basis:100%"></div></div>`;
    $('#its', el).innerHTML = item();
    const vlr = r => numIn($('[data-q]', r).value) * numIn($('[data-c]', r).value);
    const total = () => $$('.it2', el).filter(r => !$('[data-dc]', r).checked).reduce((s, r) => s + vlr(r), 0);
    const totalDoado = () => $$('.it2', el).filter(r => $('[data-dc]', r).checked).reduce((s, r) => s + vlr(r), 0);
    const atualizaTotal = () => { $('#tt', el).textContent = R(total()); const d = totalDoado(); $('#ttd', el).textContent = d > 0 ? `· doado (sem pagamento): ${R(d)}` : ''; };
    const destino = r => { const pat = $('[data-d]', r).value === 'p'; $('[data-lp]', r).style.display = pat ? 'none' : ''; $('[data-lf]', r).style.display = pat ? 'none' : ''; $('[data-ld]', r).style.display = pat ? '' : 'none'; prev(r); };
    // acha o produto pelo rótulo da lista, código interno ou código de barras (inclusive lido pelo leitor)
    const acharProd = txt => { const id = idDoRotulo(txt); if (id) return { p: estocaveis.find(x => x.id === id), barras: '' };
      const s = String(txt || '').trim(); if (!s) return {};
      const p = estocaveis.find(x => (x.codigos_barras || []).includes(s)); if (p) return { p, barras: s };
      const q = estocaveis.find(x => String(x.codigo || '').toLowerCase() === s.toLowerCase()); return q ? { p: q, barras: '' } : {}; };
    const fatorDe = async r => { const { p, barras } = acharProd($('[data-p]', r).value); if (!p) return;
      const x = await api(`/estoque/fator?produto_id=${p.id}&fornecedor_id=${$('#fo', el).value || ''}&barras=${encodeURIComponent(barras)}`); $('[data-f]', r).value = x.fator; prev(r); };
    const prev = r => { const q = numIn($('[data-q]', r).value), c = numIn($('[data-c]', r).value), f = numIn($('[data-f]', r).value), pv = $('[data-pv]', r);
      const dc = $('[data-dc]', r).checked;
      if ($('[data-d]', r).value === 'p') { pv.innerHTML = q > 0 ? `Vai para o <b>Patrimônio</b>: ${q} bem(ns) com número próprio${dc ? ' · <b>doação</b>' : ` · ${R(c)} cada`}` : ''; return; }
      const pr = acharProd($('[data-p]', r).value).p, un = pr ? pr.unidade : 'un';
      pv.innerHTML = f > 0 && q > 0 ? `Entra no estoque: <b>${N(q * f)} ${esc(un)}</b> · ${dc ? '<b>doação</b> (custo zero, sem conta a pagar)' : `custo unitário: <b>${R(c / f)}</b>`}` : (f > 0 ? '' : '<span class="erro">Informe o fator (use 1 se já é unitário).</span>'); };
    el.oninput = e => { if (e.target.matches('[data-q],[data-c],[data-f],[data-p]')) { const r = e.target.closest('.it2'); if (r) prev(r); }
      if (e.target.matches('[data-q],[data-c]')) atualizaTotal(); };
    el.onchange = seguro(async e => {
      if (e.target.matches('[data-p]')) { const r = e.target.closest('.it2'), a = acharProd(e.target.value);
        if (a.p) { e.target.value = rotuloProd(a.p); await fatorDe(r); } else if (e.target.value.trim()) toast('Produto não encontrado. Use "+ Cadastrar produto novo".', 'aviso'); }
      if (e.target.id === 'fo') for (const r of $$('.it2', el)) await fatorDe(r);
      if (e.target.matches('[data-d]')) destino(e.target.closest('.it2'));
      if (e.target.matches('[data-dc]')) { prev(e.target.closest('.it2')); atualizaTotal(); }
      if (e.target.id === 'dn') { $$('[data-dc]', el).forEach(x => { x.checked = e.target.checked; }); $$('.it2', el).forEach(prev); atualizaTotal(); }
    });
    el.onclick = seguro(async e => {
      const ab = e.target.dataset.ab; if (ab) { aba = ab; return desenharAba(); }
      if (e.target.id === 'novoprod') {
        const fid = $('#fo', el).value, fnome = fid ? $('#fo', el).selectedOptions[0].textContent : null;
        formModal({ titulo: 'Cadastrar produto novo', tam: 'md', valores: { fator: 1, unidade: 'UN', tipo: 'revenda' },
          extra: `<p class="muted">${fnome ? 'Fornecedor desta entrada: <b>' + esc(fnome) + '</b> (o código abaixo fica ligado a ele).' : 'Nenhum fornecedor escolhido na entrada: o código do fornecedor não será gravado. Escolha o fornecedor acima antes, se quiser.'}</p>`,
          campos: [{ k: 'codigo_fornecedor', l: 'Código do produto no fornecedor' }, { k: 'nome', l: 'Nome do produto', req: true, full: true }, { k: 'codigo_barras', l: 'Código de barras' },
            { k: 'fator', l: 'Fator deste código de barras (un. na embalagem; fardo com 5 → 5)', t: 'number', step: '0.0001', req: true },
            { k: 'unidade', l: 'Unidade do estoque', t: 'select', op: ['UN', 'KG', 'G', 'L', 'ML', 'CX', 'PCT'].map(u => [u, u]) },
            { k: 'tipo', l: 'Tipo', t: 'select', op: [['revenda', 'Revenda'], ['insumo', 'Insumo / matéria-prima']] }],
          onSave: async o => {
            const np = await api('/estoque/produto-rapido', { method: 'POST', body: { ...o, fornecedor_id: fid || null } });
            estocaveis.push(np); $('#dl-prod', el).insertAdjacentHTML('beforeend', `<option value="${esc(rotuloProd(np))}">`);
            const livre = $$('.it2', el).find(r => !$('[data-p]', r).value.trim()) || ($('#addit', el).click(), $$('.it2', el).pop());
            $('[data-p]', livre).value = rotuloProd(np); $('[data-f]', livre).value = np.fator; prev(livre); $('[data-q]', livre).focus();
            toast('Produto cadastrado e selecionado.');
          } });
        return;
      }
      if (e.target.id === 'addit') { $('#its', el).insertAdjacentHTML('beforeend', item()); if ($('#dn', el).checked) $$('[data-dc]', el).pop().checked = true; }
      if (e.target.dataset.x !== undefined) { const r = e.target.closest('.it2,.tt'); if (r) r.remove(); atualizaTotal(); }
      if (e.target.dataset.addt !== undefined) e.target.insertAdjacentHTML('beforebegin', `<div class="row tt"><label>Vencimento<input type="date" data-vc></label><label>Valor<input data-vl inputmode="decimal"></label><button class="btn sm danger auto" data-x type="button">✕</button></div>`);
      if (e.target.id === 'salvar') {
        const itens = $$('.it2', el).map(r => $('[data-d]', r).value === 'p'
          ? { patrimonio: true, descricao: $('[data-ds]', r).value.trim(), quantidade: numIn($('[data-q]', r).value), custo_unit: numIn($('[data-c]', r).value), doacao: $('[data-dc]', r).checked }
          : { produto_id: (acharProd($('[data-p]', r).value).p || {}).id, quantidade: numIn($('[data-q]', r).value), custo_unit: numIn($('[data-c]', r).value), fator: numIn($('[data-f]', r).value), doacao: $('[data-dc]', r).checked })
          .filter(i => (i.patrimonio ? i.descricao : i.produto_id) && i.quantidade > 0);
        if (itens.some(i => i.patrimonio && (i.quantidade !== Math.floor(i.quantidade) || i.quantidade > 500))) throw new Error('Bens de patrimônio: informe a quantidade em unidades inteiras.');
        if (itens.some(i => !i.patrimonio && !(i.fator > 0))) throw new Error('Informe o fator de cada item (quantas unidades vêm na embalagem; 1 se já é unitário).');
        if (!itens.length) throw new Error('Informe ao menos um item (escolha o produto na lista).');
        const tot = itens.filter(i => !i.doacao).reduce((s, i) => s + i.quantidade * i.custo_unit, 0), fo = $('#fo', el);
        const cons = $('#cs', el).checked;
        if (cons && itens.some(i => i.patrimonio || i.doacao)) throw new Error('Nota consignada não pode ter itens de doação ou patrimônio. Lance essa parte em outra entrada.');
        if (cons && !fo.value) throw new Error('Escolha o fornecedor da consignação.');
        const dsp = tot > 0 && !cons ? await lancarDespesa({ total: Math.round(tot * 100) / 100, fornecedor: fo.value ? fo.selectedOptions[0].textContent : '' }) : { titulos: [] };
        if (!dsp) return;
        const r = await api('/estoque/entrada', { method: 'POST', body: { fornecedor_id: fo.value || null, numero: $('#nf', el).value, itens, doacao: $('#dn', el).checked, consignada: cons, titulos: dsp.titulos, categoria_despesa: dsp.categoria } });
        toast(cons ? `Consignação #${r.id} lançada (${R(r.total)} a acertar no fim do evento).` : `Entrada #${r.id} lançada (${R(r.total)}).` + (r.patrimonios?.length ? ` Patrimônio nº ${r.patrimonios.join(', ')}.` : '') + (r.valor_doacao > 0 ? ` Doação: ${R(r.valor_doacao)}.` : '')); manual();
      }
    });
  };

  const xml = () => {
    el.innerHTML = abas() + dl + `<div class="card"><label>Arquivo XML da NF-e, NFC-e ou cupom fiscal (CF-e SAT)<input type="file" id="arq" accept=".xml,text/xml"></label><p class="muted">O sistema lê itens, quantidades, custos, fornecedor e duplicatas. Se o código de barras (ou o código do fornecedor) já estiver no cadastro, o item é ligado ao produto existente, sem duplicar. O que ainda não existe é cadastrado automaticamente com o nome da nota, o código de barras e o código do fornecedor. Confira o fator de cada item: o fornecedor pode mandar errado.</p></div><div id="nfbox"></div>`;
    el.onclick = e => { const ab = e.target.dataset.ab; if (ab) { aba = ab; desenharAba(); } };
    const carregarXml = seguro(async texto => {
      const nf = await api('/estoque/xml/ler', { method: 'POST', body: { xml: texto } });
      const un = u => ['KG', 'G', 'L', 'ML'].includes(u);
      const box = $('#nfbox', el);
      box.innerHTML = `<div class="card"><b>${esc(nf.tipo_doc || 'NF-e')} ${esc(nf.numero)}</b> · emitida ${dia(nf.data_emissao)} · Total ${R(nf.total_nf)}<br>Fornecedor: <b>${esc(nf.fornecedor.nome)}</b> (${esc(nf.fornecedor.documento)}) ${nf.fornecedor_id ? chip('já cadastrado', 'ok') : chip('será cadastrado', 'warn')}
        <label class="chk" style="margin-top:8px" title="A nota entra no estoque, mas não gera conta a pagar; o pagamento é feito no Acerto da consignação."><input type="checkbox" id="csx"> <b>Nota consignada</b> <span class="muted">(só será paga no acerto, após as devoluções)</span></label>
        <label class="chk" style="margin-top:4px"><input type="checkbox" id="dnx"> <b>Esta nota é de doação</b> <span class="muted">(marca todos os itens; desmarque os que foram comprados)</span></label>
        ${nf.ja_importada ? `<p class="erro"><b>Atenção:</b> esta nota já foi importada em ${dt(nf.ja_importada.criado_em)} (entrada #${nf.ja_importada.id}). Não será possível importar de novo.</p>` : ''}</div>
        <div class="tw"><table><thead><tr><th>Item da nota</th><th class="n">Qtd (${'XML'})</th><th class="n">Custo un.</th><th title="Unidades por embalagem">Fator (un. por emb.)</th><th title="Item recebido de doação: entra sem custo e não gera conta a pagar">Doação</th><th>Ação / produto do sistema</th></tr></thead><tbody>
        ${nf.itens.map((i, n) => { const m = estocaveis.find(p => p.id === i.produto_id); return `<tr data-n="${n}"><td>${esc(i.nome)}<br><small class="muted">cód ${esc(i.codigo_fornecedor)}${i.ean ? ' · EAN ' + esc(i.ean) : ''}</small><br>${i.origem_match === 'vinculo' ? chip('código do fornecedor já vinculado', 'ok') : i.origem_match === 'ean' ? chip('código de barras já cadastrado', 'ok') : chip('novo: será cadastrado', 'warn')}</td><td class="n">${N(i.quantidade)} ${esc(i.unidade_xml)}</td><td class="n">${R(i.custo_unit)}</td>
          <td style="width:90px"><input data-f value="${i.fator || 1}" class="${i.origem_match === 'novo' ? 'pedir' : ''}" title="Quantas unidades vêm em cada embalagem: fardo com 12 un → 12 (1 se já é unitário). O estoque entra multiplicado e o custo é dividido pelo fator." inputmode="decimal"></td>
          <td style="text-align:center"><input type="checkbox" data-dc></td>
          <td style="min-width:280px"><select data-a><option value="existente" ${m ? 'selected' : ''}>Produto existente</option><option value="novo-revenda" ${!m && !un(i.unidade) ? 'selected' : ''}>Cadastrar novo (revenda)</option><option value="novo-insumo" ${!m && un(i.unidade) ? 'selected' : ''}>Cadastrar novo (insumo)</option><option value="patrimonio">Patrimônio (bem durável, sem estoque)</option><option value="ignorar">Ignorar item</option></select>
          <input data-p list="dl-prod" value="${m ? esc(rotuloProd(m)) : ''}" placeholder="buscar produto" style="margin-top:4px" autocomplete="off"></td></tr>`; }).join('')}</tbody></table></div>
        <button class="btn primary big" id="conf" ${nf.ja_importada ? 'disabled' : ''}>Finalizar entrada (lançar despesa)</button>`;
      box.onclick = seguro(async ev => {
        if (ev.target.dataset.x !== undefined) ev.target.closest('.tt')?.remove();
        if (ev.target.dataset.addt !== undefined) ev.target.insertAdjacentHTML('beforebegin', `<div class="row tt"><label>Vencimento<input type="date" data-vc></label><label>Valor<input data-vl inputmode="decimal"></label><button class="btn sm danger auto" data-x type="button">✕</button></div>`);
        if (ev.target.id === 'dnx') $$('[data-dc]', box).forEach(x => { x.checked = ev.target.checked; });
        if (ev.target.id === 'conf') {
          const itens = $$('tbody tr', box).map(tr => { const i = nf.itens[+tr.dataset.n], a = $('[data-a]', tr).value; if (a === 'ignorar') return null;
            const dc = $('[data-dc]', tr).checked;
            if (a === 'patrimonio') { if (i.quantidade !== Math.floor(i.quantidade)) throw new Error('Patrimônio: a quantidade deve ser inteira em: ' + i.nome); return { patrimonio: true, descricao: i.nome, quantidade: i.quantidade, custo_unit: i.custo_unit, doacao: dc }; }
            const base = { quantidade: i.quantidade, custo_unit: i.custo_unit, fator: numIn($('[data-f]', tr).value), doacao: dc, codigo_fornecedor: i.codigo_fornecedor, nome: i.nome, ean: i.ean, ean_trib: i.ean_trib, unidade: i.unidade, unidade_trib: i.unidade_trib };
            if (!(base.fator > 0)) throw new Error('Informe o fator (unidades por embalagem; 1 se já é unitário) para: ' + i.nome);
            if (a === 'existente') { const id = idDoRotulo($('[data-p]', tr).value); if (!id) throw new Error('Escolha o produto na lista para: ' + i.nome); return { ...base, produto_id: id }; }
            return { ...base, criar: true, tipo: a === 'novo-insumo' ? 'insumo' : 'revenda' }; }).filter(Boolean);
          if (!itens.length) throw new Error('Nenhum item para lançar.');
          // doação não gera conta a pagar: com itens doados, o valor a pagar é só o dos itens comprados (sem usar as duplicatas da nota)
          const temDoacao = itens.some(x => x.doacao), semDoacao = itens.filter(x => !x.doacao).reduce((t, x) => t + x.quantidade * x.custo_unit, 0);
          const aPagar = temDoacao ? Math.round(semDoacao * 100) / 100 : nf.total_nf, cons = $('#csx', box).checked;
          if (cons && itens.some(x => x.patrimonio || x.doacao)) throw new Error('Nota consignada não pode ter itens de doação ou patrimônio.');
          const dsp = aPagar > 0 && !cons ? await lancarDespesa({ total: aPagar, fornecedor: nf.fornecedor.nome, duplicatas: temDoacao ? null : nf.duplicatas }) : { titulos: [] };
          if (!dsp) return;
          const r = await api('/estoque/xml/confirmar', { method: 'POST', body: { chave: nf.chave, numero: nf.numero, data_emissao: nf.data_emissao, fornecedor: nf.fornecedor, fornecedor_id: nf.fornecedor_id, itens, doacao: $('#dnx', box).checked, consignada: cons, titulos: dsp.titulos, categoria_despesa: dsp.categoria } });
          toast(`NF importada: entrada #${r.id}, ${R(r.total)}${r.titulos ? ', ' + r.titulos + ' conta(s) a pagar' : ''}.` + (r.patrimonios?.length ? ` Patrimônio nº ${r.patrimonios.join(', ')}.` : '') + (r.valor_doacao > 0 ? ` Doação: ${R(r.valor_doacao)}.` : '')); xml();
        }
      });
    });
    $('#arq', el).onchange = seguro(async e => { const f = e.target.files[0]; if (!f) return; await carregarXml(await f.text()); });
    // vindo do painel "Notas da SEFAZ": abre direto o XML da nota escolhida
    const ch = sessionStorage.getItem('xmlChave');
    if (ch) { sessionStorage.removeItem('xmlChave'); seguro(async () => { const d = await api('/fiscal/doc/' + ch + '/xml'); await carregarXml(d.xml); })(); }
  };

  const hist = async () => {
    const h = await api('/estoque/entradas');
    el.innerHTML = abas() + tabela([{ l: '#', k: 'id' }, { l: 'Data', f: r => dt(r.criado_em) }, { l: 'Como entrou', f: r => { const t = { manual: 'Manual (digitada)', busca_auto: 'XML — busca automática', busca_botao: 'XML — busca manual (botão)', servico: 'XML — serviço por chave', arquivo: 'XML — arquivo importado' }; return chip(t[r.via] || r.origem, r.via === 'busca_auto' ? 'retirado' : r.via === 'manual' ? '' : 'novo'); } }, { l: 'NF', k: 'numero' }, { l: 'Fornecedor', k: 'fornecedor' }, { l: 'Usuário', k: 'usuario' }, { l: 'Doação / patrimônio', f: r => { const t = []; if (r.qtd_doacao > 0) t.push(chip(r.qtd_doacao === r.qtd_itens ? 'Doação' : `Doação parcial (${r.qtd_doacao}/${r.qtd_itens})`, 'warn') + (r.valor_doacao > 0 ? ' ' + R(r.valor_doacao) : '')); if (r.qtd_patrimonio > 0) t.push(chip(r.qtd_patrimonio + ' patrimônio', 'novo')); return t.join(' '); } }, { l: 'Total pago', n: 1, f: r => r.consig === 'aberta' ? chip('Consignada · a acertar', 'warn') + `<br><small class="muted">${R(r.total)} recebido</small>` : R(r.total) + (r.consig === 'acertada' ? '<br><small class="muted">consignação acertada</small>' : '') }], h, { vazio: 'Nenhuma entrada ainda.' });
    el.onclick = e => { const ab = e.target.dataset.ab; if (ab) { aba = ab; desenharAba(); } };
  };
  const desenharAba = () => seguro(async () => { if (aba === 'manual') manual(); else if (aba === 'xml') xml(); else await hist(); })();
  desenharAba();
} });

registrar({ id: 'movimentos', titulo: 'Movimentação de estoque', grupo: 'Estoque', perm: ['estoque.ver', 'relatorios.estoque'], render: async el => {
  const prods = await api('/produtos?ativos=1');
  el.innerHTML = `<div class="bar"><label class="chk" style="margin:0">De <input type="date" id="de" value="${iniMes()}"></label><label class="chk" style="margin:0">Até <input type="date" id="ate" value="${hojeISO()}"></label>
    <input id="pp" list="dl-m" placeholder="Produto (opcional)" autocomplete="off"><datalist id="dl-m">${prods.map(p => `<option value="${esc(rotuloProd(p))}">`).join('')}</datalist>
    <select id="tp"><option value="">Todos os tipos</option><option value="entrada">Entrada</option><option value="venda">Venda (saída)</option><option value="estorno">Estorno</option><option value="ajuste">Ajuste</option></select>
    <button class="btn primary" id="ok">Filtrar</button><div class="grow"></div><button class="btn" id="csv">CSV</button><button class="btn" onclick="window.print()">Imprimir</button></div><div id="res"></div>`;
  let ultimo = null;
  const buscar = seguro(async () => {
    const r = await api('/estoque/movimentos?' + qs({ de: $('#de', el).value, ate: $('#ate', el).value, produto_id: idDoRotulo($('#pp', el).value), tipo: $('#tp', el).value })); ultimo = r;
    $('#res', el).innerHTML = `<h3 style="margin:6px 0">Resumo por produto</h3>` + tabela([{ l: 'Produto', k: 'nome' }, { l: 'Entradas', n: 1, f: x => N(x.entradas) + ' ' + x.unidade }, { l: 'Saídas', n: 1, f: x => N(x.saidas) + ' ' + x.unidade }, { l: 'Saldo atual', n: 1, f: x => N(x.estoque_atual) + ' ' + x.unidade }], r.resumo, { vazio: 'Sem movimento no período.' }) +
      `<h3 style="margin:16px 0 6px">Movimentos</h3>` + tabela([{ l: 'Data', f: x => dt(x.criado_em) }, { l: 'Produto', k: 'produto' }, { l: 'Tipo', f: x => chip(x.tipo, x.quantidade > 0 ? 'ok' : 'warn') }, { l: 'Qtd', n: 1, f: x => (x.quantidade > 0 ? '+' : '') + N(x.quantidade) + ' ' + x.unidade }, { l: 'Saldo', n: 1, f: x => N(x.saldo_apos) }, { l: 'Motivo', k: 'motivo' }, { l: 'Usuário', k: 'usuario' }], r.movimentos, { vazio: 'Sem movimentos.' });
  });
  $('#ok', el).onclick = buscar;
  $('#csv', el).onclick = () => ultimo && csv('movimentacao-estoque', [{ l: 'Data', k: 'criado_em' }, { l: 'Produto', k: 'produto' }, { l: 'Tipo', k: 'tipo' }, { l: 'Quantidade', k: 'quantidade' }, { l: 'Saldo', k: 'saldo_apos' }, { l: 'Motivo', k: 'motivo' }, { l: 'Usuário', k: 'usuario' }], ultimo.movimentos);
  await buscar();
} });

// ---- Busca de produto por nome, código interno ou código de barras (telas de ajuste e extrato)
function seletorProduto(prods, idLista) {
  const dl = `<datalist id="${idLista}">${prods.map(p => `<option value="${esc(rotuloProd(p))}">`).join('')}</datalist>`;
  const achar = txt => { const id = idDoRotulo(txt); if (id) return prods.find(x => x.id === id); const s = String(txt || '').trim(); if (!s) return null;
    return prods.find(x => (x.codigos_barras || []).includes(s)) || prods.find(x => String(x.codigo || '').toLowerCase() === s.toLowerCase()) || null; };
  return { dl, achar };
}

registrar({ id: 'ajuste-avulso', titulo: 'Ajuste de estoque (avulso)', grupo: 'Estoque', perm: 'estoque.ajuste', render: async el => {
  const prods = (await api('/produtos?ativos=1')).filter(p => p.controla_estoque);
  const { dl, achar } = seletorProduto(prods, 'dl-aj');
  let atual = null;
  const lista = seguro(async () => {
    const h = await api('/estoque/ajustes');
    $('#hist', el).innerHTML = tabela([{ l: '#', k: 'id' }, { l: 'Data', f: r => dt(r.criado_em) }, { l: 'Produto', k: 'produto' }, { l: 'No sistema', n: 1, f: r => N(r.estoque_sistema) + ' ' + r.unidade }, { l: 'Informado', n: 1, f: r => N(r.estoque_informado) + ' ' + r.unidade },
      { l: 'Diferença', n: 1, f: r => `<b class="${r.diferenca < 0 ? 'erro' : ''}">${r.diferenca > 0 ? '+' : ''}${N(r.diferenca)}</b>` }, { l: 'Motivo', k: 'motivo' }, { l: 'Usuário', k: 'usuario' }], h, { vazio: 'Nenhum ajuste lançado ainda.' });
  });
  el.innerHTML = `<div class="card" style="max-width:640px">${dl}<p class="muted">Use para corrigir o estoque quando a contagem física for diferente do sistema. Cada ajuste fica registrado com usuário, data, motivo e diferença, e aparece no Extrato do produto.</p>
    <label>Produto (nome, código interno ou código de barras)<input id="pp" list="dl-aj" autocomplete="off" placeholder="digite ou leia o código de barras"></label>
    <div class="row"><label>Estoque no sistema<input id="es" readonly placeholder="—"></label><label>Estoque real (contado) *<input id="er" inputmode="decimal" disabled></label><label>Diferença<input id="df" readonly placeholder="—"></label></div>
    <label>Motivo * (inventário, perda, quebra...)<input id="mo"></label><button class="btn primary big" id="lan" disabled style="margin-top:10px">Lançar ajuste</button></div>
    <h3 style="margin:18px 0 6px">Últimos ajustes</h3><div id="hist"></div>`;
  const dif = () => { if (!atual) return; const v = numIn($('#er', el).value), d = $('#df', el); if ($('#er', el).value.trim() === '') { d.value = ''; return; } const x = Math.round((v - atual.estoque_atual) * 1000) / 1000; d.value = (x > 0 ? '+' : '') + N(x) + ' ' + atual.unidade; };
  const escolher = seguro(async () => {
    const p = achar($('#pp', el).value); atual = null; $('#es', el).value = ''; $('#er', el).value = ''; $('#df', el).value = ''; $('#er', el).disabled = true; $('#lan', el).disabled = true;
    if (!p) { if ($('#pp', el).value.trim()) toast('Produto não encontrado.', 'aviso'); return; }
    $('#pp', el).value = rotuloProd(p);
    atual = await api('/estoque/saldo?produto_id=' + p.id); atual.estoque_atual = Number(atual.estoque_atual);
    $('#es', el).value = N(atual.estoque_atual) + ' ' + atual.unidade; $('#er', el).disabled = false; $('#lan', el).disabled = false; $('#er', el).focus();
  });
  $('#pp', el).onchange = escolher; $('#er', el).oninput = dif;
  $('#lan', el).onclick = seguro(async () => {
    if (!atual) return; if ($('#er', el).value.trim() === '') throw new Error('Informe o estoque real (quantidade contada).'); if (!$('#mo', el).value.trim()) throw new Error('Informe o motivo do ajuste.');
    const v = numIn($('#er', el).value);
    if (!await confirmar(`Ajustar ${atual.nome} de ${N(atual.estoque_atual)} para ${N(v)} ${atual.unidade}?`)) return;
    const r = await api('/estoque/ajuste', { method: 'POST', body: { produto_id: atual.id, nova_qtd: v, motivo: $('#mo', el).value } });
    toast(r.delta ? `Ajuste #${r.id} lançado (${r.delta > 0 ? '+' : ''}${N(r.delta)} ${atual.unidade}).` : 'Estoque já confere; nada a ajustar.');
    $('#pp', el).value = ''; $('#mo', el).value = ''; atual = null; $('#es', el).value = ''; $('#er', el).value = ''; $('#df', el).value = ''; $('#er', el).disabled = true; $('#lan', el).disabled = true; lista();
  });
  await lista();
} });

// ---- Produção: gasta os insumos pela ficha técnica e coloca o produto preparado (ex.: pipoca) no estoque
registrar({ id: 'producao-estoque', titulo: 'Produção (insumos → produto)', grupo: 'Estoque', perm: 'estoque.producao', render: async el => {
  const prods = (await api('/produtos?ativos=1')).filter(p => p.tipo === 'preparado' && p.controla_estoque);
  const { dl, achar } = seletorProduto(prods, 'dl-prd');
  let atual = null, prev = null;
  const hist = seguro(async () => {
    const h = await api('/estoque/producoes');
    $('#hist', el).innerHTML = tabela([{ l: '#', k: 'id' }, { l: 'Data', f: r => dt(r.criado_em) }, { l: 'Produto', k: 'produto' }, { l: 'Quantidade produzida', n: 1, f: r => N(r.quantidade) + ' ' + r.unidade },
      { l: 'Custo total', n: 1, f: r => R(r.custo_total) }, { l: 'Custo unitário', n: 1, f: r => R(r.custo_unit) }, { l: 'Usuário', k: 'usuario' }, { l: 'Obs.', f: r => esc(r.observacao || '') }], h, { vazio: 'Nenhuma produção registrada ainda.' });
  });
  el.innerHTML = `<div class="card" style="max-width:760px">${dl}
    <p class="muted">Use quando o produto é feito <b>antes</b> da venda (ex.: pipoca). Ao registrar a produção, o sistema <b>coloca a quantidade produzida no estoque do produto</b> e já reserva o uso previsto dos insumos (pela ficha técnica). Os insumos só <b>baixam do estoque no fechamento do caixa</b>, quando você informa o que sobrou. Na venda, só o estoque do produto diminui.</p>
    <div class="row"><label style="flex:3">Produto preparado *<input id="pp" list="dl-prd" autocomplete="off" placeholder="digite o nome (só aparecem pratos que controlam estoque)"></label><label>Quantidade produzida *<input id="qt" inputmode="decimal" disabled></label></div>
    <div id="pv"></div>
    <label>Observação<input id="ob" placeholder="ex: lote da manhã"></label>
    <button class="btn primary big" id="reg" disabled style="margin-top:10px">Registrar produção</button></div>
    <h3 style="margin:18px 0 6px">Últimas produções</h3><div id="hist"></div>`;
  const previa = seguro(async () => {
    $('#reg', el).disabled = true; if (!atual) { $('#pv', el).innerHTML = ''; return; }
    const q = numIn($('#qt', el).value); if (!(q > 0)) { $('#pv', el).innerHTML = '<p class="muted">Informe a quantidade para ver quanto de cada insumo será gasto.</p>'; return; }
    prev = await api(`/estoque/producao/previa?produto_id=${atual.id}&quantidade=${q}`);
    const falta = prev.itens.some(x => x.disponivel - x.necessario < -0.0005);
    $('#pv', el).innerHTML = tabela([{ l: 'Insumo', k: 'nome' }, { l: 'Por unidade', n: 1, f: x => N(x.por_unidade) + ' ' + x.unidade }, { l: 'Uso previsto', n: 1, f: x => `<b>${N(x.necessario)} ${x.unidade}</b>` },
      { l: 'Disponível', n: 1, f: x => `<span class="${x.disponivel - x.necessario < -0.0005 ? 'erro' : ''}">${N(x.disponivel)} ${x.unidade}</span>` }, { l: 'Custo', n: 1, f: x => R(x.custo) }], prev.itens)
      + `<p>Custo total: <b>${R(prev.custo_total)}</b> · custo por unidade: <b>${R(prev.custo_total / q)}</b></p>${falta ? '<p class="erro">Há insumo insuficiente em estoque. Dê entrada na compra ou ajuste o estoque antes.</p>' : ''}`;
    $('#reg', el).disabled = falta;
  });
  const escolher = seguro(async () => {
    const p = achar($('#pp', el).value); atual = null; $('#qt', el).disabled = true; $('#qt', el).value = ''; $('#pv', el).innerHTML = ''; $('#reg', el).disabled = true;
    if (!p) { if ($('#pp', el).value.trim()) toast('Produto não encontrado (precisa ser Prato / preparado com "Controla estoque" marcado e ficha técnica).', 'aviso'); return; }
    $('#pp', el).value = rotuloProd(p); atual = p; $('#qt', el).disabled = false; $('#qt', el).focus();
  });
  $('#pp', el).onchange = escolher; $('#qt', el).oninput = previa;
  $('#reg', el).onclick = seguro(async () => {
    if (!atual) return; const q = numIn($('#qt', el).value);
    if (!await confirmar(`Registrar a produção de ${N(q)} ${atual.unidade} de ${atual.nome}? Os insumos serão baixados no fechamento do caixa.`)) return;
    const r = await api('/estoque/producao', { method: 'POST', body: { produto_id: atual.id, quantidade: q, observacao: $('#ob', el).value } });
    toast(`Produção #${r.id} registrada. Estoque de ${atual.nome} atualizado (insumos baixam no fechamento do caixa).`);
    $('#pp', el).value = ''; $('#ob', el).value = ''; atual = null; $('#qt', el).value = ''; $('#qt', el).disabled = true; $('#pv', el).innerHTML = ''; $('#reg', el).disabled = true; hist();
  });
  await hist();
} });

// Lançar produção rápida (usada na lista de produtos, no cadastro e na tela de vendas): baixa os insumos e soma ao estoque do produto
async function produzirModal(prodId, depois) {
  const prods = (await api('/produtos?ativos=1')).filter(p => p.tipo === 'preparado' && p.controla_estoque);
  if (!prods.length) return toast('Nenhum prato preparado com "Controla estoque" marcado. Ajuste o cadastro do produto.', 'aviso');
  const corpo = document.createElement('div');
  corpo.innerHTML = `<p class="muted">Informe quantas unidades foram feitas. A quantidade entra no estoque do produto para venda. Os insumos serão baixados no fechamento do caixa (pela sobra que você contar).</p>
    <div class="row"><label style="flex:3">Produto<select id="pz">${prods.map(p => `<option value="${p.id}" ${p.id == prodId ? 'selected' : ''}>${esc(p.nome)} (estoque ${N(p.estoque_atual)} ${p.unidade})</option>`).join('')}</select></label>
    <label>Quantidade feita *<input id="pq" inputmode="decimal" placeholder="ex: 10"></label></div><div id="pv"></div>
    <label>Observação<input id="po" placeholder="ex: lote da tarde"></label>`;
  let falta = false;
  const previa = seguro(async () => {
    const q = numIn($('#pq', corpo).value); if (!(q > 0)) { $('#pv', corpo).innerHTML = ''; falta = false; return; }
    const v = await api(`/estoque/producao/previa?produto_id=${$('#pz', corpo).value}&quantidade=${q}`);
    falta = v.itens.some(x => x.disponivel - x.necessario < -0.0005);
    $('#pv', corpo).innerHTML = tabela([{ l: 'Insumo', k: 'nome' }, { l: 'Uso previsto', n: 1, f: x => `<b>${N(x.necessario)} ${x.unidade}</b>` }, { l: 'Disponível', n: 1, f: x => `<span class="${x.disponivel - x.necessario < -0.0005 ? 'erro' : ''}">${N(x.disponivel)} ${x.unidade}</span>` }], v.itens)
      + (falta ? '<p class="erro">Insumo insuficiente em estoque.</p>' : '');
  });
  corpo.oninput = previa; corpo.onchange = previa;
  modal({ titulo: 'Lançar produção', tam: 'md', corpo, botoes: [{ txt: 'Cancelar' }, { txt: 'Lançar produção', cls: 'primary', fn: async () => {
    const q = numIn($('#pq', corpo).value); if (!(q > 0)) throw new Error('Informe a quantidade feita.'); if (falta) throw new Error('Insumo insuficiente em estoque.');
    const r = await api('/estoque/producao', { method: 'POST', body: { produto_id: +$('#pz', corpo).value, quantidade: q, observacao: $('#po', corpo).value } });
    toast(`Produção #${r.id} lançada: ${N(q)} un. no estoque (insumos baixam no fechamento do caixa).`); if (depois) depois();
  } }] });
}

// ---- Controle de patrimônio: bens não imobilizados (nem revenda nem consumo), comprados ou doados
registrar({ id: 'patrimonio', titulo: 'Patrimônio', grupo: 'Estoque', perm: 'patrimonio.ver', render: async el => {
  const gerir = tem('patrimonio.gerenciar');
  let lista = [];
  const camposBem = [{ k: 'descricao', l: 'Descrição do bem', req: true, full: true }, { k: 'marca', l: 'Marca' }, { k: 'modelo', l: 'Modelo' }, { k: 'serie', l: 'Nº de série' },
    { k: 'valor', l: 'Valor (R$)', t: 'number', step: '0.01' }, { k: 'local', l: 'Local (onde está)' }, { k: 'responsavel', l: 'Responsável' }, { k: 'observacao', l: 'Observações', full: true }];
  const nPat = n => String(n).padStart(5, '0');
  const etiqueta = bs => { // etiqueta para colar no bem (uma ou várias)
    const w = window.open('', '_blank', 'width=520,height=640'); if (!w) return toast('Libere pop-ups para imprimir a etiqueta.', 'aviso');
    w.document.write(`<html><head><meta charset="utf-8"><title>Etiquetas de patrimônio</title><style>body{font-family:Arial,sans-serif;margin:8px}.e{border:2px solid #000;border-radius:6px;padding:8px 12px;margin:6px 0;width:300px;page-break-inside:avoid}.t{font-size:11px;letter-spacing:1px;text-transform:uppercase}.n{font-size:34px;font-weight:bold;letter-spacing:2px}.d{font-size:13px}</style></head><body>${
      bs.map(b => `<div class="e"><div class="t">Patrimônio</div><div class="n">${nPat(b.numero)}</div><div class="d">${esc(b.descricao)}${b.local ? '<br><small>' + esc(b.local) + '</small>' : ''}</div></div>`).join('')}<script>window.onload=()=>setTimeout(()=>window.print(),200)<\/script></body></html>`);
    w.document.close();
  };
  const desenhar = () => {
    const tot = lista.filter(b => b.situacao === 'ativo').reduce((s, b) => s + Number(b.valor), 0);
    $('#res', el).innerHTML = `<div class="cards"><div class="stat">Bens ativos<b>${lista.filter(b => b.situacao === 'ativo').length}</b></div><div class="stat">Valor dos ativos<b>${R(tot)}</b></div><div class="stat">Doados (ativos)<b>${lista.filter(b => b.situacao === 'ativo' && b.origem === 'doacao').length}</b></div></div>` +
      tabela([{ l: 'Nº', f: b => `<b>${nPat(b.numero)}</b>` }, { l: 'Descrição', f: b => `${esc(b.descricao)}${b.marca || b.modelo ? `<br><small class="muted">${esc([b.marca, b.modelo].filter(Boolean).join(' · '))}${b.serie ? ' · série ' + esc(b.serie) : ''}</small>` : ''}` },
        { l: 'Local / responsável', f: b => esc([b.local, b.responsavel].filter(Boolean).join(' · ')) }, { l: 'Origem', f: b => b.origem === 'doacao' ? chip('Doação', 'warn') : chip('Compra') },
        { l: 'Aquisição', f: b => dia(b.data_aquisicao) + (b.nota ? `<br><small class="muted">NF ${esc(b.nota)}</small>` : '') + (b.fornecedor ? `<br><small class="muted">${esc(b.fornecedor)}</small>` : '') },
        { l: 'Valor', n: 1, f: b => R(b.valor) }, { l: 'Situação', f: b => b.situacao === 'ativo' ? chip('Ativo', 'ok') : chip('Baixado', 'erro') + `<br><small class="muted">${dia(b.baixa_em)} · ${esc(b.baixa_motivo || '')}</small>` }],
      lista, { vazio: 'Nenhum bem encontrado. Os bens entram pela Entrada de mercadoria (destino Patrimônio) ou pelo botão "+ Novo bem".', rowCls: b => b.situacao === 'baixado' ? 'low' : '',
        acoes: b => `<button class="btn sm" data-et="${b.id}">Etiqueta</button>` + (gerir ? ` <button class="btn sm" data-ed="${b.id}">Editar</button>` + (b.situacao === 'ativo' ? ` <button class="btn sm danger" data-bx="${b.id}">Baixar</button>` : ` <button class="btn sm" data-re="${b.id}">Reativar</button>`) : '') });
  };
  const carregar = seguro(async () => { lista = await api('/patrimonio?' + qs({ q: $('#bq', el).value, situacao: $('#bs', el).value, origem: $('#bo', el).value })); desenhar(); });
  el.innerHTML = `<div class="bar"><input id="bq" placeholder="Buscar por nº, descrição, local, série..."><select id="bs"><option value="ativo">Só ativos</option><option value="baixado">Só baixados</option><option value="">Todos</option></select>
    <select id="bo"><option value="">Compra e doação</option><option value="compra">Só compra</option><option value="doacao">Só doação</option></select><div class="grow"></div>
    ${gerir ? '<button class="btn primary" id="novo">+ Novo bem</button>' : ''}<button class="btn" id="csv">CSV</button><button class="btn" id="etall">Etiquetas da lista</button></div><div id="res"></div>`;
  let t; $('#bq', el).oninput = () => { clearTimeout(t); t = setTimeout(carregar, 300); }; $('#bs', el).onchange = $('#bo', el).onchange = carregar;
  $('#csv', el).onclick = () => csv('patrimonio', [{ l: 'Nº', k: 'numero' }, { l: 'Descrição', k: 'descricao' }, { l: 'Marca', k: 'marca' }, { l: 'Modelo', k: 'modelo' }, { l: 'Série', k: 'serie' }, { l: 'Local', k: 'local' }, { l: 'Responsável', k: 'responsavel' }, { l: 'Origem', k: 'origem' }, { l: 'Valor', k: 'valor' }, { l: 'Aquisição', k: 'data_aquisicao' }, { l: 'Situação', k: 'situacao' }, { l: 'Baixa', k: 'baixa_em' }, { l: 'Motivo da baixa', k: 'baixa_motivo' }], lista);
  $('#etall', el).onclick = () => lista.length ? etiqueta(lista) : toast('Nada na lista.', 'aviso');
  if (gerir) $('#novo', el).onclick = () => formModal({ titulo: 'Novo bem (já existente na casa, sem nota)', tam: 'md', valores: { quantidade: 1, origem: 'compra' },
    campos: [{ k: 'quantidade', l: 'Quantidade (um nº para cada)', t: 'number', step: '1' }, { k: 'origem', l: 'Origem', t: 'select', op: [['compra', 'Compra'], ['doacao', 'Doação']] }, ...camposBem],
    onSave: async o => { const r = await api('/patrimonio', { method: 'POST', body: o }); toast('Cadastrado: patrimônio nº ' + r.numeros.join(', ') + '.'); carregar(); } });
  el.onclick = seguro(async e => {
    const d = e.target.dataset, b = lista.find(x => x.id == (d.et || d.ed || d.bx || d.re)); if (!b) return;
    if (d.et) return etiqueta([b]);
    if (d.ed) return formModal({ titulo: `Editar patrimônio nº ${nPat(b.numero)}`, tam: 'md', valores: b, campos: camposBem, onSave: async o => { await api('/patrimonio/' + b.id, { method: 'PUT', body: o }); toast('Salvo.'); carregar(); } });
    if (d.bx) return formModal({ titulo: `Baixar patrimônio nº ${nPat(b.numero)} — ${b.descricao}`, valores: { data: hojeISO() },
      campos: [{ k: 'data', l: 'Data da baixa', t: 'date', req: true }, { k: 'motivo', l: 'Motivo (venda, perda, quebra, descarte, devolução...)', req: true, full: true }],
      onSave: async o => { await api(`/patrimonio/${b.id}/baixar`, { method: 'POST', body: o }); toast('Baixa registrada.'); carregar(); } });
    if (d.re) { await api(`/patrimonio/${b.id}/reativar`, { method: 'POST' }); toast('Bem reativado.'); carregar(); }
  });
  await carregar();
} });

// ---- Consignações: mercadoria que entra no estoque sem pagar; devolve-se o que não foi usado e o acerto gera o contas a pagar
registrar({ id: 'consignacoes', titulo: 'Consignações', grupo: 'Estoque', perm: 'estoque.ver', render: async el => {
  const gerir = tem('estoque.entrada');
  let status = 'aberta', lista = [];
  const pendentes = card => $$('[data-dv]', card).map(i => ({ item_id: +i.dataset.dv, qtd: numIn(i.value) })).filter(d => d.qtd > 0);
  const aPagar = (c, pend) => c.itens.reduce((s, i) => s + (Number(i.quantidade) - Number(i.qtd_devolvida) - (pend.find(d => d.item_id === i.id)?.qtd || 0)) * Number(i.custo_unit), 0);
  const desenhar = () => {
    $('#res', el).innerHTML = lista.length ? lista.map(c => `<div class="card" data-c="${c.id}"><div class="bar" style="margin:0 0 8px"><b>Consignação #${c.id}</b> · ${esc(c.fornecedor || 'sem fornecedor')}${c.numero ? ' · doc. ' + esc(c.numero) : ''} · recebida em ${dt(c.criado_em)}
      ${c.consig_status === 'acertada' ? chip('Acertada', 'ok') + ` <span class="muted">NF ${esc(c.acerto_nf)} · ${dt(c.acerto_em)} · pago ${R(c.acerto_total)}</span>` : chip('Em aberto', 'warn')}</div>
      ${tabela([{ l: 'Produto', k: 'produto' }, { l: 'Recebido', n: 1, f: i => N(i.quantidade) + ' ' + i.unidade }, { l: 'Devolvido', n: 1, f: i => N(i.qtd_devolvida) }, { l: 'Fica com a casa', n: 1, f: i => `<b>${N(Number(i.quantidade) - Number(i.qtd_devolvida))}</b>` },
        { l: 'Custo un.', n: 1, f: i => R(i.custo_unit) }, { l: 'Estoque atual', n: 1, f: i => N(i.estoque_atual) },
        ...(c.consig_status === 'aberta' && gerir ? [{ l: 'Devolver agora', n: 1, f: i => `<input data-dv="${i.id}" inputmode="decimal" style="width:90px" placeholder="0">` }] : [])], c.itens)}
      ${c.consig_status === 'aberta' && gerir ? `<div class="bar" style="margin-top:8px"><span class="muted">A pagar no acerto: <b data-ap>${R(aPagar(c, []))}</b></span><div class="grow"></div><button class="btn" data-dev="${c.id}">Registrar devolução (sem acertar)</button><button class="btn primary" data-ace="${c.id}">Acertar com a nota final</button></div>` : ''}</div>`).join('')
      : `<div class="card muted">${status === 'aberta' ? 'Nenhuma consignação em aberto. Na Entrada de mercadoria marque "Nota consignada".' : 'Nenhuma consignação acertada.'}</div>`;
  };
  const carregar = seguro(async () => { lista = await api('/estoque/consignacoes?status=' + status); desenhar(); });
  el.innerHTML = `<div class="tabs"><button data-st="aberta" class="on">Em aberto</button><button data-st="acertada">Acertadas</button></div>
    <p class="muted">Mercadoria consignada entra no estoque sem gerar conta a pagar. Registre as devoluções do que não foi usado; no fim, o <b>acerto</b> usa a nota final do fornecedor e gera as parcelas a pagar só do que ficou (recebido − devolvido). O que ficar sobrando no estoque passa a ser da casa.</p><div id="res"></div>`;
  el.oninput = e => { if (!e.target.matches('[data-dv]')) return; const card = e.target.closest('[data-c]'), c = lista.find(x => x.id == card.dataset.c); $('[data-ap]', card).textContent = R(aPagar(c, pendentes(card))); };
  el.onclick = seguro(async e => {
    const d = e.target.dataset;
    if (d.st) { status = d.st; $$('[data-st]', el).forEach(b => b.classList.toggle('on', b === e.target)); return carregar(); }
    const id = d.dev || d.ace; if (!id) return;
    const card = e.target.closest('[data-c]'), c = lista.find(x => x.id == id), pend = pendentes(card);
    if (d.dev) { if (!pend.length) throw new Error('Informe a quantidade devolvida de ao menos um item.'); await api(`/estoque/consignacoes/${id}/devolver`, { method: 'POST', body: { devolucoes: pend } }); toast('Devolução registrada (saiu do estoque).'); return carregar(); }
    const total = Math.round(aPagar(c, pend) * 100) / 100;
    formModal({ titulo: `Acertar consignação #${c.id} — ${c.fornecedor || ''}`, tam: 'md',
      extra: `<p>Devolvendo agora: <b>${pend.length}</b> item(ns). Valor a pagar ao fornecedor: <b>${R(total)}</b>.</p><p class="muted">Depois de salvar você escolhe vencimentos e parcelas. Esta nota final <b>não</b> deve ser importada de novo pelo XML (o sistema bloqueia se a chave for informada aqui).</p>`,
      campos: [{ k: 'numero', l: 'Nº da nota final do fornecedor', req: true }, { k: 'chave', l: 'Chave de acesso da nota (44 dígitos, opcional)', full: true }],
      onSave: async o => {
        const dsp = total > 0 ? await lancarDespesa({ total, fornecedor: c.fornecedor || '' }) : { titulos: [] };
        if (!dsp) return false;
        const r = await api(`/estoque/consignacoes/${id}/acerto`, { method: 'POST', body: { ...o, devolucoes: pend, titulos: dsp.titulos, categoria_despesa: dsp.categoria } });
        toast(`Consignação acertada: ${R(r.total)}${r.titulos ? ', ' + r.titulos + ' conta(s) a pagar' : ''}.`); carregar();
      } });
  });
  await carregar();
} });
