// Cadastros: produtos (com ficha técnica de insumos), clientes, fornecedores e categorias.
const UNID = ['UN', 'KG', 'G', 'L', 'ML', 'CX', 'PCT'].map(u => [u, u]);
const TIPOS = [['revenda', 'Revenda (produto pronto: cerveja, refrigerante...)'], ['insumo', 'Insumo / matéria-prima (kg, litro...)'], ['preparado', 'Prato / preparado (usa ficha técnica)']];

registrar({ id: 'produtos', titulo: 'Produtos e insumos', grupo: 'Cadastros', perm: 'cadastros.ver', render: async el => {
  let dados = [], cats = [];
  const desenhar = () => {
    const q = $('#bq', el).value.toLowerCase(), t = $('#bt', el).value;
    const l = dados.filter(p => (!t || p.tipo === t) && (!q || (p.nome + ' ' + (p.codigo || '') + ' ' + ((p.codigos_barras || []).join(' ')) + ' ' + (p.categoria || '')).toLowerCase().includes(q)));
    $('#lista', el).innerHTML = tabela([{ l: 'Código', k: 'codigo' }, { l: 'Códigos de barras', f: p => (p.codigos_barras || []).map(esc).join('<br>') || '<span class="muted">—</span>' }, { l: 'Nome', f: p => esc(p.nome) + (p.ativo ? '' : ' ' + chip('inativo', 'cancelado')) }, { l: 'Categoria', k: 'categoria' }, { l: 'Tipo', k: 'tipo' }, { l: 'Destino', k: 'destino' },
      { l: 'Preço', n: 1, f: p => (p.vendavel ? R(p.preco_venda) : '—') }, { l: 'Custo méd.', n: 1, f: p => R(p.custo_medio) }, { l: 'Estoque', n: 1, f: p => (p.controla_estoque ? N(p.estoque_atual) + ' ' + p.unidade : '—') }], l,
      { rowCls: p => (p.controla_estoque && p.estoque_minimo > 0 && p.estoque_atual <= p.estoque_minimo ? 'low' : ''),
        acoes: p => (tem('estoque.producao') && p.tipo === 'preparado' && p.controla_estoque ? `<button class="btn sm" data-pz="${p.id}">Produzir</button> ` : '') + (tem('cadastros.editar') ? `<button class="btn sm" data-ed="${p.id}">Editar</button> ` : '') + (tem('cadastros.excluir') ? `<button class="btn sm danger" data-ex="${p.id}">Excluir</button>` : '') });
  };
  const carregar = seguro(async () => { [dados, cats] = await Promise.all([api('/produtos'), api('/categorias')]); desenhar(); });
  el.innerHTML = `<div class="bar"><input id="bq" placeholder="Buscar nome, código, categoria..."><select id="bt"><option value="">Todos os tipos</option><option value="revenda">Revenda</option><option value="insumo">Insumo</option><option value="preparado">Preparado</option></select><div class="grow"></div>
    ${tem('cadastros.editar') ? '<button class="btn" id="cats">Categorias</button><button class="btn primary" id="novo">+ Novo produto</button>' : ''}</div><div id="lista"></div>`;
  $('#bq', el).oninput = desenhar; $('#bt', el).onchange = desenhar;

  const abrir = async reg => {
    const p = reg ? await api('/produtos/' + reg.id) : { tipo: 'revenda', unidade: 'UN', destino: 'nenhum', ativo: true, vendavel: true, controla_estoque: true, permite_obs: false, receita: [] };
    const insumos = dados.filter(x => x.tipo === 'insumo' || x.tipo === 'revenda').filter(x => !reg || x.id !== reg.id);
    const campos = [
      { k: 'nome', l: 'Nome', req: true, full: true }, { k: 'codigo', l: 'Código interno (automático)', ro: true, ph: 'Gerado ao gravar' },
      { k: 'categoria_id', l: 'Categoria', t: 'select', op: [['', '—']].concat(cats.map(c => [c.id, c.nome])) }, { k: 'unidade', l: 'Unidade de estoque', t: 'select', op: UNID },
      { k: 'tipo', l: 'Tipo', t: 'select', op: TIPOS, full: true }, { k: 'destino', l: 'Vai para (pedido impresso)', t: 'select', op: [['nenhum', 'Nenhum (entrega no balcão)'], ['cozinha', 'Cozinha'], ['bar', 'Bar']] },
      { k: 'preco_venda', l: 'Preço de venda (R$)', t: 'number', step: '0.01' }, { k: 'estoque_minimo', l: 'Estoque mínimo', t: 'number', step: '0.001' },
      { k: 'controla_estoque', l: 'Controla estoque deste item', t: 'check' }, { k: 'vendavel', l: 'Pode ser vendido', t: 'check' }, { k: 'permite_obs', l: 'Permite observação na venda (ex.: sem cebola)', t: 'check' }, { k: 'ativo', l: 'Ativo', t: 'check' }];
    const info = reg ? `<p class="muted">Estoque atual: <b>${N(p.estoque_atual)} ${p.unidade}</b> · Custo médio: <b>${R(p.custo_medio)}</b> (alterados por entradas/ajustes em "Estoque")</p>` : '';
    const forn = await api('/fornecedores');
    const barras = `<div class="cbarras"><h4>Códigos de barras deste item <small class="muted">(o primeiro é o principal; fator = unidades dentro da embalagem daquele código, ex.: fardo com 5 → 5)</small></h4><div id="cbl"></div>
      <div class="row"><label>Novo código de barras<input id="cbn" inputmode="numeric" placeholder="digite ou leia com o leitor"></label><label style="max-width:120px">Fator<input id="cbf" value="1" inputmode="decimal"></label><button class="btn sm auto" type="button" id="cba">+ Adicionar</button></div></div>
      <div class="cbarras"><h4>Códigos do fornecedor <small class="muted">(como cada fornecedor chama este produto; usados na entrada por XML)</small></h4><div id="cfl"></div>
      <div class="row"><label>Fornecedor<select id="cfs">${forn.map(f => `<option value="${f.id}">${esc(f.nome)}</option>`).join('') || '<option value="">Cadastre um fornecedor primeiro</option>'}</select></label><label>Código no fornecedor<input id="cfc"></label><label style="max-width:120px">Fator<input id="cff" value="1" inputmode="decimal"></label><button class="btn sm auto" type="button" id="cfa">+ Adicionar</button></div></div>`;
    let imagem = p.imagem || '';
    const imgBox = `<div class="cbarras"><h4>Imagem do produto <small class="muted">(aparece no botão da tela de vendas)</small></h4>
      <div style="display:flex;gap:12px;align-items:center"><div class="vimg" id="pprev" style="width:96px;height:96px"></div>
      <div><input type="file" id="pfile" accept="image/*"><br><button class="btn sm danger" type="button" id="pimgx" style="margin-top:6px">Remover imagem</button></div></div></div>`;
    const pagora = tem('estoque.producao') ? `<div class="cbarras" id="pgbox"><h4>Produzir agora <small class="muted">(opcional: quantas unidades já foram feitas; entra no estoque do produto; os insumos baixam no fechamento do caixa)</small></h4><label style="max-width:220px">Quantidade feita<input id="pgq" inputmode="decimal" placeholder="ex: 10"></label></div>` : '';
    const rec = `<div id="recbox" class="${p.tipo === 'preparado' ? '' : 'hidden'}"><h4>Ficha técnica (insumos usados em <u>1 unidade</u> do produto)</h4><p class="muted"><b>Como lançar:</b> escolha o insumo, digite quanto dele vai em <u>1 unidade</u> do prato e escolha a unidade (a lista mostra a unidade do estoque do insumo e, para quilo/grama e litro/mililitro, a outra também — o sistema converte sozinho). Ex.: pipoca — milho 0,05 kg, óleo 0,01 L, saco 1 un por pacote. <b>Se o produto é feito antes e fica em estoque</b> (ex.: pipoca), deixe "Controla estoque deste item" marcado e registre a quantidade feita em <b>Estoque → Produção</b>: aí a venda baixa só o produto e os insumos baixam no <b>fechamento do caixa</b>, pela sobra que você contar. <b>Se é feito na hora</b>, desmarque "Controla estoque": a venda baixa os insumos direto.</p><div id="recs"></div>
      <button class="btn sm" type="button" id="addrec">+ insumo</button><datalist id="dl-ins">${insumos.map(i => `<option value="${esc(rotuloProd(i))}">`).join('')}</datalist></div>`;
    const cbs = (p.codigos_barras_det || []).map(x => ({ c: x.codigo_barras, f: x.fator })), cfs = (p.codigos_fornecedor || []).map(x => ({ fid: x.fornecedor_id, forn: x.fornecedor, c: x.codigo_fornecedor, f: x.fator }));
    const m = formModal({ titulo: reg ? 'Editar produto' : 'Novo produto', campos, valores: p, tam: 'md', extra: info + barras + imgBox + rec + (pagora ? pagora.replace('id="pgbox"', 'id="pgbox"') : ''),
      onSave: async (o, mm) => {
        const pend = $('#cbn', mm.body).value.trim(); if (pend && !cbs.some(x => x.c === pend)) cbs.push({ c: pend, f: numIn($('#cbf', mm.body).value) || 0 });
        const pf = $('#cfc', mm.body).value.trim(); if (pf && $('#cfs', mm.body).value) cfs.push({ fid: +$('#cfs', mm.body).value, c: pf, f: numIn($('#cff', mm.body).value) || 0 });
        if (cbs.some(x => !(x.f > 0)) || cfs.some(x => !(x.f > 0))) throw new Error('Informe o fator de cada código (1 se for unitário).');
        o.imagem = imagem;
        o.codigos_barras = cbs.map(x => ({ codigo_barras: x.c, fator: x.f })); o.codigos_fornecedor = cfs.map(x => ({ fornecedor_id: x.fid, codigo_fornecedor: x.c, fator: x.f }));
        o.receita = o.tipo === 'preparado' ? $$('.rec', mm.body).map(r => ({ insumo_id: idDoRotulo($('[data-i]', r).value), quantidade: Math.round(numIn($('[data-q]', r).value) * paraUnidadeBase(r) * 1e6) / 1e6 })).filter(r => r.insumo_id && r.quantidade > 0) : [];
        if (o.tipo === 'preparado' && !o.receita.length && !o.controla_estoque && !await confirmar('Prato sem ficha técnica não baixa estoque de insumos. Salvar assim mesmo?')) return false;
        const pq = tem('estoque.producao') && o.tipo === 'preparado' && o.controla_estoque ? numIn(($('#pgq', mm.body) || {}).value) : 0;
        const sv = await api('/produtos' + (reg ? '/' + reg.id : ''), { method: reg ? 'PUT' : 'POST', body: o }); toast('Produto salvo.');
        if (pq > 0) { const rp = await api('/estoque/producao', { method: 'POST', body: { produto_id: reg ? reg.id : sv.id, quantidade: pq, observacao: 'Lançada no cadastro do produto' } }); toast(`Produção #${rp.id} lançada: ${N(pq)} un. no estoque (insumos baixam no fechamento do caixa).`); }
        carregar();
      } });
    const prev = () => { $('#pprev', m.body).innerHTML = imagem ? `<img src="${imagem}" alt="">` : `<div class="noimg">${esc(((p.nome || '?').trim().charAt(0) || '?').toUpperCase())}</div>`; };
    prev();
    $('#pimgx', m.body).onclick = () => { imagem = ''; $('#pfile', m.body).value = ''; prev(); };
    $('#pfile', m.body).onchange = e => { const f = e.target.files[0]; if (!f) return; const rd = new FileReader();
      rd.onload = () => { const im = new Image(); im.onload = () => { const L = 240, s = Math.min(1, L / Math.max(im.width, im.height)), cv = document.createElement('canvas'); cv.width = Math.round(im.width * s); cv.height = Math.round(im.height * s);
        const cx = cv.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height); cx.drawImage(im, 0, 0, cv.width, cv.height); imagem = cv.toDataURL('image/jpeg', 0.8); prev(); }; im.onerror = () => toast('Não foi possível ler esta imagem.', 'aviso'); im.src = rd.result; };
      rd.readAsDataURL(f); };
    const linha = (r = {}) => `<div class="row rec"><label>Insumo<input data-i list="dl-ins" value="${r.insumo_id ? esc(r.nome + ' (#' + r.insumo_id + ')') : ''}" placeholder="digite para buscar"></label>
      <label class="auto" style="width:120px">Quantidade usada<input data-q value="${r.quantidade ?? ''}" inputmode="decimal" placeholder="ex: 0,05"></label>
      <label class="auto" style="width:110px">Unidade<select data-u></select></label><button class="btn sm danger auto" type="button" data-x>✕</button></div>`;
    // Unidade: mostra a unidade do insumo (a que o estoque usa) e, para kg/g e L/ml, permite lançar na outra (o sistema converte)
    const CONV = { KG: [['KG', 1], ['G', 1000]], G: [['G', 1], ['KG', 0.001]], L: [['L', 1], ['ML', 1000]], ML: [['ML', 1], ['L', 0.001]] };
    const paraUnidadeBase = row => { const ins = insDe(row), un = ins ? String(ins.unidade || 'UN').toUpperCase() : '', c = (CONV[un] || []).find(x => x[0] === $('[data-u]', row).value); return c ? 1 / c[1] : 1; };
    const insDe = row => { const id = idDoRotulo($('[data-i]', row).value); return insumos.find(x => x.id == id); };
    const ajustaUn = row => { const sel = $('[data-u]', row), ins = insDe(row), un = ins ? String(ins.unidade || 'UN').toUpperCase() : '';
      const lista = CONV[un] ? CONV[un].map(c => c[0]) : (un ? [un] : []); const ant = sel.value;
      sel.innerHTML = lista.length ? lista.map(u => `<option ${u === (lista.includes(ant) ? ant : un) ? 'selected' : ''}>${u}</option>`).join('') : '<option value="">escolha o insumo</option>';
      row.title = ins ? `O estoque de "${ins.nome}" é controlado em ${un}.` : ''; };
    const desenharCb = () => {
      const th = h => `<thead><tr>${h.map(x => `<th>${x}</th>`).join('')}</tr></thead>`;
      $('#cbl', m.body).innerHTML = cbs.length ? `<table class="tcb">${th(['Código de barras', 'Tipo', 'Fator (un. na embalagem)', ''])}<tbody>${cbs.map((c, i) => `<tr><td><b>${esc(c.c)}</b></td><td>${i === 0 ? '<span class="chip">principal</span>' : '<span class="muted">adicional</span>'}</td><td><input data-cbf="${i}" value="${esc(c.f)}" inputmode="decimal"></td><td><button class="btn sm danger" type="button" data-cbx="${i}">✕</button></td></tr>`).join('')}</tbody></table>` : '<p class="muted">Nenhum código de barras.</p>';
      $('#cfl', m.body).innerHTML = cfs.length ? `<table class="tcb">${th(['Fornecedor', 'Código no fornecedor', 'Fator (un. na embalagem)', ''])}<tbody>${cfs.map((c, i) => `<tr><td><b>${esc(c.forn || (forn.find(f => f.id == c.fid) || {}).nome || '')}</b></td><td>${esc(c.c)}</td><td><input data-cff="${i}" value="${esc(c.f)}" inputmode="decimal"></td><td><button class="btn sm danger" type="button" data-cfx="${i}">✕</button></td></tr>`).join('')}</tbody></table>` : '<p class="muted">Nenhum código de fornecedor.</p>'; };
    const addCb = () => { const i = $('#cbn', m.body), v = i.value.trim(); if (!v) return; const f = numIn($('#cbf', m.body).value); if (!(f > 0)) return toast('Informe o fator (1 se for unitário).', 'aviso');
      if (cbs.some(x => x.c === v)) toast('Esse código já está na lista.', 'aviso'); else cbs.push({ c: v, f }); i.value = ''; $('#cbf', m.body).value = '1'; desenharCb(); i.focus(); };
    const addCf = () => { const v = $('#cfc', m.body).value.trim(), fid = +$('#cfs', m.body).value, f = numIn($('#cff', m.body).value); if (!v || !fid) return; if (!(f > 0)) return toast('Informe o fator (1 se for unitário).', 'aviso');
      if (cfs.some(x => x.fid === fid && x.c === v)) toast('Esse código já está na lista.', 'aviso'); else cfs.push({ fid, forn: (forn.find(x => x.id === fid) || {}).nome, c: v, f }); $('#cfc', m.body).value = ''; $('#cff', m.body).value = '1'; desenharCb(); };
    m.body.addEventListener('input', e => { if (e.target.dataset.cbf !== undefined) cbs[+e.target.dataset.cbf].f = numIn(e.target.value); if (e.target.dataset.cff !== undefined) cfs[+e.target.dataset.cff].f = numIn(e.target.value); });
    desenharCb();
    $('#cbn', m.body).addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); addCb(); } });
    $('#recs', m.body).innerHTML = (p.receita || []).map(linha).join(''); $$('.rec', m.body).forEach(ajustaUn);
    m.body.addEventListener('input', e => { if (e.target.matches('[data-i]')) ajustaUn(e.target.closest('.rec')); });
    // porções, pratos e sobremesas: "permite observação" marcado por padrão ao escolher a categoria (o usuário pode desmarcar)
    m.body.addEventListener('change', e => { if (e.target.dataset.k !== 'categoria_id') return; const ct = cats.find(c => c.id == e.target.value);
      const nm = ct ? ct.nome.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase() : ''; const ck = $('[data-k="permite_obs"]', m.body);
      if (ck && /(porco|prato|sobremesa)/.test(nm)) ck.checked = true; });
    m.body.addEventListener('change', e => { if (e.target.matches('[data-i]')) ajustaUn(e.target.closest('.rec')); });
    m.body.addEventListener('click', e => { if (e.target.id === 'cba') addCb(); if (e.target.id === 'cfa') addCf(); if (e.target.dataset.cfx !== undefined) { cfs.splice(+e.target.dataset.cfx, 1); desenharCb(); } if (e.target.dataset.cbx !== undefined) { cbs.splice(+e.target.dataset.cbx, 1); desenharCb(); } if (e.target.id === 'addrec') $('#recs', m.body).insertAdjacentHTML('beforeend', linha()); if (e.target.dataset.x !== undefined) e.target.closest('.rec').remove(); });
    m.body.addEventListener('change', e => {
      if (e.target.dataset.k === 'tipo') {
        const t = e.target.value; $('#recbox', m.body).classList.toggle('hidden', t !== 'preparado');
        $('[data-k=vendavel]', m.body).checked = t !== 'insumo'; $('[data-k=controla_estoque]', m.body).checked = t !== 'preparado';
        if (t === 'preparado') $('[data-k=destino]', m.body).value = 'cozinha';
      }
    });
  };
  if ($('#novo', el)) $('#novo', el).onclick = seguro(() => abrir(null));
  if ($('#cats', el)) $('#cats', el).onclick = seguro(async () => {
    const mm = modal({ titulo: 'Categorias', corpo: '<div id="cl"></div><div class="row" style="margin-top:10px"><label>Nova categoria<input id="cn"></label><button class="btn primary auto" id="ca">Adicionar</button></div>', botoes: [{ txt: 'Fechar' }] });
    const lst = () => { $('#cl', mm.body).innerHTML = cats.map(c => `<div class="it" style="display:flex;gap:8px;padding:4px 0"><span style="flex:1">${esc(c.nome)}</span><button class="btn sm" data-ren="${c.id}">Renomear</button><button class="btn sm danger" data-del="${c.id}">Excluir</button></div>`).join('') || '<p class="muted">Nenhuma.</p>'; };
    lst();
    mm.body.onclick = seguro(async e => {
      if (e.target.id === 'ca') { const n = $('#cn', mm.body).value.trim(); if (!n) return; await api('/categorias', { method: 'POST', body: { nome: n } }); cats = await api('/categorias'); $('#cn', mm.body).value = ''; lst(); }
      if (e.target.dataset.del && await confirmar('Excluir categoria?')) { await api('/categorias/' + e.target.dataset.del, { method: 'DELETE' }); cats = await api('/categorias'); lst(); }
      if (e.target.dataset.ren) { const c = cats.find(x => x.id == e.target.dataset.ren); const n = prompt('Novo nome', c.nome); if (n && n.trim()) { await api('/categorias/' + c.id, { method: 'PUT', body: { nome: n } }); cats = await api('/categorias'); lst(); } }
    });
  });
  el.onclick = seguro(async e => {
    if (e.target.dataset.pz) return produzirModal(+e.target.dataset.pz, carregar);
    if (e.target.dataset.ed) abrir(dados.find(d => d.id == e.target.dataset.ed));
    if (e.target.dataset.ex && await confirmar('Excluir produto? Só é possível se ele nunca teve movimento; caso contrário, inative-o em Editar.')) { await api('/produtos/' + e.target.dataset.ex, { method: 'DELETE' }); toast('Excluído.'); carregar(); }
  });
  await carregar();
} });

crudView({ id: 'clientes', titulo: 'Clientes', grupo: 'Cadastros', perm: 'cadastros.ver', endpoint: '/clientes',
  campos: [{ k: 'nome', l: 'Nome', req: true, full: true }, { k: 'documento', l: 'CPF/CNPJ' }, { k: 'telefone', l: 'Telefone' }, { k: 'email', l: 'E-mail', full: true }, { k: 'endereco', l: 'Endereço', full: true }, { k: 'observacao', l: 'Observações', t: 'textarea', full: true }, { k: 'ativo', l: 'Ativo', t: 'check', padrao: true }],
  cols: [{ l: 'Nome', k: 'nome' }, { l: 'Documento', k: 'documento' }, { l: 'Telefone', k: 'telefone' }, { l: 'E-mail', k: 'email' }, { l: 'Situação', f: r => chip(r.ativo ? 'ativo' : 'inativo', r.ativo ? 'ok' : 'cancelado') }] });

crudView({ id: 'fornecedores', titulo: 'Fornecedores', grupo: 'Cadastros', perm: 'cadastros.ver', endpoint: '/fornecedores',
  campos: [{ k: 'nome', l: 'Razão social / Nome', req: true, full: true }, { k: 'fantasia', l: 'Nome fantasia' }, { k: 'documento', l: 'CNPJ/CPF (somente números)' }, { k: 'contato', l: 'Pessoa de contato' }, { k: 'telefone', l: 'Telefone' },
    { k: 'email', l: 'E-mail', full: true }, { k: 'endereco', l: 'Endereço', full: true }, { k: 'cidade', l: 'Cidade' }, { k: 'uf', l: 'UF' }, { k: 'condicao_pagamento', l: 'Condição de pagamento', ph: 'ex: 30/60 dias', full: true },
    { k: 'observacao', l: 'Observações', t: 'textarea', full: true }, { k: 'ativo', l: 'Ativo', t: 'check', padrao: true }],
  cols: [{ l: 'Nome', f: r => esc(r.nome) + (r.fantasia ? `<br><small class="muted">${esc(r.fantasia)}</small>` : '') }, { l: 'CNPJ/CPF', k: 'documento' }, { l: 'Contato', k: 'contato' }, { l: 'Telefone', k: 'telefone' }, { l: 'Cidade', f: r => esc([r.cidade, r.uf].filter(Boolean).join('/')) }, { l: 'Pagamento', k: 'condicao_pagamento' }, { l: 'Situação', f: r => chip(r.ativo ? 'ativo' : 'inativo', r.ativo ? 'ok' : 'cancelado') }] });

// ---- Formas de pagamento (com integração TEF por pastas)
const TIPOS_FORMA = [['dinheiro', 'Dinheiro'], ['pix', 'PIX'], ['debito', 'Cartão de débito'], ['credito', 'Cartão de crédito'], ['voucher', 'Voucher / Vale'], ['fiado', 'Fiado (cliente)'], ['consignado', 'Consignado (pagar compra ao fornecedor depois, conforme a venda)'], ['outro', 'Outro']];
const TEF_PADRAO = { tef_dir_envio: 'C:/TEF_DIAL/REQ/', tef_arq_envio: 'IntPos', tef_ext_envio: '001', tef_dir_retorno: 'C:/TEF_DIAL/RESP/', tef_arq_retorno: 'IntPos', tef_ext_retorno: '001',
  tef_dir_status: 'C:/TEF_DIAL/RESP/', tef_arq_status: 'IntPos', tef_ext_status: 'sts', tef_dir_temp: 'C:/TEF_DIAL/REQ/', tef_arq_temp: 'IntPos', tef_ext_temp: 'pod', tef_dir_exec: 'C:/TEF_DIAL/TEF_DIAL.EXE', tef_provedor: 'SITEF' };

// Navegador de pastas do SERVIDOR (o TEF é lido pelo servidor do sistema)
function escolherPasta(inicial, arquivos = false) {
  return new Promise(resolve => {
    let atual = inicial || '';
    const desenhar = async m => {
      let d; try { d = await api('/fs/listar?' + qs({ dir: atual, arquivos: arquivos ? 1 : '' })); } catch (e) { if (atual) { atual = ''; return desenhar(m); } toast(e.message, 'erro'); return; }
      atual = d.dir;
      m.body.innerHTML = `<div class="muted">Pasta no computador servidor:</div><div style="font-weight:600;margin:4px 0 10px;word-break:break-all">${esc(d.dir || 'Meu computador')}</div>
        <div style="max-height:44vh;overflow:auto;border:1px solid var(--br);border-radius:8px">${d.pai !== null && d.dir ? `<div class="it" data-ir="${esc(d.pai)}" style="padding:8px 10px;cursor:pointer;border-bottom:1px solid var(--br)">⬆ Subir um nível</div>` : ''}
        ${(d.arquivos || []).map(p => `<div data-arq="${esc(p.caminho)}" style="padding:8px 10px;cursor:pointer;border-bottom:1px solid var(--br);font-weight:600">⚙ ${esc(p.nome)}</div>`).join('')}
        ${d.pastas.map(p => `<div data-ir="${esc(p.caminho)}" style="padding:8px 10px;cursor:pointer;border-bottom:1px solid var(--br)">📁 ${esc(p.nome)}</div>`).join('') || '<div class="muted" style="padding:10px">Sem subpastas.</div>'}</div>`;
      $$('[data-arq]', m.body).forEach(x => { x.onclick = () => { resolve(x.dataset.arq); m.fechar(); }; });
      $$('[data-ir]', m.body).forEach(x => { x.onclick = () => { atual = x.dataset.ir; desenhar(m); }; x.onmouseenter = () => (x.style.background = '#f0f1f4'); x.onmouseleave = () => (x.style.background = ''); });
    };
    modal({ titulo: arquivos ? 'Escolher o executável do TEF (.exe)' : 'Escolher pasta', corpo: '<p class="muted">Carregando...</p>', botoes: [{ txt: 'Cancelar', fn: () => resolve(null) },
      { txt: arquivos ? 'Cancelar escolha' : 'Selecionar esta pasta', cls: 'primary', fn: () => { if (arquivos) { resolve(null); return; } if (!atual) throw new Error('Entre em um disco/pasta primeiro.'); resolve(atual); } }], aoAbrir: m => desenhar(m) });
  });
}

registrar({ id: 'formas', titulo: 'Formas de pagamento', grupo: 'Cadastros', perm: 'formas.gerenciar', render: async el => {
  let dados = [];
  const desenhar = () => { $('#lista', el).innerHTML = tabela([{ l: 'Descrição', k: 'descricao' }, { l: 'Tipo', f: r => esc((TIPOS_FORMA.find(t => t[0] === r.tipo) || [])[1] || r.tipo) },
    { l: 'Parcelas até', n: 1, f: r => (r.tipo === 'credito' ? r.max_parcelas + 'x' : '—') }, { l: 'Taxa da máquina', n: 1, f: r => [Number(r.taxa_pct) ? N(r.taxa_pct, 3) + '%' : '', Number(r.taxa_fixa) ? R(r.taxa_fixa) : ''].filter(Boolean).join(' + ') || '—' }, { l: 'Recebe em', n: 1, f: r => (r.dias_recebimento ? r.dias_recebimento + ' dias' : 'À vista') },
    { l: 'TEF', f: r => (r.tef_ativo ? chip('integrado', 'ok') : '<span class="muted">—</span>') }, { l: 'Situação', f: r => chip(r.ativo ? 'ativa' : 'inativa', r.ativo ? 'ok' : 'cancelado') }], dados,
    { acoes: r => `<button class="btn sm" data-ed="${r.id}">Editar</button> ` + (['dinheiro', 'fiado'].includes(r.tipo) ? '' : `<button class="btn sm danger" data-ex="${r.id}">Excluir</button>`) }); };
  const carregar = seguro(async () => { dados = await api('/formas-pagamento'); desenhar(); });
  el.innerHTML = '<div class="bar"><div class="grow"></div><button class="btn primary" id="novo">+ Nova forma de pagamento</button></div><div id="lista"></div>';

  const pasta = (k, rotulo, arqK, extK, v) => `<div class="row" style="align-items:flex-end"><label style="flex:3;min-width:220px">${rotulo}<input data-k="${k}" value="${esc(v[k] ?? '')}" placeholder="ex: C:/TEF_DIAL/REQ/"></label>
    <button class="btn sm auto" type="button" data-pick="${k}">Procurar…</button>${arqK ? `<label style="max-width:120px">Arquivo<input data-k="${arqK}" value="${esc(v[arqK] ?? '')}"></label><label style="max-width:80px">Ext.<input data-k="${extK}" value="${esc(v[extK] ?? '')}"></label>` : ''}</div>`;

  const abrir = reg => {
    const v = reg || { ativo: true, tipo: 'credito', max_parcelas: 1, taxa_pct: 0, taxa_fixa: 0, dias_recebimento: 0, tef_vias: 1, tef_timeout: 120, ...Object.fromEntries(Object.keys(TEF_PADRAO).filter(k => /arq|ext/.test(k)).map(k => [k, TEF_PADRAO[k]])) };
    const campos = [{ k: 'descricao', t: 'text' }, { k: 'tipo', t: 'select' }, { k: 'ativo', t: 'check' }, { k: 'bandeira', t: 'text' }, { k: 'max_parcelas', t: 'number' }, { k: 'taxa_pct', t: 'number' }, { k: 'taxa_fixa', t: 'number' }, { k: 'dias_recebimento', t: 'number' }, { k: 'ordem', t: 'number' },
      { k: 'tef_ativo', t: 'check' }, { k: 'tef_provedor', t: 'text' }, { k: 'tef_rede', t: 'text' }, { k: 'tef_vias', t: 'number' }, { k: 'tef_timeout', t: 'number' }, ...Object.keys(TEF_PADRAO).map(k => ({ k, t: 'text' })), { k: 'tef_dir_exec', t: 'text' }];
    const corpo = document.createElement('div');
    corpo.innerHTML = `<div class="tabs"><button type="button" data-tab="g" class="on">Geral</button><button type="button" data-tab="f">Financeiro</button><button type="button" data-tab="t" id="tabtef">Configurações TEF</button></div>
      <div data-p="g">${camposHtml([{ k: 'descricao', l: 'Descrição', req: true, full: true }, { k: 'tipo', l: 'Tipo', t: 'select', op: TIPOS_FORMA }, { k: 'bandeira', l: 'Bandeira / rede (opcional)' }, { k: 'ordem', l: 'Ordem na tela', t: 'number' }, { k: 'ativo', l: 'Ativa', t: 'check' }], v)}
        ${reg && ['dinheiro', 'fiado'].includes(reg.tipo) ? '<p class="muted">O tipo de Dinheiro e Fiado não pode ser alterado (são usados no fechamento do caixa e no contas a receber).</p>' : ''}</div>
      <div data-p="f" class="hidden">${camposHtml([{ k: 'max_parcelas', l: 'Máx. de parcelas (só crédito)', t: 'number' }, { k: 'taxa_pct', l: 'Taxa da máquina (%) sobre o valor', t: 'number', step: '0.001' }, { k: 'taxa_fixa', l: 'Taxa fixa da máquina (R$ por transação)', t: 'number', step: '0.01' }, { k: 'dias_recebimento', l: 'Dias para receber (0 = à vista)', t: 'number' }], v)}</div>
      <div data-p="t" class="hidden">
        <label class="chk"><input type="checkbox" data-k="tef_ativo" ${v.tef_ativo ? 'checked' : ''}> Integrar esta forma com TEF (cobrança no PIN-pad)</label>
        <div class="card muted" style="font-size:13px">As pastas são lidas pelo <b>computador servidor</b> do LoPDV. Se o TEF está instalado em outro computador (ex.: o caixa), compartilhe a pasta dele na rede e informe o caminho de rede, como <code>\\\\CAIXA01\\TEF_DIAL\\REQ\\</code>. Confirme os nomes de arquivo e pastas no manual do seu provedor de TEF.</div>
        <div class="row"><label>Provedor TEF<input data-k="tef_provedor" value="${esc(v.tef_provedor ?? '')}" placeholder="ex: SITEF"></label><label>Nome da rede<input data-k="tef_rede" value="${esc(v.tef_rede ?? '')}"></label><label style="max-width:150px">Vias do comprovante<input data-k="tef_vias" type="number" min="1" max="3" value="${esc(v.tef_vias ?? 1)}"></label><label style="max-width:170px">Tempo limite (seg.)<input data-k="tef_timeout" type="number" value="${esc(v.tef_timeout ?? 120)}"></label></div>
        ${pasta('tef_dir_envio', 'Pasta / arquivo de ENVIO', 'tef_arq_envio', 'tef_ext_envio', v)}${pasta('tef_dir_retorno', 'Pasta / arquivo de RETORNO', 'tef_arq_retorno', 'tef_ext_retorno', v)}
        ${pasta('tef_dir_status', 'Pasta / arquivo de STATUS', 'tef_arq_status', 'tef_ext_status', v)}${pasta('tef_dir_temp', 'Pasta / arquivo TEMPORÁRIO', 'tef_arq_temp', 'tef_ext_temp', v)}
        ${pasta('tef_dir_exec', 'Executável do TEF (arquivo .exe, opcional)', null, null, v)}
        <div class="bar"><button class="btn sm" type="button" id="pad">Preencher padrão SITEF (C:/TEF_DIAL)</button><button class="btn sm" type="button" id="tst">Testar pastas</button></div><div id="tres"></div></div>`;
    const tipoSel = $('[data-k="tipo"]', corpo), atualizar = () => {
      const t = tipoSel.value; $('#tabtef', corpo).classList.toggle('hidden', ['dinheiro', 'fiado', 'consignado'].includes(t));
      const mp = $('[data-k="max_parcelas"]', corpo); mp.disabled = t !== 'credito'; if (t !== 'credito') mp.value = 1;
    };
    tipoSel.value = v.tipo; if (reg && ['dinheiro', 'fiado'].includes(reg.tipo)) tipoSel.disabled = true;
    tipoSel.onchange = atualizar; atualizar();
    corpo.onclick = seguro(async e => {
      const t = e.target;
      if (t.dataset.tab) { $$('[data-tab]', corpo).forEach(b => b.classList.toggle('on', b === t)); $$('[data-p]', corpo).forEach(p => p.classList.toggle('hidden', p.dataset.p !== t.dataset.tab)); }
      if (t.dataset.pick) { const inp = $(`[data-k="${t.dataset.pick}"]`, corpo); const r = await escolherPasta(inp.value, t.dataset.pick === 'tef_dir_exec'); if (r) inp.value = r; }
      if (t.id === 'pad') Object.entries(TEF_PADRAO).forEach(([k, val]) => { const i = $(`[data-k="${k}"]`, corpo); if (i && (!i.value || /dir/.test(k))) i.value = val; });
      if (t.id === 'tst') { const r = await api('/tef/testar', { method: 'POST', body: lerCampos(corpo, campos) }); $('#tres', corpo).innerHTML = r.resultados.map(x => `<div>${x.ok ? '✅' : '❌'} <b>${esc(x.rotulo)}:</b> ${esc(x.msg)}</div>`).join(''); }
    });
    modal({ titulo: reg ? 'Forma de pagamento: ' + reg.descricao : 'Nova forma de pagamento', tam: 'md', corpo, botoes: [{ txt: 'Cancelar' }, { txt: 'Salvar', cls: 'primary', fn: async m => {
      const o = lerCampos(corpo, campos); if (tipoSel.disabled) o.tipo = reg.tipo; validar(o, [{ k: 'descricao', l: 'Descrição', req: true }]);
      await api('/formas-pagamento' + (reg ? '/' + reg.id : ''), { method: reg ? 'PUT' : 'POST', body: o }); toast('Salvo.'); carregar(); } }] });
  };
  $('#novo', el).onclick = () => abrir(null);
  el.onclick = seguro(async e => {
    const ed = e.target.dataset.ed, ex = e.target.dataset.ex;
    if (ed) abrir(dados.find(d => d.id == ed));
    if (ex && await confirmar('Excluir esta forma de pagamento? (se já foi usada em vendas, inative-a)')) { await api('/formas-pagamento/' + ex, { method: 'DELETE' }); toast('Excluída.'); carregar(); }
  });
  await carregar();
} });
