// Núcleo do front-end: utilitários, API, modais, formulários, menu e roteamento.
const S = { token: sessionStorage.getItem('tk'), user: null, timer: null, cfg: {} };
const VIEWS = [];
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const R = n => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const N = (n, d = 3) => Number(n || 0).toLocaleString('pt-BR', { maximumFractionDigits: d });
const dt = s => (s ? new Date(s).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '');
const hr = s => (s ? new Date(s).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '');
const dia = s => (s ? String(s).slice(0, 10).split('-').reverse().join('/') : '');
const hojeISO = () => { const d = new Date(); return new Date(d - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); };
const iniMes = () => hojeISO().slice(0, 8) + '01';
const tem = p => !!S.user && (S.user.perms.includes('*') || S.user.perms.includes(p));
const num = v => { const n = parseFloat(String(v ?? '').replace(/\./g, '').replace(',', '.')); return Number.isFinite(n) ? n : 0; };
const numIn = v => { const s = String(v ?? '').trim(); if (/^-?\d+(\.\d+)?$/.test(s)) return parseFloat(s); return num(s); };

async function api(path, { method = 'GET', body } = {}) {
  const r = await fetch('/api' + path, { method, headers: { 'Content-Type': 'application/json', ...(S.token ? { Authorization: 'Bearer ' + S.token } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
  let j = {}; try { j = await r.json(); } catch { /* sem corpo */ }
  if (!r.ok) {
    if (j.setup) { location = '/setup.html'; }
    if (r.status === 401 && S.token) { S.token = null; sessionStorage.removeItem('tk'); mostrarLogin(); }
    const e = new Error(j.erro || 'Erro ' + r.status); e.status = r.status; e.data = j; throw e;
  }
  return j;
}
const qs = o => Object.entries(o).filter(([, v]) => v !== '' && v != null).map(([k, v]) => k + '=' + encodeURIComponent(v)).join('&');

function toast(msg, tipo = 'ok') {
  const t = document.createElement('div'); t.className = 'toast ' + (tipo === 'ok' ? '' : tipo); t.textContent = msg;
  $('#toasts').appendChild(t); setTimeout(() => t.remove(), tipo === 'erro' ? 6000 : 3500);
}
// executa uma ação mostrando erros como aviso
const seguro = fn => async (...a) => { try { return await fn(...a); } catch (e) { toast(e.message, 'erro'); } };

function modal({ titulo, corpo, botoes = [], tam = '', aoAbrir }) {
  const bg = document.createElement('div'); bg.className = 'modal-bg';
  bg.innerHTML = `<div class="modal ${tam}"><h3>${esc(titulo)}</h3><div class="body"></div><div class="foot"></div></div>`;
  const body = $('.body', bg); if (typeof corpo === 'string') body.innerHTML = corpo; else body.appendChild(corpo);
  const m = { el: bg, body, fechar: () => bg.remove() };
  botoes.forEach(b => {
    const bt = document.createElement('button'); bt.className = 'btn ' + (b.cls || ''); bt.textContent = b.txt;
    bt.onclick = async () => {
      if (!b.fn) return m.fechar();
      bt.disabled = true;
      try { const r = await b.fn(m); if (r !== false) m.fechar(); } catch (e) { toast(e.message, 'erro'); }
      bt.disabled = false;
    };
    $('.foot', bg).appendChild(bt);
  });
  document.body.appendChild(bg);
  const f = $('input,select,textarea', body); if (f) f.focus();
  if (aoAbrir) aoAbrir(m);
  return m;
}
const confirmarSaidaVenda = () => confirmar('Você tem uma venda em andamento que ainda não foi finalizada.\n\nTem certeza que deseja sair? A venda ficará salva como PENDENTE e, ao voltar para Vendas, você poderá resgatá-la ou excluí-la.', 'Sair sem finalizar a venda?');
const confirmar = (txt, titulo = 'Confirmar') => new Promise(res => {
  modal({ titulo, corpo: `<p>${esc(txt)}</p>`, botoes: [{ txt: 'Cancelar', fn: () => { res(false); } }, { txt: 'Confirmar', cls: 'primary', fn: () => { res(true); } }] });
});
const aviso = (txt, titulo = 'Aviso') => modal({ titulo, corpo: `<p style="white-space:pre-line">${esc(txt)}</p>`, botoes: [{ txt: 'OK', cls: 'primary' }] });

// ---- Formulários
function campoHtml(f, v) {
  const val = v ?? f.padrao ?? '';
  const id = ' data-k="' + f.k + '"';
  if (f.t === 'check') return `<label class="chk"><input type="checkbox"${id} ${val === true || val === 'true' || (val === '' && f.padrao) ? 'checked' : ''}> ${esc(f.l)}</label>`;
  let inp;
  if (f.t === 'select') inp = `<select${id}>${(f.op || []).map(o => `<option value="${esc(o[0])}" ${String(o[0]) === String(val) ? 'selected' : ''}>${esc(o[1])}</option>`).join('')}</select>`;
  else if (f.t === 'textarea') inp = `<textarea${id} rows="2">${esc(val)}</textarea>`;
  else inp = `<input${id} type="${f.t || 'text'}" value="${esc(val)}" ${f.ph ? `placeholder="${esc(f.ph)}"` : ''} ${f.ro ? 'readonly tabindex="-1" class="ro"' : ''} ${f.step ? `step="${f.step}"` : ''} ${f.t === 'password' ? 'autocomplete="new-password"' : ''}>`;
  return `<label>${esc(f.l)}${f.req ? ' *' : ''}${inp}</label>`;
}
function camposHtml(campos, vals = {}) {
  let out = '', linha = [];
  const flush = () => { if (linha.length) out += `<div class="row">${linha.join('')}</div>`; linha = []; };
  campos.forEach(f => { if (f.t === 'check' || f.full) { flush(); out += campoHtml(f, vals[f.k]); } else { linha.push(campoHtml(f, vals[f.k])); if (linha.length === (f.cols || 2)) flush(); } });
  flush(); return out;
}
function lerCampos(root, campos) {
  const o = {};
  campos.forEach(f => {
    const el = $(`[data-k="${f.k}"]`, root); if (!el) return;
    if (f.t === 'check') o[f.k] = el.checked;
    else if (f.t === 'number') o[f.k] = el.value === '' ? '' : numIn(el.value);
    else o[f.k] = el.value.trim();
  });
  return o;
}
function validar(o, campos) { for (const f of campos) if (f.req && (o[f.k] === '' || o[f.k] == null)) throw new Error(`Preencha: ${f.l}`); }

function formModal({ titulo, campos, valores = {}, onSave, tam = '', extra = '' }) {
  return modal({ titulo, tam, corpo: camposHtml(campos, valores) + extra, botoes: [{ txt: 'Cancelar' }, { txt: 'Salvar', cls: 'primary', fn: async m => { const o = lerCampos(m.body, campos); validar(o, campos); return onSave(o, m); } }] });
}

// ---- Tabelas
function tabela(cols, rows, { acoes, vazio = 'Nenhum registro.', rowCls } = {}) {
  if (!rows.length) return `<div class="card muted">${esc(vazio)}</div>`;
  const th = cols.map(c => `<th class="${c.n ? 'n' : ''}">${esc(c.l)}</th>`).join('') + (acoes ? '<th></th>' : '');
  const tr = rows.map((r, i) => `<tr data-i="${i}" class="${rowCls ? rowCls(r) : ''}">` + cols.map(c => `<td class="${c.n ? 'n' : ''}">${c.f ? c.f(r) : esc(r[c.k])}</td>`).join('') + (acoes ? `<td class="n">${acoes(r)}</td>` : '') + '</tr>').join('');
  return `<div class="tw"><table><thead><tr>${th}</tr></thead><tbody>${tr}</tbody></table></div>`;
}
const chip = (t, c = '') => `<span class="chip ${c}">${esc(t)}</span>`;
function csv(nome, cols, rows) {
  const l = [cols.map(c => c.l).join(';')].concat(rows.map(r => cols.map(c => { const v = c.csv ? c.csv(r) : r[c.k]; return '"' + String(v ?? '').replace(/"/g, '""') + '"'; }).join(';')));
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + l.join('\n')], { type: 'text/csv;charset=utf-8' })); a.download = nome + '.csv'; a.click();
}
// campo de busca por produto com datalist: "Nome (#id)"
const rotuloProd = p => `${p.nome} (#${p.id})`;
const idDoRotulo = t => { const m = /\(#(\d+)\)\s*$/.exec(t || ''); return m ? Number(m[1]) : null; };

// ---- CRUD genérico
function crudView({ id, titulo, grupo, perm, endpoint, campos, cols, editar = 'cadastros.editar', excluir = 'cadastros.excluir', ordemBusca }) {
  registrar({ id, titulo, grupo, perm, render: async el => {
    let dados = [];
    const desenhar = () => {
      const q = ($('#bq', el)?.value || '').toLowerCase();
      const lista = dados.filter(d => !q || JSON.stringify(Object.values(d)).toLowerCase().includes(q));
      $('#lista', el).innerHTML = tabela(cols, lista, { acoes: r => (tem(editar) ? `<button class="btn sm" data-ed="${r.id}">Editar</button> ` : '') + (tem(excluir) ? `<button class="btn sm danger" data-ex="${r.id}">Excluir</button>` : '') });
    };
    const carregar = seguro(async () => { dados = await api(endpoint); desenhar(); });
    el.innerHTML = `<div class="bar"><input id="bq" placeholder="Buscar..."><div class="grow"></div>${tem(editar) ? '<button class="btn primary" id="novo">+ Novo</button>' : ''}</div><div id="lista"></div>`;
    $('#bq', el).oninput = desenhar;
    const abrir = reg => formModal({ titulo: (reg ? 'Editar ' : 'Novo ') + titulo.toLowerCase(), campos, valores: reg || {}, tam: 'md',
      onSave: async o => { await api(endpoint + (reg ? '/' + reg.id : ''), { method: reg ? 'PUT' : 'POST', body: o }); toast('Salvo.'); carregar(); } });
    if ($('#novo', el)) $('#novo', el).onclick = () => abrir(null);
    el.onclick = seguro(async e => {
      const ed = e.target.dataset.ed, ex = e.target.dataset.ex;
      if (ed) abrir(dados.find(d => d.id == ed));
      if (ex && await confirmar('Excluir este registro? (se já foi usado, inative-o em vez de excluir)')) { await api(endpoint + '/' + ex, { method: 'DELETE' }); toast('Excluído.'); carregar(); }
    });
    await carregar();
  } });
}

// ---- Roteamento / menu
function registrar(v) { VIEWS.push(v); }
function limparTimer() { if (S.timer) { clearInterval(S.timer); S.timer = null; } }
// Menu em grupos suspensos (abre/fecha ao clicar). Todos os relatórios ficam num grupo só.
const MENU_GRUPOS = [
  ['Início', '🏠', ['painel']],
  ['Vendas', '🧾', ['vendas', 'producao']],
  ['Estoque', '📦', ['entrada', 'notas-sefaz', 'ajuste-avulso', 'producao-estoque', 'consignacoes', 'patrimonio']],
  ['Cadastros', '🗂️', ['produtos', 'clientes', 'fornecedores', 'formas']],
  ['Financeiro', '💰', ['caixa', 'conferencia', 'fiado', 'contas-receber', 'contas-pagar']],
  ['Relatórios', '📊', ['relatorios', 'extrato-produto', 'posicao', 'movimentos', 'auditoria']],
  ['Equipe', '👥', ['usuarios', 'perfis']],
  ['Configurações', '⚙️', ['empresa', 'config', 'integracao-fiscal']],
];
function menuAbertos() { try { return JSON.parse(sessionStorage.getItem('menuAb') || '[]'); } catch { return []; } }
function montarMenu() {
  const vis = VIEWS.filter(v => !v.perm || [].concat(v.perm).some(tem));
  const ativo = location.hash.replace('#/', '') || 'painel', usados = new Set(), abertos = menuAbertos();
  let h = '<div class="logo"><img src="icon.png" width="22" height="22" style="vertical-align:-5px" alt=""> LoPDV</div>';
  const grupos = MENU_GRUPOS.map(([nome, ic, ids]) => [nome, ic, ids.map(id => vis.find(v => v.id === id)).filter(Boolean)]);
  grupos.forEach(g => g[2].forEach(v => usados.add(v.id)));
  const sobra = vis.filter(v => !usados.has(v.id)); if (sobra.length) grupos.push(['Outros', '•', sobra]);
  grupos.forEach(([nome, ic, itens]) => {
    if (!itens.length) return;
    if (itens.length === 1 && nome === 'Início') { h += `<a class="mi" href="#/${itens[0].id}" data-id="${itens[0].id}"><span class="ico">${ic}</span>${esc(itens[0].titulo)}</a>`; return; }
    const aberto = abertos.includes(nome) || itens.some(v => v.id === ativo);
    h += `<div class="mg ${aberto ? 'open' : ''}" data-g="${esc(nome)}"><button type="button" class="mh"><span class="ico">${ic}</span><span class="mt">${esc(nome)}</span><span class="chev">▾</span></button><div class="ms">${itens.map(v => `<a href="#/${v.id}" data-id="${v.id}">${esc(v.titulo)}</a>`).join('')}</div></div>`;
  });
  if (S.versao) h += `<div class="grp" style="margin-top:18px">LoPDV v${esc(S.versao)}</div>`;
  const m = $('#menu'); m.innerHTML = h;
  m.onclick = e => {
    const b = e.target.closest('.mh'); if (!b) return;
    const g = b.parentElement; g.classList.toggle('open'); const nome = g.dataset.g;
    const l = menuAbertos().filter(x => x !== nome); if (g.classList.contains('open')) l.push(nome);
    try { sessionStorage.setItem('menuAb', JSON.stringify(l)); } catch { /* */ }
  };
}
// Durante um evento as permissões mudam (função do dia); confere com o servidor e refaz o menu se mudou.
async function sincronizarPerfil() {
  try { const me = await api('/me'); const mudou = JSON.stringify(me.perms) !== JSON.stringify(S.user.perms); S.user = me; $('#quem').textContent = `${me.nome} · ${me.perfil || ''}`; if (mudou) montarMenu(); } catch { /* sem rede: mantém */ }
}
async function rotear() {
  limparTimer(); S.guarda = null; await sincronizarPerfil();
  const id = (location.hash.replace('#/', '') || 'painel');
  const v = VIEWS.find(x => x.id === id && (!x.perm || [].concat(x.perm).some(tem))) || VIEWS.find(x => x.id === 'painel');
  $$('#menu a').forEach(a => a.classList.toggle('on', a.dataset.id === v.id)); const am = $('#menu a.on'); if (am && am.closest('.mg')) am.closest('.mg').classList.add('open');
  $('#titulo').textContent = v.titulo; $('#menu').classList.remove('open');
  const el = $('#view'); el.innerHTML = '<p class="muted">Carregando...</p>'; el.onclick = null;
  try { await v.render(el); } catch (e) { el.innerHTML = `<div class="card erro">${esc(e.message)}</div>`; }
}
// Janela do aplicativo: no login fica pequena (so o cartao); depois do login ocupa a area util da tela do cliente.
function ajustarJanela(modo) {
  try {
    const aw = screen.availWidth, ah = screen.availHeight, ax = screen.availLeft || 0, ay = screen.availTop || 0;
    if (modo === 'login') { const w = Math.min(460, aw), h = Math.min(700, ah); window.resizeTo(w, h); window.moveTo(ax + Math.round((aw - w) / 2), ay + Math.round((ah - h) / 2)); }
    else { window.moveTo(ax, ay); window.resizeTo(aw, ah); }
  } catch { /* navegador comum: ignora */ }
}
function mostrarLogin() { $('#app').classList.add('hidden'); $('#login').classList.remove('hidden'); limparTimer(); ajustarJanela('login'); $('#lg').focus(); }
async function entrar() {
  $('#login').classList.add('hidden'); $('#app').classList.remove('hidden'); ajustarJanela('app');
  $('#quem').textContent = `${S.user.nome} · ${S.user.perfil || ''}`;
  try { S.cfg = await api('/config'); } catch { S.cfg = {}; }
  montarMenu(); await rotear();
  if (typeof iniciarAtualizacao === 'function') iniciarAtualizacao();
}
// Recuperação de senha: pede o usuário (ou e-mail), manda um código ao e-mail cadastrado e redefine com o código.
function recuperarSenha() {
  let usuario = $('#lg').value.trim();
  const m1 = modal({ titulo: 'Recuperar senha', corpo: `<p>Informe seu usuário (ou o e-mail cadastrado). Enviaremos um código de 6 dígitos para o e-mail do seu cadastro.</p><label>Usuário ou e-mail<input id="rcu" value="${esc(usuario)}" autocomplete="off"></label>`,
    botoes: [{ txt: 'Cancelar' }, { txt: 'Enviar código', cls: 'primary', fn: async m => {
      usuario = $('#rcu', m.body).value.trim(); if (!usuario) throw new Error('Informe o usuário ou e-mail.');
      const r = await api('/senha/solicitar', { method: 'POST', body: { usuario } }); toast(r.mensagem, 'ok'); setTimeout(passo2, 50); } }] });
  const passo2 = () => modal({ titulo: 'Digite o código e a nova senha', corpo: `<p class="muted">Veja o e-mail enviado (confira também o spam). O código vale por 15 minutos.</p>
      <label>Código de 6 dígitos<input id="rcc" inputmode="numeric" maxlength="6" autocomplete="off"></label><label>Nova senha (mín. 4)<input id="rcn" type="password" autocomplete="off"></label><label>Repita a nova senha<input id="rcn2" type="password" autocomplete="off"></label>`,
    botoes: [{ txt: 'Cancelar' }, { txt: 'Redefinir senha', cls: 'primary', fn: async m => {
      const n = $('#rcn', m.body).value; if (n !== $('#rcn2', m.body).value) throw new Error('As senhas não conferem.');
      await api('/senha/redefinir', { method: 'POST', body: { usuario, codigo: $('#rcc', m.body).value, nova: n } }); toast('Senha redefinida. Entre com a nova senha.'); $('#ls').value = ''; $('#lg').value = usuario; } }] });
}
// Tela de entrada: ao clicar no campo Usuário lista os usuários ativos (número e nome); a partir de 2 letras filtra por nome ou número.
function ligarListaUsuarios() {
  const inp = $('#lg'); if (!inp || inp.dataset.lista) return; inp.dataset.lista = '1';
  const box = document.createElement('div'); box.className = 'ulista hidden'; inp.parentNode.style.position = 'relative'; inp.parentNode.appendChild(box);
  let lista = [], idx = -1;
  const pad = c => String(Number(c)), norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const filtra = () => { const q = norm(inp.value).trim(); return lista.filter(u => q.length < 2 || norm(u.nome).includes(q) || pad(u.codigo).startsWith(q.replace(/^0+/, '')) || String(u.codigo) === q.replace(/^0+/, '')); };
  const desenha = () => { const l = filtra(); if (!l.length && inp.value.trim().length >= 2) { box.classList.add('hidden'); return; }
    box.innerHTML = l.map((u, i) => `<button type="button" data-c="${u.codigo}" class="${i === idx ? 'on' : ''}"><b>${pad(u.codigo)}</b> ${esc(u.nome)}</button>`).join('') || '<div class="muted" style="padding:8px">Nenhum usuário ativo.</div>'; box.classList.remove('hidden'); };
  const abre = async () => { try { lista = await (await fetch('/api/login/usuarios', { cache: 'no-store' })).json(); } catch { lista = []; } idx = -1; desenha(); };
  const escolhe = c => { inp.value = pad(c); box.classList.add('hidden'); $('#ls').focus(); };
  inp.addEventListener('focus', abre); inp.addEventListener('click', () => { if (box.classList.contains('hidden')) abre(); });
  inp.addEventListener('input', () => { idx = -1; desenha(); });
  inp.addEventListener('keydown', e => { const n = filtra().length;
    if (e.key === 'ArrowDown' && n) { e.preventDefault(); idx = (idx + 1) % n; desenha(); }
    else if (e.key === 'ArrowUp' && n) { e.preventDefault(); idx = (idx - 1 + n) % n; desenha(); }
    else if (e.key === 'Enter' && idx >= 0 && !box.classList.contains('hidden')) { e.preventDefault(); escolhe(filtra()[idx].codigo); }
    else if (e.key === 'Escape') box.classList.add('hidden'); });
  box.addEventListener('mousedown', e => { const b = e.target.closest('[data-c]'); if (b) { e.preventDefault(); escolhe(b.dataset.c); } });
  inp.addEventListener('blur', () => setTimeout(() => box.classList.add('hidden'), 150));
}
async function iniciar() {
  ligarListaUsuarios();
  try { const j = await (await fetch('/api/saude')).json(); S.versao = j.versao; const v = $('#verlogin'); if (v && j.versao) v.textContent = 'Versão ' + j.versao; } catch { /* sem versão */ }
  // Menu lateral: fica parado se todos os itens cabem na tela; se não cabem, sobe junto com a rolagem até mostrar o fim do menu
  const ajustaMenu = () => { const m = $('#menu'); if (!m) return;
    if (window.innerWidth <= 900) { m.style.top = ''; return; }
    const folga = m.offsetHeight - window.innerHeight; m.style.top = folga > 0 ? -Math.min(window.scrollY, folga) + 'px' : '0px'; };
  window.addEventListener('scroll', ajustaMenu, { passive: true }); window.addEventListener('resize', ajustaMenu);
  try { new ResizeObserver(ajustaMenu).observe($('#menu')); } catch { }
  ajustaMenu();
  // Venda em andamento: não deixa sair da tela sem confirmar (a venda fica salva como pendente)
  S.hashAtual = location.hash;
  window.addEventListener('hashchange', async () => {
    if (location.hash === S.hashAtual) return;
    if (S.guarda && S.guarda()) {
      const novo = location.hash; location.hash = S.hashAtual;   // volta para a venda enquanto pergunta
      if (await confirmarSaidaVenda()) { S.guarda = null; S.hashAtual = novo; location.hash = novo; }
      return;
    }
    S.hashAtual = location.hash; rotear();
  });
  const aplicarRecolhido = r => { $('#app').classList.toggle('recolhido', r); if (r) document.documentElement.style.setProperty('--menuw', '0px'); else document.documentElement.style.removeProperty('--menuw'); window.dispatchEvent(new Event('resize')); };
  try { if (localStorage.getItem('menuRecolhido') === '1' && window.innerWidth > 900) aplicarRecolhido(true); } catch { }
  $('#btnMenu').onclick = () => {
    if (window.innerWidth <= 900) return $('#menu').classList.toggle('open');   // celular/tela pequena: abre por cima
    const r = !$('#app').classList.contains('recolhido'); aplicarRecolhido(r);   // computador: recolhe e a tela ocupa o espaço
    try { localStorage.setItem('menuRecolhido', r ? '1' : '0'); } catch { }
  };
  $('#btnSair').onclick = async () => { if (S.guarda && S.guarda() && !(await confirmarSaidaVenda())) return; S.guarda = null; try { await api('/logout', { method: 'POST' }); } catch { /* */ } S.token = null; sessionStorage.removeItem('tk'); mostrarLogin(); };
  $('#btnSenha').onclick = () => formModal({ titulo: 'Alterar minha senha', campos: [{ k: 'atual', l: 'Senha atual', t: 'password', req: true, full: true }, { k: 'nova', l: 'Nova senha (mín. 4)', t: 'password', req: true, full: true }],
    onSave: async o => { await api('/me/senha', { method: 'POST', body: o }); toast('Senha alterada.'); } });
  $('#esqueci').onclick = e => { e.preventDefault(); recuperarSenha(); };
  $('#loginForm').onsubmit = async e => {
    e.preventDefault(); $('#lerr').textContent = '';
    try {
      const r = await api('/login', { method: 'POST', body: { login: $('#lg').value, senha: $('#ls').value } });
      S.token = r.token; S.user = r.user; sessionStorage.setItem('tk', r.token); $('#ls').value = ''; entrar();
    } catch (er) { $('#lerr').textContent = er.message; }
  };
  if (S.token) { try { S.user = await api('/me'); return entrar(); } catch { /* cai no login */ } }
  mostrarLogin();
}


// Senhas: o navegador nunca deve oferecer salvar usuário/senha. Todo <input type=password> vira texto mascarado, sem autopreenchimento.
(function () {
  const fix = el => { if (el.matches && el.matches('input[type=password]')) { el.type = 'text'; el.classList.add('pw'); el.setAttribute('autocomplete', 'off'); el.setAttribute('autocapitalize', 'off'); el.setAttribute('spellcheck', 'false'); } };
  const varre = no => { if (no.nodeType !== 1) return; fix(no); no.querySelectorAll && no.querySelectorAll('input[type=password]').forEach(fix); };
  new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(varre))).observe(document.documentElement, { childList: true, subtree: true });
  document.querySelectorAll('input[type=password]').forEach(fix);
})();
