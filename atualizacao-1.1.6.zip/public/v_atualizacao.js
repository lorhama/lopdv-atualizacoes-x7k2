// Atualização do sistema: aviso de versão nova, confirmação, tela de andamento e tela de novidades após o login.
const NOTA_TIPO = { correcao: 'Correção', melhoria: 'Melhoria' };
const notasHtml = lista => (lista && lista.length ? '<ul class="nv">' + lista.map(n => `<li><b>${esc(NOTA_TIPO[n.tipo] || n.tipo || 'Melhoria')}:</b> ${esc(n.texto)}</li>`).join('') + '</ul>' : '<p class="muted">Sem detalhes.</p>');

async function checarAtualizacao() {
  if (!tem('config.gerenciar')) return;
  let s; try { s = await api('/atualizacao?checar=1'); } catch { return; }
  let b = $('#bannerUpd');
  if (!s.disponivel) { // sem versão nova: se a verificação não está funcionando, avisa em vez de ficar em silêncio
    const naoConfig = !s.url && !s.url_padrao, falha = s.erro;
    if ((naoConfig || falha) && !sessionStorage.getItem('updAvisoFechado')) {
      if (!b) { b = document.createElement('div'); b.id = 'bannerUpd'; const top = $('.main .top'); top.parentNode.insertBefore(b, top); }
      b.className = 'banner-upd aviso';
      b.innerHTML = `<span>⚠️ <b>${naoConfig ? 'A atualização automática não está configurada' : 'Não foi possível verificar novas versões'}</b> — ${esc(naoConfig ? 'o sistema não sabe onde procurar versões novas.' : falha)}</span><span class="grow"></span><a class="btn sm primary" href="#/config">Configurar</a><button class="btn sm" id="updX">Dispensar</button>`;
      $('#updX', b).onclick = () => { try { sessionStorage.setItem('updAvisoFechado', '1'); } catch { /* */ } b.remove(); };
    } else if (b) b.remove();
    return;
  }
  if (!b) { b = document.createElement('div'); b.id = 'bannerUpd'; b.className = 'banner-upd'; const top = $('.main .top'); top.parentNode.insertBefore(b, top); }
  b.innerHTML = `<span>🔔 <b>Nova versão ${esc(s.disponivel.versao)} disponível</b> (você está na ${esc(s.versao)}).</span><span class="grow"></span><button class="btn sm" id="updVer">O que muda</button><button class="btn sm primary" id="updGo">Atualizar</button>`;
  $('#updVer', b).onclick = () => modal({ titulo: 'Versão ' + s.disponivel.versao + (s.disponivel.data ? ' — ' + s.disponivel.data : ''), corpo: notasHtml(s.disponivel.notas), botoes: [{ txt: 'Fechar' }] });
  $('#updGo', b).onclick = () => confirmarAtualizacao(s);
}

function confirmarAtualizacao(s) {
  modal({ titulo: 'Atualizar para a versão ' + s.disponivel.versao + '?', tam: 'md',
    corpo: `<p><b>O sistema precisa ser fechado para atualizar.</b> Todos os terminais ficarão sem acesso por alguns minutos (normalmente 1 a 3).</p>
      <ul class="nv"><li>Antes de trocar os arquivos o sistema faz o backup do banco de dados.</li><li>Seus dados, vendas e cadastros são mantidos.</li><li>Se algo der errado, o sistema volta sozinho para a versão atual.</li><li>Termine as vendas em andamento antes de confirmar.</li><li>Ao terminar, o sistema abre pedindo usuário e senha, já na versão nova.</li></ul>
      <p>Deseja atualizar agora?</p>`,
    botoes: [{ txt: 'Agora não' }, { txt: 'Sim, atualizar agora', cls: 'primary', fn: async () => { await api('/atualizacao/aplicar', { method: 'POST' }); telaAtualizando(s.disponivel.versao); } }] });
}

// Tela cheia durante a atualização: acompanha o andamento e, quando o sistema volta na versão nova, recarrega no login.
function telaAtualizando(nova) {
  const ov = document.createElement('div'); ov.className = 'upd-ov';
  ov.innerHTML = `<div class="upd-box"><img src="icon.png" width="64" height="64" alt=""><h2>Atualizando o LoPDV para a versão ${esc(nova)}</h2><div class="upd-bar"><i id="updPct"></i></div><p id="updTxt">Preparando...</p><p class="muted">Não desligue o computador. Esta tela se atualiza sozinha.</p><div id="updErr"></div></div>`;
  document.body.appendChild(ov);
  let caiu = false, parou = false;
  const txt = t => { $('#updTxt', ov).textContent = t; }, pct = p => { $('#updPct', ov).style.width = p + '%'; };
  const falhou = m => { parou = true; $('#updErr', ov).innerHTML = `<div class="erro" style="margin:12px 0">${esc(m)}</div><button class="btn primary" id="updFecha">Voltar ao sistema</button>`; $('#updFecha', ov).onclick = () => { ov.remove(); if (!S.token) mostrarLogin(); else rotear(); }; txt('A atualização não foi concluída.'); };
  const volta = () => { try { sessionStorage.removeItem('tk'); } catch { /* */ } location.reload(); };
  const tick = async () => {
    if (parou) return;
    try {
      const s = await (await fetch('/api/atualizacao/status?ov=1', { cache: 'no-store' })).json();
      if (s.versao === nova) { txt('Atualizado! Abrindo o sistema...'); pct(100); parou = true; return setTimeout(volta, 800); }
      if (s.fase === 'erro') return falhou(s.erro || 'Erro ao baixar a atualização.');
      if (s.resultado && s.resultado.ok === false && caiu) return falhou(s.resultado.erro);
      if (s.fase === 'baixando') { txt('Baixando a atualização... ' + s.pct + '%'); pct(Math.round(s.pct * 0.6)); }
      else if (s.fase === 'conferindo') { txt('Conferindo a segurança do pacote...'); pct(65); }
      else if (s.fase === 'reiniciando') { txt('Fechando o sistema para atualizar...'); pct(75); }
      else if (caiu) { txt('Reiniciando o sistema...'); pct(92); }
    } catch { caiu = true; txt('Instalando a nova versão... (o sistema está fechado, aguarde)'); pct(85); }
    setTimeout(tick, 2000);
  };
  tick();
}

// Novidades: aparece uma vez por usuário depois do login na versão nova.
async function mostrarNovidades() {
  let n; try { n = await api('/novidades'); } catch { return; }
  if (!n.mostrar) return;
  const corpo = n.versoes.map(v => `<h4 style="margin:10px 0 4px">Versão ${esc(v.versao)}${v.data ? ' <small class="muted">— ' + esc(v.data) + '</small>' : ''}</h4>${notasHtml(v.itens)}`).join('');
  modal({ titulo: '🎉 O que há de novo no LoPDV ' + n.versao, tam: 'md', corpo: `<p>O sistema foi atualizado. Veja o que melhorou:</p>${corpo}`,
    botoes: [{ txt: 'Entendi, vamos trabalhar', cls: 'primary', fn: async () => { try { await api('/novidades/visto', { method: 'POST' }); } catch { /* */ } } }] });
}

async function iniciarAtualizacao() {
  mostrarNovidades(); checarAtualizacao();
  if (S.updTimer) clearInterval(S.updTimer); S.updTimer = setInterval(checarAtualizacao, 15 * 60 * 1000);
}
