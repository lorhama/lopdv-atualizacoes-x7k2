// Cadastro da empresa que usa o sistema: dados, e-mail padrão (remetente) e servidor de envio (SMTP).
const express = require('express');
const db = require('../db');
const { auth, auditar } = require('../auth');
const { wrap, HttpError } = require('../util');
const { cifrar } = require('../sefaz');
const email = require('../email');
const r = express.Router();
const CAMPOS = ['empresa', 'empresa_razao', 'empresa_cnpj', 'empresa_ie', 'empresa_tel', 'empresa_endereco', 'empresa_cidade', 'empresa_email', 'smtp_host', 'smtp_porta', 'smtp_seguranca', 'smtp_usuario'];
const emailOk = s => /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(String(s || '').trim());
const set = (k, v) => db.q('insert into config(chave,valor) values($1,$2) on conflict(chave) do update set valor=excluded.valor', [k, String(v ?? '')]);

r.get('/', auth('config.gerenciar'), wrap(async (req, res) => {
  const o = {}; (await db.q("select chave, valor from config where chave like 'empresa%' or chave like 'smtp\\_%'")).rows.forEach(x => { o[x.chave] = x.valor; });
  const out = {}; CAMPOS.forEach(k => { out[k] = o[k] || ''; }); out.smtp_tem_senha = !!o.smtp_senha; if (!out.smtp_seguranca) out.smtp_seguranca = 'starttls';
  res.json(out);
}));
r.put('/', auth('config.gerenciar'), wrap(async (req, res) => {
  const b = req.body || {};
  if (!String(b.empresa || '').trim()) throw new HttpError(400, 'Informe o nome da empresa.');
  if (b.empresa_email && !emailOk(b.empresa_email)) throw new HttpError(400, 'E-mail padrão da empresa inválido.');
  if (b.empresa_cnpj) { const d = String(b.empresa_cnpj).replace(/\D/g, ''); if (d.length !== 14 && d.length !== 11) throw new HttpError(400, 'CNPJ/CPF inválido.'); b.empresa_cnpj = d; }
  if (b.smtp_seguranca && !['ssl', 'starttls', 'nenhuma'].includes(b.smtp_seguranca)) throw new HttpError(400, 'Segurança do e-mail inválida.');
  for (const k of CAMPOS) if (b[k] !== undefined) await set(k, String(b[k]).trim());
  if (b.smtp_senha) await set('smtp_senha', cifrar(String(b.smtp_senha)));
  await auditar(null, req.user, 'empresa_alterada', { empresa: b.empresa });
  res.json({ ok: true });
}));
r.post('/email-teste', auth('config.gerenciar'), wrap(async (req, res) => {
  const para = String(req.body?.para || '').trim();
  if (!emailOk(para)) throw new HttpError(400, 'Informe um e-mail válido para receber o teste.');
  try { await email.enviar(db, { para, assunto: 'Teste de e-mail do LoPDV', texto: 'Este é um e-mail de teste do LoPDV.\nSe você recebeu, o envio de e-mails (recuperação de senha) está funcionando.' }); }
  catch (e) { throw new HttpError(400, e.message); }
  res.json({ ok: true });
}));
module.exports = r;
