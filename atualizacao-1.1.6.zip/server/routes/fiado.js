// Recebimento (baixa) de fiado: exige caixa aberto, escolha do caixa e forma de pagamento (nunca Fiado).
const express = require('express');
const db = require('../db');
const tef = require('../tef');
const prn = require('../printer');
const { auth, auditar } = require('../auth');
const { HttpError, wrap, num, r2, hoje } = require('../util');
const r = express.Router();

const SALDO = "t.valor - coalesce((select sum(p.valor) from pagamentos p where p.titulo_id=t.id),0)";

r.get('/pendentes', auth('vendas.receber'), wrap(async (req, res) => {
  const caixas = (await db.q("select id, numero, aberto_em, valor_abertura from caixas where usuario_id=$1 and status='aberto' order by id", [req.user.id])).rows;
  const titulos = (await db.q(`select t.id, t.descricao, t.valor, t.vencimento, t.cliente_id, c.nome cliente, t.pedido_id, ${SALDO} saldo
    from titulos t join clientes c on c.id=t.cliente_id where t.tipo='receber' and t.categoria='Venda fiado' and t.status='aberto' order by c.nome, t.vencimento, t.id`)).rows;
  res.json({ caixas, titulos });
}));

r.post('/baixar', auth('vendas.receber'), wrap(async (req, res) => {
  const b = req.body || {};
  const forma = (await db.q('select * from formas_pagamento where codigo=$1 and ativo', [b.forma])).rows[0];
  if (!forma) throw new HttpError(400, 'Escolha a forma de pagamento da baixa.');
  if (forma.tipo === 'fiado') throw new HttpError(400, 'A baixa de fiado não pode ser feita na forma Fiado.');
  const ref = b.tef_ref || null; let comprovante = null;
  try {
    await db.tx(async c => {
      const cx = (await c.query("select id from caixas where id=$1 and usuario_id=$2 and status='aberto'", [b.caixa_id, req.user.id])).rows[0];
      if (!cx) throw new HttpError(400, 'Para baixar fiado é necessário informar um caixa seu que esteja aberto.');
      const t = (await c.query(`select t.*, ${SALDO} saldo from titulos t where t.id=$1 for update of t`, [b.titulo_id])).rows[0];
      if (!t || t.categoria !== 'Venda fiado' || t.status !== 'aberto') throw new HttpError(400, 'Fiado não encontrado ou já baixado.');
      const saldo = r2(Number(t.saldo)); const valor = r2(num(b.valor, saldo));
      if (valor <= 0) throw new HttpError(400, 'Informe um valor maior que zero.');
      if (valor > saldo + 0.004) throw new HttpError(400, `O valor excede o saldo do fiado (${saldo.toFixed(2)}).`);
      let tx = null;
      if (forma.tef_ativo) { tx = tef.reservar(ref, forma.codigo, valor, req.user.id); comprovante = { linhas: tx.comprovante, vias: forma.tef_vias || 1 }; }
      else if (ref) throw new HttpError(400, 'Forma sem TEF recebeu uma transação TEF.');
      await c.query("insert into pagamentos(pedido_id, caixa_id, forma, valor, titulo_id, origem, tef_nsu, tef_autorizacao, tef_rede) values(null,$1,$2,$3,$4,'recebimento_fiado',$5,$6,$7)",
        [cx.id, forma.codigo, valor, t.id, tx?.nsu || null, tx?.autorizacao || null, tx?.rede || null]);
      const quitado = r2(saldo - valor) <= 0.004;
      if (quitado) await c.query("update titulos set status='pago', pago_em=$1, valor_pago=$2, forma=$3 where id=$4", [hoje(), t.valor, forma.codigo, t.id]);
      await auditar(c, req.user, 'fiado_baixado', { titulo: t.id, cliente: t.cliente_id, valor, forma: forma.codigo, caixa: cx.id, quitado });
      res.locals.out = { ok: true, quitado, saldo_restante: quitado ? 0 : r2(saldo - valor) };
    });
  } catch (e) { if (ref) await tef.finalizar(ref, false); throw e; }
  const imp = [];
  if (ref) { await tef.finalizar(ref, true); if (comprovante?.linhas?.length) for (let i = 0; i < comprovante.vias; i++) imp.push(await prn.imprimirTexto(db, 'caixa', '', comprovante.linhas.join('\n'))); }
  res.json({ ...res.locals.out, impressao: imp, comprovante: comprovante?.linhas || [] });
}));

module.exports = r;
