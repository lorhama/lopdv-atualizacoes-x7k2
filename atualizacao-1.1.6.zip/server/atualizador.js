// Atualização do sistema pela internet, sem acesso remoto ao cliente.
// O servidor do cliente consulta um endereço (versao.json); se houver versão nova, avisa os administradores.
// Ao confirmar: baixa o pacote, confere o tamanho/SHA-256 e a ASSINATURA (chave pública embutida), e entrega a troca de arquivos
// ao atualizar.ps1, que roda depois que o sistema fecha, atualiza, e reinicia o servidor.
const fs = require('fs'), path = require('path'), https = require('https'), http = require('http'), crypto = require('crypto'), { spawn } = require('child_process');
const VERSAO = require('../package.json').version;
const RAIZ = path.join(__dirname, '..');
const DATA = process.env.GESTAO_DATA_DIR || path.join(RAIZ, 'data');
const PASTA = path.join(DATA, 'atualizacao');
const PUBLICA = () => fs.readFileSync(path.join(__dirname, 'atualizacao-publica.pem'), 'utf8');
const tup = v => String(v || '0').split('.').map(x => parseInt(x, 10) || 0);
const maior = (a, b) => { const x = tup(a), y = tup(b); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; };

const est = { fase: 'ocioso', pct: 0, erro: '', consulta: 0 };   // fase: ocioso | baixando | conferindo | reiniciando | erro

async function cfgGet(db, k) { return (await db.q('select valor from config where chave=$1', [k])).rows[0]?.valor || ''; }
async function cfgSet(db, k, v) { await db.q('insert into config(chave,valor) values($1,$2) on conflict(chave) do update set valor=excluded.valor', [k, String(v ?? '')]); }
function urlPadrao() { try { return String(JSON.parse(fs.readFileSync(path.join(RAIZ, 'atualizacao.json'), 'utf8')).manifesto || '').trim(); } catch { return ''; } }
// O endereço é fixo (atualizacao.json, que vem dentro da versão): não é alterável pela tela nem pelo banco.
async function urlManifesto() { return urlPadrao(); }

// GET com redirecionamentos (GitHub e outros serviços redirecionam o download). Devolve texto, ou grava em arquivo.
function obter(url, { destino, max = 400e6, onProgresso, n = 0 } = {}) {
  return new Promise((resolve, reject) => {
    let u; try { u = new URL(url); } catch { return reject(new Error('Endereço de atualização inválido.')); }
    if (u.protocol !== 'https:' && !(u.protocol === 'http:' && process.env.LOPDV_UPD_HTTP === '1')) return reject(new Error('O endereço de atualização precisa começar com https://'));
    const lib = u.protocol === 'https:' ? https : http;
    const req = lib.get(u, { headers: { 'User-Agent': 'LoPDV-Atualizador/' + VERSAO, 'Cache-Control': 'no-cache' }, timeout: 30000 }, res => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
        res.resume(); if (n >= 6) return reject(new Error('Redirecionamentos demais.'));
        return resolve(obter(new URL(res.headers.location, u).toString(), { destino, max, onProgresso, n: n + 1 }));
      }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error('O servidor de atualização respondeu ' + res.statusCode + '.')); }
      const total = Number(res.headers['content-length']) || 0; let lido = 0; const hash = crypto.createHash('sha256');
      const saida = destino ? fs.createWriteStream(destino) : null, partes = [];
      res.on('data', d => {
        lido += d.length; if (lido > max) { req.destroy(new Error('Arquivo grande demais.')); return; }
        hash.update(d); if (saida) saida.write(d); else partes.push(d);
        if (onProgresso && total) onProgresso(Math.min(99, Math.round(100 * lido / total)));
      });
      res.on('end', () => { if (saida) saida.end(() => resolve({ sha256: hash.digest('hex'), tamanho: lido })); else resolve(Buffer.concat(partes).toString('utf8')); });
      res.on('error', reject);
    });
    req.on('timeout', () => req.destroy(new Error('O servidor de atualização demorou demais para responder.')));
    req.on('error', reject);
  });
}

function assinaturaOk(m) {
  try { return crypto.verify(null, Buffer.from(m.versao + '|' + m.sha256), PUBLICA(), Buffer.from(String(m.assinatura || ''), 'base64')); } catch { return false; }
}
function lerManifesto(txt) {
  let m; try { m = JSON.parse(txt); } catch { throw new Error('O arquivo de versão do servidor de atualização está inválido.'); }
  if (!/^\d+\.\d+\.\d+$/.test(m.versao || '') || !m.arquivo || !/^[0-9a-f]{64}$/.test(m.sha256 || '')) throw new Error('O arquivo de versão não tem os campos esperados.');
  if (!assinaturaOk(m)) throw new Error('A assinatura do pacote de atualização não confere. A atualização foi bloqueada por segurança.');
  return m;
}

async function verificar(db) {
  const url = await urlManifesto(db);
  if (!url) return { ok: false, erro: 'O endereço de atualização ainda não foi configurado.' };
  try {
    const m = lerManifesto(await obter(url, { max: 2e6 }));
    await cfgSet(db, 'upd_checado', new Date().toISOString()); await cfgSet(db, 'upd_erro', '');
    if (maior(m.versao, VERSAO)) await cfgSet(db, 'upd_disp', JSON.stringify({ versao: m.versao, data: m.data || '', notas: m.notas || [], arquivo: m.arquivo, sha256: m.sha256, assinatura: m.assinatura, tamanho: m.tamanho || 0, url }));
    else await cfgSet(db, 'upd_disp', '');
    return { ok: true, nova: maior(m.versao, VERSAO) ? m.versao : null };
  } catch (e) { await cfgSet(db, 'upd_erro', e.message).catch(() => { }); return { ok: false, erro: e.message }; }
}
async function situacao(db) {
  let disp = null; try { disp = JSON.parse(await cfgGet(db, 'upd_disp') || 'null'); } catch { /* */ }
  if (disp && !maior(disp.versao, VERSAO)) disp = null;
  return { versao: VERSAO, disponivel: disp && { versao: disp.versao, data: disp.data, notas: disp.notas, tamanho: disp.tamanho }, checado: await cfgGet(db, 'upd_checado'), erro: await cfgGet(db, 'upd_erro'), url: urlPadrao(), url_padrao: urlPadrao(), windows: process.platform === 'win32' || process.env.LOPDV_UPD_TESTE === '1' };
}
// Confere a versão nova ao abrir o sistema se a última verificação tem mais de 20 min (não espera só o agendador)
let emVerificacao = null;
async function verificarSeVelho(db) {
  if (!(est.fase === 'ocioso' || est.fase === 'erro')) return;
  const ult = Date.parse(await cfgGet(db, 'upd_checado') || '') || 0, errou = await cfgGet(db, 'upd_erro');
  if (!errou && Date.now() - ult < 20 * 60000) return;
  if (!emVerificacao) emVerificacao = verificar(db).finally(() => { emVerificacao = null; });
  await Promise.race([emVerificacao, new Promise(r => setTimeout(r, 6000))]).catch(() => { });
}
function resultado() { try { return JSON.parse(fs.readFileSync(path.join(PASTA, 'resultado.json'), 'utf8')); } catch { return null; } }
function status(marcar) { if (marcar) est.consulta = Date.now(); return { versao: VERSAO, fase: est.fase, pct: est.pct, erro: est.erro, resultado: resultado(), acompanhado: Date.now() - est.consulta < 20000 }; }

// Baixa, confere e entrega ao atualizar.ps1. Responde na hora; o andamento vai pelo status().
async function aplicar(db, porta, encerrar) {
  if (!(process.platform === 'win32' || process.env.LOPDV_UPD_TESTE === '1')) throw new Error('A atualização automática só funciona no Windows.');
  if (['baixando', 'conferindo', 'reiniciando'].includes(est.fase)) throw new Error('A atualização já está em andamento.');
  let d; try { d = JSON.parse(await cfgGet(db, 'upd_disp') || 'null'); } catch { /* */ }
  if (!d || !maior(d.versao, VERSAO)) throw new Error('Não há atualização disponível. Clique em "Verificar agora".');
  est.fase = 'baixando'; est.pct = 0; est.erro = '';
  (async () => {
    try {
      fs.mkdirSync(PASTA, { recursive: true }); try { fs.unlinkSync(path.join(PASTA, 'resultado.json')); } catch { /* */ }
      const zip = path.join(PASTA, 'pacote-' + d.versao + '.zip');
      const r = await obter(new URL(d.arquivo, d.url).toString(), { destino: zip, onProgresso: p => { est.pct = p; } });
      est.fase = 'conferindo'; est.pct = 100;
      if (r.sha256 !== d.sha256) throw new Error('O pacote baixado está corrompido (conferência SHA-256 falhou). Tente de novo.');
      if (!assinaturaOk(d)) throw new Error('Assinatura do pacote inválida. Atualização bloqueada.');
      const ps1 = path.join(PASTA, 'atualizar.ps1'); fs.copyFileSync(path.join(RAIZ, 'atualizar.ps1'), ps1);
      est.fase = 'reiniciando';
      const args = ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ps1, '-Zip', zip, '-Dir', RAIZ, '-Versao', d.versao, '-Anterior', VERSAO, '-Porta', String(porta || 3737)];
      if (process.env.LOPDV_UPD_TESTE === '1') { fs.writeFileSync(path.join(PASTA, 'teste-args.json'), JSON.stringify(args)); }
      else spawn('powershell.exe', args, { detached: true, stdio: 'ignore', windowsHide: true }).unref();
      setTimeout(() => encerrar(), 1500);
    } catch (e) { est.fase = 'erro'; est.erro = e.message; }
  })();
  return { ok: true };
}
function agendar(db) {
  const tick = async () => { try { if (est.fase === 'ocioso' || est.fase === 'erro') await verificar(db); } catch { /* */ } };
  setTimeout(tick, 45000); setInterval(tick, 3600 * 1000).unref();
}
// Novidades da versão (novidades.json vai dentro do pacote)
function novidades() { try { return JSON.parse(fs.readFileSync(path.join(RAIZ, 'novidades.json'), 'utf8')).versoes || []; } catch { return []; } }
module.exports = { verificar, verificarSeVelho, situacao, status, aplicar, agendar, novidades, lerManifesto, maior, VERSAO, cfgSet, PASTA };
