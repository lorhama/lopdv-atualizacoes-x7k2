# Atualizador do LoPDV. Chamado pelo proprio sistema depois que o cliente confirma. Roda escondido; registra tudo em data\atualizacao.log
param([string]$Zip, [string]$Dir, [string]$Versao, [string]$Anterior, [int]$Porta = 3737, [switch]$Elevado)
$ErrorActionPreference = 'Continue'
$dataDir = Join-Path $Dir 'data'; $pasta = Join-Path $dataDir 'atualizacao'
New-Item -ItemType Directory -Force -Path $pasta -ErrorAction SilentlyContinue | Out-Null
$log = Join-Path $dataDir 'atualizacao.log'
function G($t) { try { Add-Content -Path $log -Value ('[' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '] ' + $t) -Encoding UTF8 } catch { } }
function Resultado($ok, $erro) {
  $o = @{ ok = $ok; versao = $Versao; anterior = $Anterior; erro = $erro; quando = (Get-Date).ToString('o') } | ConvertTo-Json -Compress
  try { [IO.File]::WriteAllText((Join-Path $pasta 'resultado.json'), $o, (New-Object Text.UTF8Encoding($false))) } catch { }
}
function NodesDoSistema { @(Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and $_.CommandLine -like ('*' + $Dir + '*server*index.js*') }) }
function Iniciar {
  # inicia o servidor escondido (o mesmo comando do atalho); a tela que esta aberta recarrega sozinha
  $cmd = Join-Path $Dir 'servidor.cmd'
  if (Test-Path $cmd) { Start-Process -FilePath $cmd -WorkingDirectory $Dir -WindowStyle Hidden }
}
function PortaAberta($s) { $fim = (Get-Date).AddSeconds($s); while ((Get-Date) -lt $fim) { try { $c = New-Object Net.Sockets.TcpClient; $c.Connect('127.0.0.1', $Porta); $c.Close(); return $true } catch { Start-Sleep -Seconds 2 } }; return $false }

G ('===== Atualizacao ' + $Anterior + ' -> ' + $Versao + ' =====')
# 1) permissao de escrita na pasta do sistema; se faltar, pede ao Windows (UAC) uma vez
$teste = Join-Path $Dir ('.escrita-' + [guid]::NewGuid().ToString('N')); $escreve = $true
try { [IO.File]::WriteAllText($teste, 'x'); Remove-Item $teste -Force } catch { $escreve = $false }
if (-not $escreve -and -not $Elevado) {
  G 'Sem permissao de escrita; pedindo elevacao.'
  try { Start-Process powershell.exe -Verb RunAs -WindowStyle Hidden -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '" -Zip "' + $Zip + '" -Dir "' + $Dir + '" -Versao ' + $Versao + ' -Anterior ' + $Anterior + ' -Porta ' + $Porta + ' -Elevado'); exit } catch { G ('Elevacao recusada: ' + $_.Exception.Message); Resultado $false 'O Windows nao autorizou a atualizacao (permissao de administrador).'; Iniciar; exit }
}
# 2) espera o sistema fechar (ele faz o backup de fechamento); depois forca se precisar
for ($i = 0; $i -lt 90; $i++) { if ((NodesDoSistema).Count -eq 0) { break }; Start-Sleep -Seconds 1 }
NodesDoSistema | ForEach-Object { G ('Forcando encerramento do processo ' + $_.ProcessId); Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and $_.Name -match '^(cmd|wscript|cscript)\.exe$' -and $_.CommandLine -like ('*' + $Dir + '*') -and $_.ProcessId -ne $PID } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Seconds 2
$falha = ''
$rb = Join-Path $dataDir ('rollback\' + $Anterior)
try {
  # 3) copia de seguranca dos arquivos atuais (para voltar se algo der errado). O banco ja tem backup do fechamento.
  if (Test-Path $rb) { Remove-Item $rb -Recurse -Force -ErrorAction SilentlyContinue }
  New-Item -ItemType Directory -Force -Path $rb | Out-Null
  & robocopy $Dir $rb /E /XD data node_modules logs /NFL /NDL /NJH /NJS /NP | Out-Null
  G ('Copia de seguranca dos arquivos em ' + $rb)
  # 4) extrai o pacote novo e copia por cima (nunca toca em data\ nem node_modules\)
  $tmp = Join-Path $env:TEMP ('lopdv-upd-' + $Versao); if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
  Expand-Archive -Path $Zip -DestinationPath $tmp -Force
  & robocopy $tmp $Dir /E /XD data node_modules /NFL /NDL /NJH /NJS /NP | Out-Null
  if ($LASTEXITCODE -ge 8) { throw ('Falha ao copiar os arquivos novos (robocopy ' + $LASTEXITCODE + ').') }
  Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
  G 'Arquivos novos copiados.'
  # 5) bibliotecas
  $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
  $nlog = Join-Path $env:TEMP 'lopdv-npm-upd.log'; Remove-Item $nlog -Force -ErrorAction SilentlyContinue
  $p = Start-Process cmd.exe -ArgumentList ('/c npm.cmd install --omit=dev --no-audit --no-fund > "' + $nlog + '" 2>&1') -WorkingDirectory $Dir -WindowStyle Hidden -PassThru -Wait
  if ($p.ExitCode -ne 0) { if (Test-Path $nlog) { Get-Content $nlog -Tail 15 | ForEach-Object { G ('npm> ' + $_) } }; throw ('npm install falhou (codigo ' + $p.ExitCode + ').') }
  G 'Bibliotecas conferidas.'
  # 6) registro do Windows (se tiver permissao)
  try { Set-ItemProperty 'HKLM:\SOFTWARE\LoPDV' -Name Versao -Value $Versao -ErrorAction Stop; Set-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\LoPDV' -Name DisplayVersion -Value $Versao -ErrorAction Stop } catch { }
  # 7) liga o sistema novo e confere se subiu na versao certa
  Iniciar
  if (-not (PortaAberta 120)) { throw 'O sistema novo nao iniciou.' }
  $ver = ''; try { $ver = (Invoke-RestMethod -Uri ('http://127.0.0.1:' + $Porta + '/api/saude') -TimeoutSec 10).versao } catch { }
  if ($ver -ne $Versao) { throw ('O sistema iniciou na versao ' + $ver + ' em vez de ' + $Versao + '.') }
  Resultado $true ''
  G 'Atualizacao concluida.'
} catch {
  $falha = $_.Exception.Message; G ('FALHA: ' + $falha)
  # volta para a versao anterior
  try {
    NodesDoSistema | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }; Start-Sleep -Seconds 2
    if (Test-Path $rb) { & robocopy $rb $Dir /E /XD data node_modules /NFL /NDL /NJH /NJS /NP | Out-Null; G 'Arquivos da versao anterior restaurados.' }
  } catch { G ('Erro ao restaurar: ' + $_.Exception.Message) }
  Resultado $false ('A atualizacao falhou e o sistema voltou para a versao ' + $Anterior + '. Motivo: ' + $falha)
  Iniciar
}
# 8) se ninguem estava com a tela aberta acompanhando (ela recarrega sozinha), abre o sistema
Start-Sleep -Seconds 6
$acomp = $false; try { $acomp = (Invoke-RestMethod -Uri ('http://127.0.0.1:' + $Porta + '/api/atualizacao/status') -TimeoutSec 5).acompanhado } catch { }
if (-not $acomp) { $lnk = Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'LoPDV.lnk'; if (Test-Path $lnk) { Start-Process explorer.exe -ArgumentList ('"' + $lnk + '"') } }
