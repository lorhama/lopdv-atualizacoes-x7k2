# Gera o ícone do LoPDV: monograma "Lo" em itálico serifado, delicado. Uso: python3 scripts/gerar-icone.py
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import math
S=1024; K=2; W=S*K
lerp=lambda a,b,t: tuple(int(a[i]+(b[i]-a[i])*t) for i in range(3))
bg=Image.new('RGB',(W,W)); px=bg.load(); c1=(250,176,146); c2=(200,88,122)
for y in range(W):
    for x in range(W): px[x,y]=lerp(c1,c2,(x+y)/(2*W))
img=Image.new('RGBA',(W,W),(0,0,0,0)); m=Image.new('L',(W,W),0)
ImageDraw.Draw(m).rounded_rectangle([0,0,W-1,W-1],radius=int(W*0.26),fill=255); img.paste(bg,(0,0),m)
# luz suave no topo
luz=Image.new('RGBA',(W,W),(0,0,0,0)); ImageDraw.Draw(luz).ellipse([int(W*0.1),-int(W*0.55),int(W*0.9),int(W*0.30)],fill=(255,255,255,46))
luz=luz.filter(ImageFilter.GaussianBlur(W*0.06)); img=Image.alpha_composite(img,Image.composite(luz,Image.new('RGBA',(W,W),(0,0,0,0)),m))
d=ImageDraw.Draw(img); white=(255,255,255,255)
# moldura fina interna
inset=int(W*0.055); d.rounded_rectangle([inset,inset,W-inset,W-inset],radius=int(W*0.21),outline=(255,255,255,90),width=int(W*0.004))
# monograma "Lo"
f=ImageFont.truetype('/usr/share/fonts/truetype/freefont/FreeSerifItalic.ttf',int(W*0.52))
b=d.textbbox((0,0),'Lo',font=f); w=b[2]-b[0]; h=b[3]-b[1]
tx=(W-w)/2-b[0]; ty=W*0.385-h/2-b[1]
sombra=Image.new('RGBA',(W,W),(0,0,0,0)); ImageDraw.Draw(sombra).text((tx,ty+W*0.012),'Lo',font=f,fill=(150,50,80,70))
img=Image.alpha_composite(img,sombra.filter(ImageFilter.GaussianBlur(W*0.012))); d=ImageDraw.Draw(img)
d.text((tx,ty),'Lo',font=f,fill=white)
# filete delicado com ponto central
ly=int(W*0.665); d.line([(int(W*0.30),ly),(int(W*0.47),ly)],fill=(255,255,255,200),width=int(W*0.004)); d.line([(int(W*0.53),ly),(int(W*0.70),ly)],fill=(255,255,255,200),width=int(W*0.004))
r=int(W*0.011); d.ellipse([W//2-r,ly-r,W//2+r,ly+r],fill=white)
# PDV em destaque: letras médias, bem espaçadas, dentro de uma pílula translúcida
f2=ImageFont.truetype('/usr/share/fonts/opentype/inter/InterDisplay-SemiBold.otf',int(W*0.125))
letras='PDV'; esp=int(W*0.035); ws=[d.textbbox((0,0),c,font=f2) for c in letras]
tot=sum(x[2]-x[0] for x in ws)+esp*(len(letras)-1); x0=(W-tot)/2
py0,py1=int(W*0.725),int(W*0.885)
d.rounded_rectangle([int(W*0.25),py0,int(W*0.75),py1],radius=int((py1-py0)/2),fill=(255,255,255,235))
cor=(190,78,108,255); base=(py0+py1)/2
for c,bb in zip(letras,ws):
    d.text((x0-bb[0],base-(bb[3]-bb[1])/2-bb[1]),c,font=f2,fill=cor); x0+=bb[2]-bb[0]+esp
# faíscas
def star(x,y,s,a=255):
    pts=[(x+(s if i%2==0 else s*0.26)*math.cos(math.pi/4*i-math.pi/2),y+(s if i%2==0 else s*0.26)*math.sin(math.pi/4*i-math.pi/2)) for i in range(8)]
    d.polygon(pts,fill=(255,255,255,a))
star(int(W*0.75),int(W*0.20),int(W*0.045)); star(int(W*0.83),int(W*0.30),int(W*0.022),210); star(int(W*0.20),int(W*0.62),int(W*0.02),190)
img=img.resize((S,S),Image.LANCZOS)
img.resize((512,512),Image.LANCZOS).save('build/icon.png')
img.save('build/icon.ico',sizes=[(256,256),(128,128),(64,64),(48,48),(32,32),(24,24),(16,16)])
img.resize((256,256),Image.LANCZOS).save('public/icon.png')
img.save('public/icone.ico',sizes=[(256,256),(128,128),(64,64),(48,48),(32,32),(16,16)])
img.resize((512,512),Image.LANCZOS).save('/tmp/prev.png')
