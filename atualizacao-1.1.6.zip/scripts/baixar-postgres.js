// Baixa (uma vez) os binários portáteis do PostgreSQL e o runtime do Visual C++ para embutir no instalador.
// Rodado automaticamente por "npm run dist". Links podem ser trocados por variáveis de ambiente.
const https = require('https'), fs = require('fs'), path = require('path'), { execFileSync } = require('child_process');
const PG_URL = process.env.PG_ZIP_URL || 'https://get.enterprisedb.com/postgresql/postgresql-16.4-1-windows-x64-binaries.zip';
const VC_URL = process.env.VC_REDIST_URL || 'https://aka.ms/vs/17/release/vc_redist.x64.exe';
const V = path.join(__dirname, '..', 'vendor');
fs.mkdirSync(V, { recursive: true });

function baixar(url, dest, redir = 0) {
  return new Promise((resolve, reject) => {
    if (redir > 8) return reject(new Error('Muitos redirecionamentos'));
    https.get(url, { headers: { 'User-Agent': 'gestao-build' } }, res => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode)) { res.resume(); return resolve(baixar(new URL(res.headers.location, url).href, dest, redir + 1)); }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error(`HTTP ${res.statusCode} em ${url}`)); }
      const total = +res.headers['content-length'] || 0; let lido = 0, ult = 0;
      const f = fs.createWriteStream(dest);
      res.on('data', c => { lido += c.length; if (total && lido - ult > 20e6) { ult = lido; process.stdout.write(`  ${Math.round(lido / total * 100)}%\r`); } });
      res.pipe(f); f.on('finish', () => f.close(resolve)); f.on('error', reject);
    }).on('error', reject);
  });
}

(async () => {
  const pgExe = path.join(V, 'pgsql', 'bin', 'postgres.exe');
  if (!fs.existsSync(pgExe)) {
    const zip = path.join(V, 'pg.zip');
    console.log('Baixando PostgreSQL portátil (~300 MB)...'); await baixar(PG_URL, zip);
    console.log('Extraindo...');
    // extrai numa pasta curta (evita limite de caminho longo / OneDrive) e copia só o necessário
    const tmp = process.platform === 'win32' ? path.join(process.env.SystemDrive || 'C:', 'lopdv-tmp') : fs.mkdtempSync(path.join(require('os').tmpdir(), 'lopdv-'));
    fs.rmSync(tmp, { recursive: true, force: true }); fs.mkdirSync(tmp, { recursive: true });
    if (process.platform === 'win32') execFileSync('tar', ['-xf', zip, '-C', tmp], { stdio: 'inherit' });
    else execFileSync('unzip', ['-q', '-o', zip, '-d', tmp], { stdio: 'inherit' });
    fs.rmSync(path.join(V, 'pgsql'), { recursive: true, force: true });
    for (const d of ['bin', 'lib', 'share']) fs.cpSync(path.join(tmp, 'pgsql', d), path.join(V, 'pgsql', d), { recursive: true });
    fs.rmSync(tmp, { recursive: true, force: true });
    fs.unlinkSync(zip);
    if (!fs.existsSync(pgExe)) throw new Error('postgres.exe não encontrado após extrair. Confira PG_ZIP_URL.');
  } else console.log('PostgreSQL já baixado.');
  const vc = path.join(V, 'vc_redist.x64.exe');
  if (!fs.existsSync(vc)) { console.log('Baixando Visual C++ Runtime...'); await baixar(VC_URL, vc); } else console.log('Visual C++ Runtime já baixado.');
  console.log('Pronto.');
})().catch(e => { console.error('\nFalha ao preparar dependências do instalador:', e.message, '\nBaixe manualmente e coloque em vendor/ (veja README) ou ajuste PG_ZIP_URL / VC_REDIST_URL.'); process.exit(1); });
