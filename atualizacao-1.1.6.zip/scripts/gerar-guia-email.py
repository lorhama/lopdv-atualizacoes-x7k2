#!/usr/bin/env python3
"""Gera public/guia-email.pdf: passo a passo para configurar o envio de e-mails do LoPDV (Empresa > E-mail da empresa)."""
import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether, PageBreak
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
d = '/usr/share/fonts/truetype/dejavu/'
pdfmetrics.registerFont(TTFont('F', d + 'DejaVuSans.ttf')); pdfmetrics.registerFont(TTFont('FB', d + 'DejaVuSans-Bold.ttf'))
pdfmetrics.registerFontFamily('F', normal='F', bold='FB', italic='F', boldItalic='FB')
PRI = colors.HexColor('#b4472b'); CINZA = colors.HexColor('#6b7280'); LINHA = colors.HexColor('#e3e6ec')
h1 = ParagraphStyle('h1', fontName='FB', fontSize=21, leading=26, textColor=PRI, spaceAfter=4)
sub = ParagraphStyle('sub', fontName='F', fontSize=10.5, leading=15, textColor=CINZA, spaceAfter=14)
h2 = ParagraphStyle('h2', fontName='FB', fontSize=14, leading=19, spaceBefore=16, spaceAfter=6, textColor=colors.HexColor('#1f2430'), keepWithNext=1)
h3 = ParagraphStyle('h3', fontName='FB', fontSize=11, leading=15, spaceBefore=8, spaceAfter=3, keepWithNext=1)
p = ParagraphStyle('p', fontName='F', fontSize=10, leading=14.5, spaceAfter=4)
pc = ParagraphStyle('pc', parent=p, fontSize=9.2, leading=12.5, spaceAfter=0)
passo = ParagraphStyle('passo', parent=p, leftIndent=18, firstLineIndent=-18, spaceAfter=3)
def P(t, s=p): return Paragraph(t, s)
def passos(lista): return [P(f'<b>{i}.</b>&nbsp; {t}', passo) for i, t in enumerate(lista, 1)]
def caixa(titulo, texto, cor='#fff7e0', borda='#e6b800'):
    t = Table([[P(f'<b>{titulo}</b><br/>{texto}', pc)]], colWidths=[16.4 * cm])
    t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), colors.HexColor(cor)), ('BOX', (0, 0), (-1, -1), .8, colors.HexColor(borda)), ('LEFTPADDING', (0, 0), (-1, -1), 9), ('RIGHTPADDING', (0, 0), (-1, -1), 9), ('TOPPADDING', (0, 0), (-1, -1), 7), ('BOTTOMPADDING', (0, 0), (-1, -1), 7)]))
    return [Spacer(1, 4), t, Spacer(1, 6)]
def tabela(linhas, larg, cab=True):
    rows = [[P(c, pc) for c in l] for l in linhas]
    t = Table(rows, colWidths=[x * cm for x in larg], repeatRows=1 if cab else 0)
    est = [('GRID', (0, 0), (-1, -1), .5, LINHA), ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('TOPPADDING', (0, 0), (-1, -1), 5), ('BOTTOMPADDING', (0, 0), (-1, -1), 5)]
    if cab: est += [('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#f3e3dd'))]
    t.setStyle(TableStyle(est)); return [t, Spacer(1, 8)]
def valores(host, porta, seg, usuario, senha, extra=None):
    l = [['Campo no LoPDV', 'O que preencher'], ['Servidor SMTP', f'<b>{host}</b>'], ['Porta', f'<b>{porta}</b>'], ['Segurança', f'<b>{seg}</b>'], ['Usuário do e-mail', usuario], ['Senha do e-mail', senha]]
    if extra: l.append(extra)
    return tabela(l, [4.6, 11.8])

E = []
E += [P('Como configurar o envio de e-mails no LoPDV', h1), P('Passo a passo para Gmail, Outlook/Hotmail, Yahoo e e-mail do domínio da empresa', sub)]
E += [P('1. Para que serve', h2), P('O LoPDV usa um e-mail da empresa para <b>enviar mensagens automáticas</b>, como o <b>código de recuperação de senha</b> dos usuários. Para isso funcionar, é preciso informar ao sistema o <b>servidor de envio (SMTP)</b> da conta de e-mail da empresa. Essa configuração é feita uma única vez.'),
      P('<b>Onde configurar:</b> menu <b>Configurações &gt; Empresa</b>, cartão <b>"E-mail da empresa e envio de e-mails"</b>. Só um administrador tem acesso.')]
E += [P('2. O que cada campo significa', h2)]
E += tabela([['Campo na tela', 'O que é', 'Como preencher'],
  ['E-mail padrão da empresa (remetente)', 'O endereço que aparece como remetente nos e-mails enviados.', 'Use <b>o mesmo e-mail da conta</b> que vai enviar. Gmail e Outlook trocam o remetente se for diferente do usuário.'],
  ['Servidor SMTP', 'O endereço do servidor que envia os e-mails do seu provedor.', 'Depende do provedor (veja as seções seguintes). Ex.: <b>smtp.gmail.com</b>'],
  ['Porta', 'O "canal" de conexão com o servidor.', '<b>587</b> (mais comum) ou <b>465</b>. Evite a 25.'],
  ['Segurança', 'Tipo de criptografia da conexão.', 'Porta <b>587</b> = <b>STARTTLS</b>. Porta <b>465</b> = <b>SSL/TLS</b>. A segurança precisa combinar com a porta.'],
  ['Usuário do e-mail', 'Login da conta de e-mail.', 'Quase sempre é o <b>e-mail completo</b> (ex.: contato@suaempresa.com.br).'],
  ['Senha do e-mail', 'Senha que o servidor exige.', 'Em Gmail, Yahoo e (se disponível) Outlook use uma <b>"senha de app"</b>, e não a senha normal. Em e-mail de domínio próprio, a senha da caixa de e-mail.'],
  ['Enviar e-mail de teste para', 'Envia uma mensagem de teste para conferir tudo.', 'Digite o seu e-mail e clique em <b>Enviar teste</b>.']], [4.2, 5.2, 7.0])
E += caixa('Dica de ouro', 'Use um e-mail <b>exclusivo da empresa</b> para o sistema (por exemplo, sistema@suaempresa.com.br), e nunca o e-mail pessoal de alguém. Depois de salvar, a senha fica guardada <b>criptografada</b> no servidor do LoPDV.', '#eaf6ee', '#7bbf93')
E += [P('3. Antes de começar', h2)] + passos(['Tenha em mãos o <b>e-mail e a senha</b> da conta que vai enviar as mensagens.', 'O computador onde o LoPDV está instalado (o servidor) precisa estar <b>com internet</b>.', 'Se for Gmail ou Yahoo, tenha o <b>celular</b> por perto: a <b>verificação em duas etapas</b> pede um código.'])
E += [P('4. Gmail (@gmail.com) e Google Workspace', h2), P('O Gmail <b>não aceita a senha normal</b> para programas externos. É preciso criar uma <b>senha de app</b> de 16 letras, o que exige a verificação em duas etapas ligada.')]
E += [P('Parte A — criar a senha de app no Google', h3)] + passos([
  'Acesse <b>myaccount.google.com</b> e entre com o e-mail que vai enviar.', 'Abra <b>Segurança</b> (menu da esquerda).',
  'Em "Como você faz login no Google", ative a <b>Verificação em duas etapas</b> (se ainda não estiver ativa) e siga as instruções.',
  'Volte em Segurança e use a busca no topo da página para procurar por <b>"Senhas de app"</b> (ou acesse <b>myaccount.google.com/apppasswords</b>).',
  'Dê um nome, por exemplo <b>LoPDV</b>, e clique em <b>Criar</b>.', 'O Google mostra uma senha de <b>16 letras</b>. <b>Copie</b> e guarde: ela só aparece uma vez. No LoPDV, digite as 16 letras <b>sem espaços</b>.'])
E += [P('Parte B — preencher no LoPDV', h3)] + valores('smtp.gmail.com', '587', 'STARTTLS (porta 587)', 'seu e-mail completo, ex.: empresa@gmail.com', 'a <b>senha de app</b> de 16 letras')
E += [P('Também funciona com <b>porta 465</b> e segurança <b>SSL/TLS</b>. O e-mail padrão (remetente) deve ser o mesmo e-mail do usuário.')]
E += caixa('Bom saber', 'Contas Gmail comuns enviam até cerca de <b>500 e-mails por dia</b>; no Google Workspace, mais. Para recuperação de senha, é mais que suficiente. Em Google Workspace (e-mail do seu domínio pelo Google) os dados são os mesmos; se a opção "Senhas de app" não aparecer, o administrador do Workspace precisa liberar.')
E += [KeepTogether([P('5. Outlook, Hotmail e Live (Microsoft)', h2)] + caixa('Atenção', 'A Microsoft está <b>desligando o envio por senha</b> (autenticação básica) e passando a exigir outro método de login (OAuth), que o LoPDV <b>ainda não usa</b>. Dependendo da conta e da data, o envio pode <b>falhar mesmo com todos os dados corretos</b>. Se isso acontecer, use <b>Gmail</b> ou o <b>e-mail do domínio da empresa</b> (seções 4 e 7).', '#fdecea', '#e0867b'))]
E += [P('Se quiser tentar mesmo assim:', h3)] + passos(['Acesse <b>account.microsoft.com</b> &gt; <b>Segurança</b> &gt; <b>Opções de segurança avançadas</b> e ative a <b>verificação em duas etapas</b>.', 'Na mesma tela, crie uma <b>senha de aplicativo</b> (se a opção estiver disponível para a sua conta) e copie.', 'No LoPDV, preencha:'])
E += valores('smtp-mail.outlook.com', '587', 'STARTTLS (porta 587)', 'seu e-mail completo (@outlook.com, @hotmail.com ou @live.com)', 'a senha de aplicativo (ou a senha da conta, se não houver senha de app)')
E += [P('<b>Microsoft 365 (e-mail empresarial):</b> servidor <b>smtp.office365.com</b>, porta <b>587</b>, STARTTLS. A Microsoft vem <b>desativando a autenticação básica</b> por padrão; o administrador do Microsoft 365 precisaria habilitar o "SMTP autenticado" na caixa de e-mail. Como isso está sendo descontinuado, prefira outro provedor.')]
E += [P('6. Yahoo Mail', h2), P('Também exige <b>senha de app</b>. No Yahoo: <b>Informações da conta &gt; Segurança da conta &gt; Gerar senha de app</b> (a verificação em duas etapas deve estar ativa).')]
E += valores('smtp.mail.yahoo.com', '465 (ou 587)', 'SSL/TLS (porta 465)  — ou STARTTLS (porta 587)', 'seu e-mail completo do Yahoo', 'a <b>senha de app</b> gerada')
E += [P('7. E-mail do domínio da empresa (Locaweb, HostGator, UOL Host, Registro.br, etc.)', h2), P('Se a empresa tem um e-mail como <b>contato@suaempresa.com.br</b>, quem hospeda o e-mail é a empresa onde o domínio/hospedagem foi contratado. Aqui <b>não há senha de app</b>: use a senha normal da caixa de e-mail.')]
E += [P('Como descobrir os dados do seu provedor', h3)] + passos(['Entre no <b>painel do provedor</b> (Locaweb, HostGator, UOL Host etc.) ou abra o suporte.', 'Procure por <b>"Configurar e-mail no computador/celular"</b> ou <b>"Configurações do cliente de e-mail"</b>.', 'Anote o <b>servidor de saída (SMTP)</b>, a <b>porta</b> e o <b>tipo de segurança</b>.'])
E += valores('o servidor de saída que o provedor informar', '587 ou 465', 'STARTTLS se 587 · SSL/TLS se 465', 'o e-mail completo da caixa', 'a senha da caixa de e-mail')
E += tabela([['Provedor (exemplos comuns)', 'Servidor SMTP costuma ser', 'Porta'], ['Locaweb', 'email-ssl.com.br', '587 ou 465'], ['HostGator / cPanel em geral', 'mail.seudominio.com.br  (ou smtp.seudominio.com.br)', '465 (SSL/TLS) ou 587'], ['Outros provedores', 'veja no painel do seu provedor', '587 ou 465']], [5.0, 8.0, 3.4])
E += [P('<i>Os servidores acima são exemplos comuns. Sempre confirme no painel do seu provedor, pois podem variar de acordo com o plano.</i>', pc)]
E += [P('8. Testando', h2)] + passos(['Preencha todos os campos e clique em <b>Salvar</b>.', 'Em "Enviar e-mail de teste para", digite o <b>seu e-mail</b> e clique em <b>Enviar teste</b>.', 'Confira a <b>caixa de entrada</b> e também a pasta de <b>spam/lixo eletrônico</b>.', 'Chegou? Está tudo certo. Cadastre o <b>e-mail de cada usuário</b> em <b>Equipe &gt; Usuários</b>: é para esse e-mail que o código de recuperação de senha será enviado.'])
E += [P('9. Se der erro', h2)]
E += tabela([['O que aparece / acontece', 'Provável causa', 'O que fazer'],
  ['Usuário ou senha inválidos / falha de autenticação', 'Senha normal no lugar da senha de app (Gmail/Yahoo), usuário sem o @domínio, ou senha digitada errada.', 'Gere uma <b>senha de app</b>, digite sem espaços, e use o <b>e-mail completo</b> como usuário.'],
  ['Não conecta / tempo esgotado', 'Sem internet no servidor, porta bloqueada (antivírus, firewall ou provedor de internet) ou servidor errado.', 'Teste outra porta/segurança (587 STARTTLS ou 465 SSL/TLS). Confira o nome do servidor.'],
  ['Erro de certificado / segurança', 'Segurança não combina com a porta (ex.: porta 465 com STARTTLS).', '465 = SSL/TLS · 587 = STARTTLS.'],
  ['Diz que enviou, mas não chega', 'Foi para o spam, ou o remetente é diferente do usuário.', 'Olhe o spam. Use o <b>mesmo e-mail</b> no remetente e no usuário.'],
  ['Funcionava e parou', 'Senha de app foi revogada ou a senha da conta mudou.', 'Crie uma nova senha de app e atualize no LoPDV (campo <b>Senha do e-mail</b>).']], [4.8, 5.8, 5.8])
E += [P('Precisa de ajuda? Anote a mensagem de erro que aparece ao clicar em <b>Enviar teste</b> e envie ao suporte do LoPDV junto com o provedor de e-mail que a empresa usa.', p)]

def rodape(c, doc):
    c.saveState(); c.setFont('F', 8); c.setFillColor(CINZA); c.drawString(2.2 * cm, 1.2 * cm, 'LoPDV — Configuração de envio de e-mails'); c.drawRightString(A4[0] - 2.2 * cm, 1.2 * cm, f'Página {doc.page}'); c.restoreState()
out = os.path.join(os.path.dirname(__file__), '..', 'public', 'guia-email.pdf')
SimpleDocTemplate(out, pagesize=A4, leftMargin=2.2 * cm, rightMargin=2.2 * cm, topMargin=2 * cm, bottomMargin=2 * cm, title='LoPDV — Configuração de envio de e-mails').build(E, onFirstPage=rodape, onLaterPages=rodape)
print(os.path.abspath(out))
