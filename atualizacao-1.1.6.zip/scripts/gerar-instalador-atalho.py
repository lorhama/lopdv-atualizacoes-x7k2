# Gera terminais/Instalar-Atalho-LoPDV.bat: instalador autônomo do atalho para os terminais (ícone embutido).
import base64, io, os
from PIL import Image
root=os.path.join(os.path.dirname(__file__),'..')
big=Image.open(os.path.join(root,'public','icon.png')).convert('RGBA').resize((256,256),Image.LANCZOS)
buf=io.BytesIO(); big.save(buf,format='ICO',sizes=[(256,256),(64,64),(48,48),(32,32),(16,16)])
b64=base64.b64encode(buf.getvalue()).decode()
b64='\r\n'.join(b64[i:i+100] for i in range(0,len(b64),100))
ps=r'''
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName Microsoft.VisualBasic
Add-Type -AssemblyName System.Windows.Forms
function Msg($t,$b='OK',$i='Information'){ return [System.Windows.Forms.MessageBox]::Show($t,'LoPDV - Atalho do terminal',$b,$i) }
try {
  $pasta = Join-Path $env:LOCALAPPDATA 'LoPDV'
  New-Item -Force -ItemType Directory $pasta | Out-Null
  $arq = Join-Path $pasta 'servidor.txt'
  $ico = Join-Path $pasta 'icone.ico'
  $desk = [Environment]::GetFolderPath('Desktop')
  $lnk = Join-Path $desk 'LoPDV.lnk'; $urlf = Join-Path $desk 'LoPDV.url'
  if ((Test-Path $lnk) -or (Test-Path $urlf)) {
    $r = Msg "O atalho do LoPDV ja existe nesta area de trabalho.`n`nSim = atualizar (recriar)`nNao = remover o atalho`nCancelar = sair" 'YesNoCancel' 'Question'
    if ($r -eq 'Cancel') { exit }
    if ($r -eq 'No') { Remove-Item $lnk,$urlf -Force -ErrorAction SilentlyContinue; Msg 'Atalho removido.' | Out-Null; exit }
  }
  $padrao = '192.168.0.10:3737'
  if (Test-Path $arq) { $padrao = (Get-Content $arq -TotalCount 1) }
  $end = [Microsoft.VisualBasic.Interaction]::InputBox("Digite o endereco (IP) do computador SERVIDOR do LoPDV.`n`nExemplo: 192.168.0.10:3737", 'LoPDV - Atalho do terminal', $padrao)
  if (-not $end) { exit }
  $end = ($end.Trim() -replace '^https?://','') -replace '/.*$',''
  if ($end -notmatch ':\d+$') { $end = $end + ':3737' }
  $url = 'http://' + $end + '/'
  $ok = $true
  try { Invoke-WebRequest -UseBasicParsing -TimeoutSec 6 ($url + 'api/saude') | Out-Null } catch { $ok = $false }
  if (-not $ok) {
    $r = Msg ("Nao foi possivel conectar em " + $url + "`n`nVerifique se o servidor esta ligado, na mesma rede, e se o endereco esta certo.`n`nCriar o atalho mesmo assim?") 'YesNo' 'Warning'
    if ($r -ne 'Yes') { exit }
  }
  $dados = $script:ICONE_B64 -replace '\s',''
  [IO.File]::WriteAllBytes($ico, [Convert]::FromBase64String($dados))
  Set-Content -Path $arq -Value $end -Encoding ASCII
  Remove-Item $lnk,$urlf -Force -ErrorAction SilentlyContinue
  $cands = @("$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe", "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")
  $nav = $cands | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
  if ($nav) {
    $s = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk)
    $s.TargetPath = $nav; $s.Arguments = '--app=' + $url + ' --window-size=460,700'; $s.IconLocation = $ico; $s.Description = 'LoPDV'; $s.Save()
  } else {
    $conteudo = "[InternetShortcut]`r`nURL=" + $url + "`r`nIconFile=" + $ico + "`r`nIconIndex=0`r`n"
    Set-Content -Path $urlf -Value $conteudo -Encoding ASCII
  }
  Msg ("Pronto! O atalho LoPDV foi criado na area de trabalho.`n`nServidor: " + $url) | Out-Null
} catch {
  Msg ("Ocorreu um erro:`n" + $_.Exception.Message) 'OK' 'Error' | Out-Null
}
'''
script="$script:ICONE_B64 = @'\r\n"+b64+"\r\n'@\r\n"+ps.replace('\n','\r\n')
head=("@echo off\r\n"
"rem LoPDV - instalador do atalho para terminais (nao precisa de instalacao nem de internet)\r\n"
"powershell -NoProfile -ExecutionPolicy Bypass -STA -Command \"$t=[IO.File]::ReadAllText('%~f0'); $i=$t.IndexOf('#PS'+'START'); iex $t.Substring($i+8)\"\r\n"
"exit /b\r\n"
"#PS"+"START\r\n")
out=os.path.join(root,'terminais','Instalar-Atalho-LoPDV.bat')
open(out,'w',newline='',encoding='ascii').write(head+script)
print(out, os.path.getsize(out))
