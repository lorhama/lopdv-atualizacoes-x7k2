#!/usr/bin/env python3
"""Gera o pacote de atualizacao automatica: atualizacao-<v>.zip + versao.json (assinado com a chave privada em .chaves/).
Suba os DOIS arquivos no mesmo endereco publico (ex.: uma release do GitHub). Os clientes veem o aviso e atualizam sozinhos."""
import os, io, json, zipfile, hashlib, base64, subprocess, tempfile, sys, datetime
raiz = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
v = json.load(open(os.path.join(raiz, 'package.json'), encoding='utf-8'))['version']
EXCL = {'node_modules', 'dist', 'data', 'vendor', '.git', '.chaves', 'test'}
zp = os.path.join(raiz, f'atualizacao-{v}.zip')
with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED, 9) as z:
    for d, ds, fs in os.walk(raiz):
        ds[:] = [x for x in ds if x not in EXCL]
        for f in fs:
            if f.startswith(('Instalar-LoPDV', 'Notas-')) or (f.startswith('atualizacao-') and f.endswith('.zip')) or f in ('versao.json', 'fabrica.json'): continue
            p = os.path.join(d, f); z.write(p, os.path.relpath(p, raiz).replace('\\', '/'))
sha = hashlib.sha256(open(zp, 'rb').read()).hexdigest()
chave = os.path.join(raiz, '.chaves', 'chave-privada-atualizacao.pem')
if not os.path.exists(chave): sys.exit('Chave privada de assinatura nao encontrada em .chaves/ (guarde-a em local seguro).')
with tempfile.TemporaryDirectory() as t:
    m = os.path.join(t, 'm'); s = os.path.join(t, 's'); open(m, 'wb').write(f'{v}|{sha}'.encode())
    subprocess.check_call(['openssl', 'pkeyutl', '-sign', '-inkey', chave, '-rawin', '-in', m, '-out', s])
    assinatura = base64.b64encode(open(s, 'rb').read()).decode()
nov = json.load(open(os.path.join(raiz, 'novidades.json'), encoding='utf-8'))['versoes']
atual = next((x for x in nov if x['versao'] == v), {'itens': []})
man = {'versao': v, 'data': atual.get('data') or datetime.date.today().strftime('%d/%m/%Y'), 'arquivo': os.path.basename(zp), 'sha256': sha,
       'tamanho': os.path.getsize(zp), 'assinatura': assinatura, 'notas': atual['itens']}
json.dump(man, open(os.path.join(raiz, 'versao.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('Pacote:', zp, os.path.getsize(zp), 'bytes; manifesto: versao.json')
