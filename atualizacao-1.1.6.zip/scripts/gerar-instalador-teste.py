# Gera Instalar-LoPDV.bat: instalador SEM .exe (um único arquivo com o sistema dentro) para instalar e testar no Windows.
# Instala Node.js e PostgreSQL (se faltarem), copia o sistema, cria banco, atalho, firewall e inicialização automática.
import base64, io, json, os, zipfile, glob
root=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'))
VERSAO=json.load(open(os.path.join(root,'package.json'),encoding='utf-8'))['version']
EXCL={'node_modules','dist','data','vendor','.git','.chaves'}
buf=io.BytesIO()
with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED,9) as z:
    for d,ds,fs in os.walk(root):
        ds[:]=[x for x in ds if x not in EXCL]
        for f in fs:
            if f.endswith('.bat') and f.startswith('Instalar-LoPDV'): continue
            if (f.startswith('atualizacao-') and f.endswith('.zip')) or f=='versao.json': continue
            p=os.path.join(d,f); z.write(p,os.path.relpath(p,root).replace('\\','/'))
b64=base64.b64encode(buf.getvalue()).decode(); b64='\r\n'.join(b64[i:i+120] for i in range(0,len(b64),120))
PS=r'''
$ErrorActionPreference = 'Continue'
Add-Type -AssemblyName System.Windows.Forms
$REG = 'HKLM:\SOFTWARE\LoPDV'; $UNREG = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\LoPDV'
$VERSAO = '@@VERSAO@@'; $PGSENHA = 'postgres123'; $PORTA = 3737; $TAREFA = 'LoPDV Servidor'
# ---- LOG UNICO: cada linha recebe data e hora, em ordem cronologica (mais antigo primeiro), acertos e erros juntos.
$global:LOG = Join-Path $env:TEMP 'LoPDV-instalacao-tmp.log'
Remove-Item $global:LOG -Force -ErrorAction SilentlyContinue
function Gravar($txt){
  if ($null -eq $txt -or ("$txt").Trim() -eq '') { return }
  try { Add-Content -Path $global:LOG -Value ('[' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '] ' + $txt) -Encoding UTF8 } catch { }
}
# Toda mensagem mostrada na tela tambem vai para o log.
function Write-Host {
  param([Parameter(Position=0,ValueFromPipeline=$true,ValueFromRemainingArguments=$true)][object]$Objects, [object]$ForegroundColor)
  process {
    $txt = (@($Objects) | ForEach-Object { "$_" }) -join ' '
    Gravar $txt
    UiLog $txt $ForegroundColor
    if ($ForegroundColor) { Microsoft.PowerShell.Utility\Write-Host $txt -ForegroundColor $ForegroundColor } else { Microsoft.PowerShell.Utility\Write-Host $txt }
  }
}
function Ok($t){ Write-Host ('OK: ' + $t) -ForegroundColor Green }

# ================= TELA DO INSTALADOR (janela bonita; se algo falhar ao criar, segue no console) =================
$global:UI = $null
function Cor($r,$g,$b){ return [System.Drawing.Color]::FromArgb($r,$g,$b) }
function UiRotulo($txt,$x,$y,$w,$h,$fonte,$cor){
  $l = New-Object System.Windows.Forms.Label
  $l.Text = $txt; $l.Location = New-Object System.Drawing.Point($x,$y); $l.Size = New-Object System.Drawing.Size($w,$h)
  $l.Font = $fonte; $l.ForeColor = $cor; $l.BackColor = [System.Drawing.Color]::Transparent
  return $l
}
function UiCriar {
  try {
    Add-Type -AssemblyName System.Drawing
    try { Add-Type -Namespace LoPDV -Name Con -MemberDefinition '[DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow(); [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);' } catch { }
    [System.Windows.Forms.Application]::EnableVisualStyles()
    $fn = { param($n,$s,$e) New-Object System.Drawing.Font($n, [single]$s, [System.Drawing.FontStyle]$e) }
    $f = New-Object System.Windows.Forms.Form
    $f.Text = 'Instalador LoPDV'; $f.StartPosition = 'CenterScreen'; $f.FormBorderStyle = 'FixedSingle'; $f.MaximizeBox = $false
    $f.ClientSize = New-Object System.Drawing.Size(780, 604); $f.BackColor = (Cor 246 247 251); $f.Font = (& $fn 'Segoe UI' 9.5 'Regular')
    $h = New-Object System.Windows.Forms.Panel; $h.Dock = 'Top'; $h.Height = 96; $h.BackColor = (Cor 27 33 54)
    $logo = UiRotulo 'L' 28 20 56 56 (& $fn 'Segoe UI' 26 'Bold') ([System.Drawing.Color]::White); $logo.BackColor = (Cor 176 60 40); $logo.TextAlign = 'MiddleCenter'
    $t1 = UiRotulo 'LoPDV' 100 12 400 40 (& $fn 'Segoe UI' 22 'Bold') ([System.Drawing.Color]::White)
    $t2 = UiRotulo ('Instalador do sistema  -  versao ' + $VERSAO) 102 58 500 24 (& $fn 'Segoe UI' 10 'Regular') (Cor 170 178 205)
    $h.Controls.AddRange(@($logo, $t1, $t2))
    $passo = UiRotulo 'Preparando a instalacao...' 28 112 724 30 (& $fn 'Segoe UI Semibold' 14 'Regular') (Cor 27 33 54)
    $bar = New-Object System.Windows.Forms.ProgressBar; $bar.Location = New-Object System.Drawing.Point(28, 150); $bar.Size = New-Object System.Drawing.Size(724, 20)
    $bar.Minimum = 0; $bar.Maximum = 100; $bar.Style = 'Marquee'; $bar.MarqueeAnimationSpeed = 30
    $det = UiRotulo '' 28 176 724 22 (& $fn 'Segoe UI' 9.5 'Regular') (Cor 100 108 130)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Location = New-Object System.Drawing.Point(28, 206); $rtb.Size = New-Object System.Drawing.Size(724, 268)
    $rtb.ReadOnly = $true; $rtb.BackColor = (Cor 20 23 33); $rtb.ForeColor = (Cor 214 218 230); $rtb.Font = (& $fn 'Consolas' 9 'Regular'); $rtb.BorderStyle = 'None'; $rtb.HideSelection = $false
    $res = UiRotulo '' 28 484 724 64 (& $fn 'Segoe UI Semibold' 11 'Regular') (Cor 27 33 54); $res.BackColor = (Cor 255 255 255); $res.Visible = $false; $res.Padding = New-Object System.Windows.Forms.Padding(12, 6, 12, 6)
    $bL = New-Object System.Windows.Forms.Button; $bL.Text = 'Abrir a pasta dos logs'; $bL.Location = New-Object System.Drawing.Point(28, 558); $bL.Size = New-Object System.Drawing.Size(190, 34); $bL.Visible = $false
    $bA = New-Object System.Windows.Forms.Button; $bA.Text = 'Abrir o LoPDV'; $bA.Location = New-Object System.Drawing.Point(486, 558); $bA.Size = New-Object System.Drawing.Size(150, 34); $bA.Visible = $false
    $bA.FlatStyle = 'Flat'; $bA.BackColor = (Cor 176 60 40); $bA.ForeColor = [System.Drawing.Color]::White; $bA.FlatAppearance.BorderSize = 0
    $bF = New-Object System.Windows.Forms.Button; $bF.Text = 'Fechar'; $bF.Location = New-Object System.Drawing.Point(646, 558); $bF.Size = New-Object System.Drawing.Size(106, 34); $bF.Enabled = $false
    $bL.Add_Click({ try { Start-Process explorer.exe -ArgumentList ('"' + (Split-Path $global:LOG) + '"') } catch { } })
    $bA.Add_Click({ try { if ($global:ABRIR) { Start-Process explorer.exe -ArgumentList ('"' + $global:ABRIR + '"') } } catch { } })
    $bF.Add_Click({ $global:UI.F.Close() })
    $f.Add_FormClosing({ param($s,$e)
      if ($global:UI -and -not $global:UI.Fim) {
        $r = Perguntar ("Cancelar a instalacao?`n`nSe cancelar agora, o que ja foi copiado continua na pasta de instalacao e o log e mantido. Para continuar depois, execute o instalador de novo.") @('Continuar instalando', 'Cancelar instalacao')
        if ($r -ne 'Cancelar instalacao') { $e.Cancel = $true } else { try { Gravar 'Instalacao cancelada pelo usuario.' } catch { }; [Environment]::Exit(1) }
      } })
    $f.Controls.AddRange(@($h, $passo, $bar, $det, $rtb, $res, $bL, $bA, $bF))
    $global:UI = @{ F = $f; Passo = $passo; Bar = $bar; Det = $det; Log = $rtb; Res = $res; BF = $bF; BA = $bA; BL = $bL; Fim = $false }
    $f.Show(); $f.Activate()
    try { $w = [LoPDV.Con]::GetConsoleWindow(); if ($w -ne [IntPtr]::Zero) { [void][LoPDV.Con]::ShowWindow($w, 0) } } catch { }
    [System.Windows.Forms.Application]::DoEvents()
  } catch { $global:UI = $null }
}
function UiPasso($n,$total,$txt){
  try { $u = $global:UI; $u.Bar.Style = 'Continuous'; $u.Bar.Value = [int][math]::Min(100, [math]::Max(0, 100 * ($n - 1) / $total)); $u.Passo.Text = 'Passo ' + $n + ' de ' + $total + '  -  ' + $txt } catch { }
}
function UiLog($txt,$cor){
  if (-not $global:UI -or $null -eq $txt -or ("$txt").Trim() -eq '') { return }
  try {
    switch ("$cor") { 'Green' { $c = (Cor 110 220 140) } 'Red' { $c = (Cor 255 125 115) } 'Yellow' { $c = (Cor 240 200 90) } 'Cyan' { $c = (Cor 120 195 255) } default { $c = (Cor 214 218 230) } }
    $r = $global:UI.Log; $r.SelectionStart = $r.TextLength; $r.SelectionLength = 0; $r.SelectionColor = $c
    $r.AppendText((Get-Date -Format 'HH:mm:ss') + '  ' + $txt + "`n"); $r.SelectionStart = $r.TextLength; $r.ScrollToCaret()
    if ($txt -match '^>> (\d+)/(\d+)\s+(.*)$') { UiPasso ([int]$Matches[1]) ([int]$Matches[2]) $Matches[3] }
    elseif ($txt -match '^>> (.*)$') { $global:UI.Passo.Text = $Matches[1]; $global:UI.Bar.Style = 'Marquee' }
    else { $global:UI.Det.Text = $txt.Trim() }
    [System.Windows.Forms.Application]::DoEvents()
  } catch { }
}
function UiFim($ok,$titulo,$msg){
  if (-not $global:UI) { return }
  try {
    $u = $global:UI; $u.Fim = $true
    if ($ok) { $u.Bar.Style = 'Continuous'; $u.Bar.Value = 100 } else { $u.Bar.MarqueeAnimationSpeed = 0; $u.Bar.Style = 'Continuous' }
    $u.Passo.Text = $(if ($ok) { 'Instalacao concluida' } else { 'A instalacao nao terminou' }); $u.Det.Text = ''
    $u.Res.Text = $titulo + "`n" + $msg
    if ($ok) { $u.Res.BackColor = (Cor 220 245 228); $u.Res.ForeColor = (Cor 20 110 55) } else { $u.Res.BackColor = (Cor 253 226 223); $u.Res.ForeColor = (Cor 160 35 25) }
    $u.Res.Visible = $true; $u.BL.Visible = $true; $u.BA.Visible = $ok; $u.BF.Enabled = $true
    $u.F.Activate(); [System.Windows.Forms.Application]::DoEvents()
  } catch { }
}
function UiAguardar { if (-not $global:UI) { return }; try { while ($global:UI.F.Visible) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 100 } } catch { } }
# espera sem congelar a janela
function Dormir($s){ $fim = (Get-Date).AddSeconds($s); while ((Get-Date) -lt $fim) { if ($global:UI) { [System.Windows.Forms.Application]::DoEvents() }; Start-Sleep -Milliseconds 100 } }

Gravar ('===== Instalador LoPDV ' + $VERSAO + ' iniciado =====')
# Depois de escolhida a pasta, o log passa a ser gravado dentro dela (pasta\logs\instalacao.log), acrescentando ao que ja existe.
function MoverLog($dir){
  try {
    $ld = Join-Path $dir 'logs'; New-Item -ItemType Directory -Force -Path $ld | Out-Null
    $arq = Join-Path $ld 'instalacao.log'
    if ((Test-Path $arq) -and ((Get-Item $arq).Length -gt 2MB)) { Move-Item $arq (Join-Path $ld ('instalacao-' + (Get-Date -Format 'yyyy-MM-dd_HHmmss') + '.log')) -Force }
    Get-ChildItem $ld -Filter 'instalacao-*.log' -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-30) } | Remove-Item -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $ld 'npm-install.log') -Force -ErrorAction SilentlyContinue
    $antes = Get-Content $global:LOG -Encoding UTF8 -ErrorAction SilentlyContinue
    if ($antes) { Add-Content -Path $arq -Value $antes -Encoding UTF8 }
    Remove-Item $global:LOG -Force -ErrorAction SilentlyContinue
    $global:LOG = $arq
  } catch { }
}
# Mostra que ainda esta trabalhando: a cada 10 s escreve o tempo decorrido e a ultima linha do log do instalador filho.
function Esperar($proc,$rotulo,$logArq){
  $ini = Get-Date; $ultimo = ''; $mudou = Get-Date; $proxLog = (Get-Date).AddSeconds(10)
  $null = $proc.Handle   # sem isto o PowerShell perde o ExitCode de processos iniciados com -PassThru
  while (-not $proc.HasExited) {
    Dormir 1
    $dec = [int]((Get-Date) - $ini).TotalSeconds
    $tempo = [string]::Format('{0:00}:{1:00}', [int][math]::Floor($dec / 60), [int]($dec % 60))
    if ($global:UI) { try { $global:UI.Det.Text = $rotulo + ' - ' + $tempo + ' (nao feche a janela)' } catch { } }
    if ((Get-Date) -lt $proxLog) { continue }
    $proxLog = (Get-Date).AddSeconds(10)
    $linha = ''
    if ($logArq -and (Test-Path $logArq)) { $linha = [string](Get-Content $logArq -Tail 1 -ErrorAction SilentlyContinue) }
    if ($linha -ne $ultimo) { $ultimo = $linha; $mudou = Get-Date }
    $sem = [int]((Get-Date) - $mudou).TotalSeconds
    $msg = '   ... ' + $rotulo + ' (' + $tempo + ')'
    if ($linha.Trim()) { $msg += ' - ' + $linha.Trim() }
    if ($logArq -and $sem -ge 180) { $msg += '  [sem novidades ha ' + [int][math]::Floor($sem / 60) + ' min]' }
    Write-Host $msg
  }
  $proc.WaitForExit()
  return $proc.ExitCode
}
# Pergunta com botoes nomeados pela funcao (a caixa padrao do Windows so tem Sim/Nao). Retorna o texto do botao; X/Esc retorna $null.
function Perguntar($texto,$botoes){
  $f = New-Object System.Windows.Forms.Form
  $f.Text = 'Instalador LoPDV'; $f.StartPosition = 'CenterScreen'; $f.FormBorderStyle = 'FixedDialog'
  $f.MaximizeBox = $false; $f.MinimizeBox = $false; $f.TopMost = $true; $f.ShowInTaskbar = $true
  $f.ClientSize = New-Object System.Drawing.Size(560, 250)
  $l = New-Object System.Windows.Forms.Label
  $l.Text = $texto; $l.Location = New-Object System.Drawing.Point(20, 16); $l.Size = New-Object System.Drawing.Size(520, 170)
  $l.Font = New-Object System.Drawing.Font('Segoe UI', 10)
  $f.Controls.Add($l)
  $global:RESP = $null
  $x = 560 - 20
  for ($i = $botoes.Count - 1; $i -ge 0; $i--) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $botoes[$i]; $b.Tag = $botoes[$i]; $b.Size = New-Object System.Drawing.Size(165, 34)
    $x -= 165; $b.Location = New-Object System.Drawing.Point($x, 200); $x -= 10
    $b.Add_Click({ $global:RESP = $this.Tag; $this.FindForm().Close() })
    $f.Controls.Add($b)
  }
  [void]$f.ShowDialog()
  return $global:RESP
}
function Msg($t,$b='OK',$i='Information'){ return [System.Windows.Forms.MessageBox]::Show($t,'Instalador LoPDV',$b,$i) }
function Passo($t){ Write-Host ''; Write-Host ('>> ' + $t) -ForegroundColor Cyan }
function AtualizaPath { $env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User') }
function TemPG {
  if (Test-Path 'HKLM:\SOFTWARE\PostgreSQL\Installations') { if (@(Get-ChildItem 'HKLM:\SOFTWARE\PostgreSQL\Installations' -ErrorAction SilentlyContinue).Count -gt 0) { return $true } }
  if (@(Get-Service -Name 'postgresql*' -ErrorAction SilentlyContinue).Count -gt 0) { return $true }
  return $false
}
function AcharPsql { return (Get-ChildItem "$env:ProgramFiles\PostgreSQL\*\bin\psql.exe" -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | Select-Object -First 1).FullName }
function PortaAberta($porta,$seg){
  $fim = (Get-Date).AddSeconds($seg)
  while ((Get-Date) -lt $fim) { try { $c = New-Object Net.Sockets.TcpClient; $c.Connect('127.0.0.1',$porta); $c.Close(); return $true } catch { Dormir 2 } }
  return $false
}
function NodeDoSistema($dir){ return @(Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and $dir -and $_.CommandLine -like ('*' + $dir + '*server*index.js*') }) }
function PararSistema($dir){
  $ativos = (NodeDoSistema $dir).Count
  if ($ativos -gt 0) { Write-Host ('Parando o sistema em execucao (' + $ativos + ' processo(s)); isso faz o backup de fechamento...') }
  try { Invoke-WebRequest -UseBasicParsing -Method Post -Uri ('http://127.0.0.1:' + $PORTA + '/local/encerrar') -TimeoutSec 5 | Out-Null } catch { }
  for ($i = 0; $i -lt 60; $i++) { if ((NodeDoSistema $dir).Count -eq 0) { break }; Dormir 1 }
  NodeDoSistema $dir | ForEach-Object { Write-Host ('Forcando o encerramento do processo ' + $_.ProcessId); Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  # o que mais pode estar segurando a pasta: o iniciador (servidor.cmd / Abrir-LoPDV.vbs) e qualquer coisa ainda ouvindo a porta do sistema
  Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and $dir -and $_.Name -match '^(cmd|wscript|cscript)\.exe$' -and $_.CommandLine -like ('*' + $dir + '*') -and $_.ProcessId -ne $PID } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  try { Get-NetTCPConnection -LocalPort $PORTA -State Listen -ErrorAction SilentlyContinue | ForEach-Object { $pr = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue; if ($pr -and $pr.ProcessName -eq 'node') { Write-Host ('Encerrando node que ainda usava a porta ' + $PORTA); Stop-Process -Id $pr.Id -Force -ErrorAction SilentlyContinue } } } catch { }
  for ($i = 0; $i -lt 20; $i++) { $livre = $true; try { $c = New-Object Net.Sockets.TcpClient; $c.Connect('127.0.0.1', $PORTA); $c.Close(); $livre = $false } catch { }; if ($livre) { break }; Dormir 1 }
}
function Baixar($url,$destino){
  Write-Host ('Baixando: ' + $url)
  $feito = $false
  try {
    $job = Start-BitsTransfer -Source $url -Destination $destino -Asynchronous -ErrorAction Stop
    $ult = -1
    while ($job.JobState -in 'Queued','Connecting','Transferring','TransientError') {
      Dormir 1
      if ($job.BytesTotal -gt 0) {
        $pc = [int](100 * $job.BytesTransferred / $job.BytesTotal)
        if ($global:UI) { try { $global:UI.Det.Text = 'Baixando: ' + [math]::Round($job.BytesTransferred / 1MB) + ' de ' + [math]::Round($job.BytesTotal / 1MB) + ' MB (' + $pc + '%)' } catch { } }
        if ($pc -ge $ult + 10) { $ult = $pc; Write-Host ('   ... baixado ' + $pc + '%') }
      }
    }
    if ($job.JobState -eq 'Transferred') { Complete-BitsTransfer -BitsJob $job; $feito = $true } else { Remove-BitsTransfer -BitsJob $job -ErrorAction SilentlyContinue; throw 'download BITS nao concluido' }
  } catch {
    if (-not $feito) { Write-Host 'Download com progresso indisponivel, baixando sem barra (pode demorar)...'; $ProgressPreference = 'SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $destino }
  }
  Write-Host ('Download concluido: ' + [math]::Round((Get-Item $destino).Length / 1MB) + ' MB')
}

# ------------------------------------------------------------ DESINSTALAR
function Desinstalar($dir,$pgNosso){
  Passo 'Desinstalando o LoPDV'
  PararSistema $dir
  try { Unregister-ScheduledTask -TaskName $TAREFA -Confirm:$false -ErrorAction SilentlyContinue } catch { }
  Remove-NetFirewallRule -DisplayName 'LoPDV' -ErrorAction SilentlyContinue
  foreach ($d in @([Environment]::GetFolderPath('CommonDesktopDirectory'), [Environment]::GetFolderPath('Desktop'))) { Remove-Item (Join-Path $d 'LoPDV.lnk') -Force -ErrorAction SilentlyContinue }
  $rpg = 'Manter banco'
  if ($pgNosso) { $rpg = Perguntar "Deseja remover tambem o PostgreSQL instalado por este instalador?`n`nATENCAO: remover o banco APAGA todas as vendas e cadastros.`n`nRemover banco = remove o PostgreSQL e todos os dados`nManter banco = desinstala o LoPDV e mantem o banco de dados" @('Remover banco','Manter banco') }
  if ($rpg -eq 'Remover banco') {
    $un = Get-ChildItem "$env:ProgramFiles\PostgreSQL\*\uninstall-postgresql.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($un) { Passo 'Removendo o PostgreSQL'; Start-Process -FilePath $un.FullName -ArgumentList '--mode unattended' -Wait; Dormir 3 }
    Remove-Item "$env:ProgramFiles\PostgreSQL" -Recurse -Force -ErrorAction SilentlyContinue
  }
  Remove-Item $REG -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item $UNREG -Recurse -Force -ErrorAction SilentlyContinue
  if ($dir -and (Test-Path $dir)) { Start-Process cmd.exe -ArgumentList ('/c for /l %i in (1,1,100) do (ping -n 4 127.0.0.1 >nul & rmdir /s /q "' + $dir + '" 2>nul & if not exist "' + $dir + '" exit)') -WindowStyle Hidden }
  Msg ('LoPDV desinstalado.' + $(if ($rpg -ne 'Remover banco' -and $pgNosso) { "`nO banco de dados (PostgreSQL) foi mantido." } else { '' })) | Out-Null
}

UiCriar

try {
  # ------------------------------------------------------------ JA INSTALADO?
  $atual = Get-ItemProperty $REG -ErrorAction SilentlyContinue
  $reparar = $false; $pgNosso = $false
  if ($atual -and $atual.InstallLocation) {
    $dir = $atual.InstallLocation; $pgNosso = ($atual.PostgresInstalado -eq 1)
    $verAtual = [string]$atual.Versao; $acao = 'REPARAR (reinstala os arquivos, mantem o banco)'; $info = ''
    $incompleta = ($atual.Incompleta -eq 1)
    try {
      if ($verAtual) {
        if ([version]$verAtual -lt [version]$VERSAO) { $acao = 'ATUALIZAR de ' + $verAtual + ' para ' + $VERSAO + ' (mantem o banco; faz backup antes)' }
        elseif ([version]$verAtual -gt [version]$VERSAO) { $acao = 'REINSTALAR a versao ANTERIOR ' + $VERSAO + ' (a instalada e a ' + $verAtual + ')' }
        else { $acao = 'REPARAR a versao ' + $VERSAO + ' (reinstala os arquivos, mantem o banco)' }
      }
    } catch { }
    $cab = 'O LoPDV ja esta instalado em:'
    if ($incompleta) { $cab = 'Uma instalacao anterior NAO foi concluida em:'; $acao = 'CONTINUAR a instalacao de onde parou' }
    $btnOk = (Get-Culture).TextInfo.ToTitleCase(($acao -split ' ')[0].ToLower())
    $r = Perguntar ($cab + "`n" + $dir + "`nVersao instalada: " + $(if ($verAtual) { $verAtual } else { 'desconhecida' }) + "`nVersao deste instalador: " + $VERSAO + "`n`n" + $acao + "`nDesinstalar = remove o LoPDV deste computador`nCancelar = sai sem fazer nada") @($btnOk, 'Desinstalar', 'Cancelar')
    if (-not $r -or $r -eq 'Cancelar') { exit }
    if ($r -eq 'Desinstalar') { Desinstalar $dir $pgNosso; exit }
    $reparar = $true
  } else {
    if (TemPG) {
      Msg "Ja existe um PostgreSQL instalado neste computador.`n`nPor seguranca, a instalacao foi cancelada para nao interferir nos dados existentes.`n`nDesinstale o PostgreSQL atual (Configuracoes > Aplicativos) e execute este instalador novamente." 'OK' 'Stop' | Out-Null
      exit
    }
    $fb = New-Object System.Windows.Forms.FolderBrowserDialog
    $fb.Description = 'Escolha a pasta onde o LoPDV sera instalado (uma subpasta LoPDV sera usada se a escolhida nao estiver vazia)'
    $fb.SelectedPath = 'C:\'
    $fb.ShowNewFolderButton = $true
    if ($fb.ShowDialog() -ne 'OK') { exit }
    $dir = $fb.SelectedPath
    if ((Test-Path $dir) -and (@(Get-ChildItem $dir -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne 'logs' }).Count -gt 0)) { $dir = Join-Path $dir 'LoPDV' }
  }
  Write-Host ('Pasta de instalacao: ' + $dir) -ForegroundColor Yellow
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  MoverLog $dir
  Write-Host ('Log desta instalacao: ' + $global:LOG) -ForegroundColor Yellow
  if (-not $reparar) {
    if (-not (Test-Path $REG)) { New-Item -Path $REG -Force | Out-Null }
    Set-ItemProperty $REG -Name InstallLocation -Value $dir
    Set-ItemProperty $REG -Name Versao -Value $VERSAO
    Set-ItemProperty $REG -Name PostgresInstalado -Value 0 -Type DWord
  }
  if (-not (Test-Path $REG)) { New-Item -Path $REG -Force | Out-Null }
  Set-ItemProperty $REG -Name Incompleta -Value 1 -Type DWord

  # ------------------------------------------------------------ NODE.JS
  Passo '1/7  Node.js'
  AtualizaPath
  if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
      Write-Host 'Instalando o Node.js pelo winget...'
      $p = Start-Process winget -ArgumentList 'install -e --id OpenJS.NodeJS.LTS --silent --accept-package-agreements --accept-source-agreements' -NoNewWindow -PassThru
      $rc = Esperar $p 'instalando o Node.js' $null; Write-Host ('winget terminou com codigo ' + $rc)
    }
    AtualizaPath
    if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
      Write-Host 'Baixando o Node.js do site oficial...'
      $v = (Invoke-RestMethod 'https://nodejs.org/dist/index.json' | Where-Object { $_.lts } | Select-Object -First 1).version
      $msi = Join-Path $env:TEMP 'node-lts.msi'; Baixar ('https://nodejs.org/dist/' + $v + '/node-' + $v + '-x64.msi') $msi
      $mlog = Join-Path $env:TEMP 'node-msi.log'
      $p = Start-Process msiexec.exe -ArgumentList ('/i "' + $msi + '" /qn /norestart /l*v "' + $mlog + '"') -PassThru
      $rc = Esperar $p 'instalando o Node.js' $mlog; Write-Host ('Instalador do Node terminou com codigo ' + $rc)
      AtualizaPath
    }
    if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Nao foi possivel instalar o Node.js. Verifique a internet.' }
  }
  Write-Host ('Node.js: ' + (& node -v))

  # ------------------------------------------------------------ POSTGRESQL
  Passo '2/7  PostgreSQL'
  if (-not $reparar -or -not (TemPG)) {
    $pglog = Join-Path $env:TEMP 'install-postgresql.log'
    Remove-Item $pglog -Force -ErrorAction SilentlyContinue
    if (Get-Command winget -ErrorAction SilentlyContinue) {
      Write-Host 'Baixando e instalando o PostgreSQL pelo winget (a instalacao em si leva de 3 a 10 minutos e nao mostra janela)...'
      $ov = '--mode unattended --unattendedmodeui none --superpassword ' + $PGSENHA + ' --serverport 5432'
      $p = Start-Process winget -ArgumentList ('install -e --id PostgreSQL.PostgreSQL.16 --silent --accept-package-agreements --accept-source-agreements --override "' + $ov + '"') -NoNewWindow -PassThru
      $rc = Esperar $p 'instalando o PostgreSQL' $pglog; Write-Host ('winget terminou com codigo ' + $rc)
    }
    if (-not (TemPG)) {
      Write-Host 'Baixando o PostgreSQL do site oficial (cerca de 300 MB)...'
      $exe = Join-Path $env:TEMP 'postgresql-16-windows-x64.exe'
      Baixar 'https://get.enterprisedb.com/postgresql/postgresql-16.4-1-windows-x64.exe' $exe
      $p = Start-Process -FilePath $exe -ArgumentList ('--mode unattended --unattendedmodeui none --superpassword ' + $PGSENHA + ' --serverport 5432') -PassThru
      $rc = Esperar $p 'instalando o PostgreSQL' $pglog; Write-Host ('Instalador do PostgreSQL terminou com codigo ' + $rc)
    }
    if (-not (TemPG)) { throw 'Nao foi possivel instalar o PostgreSQL.' }
    $pgNosso = $true
    Set-ItemProperty $REG -Name PostgresInstalado -Value 1 -Type DWord
    Write-Host 'PostgreSQL instalado.'
  }
  Get-Service -Name 'postgresql*' -ErrorAction SilentlyContinue | Where-Object { $_.Status -ne 'Running' } | ForEach-Object { Start-Service $_.Name -ErrorAction SilentlyContinue }
  Write-Host 'Aguardando o PostgreSQL responder na porta 5432...'
  if (-not (PortaAberta 5432 90)) { throw 'O PostgreSQL nao respondeu na porta 5432.' }
  $psql = AcharPsql; if (-not $psql) { throw 'psql.exe nao encontrado.' }
  $env:PGPASSWORD = $PGSENHA
  $existe = (& $psql -h 127.0.0.1 -p 5432 -U postgres -tAc "select 1 from pg_database where datname='gestao'") 2>&1
  if (("$existe").Trim() -ne '1') {
    & $psql -h 127.0.0.1 -p 5432 -U postgres -c 'CREATE DATABASE gestao' 2>&1 | ForEach-Object { Write-Host $_ }
    if ($LASTEXITCODE -ne 0) { throw 'Nao foi possivel criar o banco gestao (a senha do usuario postgres e postgres123?).' }
  }
  Write-Host 'Banco "gestao" pronto (usuario postgres / senha postgres123).'
  if ($reparar) {
    try {
      $pgdump = Join-Path (Split-Path $psql) 'pg_dump.exe'; $bd = Join-Path $dir 'data\backups'; New-Item -ItemType Directory -Force -Path $bd | Out-Null
      $arqb = Join-Path $bd ('gestao-' + (Get-Date -Format 'yyyy-MM-dd_HHmmss') + '-pre-atualizacao.dump')
      & $pgdump -h 127.0.0.1 -p 5432 -U postgres -F c -f $arqb gestao
      if ($LASTEXITCODE -eq 0) { Write-Host ('Backup antes da atualizacao: ' + $arqb) } else { Write-Host 'Aviso: o backup antes da atualizacao falhou.' -ForegroundColor Yellow }
    } catch { Write-Host ('Aviso: backup antes da atualizacao: ' + $_.Exception.Message) -ForegroundColor Yellow }
  }

  # ------------------------------------------------------------ ARQUIVOS
  Passo '3/7  Copiando o sistema'
  if ($reparar) { PararSistema $dir }
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  $t = [IO.File]::ReadAllText($env:LOPDV_BAT)
  $dados = $t.Substring($t.IndexOf('#ZIP' + 'START') + 9) -replace '\s',''
  $zip = Join-Path $env:TEMP 'lopdv-sistema.zip'
  [IO.File]::WriteAllBytes($zip, [Convert]::FromBase64String($dados))
  Expand-Archive -Path $zip -DestinationPath $dir -Force
  Remove-Item $zip -Force -ErrorAction SilentlyContinue
  Ok 'arquivos do sistema copiados'
  Copy-Item $env:LOPDV_BAT (Join-Path $dir 'Instalador-LoPDV.bat') -Force
  $dataDir = Join-Path $dir 'data'; New-Item -ItemType Directory -Force -Path $dataDir | Out-Null
  $cfgFile = Join-Path $dataDir 'config.json'
  if (-not (Test-Path $cfgFile)) {
    $cfg = '{"porta":3737,"db":{"host":"127.0.0.1","port":5432,"user":"postgres","password":"postgres123","database":"gestao"}}'
    [IO.File]::WriteAllText($cfgFile, $cfg, (New-Object Text.UTF8Encoding($false)))
  }

  Passo '4/7  Instalando dependencias (npm)'
  Write-Host 'Baixando as bibliotecas do sistema (1 a 3 minutos)...'
  $nlog = Join-Path $env:TEMP 'lopdv-npm.log'; Remove-Item $nlog -Force -ErrorAction SilentlyContinue
  $p = Start-Process cmd.exe -ArgumentList ('/c npm.cmd install --omit=dev --no-audit --no-fund > "' + $nlog + '" 2>&1') -WorkingDirectory $dir -NoNewWindow -PassThru
  $npmOk = Esperar $p 'npm install' $nlog
  if (Test-Path $nlog) { Gravar '--- saida completa do npm ---'; Get-Content $nlog -ErrorAction SilentlyContinue | ForEach-Object { Gravar ('npm> ' + $_) }; Gravar '--- fim da saida do npm ---' }
  if ($null -eq $npmOk) { if (Test-Path (Join-Path $dir 'node_modules\pg')) { $npmOk = 0 } else { $npmOk = -1 } }
  if ($npmOk -ne 0) { throw ('Falha no npm install (codigo ' + $npmOk + '). A saida do npm esta no log.') }
  Ok 'bibliotecas do sistema instaladas (npm)'

  # ------------------------------------------------------------ INICIALIZACAO
  Passo '5/7  Arquivos de inicializacao, backup e firewall'
  & icacls $dataDir /grant '*S-1-5-32-545:(OI)(CI)M' /T | Out-Null
  $cmd = "@echo off`r`ncd /d `"%~dp0`"`r`nset GESTAO_DATA_DIR=%~dp0data`r`nnode `"%~dp0server\index.js`" >> `"%~dp0data\servidor.log`" 2>&1`r`n"
  [IO.File]::WriteAllText((Join-Path $dir 'servidor.cmd'), $cmd, [Text.Encoding]::ASCII)
  Remove-Item (Join-Path $dir 'iniciar.cmd'), (Join-Path $dir 'Iniciar-LoPDV.vbs') -Force -ErrorAction SilentlyContinue
  try { Unregister-ScheduledTask -TaskName $TAREFA -Confirm:$false -ErrorAction SilentlyContinue } catch { }
  $nav = @("$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe", "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe") | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
  if ($nav) { $abrir = 'sh.Run """' + $nav + '"" --app=http://localhost:' + $PORTA + '/ --window-size=460,700 --disable-save-password-bubble --disable-features=PasswordManagerOnboarding,AutofillCreditCardSignin", 1, False' } else { $abrir = 'sh.Run "http://localhost:' + $PORTA + '/", 1, False' }
  $vbs = @'
Set sh = CreateObject("Wscript.Shell")
Function Rodando()
  Rodando = (sh.Run("cmd /c netstat -ano | findstr "":@@PORTA@@ "" | findstr LISTENING >nul", 0, True) = 0)
End Function
If Not Rodando() Then sh.Run """@@DIR@@\servidor.cmd""", 0, False
For i = 1 To 45
  If Rodando() Then Exit For
  WScript.Sleep 2000
Next
@@ABRIR@@
'@
  $vbs = $vbs.Replace('@@PORTA@@', [string]$PORTA).Replace('@@DIR@@', $dir).Replace('@@ABRIR@@', $abrir)
  [IO.File]::WriteAllText((Join-Path $dir 'Abrir-LoPDV.vbs'), $vbs, [Text.Encoding]::Default)
  $par = @'
try { Invoke-WebRequest -UseBasicParsing -Method Post -Uri 'http://127.0.0.1:@@PORTA@@/local/encerrar' -TimeoutSec 5 | Out-Null } catch { }
for ($i = 0; $i -lt 60; $i++) { $p = @(Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object { $_.CommandLine -like '*@@DIR@@*server*index.js*' }); if ($p.Count -eq 0) { break }; Start-Sleep -Seconds 1 }
Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object { $_.CommandLine -like '*@@DIR@@*server*index.js*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
'@
  [IO.File]::WriteAllText((Join-Path $dir 'parar.ps1'), $par.Replace('@@DIR@@', $dir).Replace('@@PORTA@@', [string]$PORTA), [Text.Encoding]::Default)
  [IO.File]::WriteAllText((Join-Path $dir 'Parar-LoPDV.bat'), "@echo off`r`npowershell -NoProfile -ExecutionPolicy Bypass -File `"%~dp0parar.ps1`"`r`necho LoPDV encerrado (backup de fechamento feito).`r`npause`r`n", [Text.Encoding]::ASCII)
  $pgr = (Get-ChildItem "$env:ProgramFiles\PostgreSQL\*\bin\pg_restore.exe" -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | Select-Object -First 1).FullName
  if ($pgr) {
    $rest = "@echo off`r`nif `"%~1`"==`"`" (echo Arraste um arquivo .dump de backup para cima deste arquivo. & pause & exit /b)`r`necho ATENCAO: isto SUBSTITUI os dados atuais pelos do backup. Feche o LoPDV antes (Parar-LoPDV).`r`nchoice /m `"Continuar`"`r`nif errorlevel 2 exit /b`r`nset PGPASSWORD=postgres123`r`n`"$pgr`" -h 127.0.0.1 -p 5432 -U postgres -d gestao --clean --if-exists `"%~1`"`r`npause`r`n"
    [IO.File]::WriteAllText((Join-Path $dir 'Restaurar-Backup.bat'), $rest, [Text.Encoding]::ASCII)
  }
  Remove-NetFirewallRule -DisplayName 'LoPDV' -ErrorAction SilentlyContinue
  New-NetFirewallRule -DisplayName 'LoPDV' -Direction Inbound -Protocol TCP -LocalPort $PORTA -Action Allow | Out-Null

  Passo '6/7  Atalho e registro'
  $ico = Join-Path $dir 'public\icone.ico'
  $lnk = Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'LoPDV.lnk'
  $s = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk)
  $s.TargetPath = 'wscript.exe'; $s.Arguments = '"' + (Join-Path $dir 'Abrir-LoPDV.vbs') + '"'; $s.WorkingDirectory = $dir
  $s.IconLocation = $ico; $s.Description = 'LoPDV (inicia o servidor se necessario e abre o sistema)'; $s.Save()
  if (-not (Test-Path $REG)) { New-Item -Path $REG -Force | Out-Null }
  Set-ItemProperty $REG -Name InstallLocation -Value $dir
  Set-ItemProperty $REG -Name Versao -Value $VERSAO
  Set-ItemProperty $REG -Name PostgresInstalado -Value ([int]$pgNosso) -Type DWord
  New-Item -Path $UNREG -Force | Out-Null
  Set-ItemProperty $UNREG -Name DisplayName -Value 'LoPDV'
  Set-ItemProperty $UNREG -Name DisplayVersion -Value $VERSAO
  Set-ItemProperty $UNREG -Name DisplayIcon -Value $ico
  Set-ItemProperty $UNREG -Name InstallLocation -Value $dir
  Set-ItemProperty $UNREG -Name Publisher -Value 'LoPDV'
  Set-ItemProperty $UNREG -Name UninstallString -Value ('"' + (Join-Path $dir 'Instalador-LoPDV.bat') + '"')

  Ok 'atalho, firewall e registro do sistema criados'
  Passo '7/7  Iniciando o sistema (abre sozinho em instantes)'
  Start-Process explorer.exe -ArgumentList ('"' + $lnk + '"')
  $no = PortaAberta $PORTA 120
  if (-not $no) {
    Write-Host 'O sistema ainda nao respondeu. Veja o arquivo data\servidor.log na pasta de instalacao. Ultimas linhas dele:' -ForegroundColor Red
    $sl = Join-Path $dir 'data\servidor.log'
    if (Test-Path $sl) { Get-Content $sl -Tail 25 -ErrorAction SilentlyContinue | ForEach-Object { Write-Host ('servidor.log> ' + $_) -ForegroundColor Red } } else { Write-Host 'servidor.log nao existe: o servidor nem chegou a iniciar.' -ForegroundColor Red }
  }
  $ips = (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | ForEach-Object { $_.IPAddress }) -join ', '
  $global:ABRIR = $lnk
  if ($no) {
    Set-ItemProperty $REG -Name Incompleta -Value 0 -Type DWord
    $global:OKFIM = $true
    Write-Host 'SISTEMA INSTALADO COM SUCESSO.' -ForegroundColor Green
    Write-Host ('Pasta: ' + $dir); Write-Host ('Log da instalacao: ' + $global:LOG)
    Write-Host 'Para usar, abra o atalho LoPDV na area de trabalho (ele liga o servidor se estiver desligado). O sistema NAO inicia junto com o Windows.'
    Write-Host ('Backup automatico ao abrir e ao fechar (guarda 3 dias) em: ' + $dataDir + '\backups')
    Write-Host 'Login inicial: admin / admin123 (troque a senha). PostgreSQL: usuario postgres / senha postgres123.'
    Write-Host ('Outros computadores da rede: http://' + $(if ($ips) { ($ips -split ', ')[0] } else { 'IP-DO-SERVIDOR' }) + ':' + $PORTA + '/instalar')
    UiFim $true 'Sistema instalado com sucesso!' 'O LoPDV ja esta pronto. Pode fechar esta janela; para usar depois, abra o atalho LoPDV na area de trabalho.'
    if (-not $global:UI) { Msg ('LoPDV ' + $VERSAO + ' instalado com SUCESSO!' + "`n`nPasta: " + $dir + "`nLog: " + $global:LOG) | Out-Null }
  } else {
    Set-ItemProperty $REG -Name Incompleta -Value 1 -Type DWord
    Write-Host 'ERRO: o sistema foi copiado, mas NAO iniciou. Nao e possivel usar ainda.' -ForegroundColor Red
    Write-Host ('Log da instalacao: ' + $global:LOG) -ForegroundColor Yellow
    Write-Host ('Log do servidor:   ' + (Join-Path $dir 'data\servidor.log')) -ForegroundColor Yellow
    UiFim $false 'Deu erro: o sistema foi instalado, mas nao iniciou.' ('Feche esta janela e procure os logs na pasta do sistema: ' + (Join-Path $dir 'data\servidor.log') + '  e  ' + $global:LOG)
    if (-not $global:UI) { Msg ("DEU ERRO: o sistema NAO iniciou.`n`nLog do servidor: " + (Join-Path $dir 'data\servidor.log') + "`nLog da instalacao: " + $global:LOG) 'OK' 'Error' | Out-Null }
  }
} catch {
  Write-Host ''; Write-Host ('ERRO: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host ($_ | Out-String)
  $pgl = Join-Path $env:TEMP 'install-postgresql.log'
  if ((Test-Path $pgl) -and ($_.Exception.Message -match 'PostgreSQL|psql|5432|banco')) { Write-Host '--- ultimas linhas do log do instalador do PostgreSQL ---'; Get-Content $pgl -Tail 25 | ForEach-Object { Write-Host $_ } }
  if ($dir) { Write-Host ('A pasta de instalacao foi MANTIDA: ' + $dir) -ForegroundColor Yellow }
  Write-Host ('Log completo: ' + $global:LOG) -ForegroundColor Yellow
  UiFim $false 'Deu erro na instalacao.' ('Feche esta janela e procure o log em: ' + $global:LOG + '   (a pasta de instalacao foi mantida; depois de resolver, execute o instalador novamente).')
  if (-not $global:UI) {
    try { Start-Process notepad.exe -ArgumentList ('"' + $global:LOG + '"') } catch { }
    Msg ("A instalacao nao foi concluida:`n" + $_.Exception.Message + "`n`nA pasta de instalacao foi mantida e o log foi aberto no Bloco de Notas:`n" + $global:LOG + "`n`nPara continuar depois de resolver, execute o instalador novamente.") 'OK' 'Error' | Out-Null
  }
}
# instalacao/atualizacao concluida sem erro: a janela se fecha sozinha (com erro, continua aberta para ler o log)
if ($global:OKFIM -and $global:UI) { Dormir 6; try { $global:UI.F.Close() } catch { } } else { UiAguardar }
if (-not $global:UI) { Read-Host 'Pressione ENTER para fechar' | Out-Null }
'''
head=("@echo off\r\n"
"net session >nul 2>&1\r\n"
"if errorlevel 1 (\r\n  powershell -NoProfile -Command \"Start-Process -FilePath '%~f0' -Verb RunAs\"\r\n  exit /b\r\n)\r\n"
"set \"LOPDV_BAT=%~f0\"\r\n"
"title Instalador LoPDV\r\n"
"powershell -NoProfile -ExecutionPolicy Bypass -STA -Command \"$t=[IO.File]::ReadAllText($env:LOPDV_BAT); $i=$t.IndexOf('#PS'+'START'); $j=$t.IndexOf('#ZIP'+'START'); iex $t.Substring($i+8,$j-$i-8)\"\r\n"
"exit /b\r\n"
"#PS"+"START\r\n")
for old in glob.glob(os.path.join(root,'Instalar-LoPDV*.bat')): os.remove(old)
out=os.path.join(root,f'Instalar-LoPDV-{VERSAO}.bat')
data=head+PS.replace('@@VERSAO@@',VERSAO).replace('\n','\r\n')+"\r\n#ZIP"+"START\r\n"+b64+"\r\n"
open(out,'w',newline='',encoding='ascii').write(data)
print(out, os.path.getsize(out))
