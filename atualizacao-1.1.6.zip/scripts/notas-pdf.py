#!/usr/bin/env python3
"""Converte Notas-<versão>.md em PDF. Uso: python3 scripts/notas-pdf.py Notas-1.0.0.md"""
import sys, re, os
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, ListFlowable, ListItem
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
d = '/usr/share/fonts/truetype/dejavu/'
pdfmetrics.registerFont(TTFont('F', d + 'DejaVuSans.ttf')); pdfmetrics.registerFont(TTFont('FB', d + 'DejaVuSans-Bold.ttf'))
src = sys.argv[1]; out = os.path.splitext(src)[0] + '.pdf'
h1 = ParagraphStyle('h1', fontName='FB', fontSize=20, leading=26, textColor=colors.HexColor('#3b2a4a'), spaceAfter=14)
h2 = ParagraphStyle('h2', fontName='FB', fontSize=13, leading=18, spaceBefore=14, spaceAfter=6)
p = ParagraphStyle('p', fontName='F', fontSize=10.5, leading=15)
esc = lambda s: s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
fmt = lambda s: re.sub(r'`([^`]+)`', r'<font face="FB">\1</font>', esc(s))
el, itens = [], []
def flush():
    global itens
    if itens: el.append(ListFlowable([ListItem(Paragraph(fmt(i), p), leftIndent=14) for i in itens], bulletType='bullet', start='•', leftIndent=14)); itens = []
for l in open(src, encoding='utf-8').read().splitlines():
    if l.startswith('# '): flush(); el.append(Paragraph(fmt(l[2:]), h1))
    elif l.startswith('## '): flush(); el.append(Paragraph(fmt(l[3:]), h2))
    elif l.startswith('- '): itens.append(l[2:])
    elif l.strip(): flush(); el.append(Paragraph(fmt(l), p))
flush()
SimpleDocTemplate(out, pagesize=A4, leftMargin=2.2*cm, rightMargin=2.2*cm, topMargin=2.2*cm, bottomMargin=2*cm, title=os.path.basename(out)).build(el)
print(out)
