#!/usr/bin/env python3
"""Gestão de versão do LoPDV (série 1.x: só atualizações até a Lohama autorizar outra).
Uso:
  python3 scripts/nova-versao.py 1.0.1 -c "correção" -c "outra" -m "melhoria" [-f id-da-fabrica ...] [-d PASTA_DESTINO]
Faz: atualiza package.json, CHANGELOG.md e fabrica.json; gera Instalar-LoPDV-<versão>.bat e Notas-<versão>.md
(e copia os dois para a pasta destino, se -d for informado)."""
import argparse, json, os, re, shutil, subprocess, sys, datetime
raiz = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
ap = argparse.ArgumentParser()
ap.add_argument('versao'); ap.add_argument('-c', action='append', default=[]); ap.add_argument('-m', action='append', default=[])
ap.add_argument('-f', action='append', default=[]); ap.add_argument('-d')
ap.add_argument('--autorizado-maior', action='store_true', help='só use se a Lohama pediu para sair da versão 1')
a = ap.parse_args()
if not re.fullmatch(r'\d+\.\d+\.\d+', a.versao): sys.exit('Versão no formato MAIOR.MENOR.CORREÇÃO')
if not (a.c or a.m): sys.exit('Informe ao menos uma correção (-c) ou melhoria (-m).')
pj = os.path.join(raiz, 'package.json'); j = json.load(open(pj, encoding='utf-8'))
tup = lambda v: tuple(int(x) for x in v.split('.'))
if tup(a.versao) <= tup(j['version']): sys.exit(f'A nova versão ({a.versao}) precisa ser maior que a atual ({j["version"]}).')
if a.versao.split('.')[0] != '1' and not a.autorizado_maior:
    sys.exit('Bloqueado: o sistema fica na versão 1.x até a Lohama autorizar.')
hoje = datetime.date.today().strftime('%d/%m/%Y')
j['version'] = a.versao; json.dump(j, open(pj, 'w', encoding='utf-8'), indent=2, ensure_ascii=False)
linhas = [f'- Correção: {x}' for x in a.c] + [f'- Melhoria: {x}' for x in a.m]
ch = os.path.join(raiz, 'CHANGELOG.md'); t = open(ch, encoding='utf-8').read()
i = t.index('## ') if '## ' in t else len(t)
open(ch, 'w', encoding='utf-8').write(t[:i] + f'## {a.versao} — {hoje}\n' + '\n'.join(linhas) + '\n\n' + t[i:])
fp = os.path.join(raiz, 'fabrica.json'); f = json.load(open(fp, encoding='utf-8'))
f['fabrica'] = [x for x in f['fabrica'] if x['id'] not in a.f]
f['sugeridas'] = [x for x in f['sugeridas'] if x['id'] not in a.f]
f['lancadas'].insert(0, {'versao': a.versao, 'data': hoje,
    'itens': [{'tipo': 'correcao', 'texto': x} for x in a.c] + [{'tipo': 'melhoria', 'texto': x} for x in a.m]})
json.dump(f, open(fp, 'w', encoding='utf-8'), indent=2, ensure_ascii=False)
json.dump({'versoes': f['lancadas'][:8]}, open(os.path.join(raiz, 'novidades.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
subprocess.check_call([sys.executable, os.path.join(raiz, 'scripts', 'gerar-instalador-teste.py')])
subprocess.check_call([sys.executable, os.path.join(raiz, 'scripts', 'gerar-atualizacao.py')])
notas = f'# LoPDV {a.versao} — {hoje}\n\n'
if a.c: notas += '## Correções\n' + ''.join(f'- {x}\n' for x in a.c) + '\n'
if a.m: notas += '## Melhorias\n' + ''.join(f'- {x}\n' for x in a.m) + '\n'
notas += '## Como atualizar\nExecute `Instalar-LoPDV-%s.bat` na máquina servidora e escolha "Reparar/Atualizar". Os dados e o backup são mantidos.\n' % a.versao
npath = os.path.join(raiz, f'Notas-{a.versao}.md'); open(npath, 'w', encoding='utf-8').write(notas)
subprocess.check_call([sys.executable, os.path.join(raiz, 'scripts', 'notas-pdf.py'), npath])
pdf = npath[:-3] + '.pdf'
inst = os.path.join(raiz, f'Instalar-LoPDV-{a.versao}.bat')
if a.d:
    os.makedirs(a.d, exist_ok=True)
    for p in (inst, pdf): shutil.copy(p, a.d)  # instalador + notas em PDF
    os.makedirs(os.path.join(a.d, 'Atualizacao-automatica'), exist_ok=True)  # os 2 arquivos que sobem na hospedagem
    for p in (os.path.join(raiz, f'atualizacao-{a.versao}.zip'), os.path.join(raiz, 'versao.json')): shutil.copy(p, os.path.join(a.d, 'Atualizacao-automatica'))
print(f'Versão {a.versao} registrada. Arquivos: {inst} e {npath}')
