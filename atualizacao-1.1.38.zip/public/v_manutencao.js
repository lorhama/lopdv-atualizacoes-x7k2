// Manutenção: alteração em massa (produtos, fornecedores) e importação de tabela de preços / estoque por arquivo CSV.
(() => {
  // ---------- utilitários de arquivo ----------
  const lerArquivo = file => new Promise((ok, err) => { const fr = new FileReader(); fr.onerror = () => err(new Error('Não foi possível ler o arquivo.')); fr.onload = () => {
    const buf = fr.result; let t; try { t = new TextDecoder('utf-8', { fatal: true }).decode(buf); } catch { t = new TextDecoder('windows-1252').decode(buf); }   // CSV salvo pelo Excel costuma ser ANSI
    ok(t.replace(/^﻿/, '')); }; fr.readAsArrayBuffer(file); });
  const parseCsv = txt => { // separador ; , ou tab (detectado), campos entre aspas
    const prim = txt.split(/\r?\n/).find(l => l.trim()) || '', sep = [';', '\t', ','].map(s => [s, prim.split(s).length]).sort((a, b) => b[1] - a[1])[0][0];
    const rows = []; let row = [], cur = '', q = false;
    for (let i = 0; i < txt.length; i++) { const ch = txt[i];
      if (q) { if (ch === '"') { if (txt[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += ch; }
      else if (ch === '"') q = true; else if (ch === sep) { row.push(cur); cur = ''; }
      else if (ch === '\n' || ch === '\r') { if (ch === '\r' && txt[i + 1] === '\n') i++; row.push(cur); cur = ''; if (row.some(c => c.trim())) rows.push(row); row = []; }
      else cur += ch; }
    row.push(cur); if (row.some(c => c.trim())) rows.push(row);
    return rows;
  };
  const norm = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  // acha as colunas pelo nome do cabeçalho (aceita variações); sem cabeçalho usa a 1ª e a 2ª colunas
  const colunas = (rows, nomes, opcionais = []) => {
    const cab = rows[0].map(norm), idx = nomes.map(lista => cab.findIndex(c => lista.includes(c))), opc = opcionais.map(lista => cab.findIndex(c => lista.includes(c)));
    if (idx.every(i => i >= 0)) return { idx, opc, dados: rows.slice(1), inicio: 2 };
    if (idx.some(i => i >= 0)) throw new Error('Não achei todas as colunas pelo cabeçalho. Use o arquivo modelo (botões de modelo desta tela).');
    if (/^[\d.,\s]+$/.test(rows[0][0] || '')) return { idx: nomes.map((_, i) => i), opc: opcionais.map(() => -1), dados: rows, inicio: 1 };   // sem cabeçalho
    throw new Error('Não reconheci o cabeçalho do arquivo. Use o arquivo modelo (botões de modelo desta tela).');
  };
  const baixar = (nome, linhas) => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + linhas.map(l => l.map(v => /[";\n]/.test(String(v)) ? '"' + String(v).replace(/"/g, '""') + '"' : v).join(';')).join('\r\n')], { type: 'text/csv;charset=utf-8' })); a.download = nome; a.click(); };
  const fmtN = n => String(n).replace('.', ',');
  const chipSt = x => (x.status === 'ok' ? chip('será alterado', 'ok') : x.status === 'igual' ? chip('sem mudança', 'cancelado') : chip('erro: ' + esc(x.motivo), 'warn'));

  // ---------- Alteração em massa: base comum (produtos / fornecedores) ----------
  function massa({ id, titulo, rota, carregar, filtros, colunasTab, painel, coletar, rotulo }) {
    registrar({ id, titulo, grupo: 'Manutenção', perm: 'manutencao.acessar', render: async el => {
      let dados = await carregar(), vis = [];
      el.innerHTML = `<div class="card"><p class="muted" style="margin:0">Filtre, marque os cadastros que quer alterar e escolha abaixo o que mudar. Nada é gravado antes de você confirmar. Só os campos marcados em <b>"Alterar"</b> são mudados; o resto fica como está.</p></div>
        <div class="bar" id="flt">${filtros.html}</div><div id="tb"></div>
        <div class="card" style="margin-top:10px"><h3 style="margin:0 0 8px">O que alterar nos <span id="nsel">0</span> selecionado(s)</h3>${painel}
          <div style="margin-top:10px"><button class="btn primary" id="aplicar">Aplicar alterações nos selecionados</button></div></div>`;
      const contar = () => $$('input[data-sel]:checked', el).length;
      const atual = () => { $('#nsel', el).textContent = contar(); };
      const desenha = () => { vis = filtros.filtra(dados, el); $('#tb', el).innerHTML = `<div class="row" style="align-items:center;margin:6px 0"><button class="btn sm" id="todos" type="button">Marcar todos os exibidos</button><button class="btn sm" id="nenhum" type="button">Desmarcar todos</button><span class="muted">${vis.length} ${rotulo}(s) na lista</span></div>` +
        tabela([{ l: '✔', f: x => `<input type="checkbox" data-sel="${x.id}">` }, ...colunasTab], vis, { vazio: 'Nenhum cadastro com esse filtro.' }); atual(); };
      desenha();
      el.addEventListener('input', e => { if (e.target.closest('#flt')) desenha(); });
      el.addEventListener('change', e => { if (e.target.matches('input[data-sel]')) atual(); if (e.target.closest('#flt')) desenha(); });
      el.onclick = seguro(async e => {
        if (e.target.id === 'todos') { $$('#tb tbody tr', el).forEach(tr => { if (tr.style.display !== 'none') $('input[data-sel]', tr).checked = true; }); return atual(); }
        if (e.target.id === 'nenhum') { $$('input[data-sel]', el).forEach(c => { c.checked = false; }); return atual(); }
        if (e.target.id !== 'aplicar') return;
        const sel = $$('input[data-sel]:checked', el).map(c => Number(c.dataset.sel)); if (!sel.length) throw new Error('Marque ao menos um cadastro na lista.');
        const { alteracoes, resumo } = coletar(el); if (!Object.keys(alteracoes).length) throw new Error('Marque ao menos um campo em "Alterar" e preencha o valor.');
        if (!await confirmar(`Aplicar nos ${sel.length} ${rotulo}(s) selecionado(s):\n${resumo}\n\nAs alterações ficam gravadas na auditoria.`, 'Aplicar')) return;
        const r = await api('/manutencao/' + rota, { method: 'POST', body: { ids: sel, alteracoes } });
        toast(`${r.alterados} ${rotulo}(s) alterado(s).`, 'ok'); dados = await carregar(); desenha();
      });
    } });
  }
  const lin = (nome, campoHtml) => `<div class="row" style="align-items:center;margin:4px 0"><label style="flex:0 0 130px;margin:0"><input type="checkbox" data-alt="${nome}"> <b>Alterar</b></label>${campoHtml}</div>`;
  const ligado = (el, n) => $(`input[data-alt="${n}"]`, el).checked;

  // ---- produtos
  let catsCache = [];
  const painelProdutos = () => lin('categoria_id', `<label style="margin:0">Categoria<select id="pc"><option value="0">(sem categoria)</option>${catsCache.map(c => `<option value="${c.id}">${esc(c.nome)}</option>`).join('')}</select></label>`) +
    lin('destino', `<label style="margin:0">Destino<select id="pd"><option value="nenhum">nenhum</option><option value="cozinha">cozinha</option><option value="bar">bar</option></select></label>`) +
    lin('preco', `<label style="margin:0">Preço de venda<select id="pm"><option value="valor">Definir o valor</option><option value="aumentar">Aumentar em %</option><option value="reduzir">Reduzir em %</option></select></label><label style="margin:0">Valor<input id="pv" inputmode="decimal" style="width:110px" placeholder="0,00"></label>`) +
    lin('estoque_minimo', `<label style="margin:0">Estoque mínimo<input id="pe" inputmode="decimal" style="width:110px" placeholder="0"></label>`) +
    lin('vendavel', `<label style="margin:0">Vendável<select id="pn"><option value="1">sim</option><option value="0">não</option></select></label>`) +
    lin('ativo', `<label style="margin:0">Situação<select id="pa"><option value="1">ativo</option><option value="0">inativo</option></select></label>`);
  const coletaProdutos = el => { const a = {}, rs = [];
    if (ligado(el, 'categoria_id')) { a.categoria_id = Number($('#pc', el).value); rs.push('• categoria: ' + $('#pc', el).selectedOptions[0].textContent); }
    if (ligado(el, 'destino')) { a.destino = $('#pd', el).value; rs.push('• destino: ' + a.destino); }
    if (ligado(el, 'preco')) { const v = $('#pv', el).value.trim(); if (!v) throw new Error('Informe o valor do preço.'); a.preco = { modo: $('#pm', el).value, valor: v }; rs.push('• preço: ' + $('#pm', el).selectedOptions[0].textContent + ' ' + v); }
    if (ligado(el, 'estoque_minimo')) { const v = $('#pe', el).value.trim(); if (!v) throw new Error('Informe o estoque mínimo.'); a.estoque_minimo = v; rs.push('• estoque mínimo: ' + v); }
    if (ligado(el, 'vendavel')) { a.vendavel = $('#pn', el).value === '1'; rs.push('• vendável: ' + (a.vendavel ? 'sim' : 'não')); }
    if (ligado(el, 'ativo')) { a.ativo = $('#pa', el).value === '1'; rs.push('• situação: ' + (a.ativo ? 'ativo' : 'inativo')); }
    return { alteracoes: a, resumo: rs.join('\n') }; };
  registrar({ id: 'man-produtos', titulo: 'Alteração em massa de produtos', grupo: 'Manutenção', perm: 'manutencao.acessar', render: async el => {
    const [dados0, cats] = await Promise.all([api('/produtos'), api('/categorias')]); catsCache = cats; let dados = dados0;
    el.innerHTML = `<div class="card"><p class="muted" style="margin:0">Filtre, marque os produtos que quer alterar e escolha o que mudar. Nada é gravado antes de você confirmar. Só os campos marcados em <b>"Alterar"</b> mudam. Estoque e custo não são alterados aqui (entram por entrada de mercadoria, ajuste ou importação de estoque).</p></div>
      <div class="bar" id="flt"><input id="fq" placeholder="Buscar nome, código, código de barras..."><select id="fc"><option value="">Todas as categorias</option><option value="-1">(sem categoria)</option>${cats.map(c => `<option value="${c.id}">${esc(c.nome)}</option>`).join('')}</select><select id="ft"><option value="">Todos os tipos</option><option value="revenda">Revenda</option><option value="insumo">Insumo</option><option value="preparado">Preparado</option></select><select id="fs"><option value="1">Só ativos</option><option value="0">Só inativos</option><option value="">Ativos e inativos</option></select></div>
      <div id="tb"></div><div class="card" style="margin-top:10px"><h3 style="margin:0 0 8px">O que alterar nos <span id="nsel">0</span> selecionado(s)</h3>${painelProdutos()}<div style="margin-top:10px"><button class="btn primary" id="aplicar">Aplicar alterações nos selecionados</button></div></div>`;
    const atual = () => { $('#nsel', el).textContent = $$('input[data-sel]:checked', el).length; };
    const desenha = () => { const q = $('#fq', el).value.toLowerCase(), c = $('#fc', el).value, t = $('#ft', el).value, s = $('#fs', el).value;
      const vis = dados.filter(p => (!q || (p.nome + ' ' + (p.codigo || '') + ' ' + (p.codigos_barras || []).join(' ')).toLowerCase().includes(q)) && (!c || (c === '-1' ? !p.categoria_id : String(p.categoria_id) === c)) && (!t || p.tipo === t) && (!s || (s === '1') === !!p.ativo));
      $('#tb', el).innerHTML = `<div class="row" style="align-items:center;margin:6px 0"><button class="btn sm" id="todos" type="button">Marcar todos os exibidos</button><button class="btn sm" id="nenhum" type="button">Desmarcar todos</button><span class="muted">${vis.length} produto(s) na lista</span></div>` +
        tabela([{ l: '✔', f: p => `<input type="checkbox" data-sel="${p.id}">` }, { l: 'Código', f: p => esc(p.suspenso ? 'pendente' : p.codigo || '') }, { l: 'Nome', f: p => esc(p.nome) + (p.ativo ? '' : ' ' + chip('inativo', 'cancelado')) }, { l: 'Categoria', k: 'categoria' }, { l: 'Tipo', k: 'tipo' }, { l: 'Destino', k: 'destino' }, { l: 'Preço', n: 1, f: p => R(p.preco_venda) }, { l: 'Est. mín.', n: 1, f: p => N(p.estoque_minimo) }, { l: 'Vendável', f: p => (p.vendavel ? 'sim' : 'não') }], vis, { vazio: 'Nenhum produto com esse filtro.' }); atual(); };
    desenha();
    el.addEventListener('input', e => { if (e.target.closest('#flt')) desenha(); }); el.addEventListener('change', e => { if (e.target.matches('input[data-sel]')) atual(); if (e.target.closest('#flt')) desenha(); });
    el.onclick = seguro(async e => {
      if (e.target.id === 'todos') { $$('#tb tbody tr', el).forEach(tr => { if (tr.style.display !== 'none') $('input[data-sel]', tr).checked = true; }); return atual(); }
      if (e.target.id === 'nenhum') { $$('input[data-sel]', el).forEach(c => { c.checked = false; }); return atual(); }
      if (e.target.id !== 'aplicar') return;
      const sel = $$('input[data-sel]:checked', el).map(c => Number(c.dataset.sel)); if (!sel.length) throw new Error('Marque ao menos um produto na lista.');
      const { alteracoes, resumo } = coletaProdutos(el); if (!Object.keys(alteracoes).length) throw new Error('Marque ao menos um campo em "Alterar".');
      if (!await confirmar(`Aplicar nos ${sel.length} produto(s) selecionado(s):\n${resumo}\n\nFica registrado na auditoria. Não há botão de desfazer.`, 'Aplicar')) return;
      const r = await api('/manutencao/produtos-massa', { method: 'POST', body: { ids: sel, alteracoes } });
      toast(`${r.alterados} produto(s) alterado(s).`, 'ok'); dados = await api('/produtos'); desenha();
    });
  } });

  // ---- fornecedores
  massa({ id: 'man-fornecedores', titulo: 'Alteração em massa de fornecedores', rota: 'fornecedores-massa', rotulo: 'fornecedor',
    carregar: () => api('/fornecedores'),
    filtros: { html: `<input id="fq" placeholder="Buscar nome, CNPJ, cidade..."><select id="fs"><option value="1">Só ativos</option><option value="0">Só inativos</option><option value="">Ativos e inativos</option></select>`,
      filtra: (d, el) => { const q = $('#fq', el).value.toLowerCase(), s = $('#fs', el).value; return d.filter(f => (!q || ((f.nome || '') + ' ' + (f.documento || '') + ' ' + (f.cidade || '')).toLowerCase().includes(q)) && (!s || (s === '1') === !!f.ativo)); } },
    colunasTab: [{ l: 'Nome', f: f => esc(f.nome) + (f.ativo ? '' : ' ' + chip('inativo', 'cancelado')) }, { l: 'CNPJ', k: 'documento' }, { l: 'Cidade/UF', f: f => esc([f.cidade, f.uf].filter(Boolean).join('/')) }, { l: 'Cond. pagamento', k: 'condicao_pagamento' }, { l: 'Telefone', k: 'telefone' }],
    painel: lin('ativo', `<label style="margin:0">Situação<select id="fa"><option value="1">ativo</option><option value="0">inativo</option></select></label>`) +
      lin('condicao_pagamento', `<label style="margin:0">Condição de pagamento<input id="fcp" maxlength="120" placeholder="ex.: 28 dias" style="min-width:240px"></label>`) +
      lin('cidade', `<label style="margin:0">Cidade<input id="fci" maxlength="80"></label>`) + lin('uf', `<label style="margin:0">UF<input id="fuf" maxlength="2" style="width:60px;text-transform:uppercase"></label>`) +
      lin('observacao', `<label style="margin:0">Observação (substitui a atual)<input id="fob" maxlength="300" style="min-width:300px"></label>`),
    coletar: el => { const a = {}, rs = [];
      if (ligado(el, 'ativo')) { a.ativo = $('#fa', el).value === '1'; rs.push('• situação: ' + (a.ativo ? 'ativo' : 'inativo')); }
      if (ligado(el, 'condicao_pagamento')) { a.condicao_pagamento = $('#fcp', el).value; rs.push('• condição de pagamento: ' + (a.condicao_pagamento || '(limpar)')); }
      if (ligado(el, 'cidade')) { a.cidade = $('#fci', el).value; rs.push('• cidade: ' + (a.cidade || '(limpar)')); }
      if (ligado(el, 'uf')) { a.uf = $('#fuf', el).value; rs.push('• UF: ' + (a.uf || '(limpar)')); }
      if (ligado(el, 'observacao')) { a.observacao = $('#fob', el).value; rs.push('• observação: ' + (a.observacao || '(limpar)')); }
      return { alteracoes: a, resumo: rs.join('\n') }; } });

  // ---------- Importações (preços / estoque) ----------
  function importacao({ id, titulo, intro, rota, nomes, opcionais = [], montaLinha, modelo, modeloVazio, colsPrevia, relCab, relLinha, relFora, extra = '' }) {
    registrar({ id, titulo, grupo: 'Manutenção', perm: 'manutencao.acessar', render: async el => {
      let linhas = [], ultimo = { linhas: [], fora: [] };
      const relatorio = (res, final) => { const t = { importado: 'IMPORTADO', ok: 'SERÁ IMPORTADO', igual: 'SEM MUDANÇA (já estava igual)', erro: 'NÃO IMPORTADO' };
        const rows = [['Resultado', 'Linha do arquivo', ...relCab, 'Motivo']].concat(res.linhas.slice().sort((a, b) => a.linha - b.linha).map(x => [t[x.status] || x.status, x.linha, ...relLinha(x), x.motivo || '']))
          .concat((res.fora || []).map(f => ['NÃO ESTAVA NO ARQUIVO (cadastrado no sistema, não alterado)', '', ...relFora(f), '']));
        const d = new Date(), z = n => String(n).padStart(2, '0'); baixar(`contrapartida-${rota}-${final ? 'importacao' : 'conferencia'}-${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}-${z(d.getHours())}${z(d.getMinutes())}.csv`, rows); };
      el.innerHTML = `<div class="card">${intro}<div class="row" style="align-items:flex-end;margin-top:8px"><button class="btn" id="mod" type="button" title="Já vem com todos os produtos cadastrados e os valores atuais">⬇ Modelo com os produtos cadastrados</button><button class="btn" id="modv" type="button" title="Só o cabeçalho: você digita o que quer importar">⬇ Modelo em branco</button><label style="flex:2">Arquivo CSV preenchido<input type="file" id="arq" accept=".csv,.txt,text/csv"></label>${extra}<button class="btn primary auto" id="ler" type="button">Conferir arquivo</button></div></div><div id="res" style="margin-top:10px"></div>`;
      el.onclick = seguro(async e => {
        if (e.target.id === 'mod') return modelo();
        if (e.target.id === 'modv') return modeloVazio();
        if (e.target.id === 'ler') {
          const f = $('#arq', el).files[0]; if (!f) throw new Error('Escolha o arquivo CSV primeiro.');
          if (/\.xlsx?$/i.test(f.name)) throw new Error('Esse é um arquivo do Excel. No Excel use Arquivo > Salvar como > "CSV (separado por vírgulas/ponto e vírgula)" e envie o CSV.');
          const rows = parseCsv(await lerArquivo(f)); if (!rows.length) throw new Error('O arquivo está vazio.');
          const { idx, opc, dados, inicio } = colunas(rows, nomes, opcionais); linhas = dados.map((r, i) => montaLinha(r, idx, i + inicio, opc));
          if (!linhas.length) throw new Error('Não há linhas de dados no arquivo.'); if (linhas.length > 20000) throw new Error('O arquivo tem mais de 20.000 linhas. Divida em partes.');
          $('#res', el).innerHTML = '<p>⏳ Conferindo...</p>';
          const r = await api('/manutencao/' + rota + '/previa', { method: 'POST', body: { linhas } });
          const s = r.resumo; ultimo = { linhas: r.linhas, fora: r.fora || [] };
          $('#res', el).innerHTML = `<div class="card"><b>${s.total}</b> linha(s) no arquivo · <b style="color:var(--ok)">${s.aplicar}</b> serão alteradas · ${s.iguais} sem mudança · <b class="${s.erros ? 'erro' : ''}">${s.erros}</b> não serão importadas (código não encontrado, valor inválido ou repetido) · <b>${ultimo.fora.length}</b> cadastrado(s) no sistema que não vieram no arquivo.
            <div style="margin-top:8px"><button class="btn" id="rel" type="button">⬇ Baixar arquivo de contrapartida (conferência)</button> ${s.aplicar || ($('#zer', el) && $('#zer', el).value === 'sim' && ultimo.fora.some(f => Number(f.valor) !== 0)) ? `<button class="btn primary" id="ap">Aplicar ${s.aplicar} alteração(ões)${$('#zer', el) && $('#zer', el).value === 'sim' ? ' e zerar os que não vieram' : ''}</button>` : '<span class="muted">Nada para aplicar.</span>'}</div></div>` +
            tabela(colsPrevia, r.linhas.sort((a, b) => (a.status === 'erro' ? 0 : 1) - (b.status === 'erro' ? 0 : 1)), { vazio: 'Sem linhas.' });
          return;
        }
        if (e.target.id === 'rel') return relatorio(ultimo, false);
        if (e.target.id === 'ap') {
          const n = e.target.textContent.match(/\d+/)[0];
          const zer = $('#zer', el) && $('#zer', el).value === 'sim', nz = zer ? ultimo.fora.filter(f => Number(f.valor) !== 0).length : 0;
          if (!await confirmar(`Aplicar ${n} alteração(ões) do arquivo? Só as linhas sem erro são gravadas. Fica registrado na auditoria.` + (zer ? `\n\n⚠ Também serão ZERADOS ${nz} produto(s) que não estão no arquivo.` : ''), 'Aplicar')) return;
          const mo = $('#mot', el); const r = await api('/manutencao/' + rota + '/aplicar', { method: 'POST', body: { linhas, motivo: mo ? mo.value : '', zerar: zer } });
          toast(`${r.alterados} alteração(ões) aplicada(s)` + (r.zerados ? ` e ${r.zerados} produto(s) zerado(s).` : '.'), 'ok'); ultimo = { linhas: r.linhas || [], fora: r.fora || [] };
          const ni = ultimo.linhas.filter(x => x.status === 'erro').length, ig = ultimo.linhas.filter(x => x.status === 'igual').length;
          $('#res', el).innerHTML = `<div class="card">✅ <b>${r.alterados}</b> importado(s)${r.clientes_novos ? ` (+ ${r.clientes_novos} cadastrado(s) como cliente)` : ''} · ${ig} sem mudança · <b class="${ni ? 'erro' : ''}">${ni}</b> NÃO importado(s) · <b>${ultimo.fora.length}</b> cadastrado(s) que não vieram no arquivo.<div style="margin-top:8px"><button class="btn primary" id="rel" type="button">⬇ Baixar arquivo de contrapartida (o que foi e o que não foi importado)</button></div></div>`; linhas = [];
          relatorio(ultimo, true);   // já baixa o arquivo de contrapartida
        }
      });
    } });
  }
  importacao({ id: 'man-precos', titulo: 'Importar tabela de preços', rota: 'precos',
    intro: `<p style="margin:0">Atualiza o <b>preço de venda</b> pelo <b>código reduzido</b> do produto (o código do cadastro). Arquivo CSV com duas colunas: <code>codigo_reduzido</code> e <code>preco</code> (pode usar vírgula nos centavos, ex.: 12,50). Você vê tudo (preço atual × novo) antes de confirmar. Código que não existe ou preço inválido fica de fora.</p><p class="muted" style="margin:6px 0 0">Há dois modelos: o <b>com os produtos cadastrados</b> (todos os códigos e o preço atual: edite o preço no Excel) e o <b>em branco</b> (só o cabeçalho, para você digitar o que quer). Salve como CSV e envie. Ao importar, o sistema confere se cada código existe e gera um <b>arquivo de contrapartida</b> (CSV) dizendo o que foi e o que não foi importado, e quais produtos do sistema não vieram no arquivo.</p>`,
    nomes: [['codigo reduzido', 'codigo', 'cod reduzido', 'cod', 'codigo do produto'], ['preco', 'preco de venda', 'preco venda', 'valor']],
    montaLinha: (r, ix, n) => ({ linha: n, codigo: r[ix[0]], preco: r[ix[1]] }),
    modeloVazio: () => baixar('modelo-em-branco-importacao-precos.csv', [['codigo_reduzido', 'preco']]),
    relCab: ['Código reduzido', 'Produto', 'Preço informado no arquivo', 'Preço anterior', 'Preço novo'],
    relLinha: x => [x.codigo, x.produto || '', x.preco_arquivo, x.antes === undefined ? '' : fmtN(Number(x.antes).toFixed(2)), x.depois === undefined ? '' : fmtN(Number(x.depois).toFixed(2))],
    relFora: f => [f.codigo, f.produto, '', fmtN(Number(f.valor).toFixed(2)), ''],
    modelo: async () => { const p = (await api('/produtos')).filter(x => !x.suspenso && x.codigo); baixar('modelo-importacao-precos.csv', [['codigo_reduzido', 'preco', 'nome (so para voce se orientar; nao e lido)']].concat(p.length ? p.map(x => [x.codigo, fmtN(Number(x.preco_venda).toFixed(2)), x.nome]) : [['1', '12,50', 'EXEMPLO']])); },
    colsPrevia: [{ l: 'Linha', k: 'linha' }, { l: 'Código', k: 'codigo' }, { l: 'Produto', f: x => esc(x.produto || '—') + (x.pendente ? ' ' + chip('cadastro pendente', 'warn') : '') }, { l: 'Preço atual', n: 1, f: x => (x.antes === undefined ? '—' : R(x.antes)) }, { l: 'Novo preço', n: 1, f: x => (x.depois === undefined ? esc(x.preco_arquivo) : R(x.depois)) }, { l: 'Situação', f: chipSt }] });
  importacao({ id: 'man-estoque', titulo: 'Importar estoque', rota: 'estoque',
    intro: `<p style="margin:0">Acerta o <b>estoque</b> pelo <b>código de barras</b>. Arquivo CSV com as colunas <code>codigo_barras</code> e <code>estoque</code> (quantidade real contada, na unidade do produto); a coluna <code>codigo_reduzido</code> é opcional e vale quando o produto não tem código de barras. O modelo com os produtos cadastrados traz todos os que controlam estoque; há também o modelo em branco. Ao importar, o sistema confere os códigos e gera o <b>arquivo de contrapartida</b> (o que foi e o que não foi importado). O sistema lança a diferença como <b>ajuste de estoque</b> (fica no histórico e na movimentação). Você vê estoque atual × novo antes de confirmar.</p><p class="muted" style="margin:6px 0 0"><b>Cuidado no Excel:</b> deixe a coluna do código de barras formatada como <b>Texto</b>, senão o Excel troca o número por notação científica (7,89E+12) e o código se perde. Não funciona durante um balanço em andamento.</p>`,
    nomes: [['codigo de barras', 'codigo barras', 'codigo_barras', 'ean', 'barras', 'cod barras'], ['estoque', 'quantidade', 'qtd', 'estoque real', 'contagem']],
    opcionais: [['codigo reduzido', 'codigo', 'cod reduzido', 'cod']],
    montaLinha: (r, ix, n, opc) => ({ linha: n, codigo_barras: r[ix[0]], estoque: r[ix[1]], codigo_reduzido: opc && opc[0] >= 0 ? r[opc[0]] : '' }),
    modeloVazio: () => baixar('modelo-em-branco-importacao-estoque.csv', [['codigo_barras', 'estoque', 'codigo_reduzido']]),
    relCab: ['Código de barras', 'Código reduzido', 'Produto', 'Estoque informado no arquivo', 'Estoque anterior', 'Estoque novo'],
    relLinha: x => [x.codigo_barras, x.codigo || '', x.produto || '', x.estoque_arquivo, x.antes === undefined ? '' : fmtN(x.antes), x.depois === undefined ? '' : fmtN(x.depois)],
    relFora: f => ['', f.codigo, f.produto, '', fmtN(f.valor), ''],
    extra: `<label style="flex:2">Motivo do ajuste<input id="mot" value="Importação de estoque (arquivo)" maxlength="200"></label><label style="flex:2">Produtos que NÃO estão no arquivo<select id="zer"><option value="nao">Manter o estoque como está</option><option value="sim">Zerar o estoque</option></select></label>`,
    modelo: async () => { const p = (await api('/produtos')).filter(x => x.controla_estoque && !x.suspenso); baixar('modelo-importacao-estoque.csv', [['codigo_barras', 'estoque', 'codigo_reduzido', 'nome (so para voce se orientar; nao e lido)']].concat(p.length ? p.map(x => [(x.codigos_barras || [])[0] ? '\t' + x.codigos_barras[0] : '', fmtN(Number(x.estoque_atual)), x.codigo, x.nome]) : [['7891000100103', '24', '1', 'EXEMPLO']])); },
    colsPrevia: [{ l: 'Linha', k: 'linha' }, { l: 'Código de barras', k: 'codigo_barras' }, { l: 'Produto', f: x => esc(x.produto || '—') }, { l: 'Estoque atual', n: 1, f: x => (x.antes === undefined ? '—' : N(x.antes) + ' ' + esc(x.unidade || '')) }, { l: 'Novo estoque', n: 1, f: x => (x.depois === undefined ? esc(x.estoque_arquivo) : N(x.depois)) }, { l: 'Diferença', n: 1, f: x => (x.diferenca === undefined ? '' : (x.diferenca > 0 ? '+' : '') + N(x.diferenca)) }, { l: 'Situação', f: chipSt }] });
  importacao({ id: 'man-equipe', titulo: 'Importar equipe', rota: 'equipe',
    intro: `<p style="margin:0">Cadastra ou atualiza <b>usuários da equipe</b> por arquivo CSV. O arquivo padrão tem <code>nome</code> e <code>cpf</code>; só o <code>nome</code> é obrigatório. Colunas opcionais: <code>login</code>, <code>senha</code>, <code>cargo</code>, <code>telefone</code>, <code>email</code> e <code>ativo</code> (sim/não). A <b>função</b> (perfil de acesso) não vem no arquivo: depois de importar, vincule os usuários em <b>Equipe &gt; Perfis e permissões</b>, abrindo a função e marcando quem a exerce (se o arquivo trouxer uma coluna <code>funcao</code> ou <code>perfil</code> com o nome de uma função já cadastrada, ela também é vinculada). <b>O que não estiver no arquivo fica em branco</b> (em usuário que já existe, o dado atual é mantido). O usuário que já existe é reconhecido pelo <code>login</code>, pelo <code>cpf</code> ou pelo nome, nessa ordem.</p><p class="muted" style="margin:6px 0 0">Sem <code>login</code>, o sistema usa o número do usuário gerado. <b>Sem <code>senha</code> no arquivo, o usuário novo recebe a senha padrão <code>1234</code></b> (quem já existe mantém a senha atual; só muda se a coluna senha vier preenchida) — peça para cada um trocar a senha no primeiro acesso (botão de alterar senha). Você vê tudo antes de confirmar e baixa um arquivo de contrapartida com o que foi e o que não foi importado.</p>`,
    nomes: [['nome', 'nome completo', 'funcionario', 'colaborador', 'usuario nome']],
    opcionais: [['cpf', 'cpf do usuario', 'documento'], ['cargo'], ['login', 'usuario', 'user'], ['senha', 'password'], ['perfil', 'funcao', 'perfil de acesso', 'permissao'], ['telefone', 'fone', 'celular', 'whatsapp'], ['email', 'e mail'], ['ativo', 'situacao', 'status']],
    montaLinha: (r, ix, n, opc) => { const g = k => (opc && opc[k] >= 0 ? r[opc[k]] : ''); return { linha: n, nome: r[ix[0]], cpf: g(0), cargo: g(1), login: g(2), senha: g(3), perfil: g(4), telefone: g(5), email: g(6), ativo: g(7) }; },
    modeloVazio: () => baixar('modelo-em-branco-importacao-equipe.csv', [['nome', 'cpf', 'login', 'senha', 'cargo', 'telefone', 'email', 'ativo']]),
    relCab: ['Nome', 'CPF', 'Cargo', 'Login', 'Função (perfil)', 'Telefone', 'E-mail', 'Ativo', 'O que muda'],
    relLinha: x => [x.nome, x.cpf_arquivo || '', x.cargo || '', x.login_final || x.login || '', x.perfil || '', x.telefone || '', x.email || '', x.ativo_arquivo || '', x.novo ? 'novo usuário' + (x.aviso ? ' (' + x.aviso + ')' : '') : (x.mudancas || '')],
    relFora: f => [f.produto, '', '', f.valor, '', '', '', f.ativo ? 'sim' : 'não', ''],
    modelo: async () => { const [u, pf] = await Promise.all([api('/usuarios'), api('/perfis')]); baixar('modelo-importacao-equipe.csv', [['nome', 'cpf', 'login', 'senha', 'cargo', 'telefone', 'email', 'ativo']].concat(u.length ? u.map(x => [x.nome, x.login, '', x.perfil || '', x.cargo || '', x.telefone || '', x.email || '', x.ativo ? 'sim' : 'não']) : [['MARIA', 'maria', '', (pf[0] || {}).nome || '', 'CAIXA', '', '', 'sim']])); },
    colsPrevia: [{ l: 'Linha', k: 'linha' }, { l: 'Nome', f: x => esc(x.nome) }, { l: 'CPF', f: x => esc(x.cpf_arquivo || '') }, { l: 'Login', f: x => esc(x.login_final || x.login || '') }, { l: 'Função', f: x => esc(x.perfil || '') }, { l: 'O que acontece', f: x => (x.status === 'erro' ? chip('erro: ' + esc(x.motivo), 'warn') : x.status === 'igual' ? chip('sem mudança', 'cancelado') : x.novo ? chip('novo usuário', 'ok') + (x.aviso ? ` <small class="muted">${esc(x.aviso)}</small>` : '') : chip('altera: ' + esc(x.mudancas), 'ok')) }] });
})();
