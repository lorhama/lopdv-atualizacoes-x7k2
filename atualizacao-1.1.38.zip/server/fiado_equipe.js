// Todo usuário da equipe também é um cliente (clientes.usuario_id): é criado/ligado automaticamente e acompanha nome, CPF, telefone, e-mail e situação do usuário.
// Quem pode retirar no fiado é controlado por usuarios.pode_fiado (verificado na venda fiado).
async function sincronizar(c, usuarioId) {
  const u = (await c.query('select id, nome, cpf, telefone, email, ativo, pode_fiado from usuarios where id=$1', [usuarioId])).rows[0];
  if (!u) return;
  const permitido = !!u.ativo;   // cliente ativo enquanto o usuário estiver ativo
  let cl = (await c.query('select id from clientes where usuario_id=$1 limit 1', [u.id])).rows[0];
  if (!cl) {
    const cpf = String(u.cpf || '').replace(/\D/g, '');
    const ja = (await c.query(`select id from clientes where usuario_id is null and (lower(nome)=lower($1) or ($2<>'' and regexp_replace(coalesce(documento,''),'\\D','','g')=$2)) order by id limit 1`, [u.nome, cpf])).rows[0];
    if (ja) { await c.query('update clientes set usuario_id=$1 where id=$2', [u.id, ja.id]); cl = ja; }
    else cl = (await c.query("insert into clientes(nome, documento, telefone, email, observacao, ativo, usuario_id) values($1,$2,$3,$4,'Equipe',true,$5) returning id", [u.nome, cpf || null, u.telefone || null, u.email || null, u.id])).rows[0];
  }
  await c.query("update clientes set ativo=$1, nome=$2, documento=coalesce(nullif($3,''), documento), telefone=coalesce($4, telefone), email=coalesce($5, email) where id=$6",
    [permitido, u.nome, String(u.cpf || '').replace(/\D/g, ''), u.telefone || null, u.email || null, cl.id]);
}
async function sincronizarTodos(c) {
  const us = (await c.query('select id from usuarios order by id')).rows;
  for (const u of us) await sincronizar(c, u.id);
  return us.length;
}
module.exports = { sincronizar, sincronizarTodos };
