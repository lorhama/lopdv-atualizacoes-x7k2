// Promoções de produtos com data e horário. Horários são locais do computador do sistema (timestamp sem fuso).
// Preço promocional vigente de um produto = menor preço entre as promoções ativas cujo período contém o momento atual.
const PRECO_PROMO = alias => `(select min(case when pr.tipo='percentual' then round(${alias}.preco_venda * (1 - pr.valor / 100.0), 2) else pr.valor end)
  from promocoes pr where pr.produto_id=${alias}.id and pr.ativo and pr.tipo<>'combo' and localtimestamp between pr.inicio and pr.fim)`;
async function precoVigente(c, produtoId) {
  const r = (await c.query(`select p.preco_venda, ${PRECO_PROMO('p')} promo from produtos p where p.id=$1`, [produtoId])).rows[0];
  if (!r) return null;
  const n = Number(r.preco_venda), pr = r.promo === null ? null : Number(r.promo);
  return pr !== null && pr < n ? pr : n;
}
// Melhor promoção "leve N por R$ X" vigente do produto (menor preço por unidade), ou null
const COMBO_SQL = alias => `(select json_build_object('n', pr.qtd, 'preco', pr.valor) from promocoes pr where pr.produto_id=${alias}.id and pr.ativo and pr.tipo='combo' and localtimestamp between pr.inicio and pr.fim order by pr.valor / pr.qtd, pr.id limit 1)`;
const r4 = x => Math.round(x * 10000) / 10000;
// Reaplica os combos da venda aberta: a cada N unidades do produto (somando todas as linhas) o conjunto custa X; as unidades que sobram saem ao preço normal/promocional.
// Chamar depois de lançar, alterar quantidade ou cancelar item.
async function reaplicarCombos(c, pedidoId) {
  const its = (await c.query("select id, produto_id, quantidade, preco_unit, combo from pedido_itens where pedido_id=$1 and status<>'cancelado' order by id", [pedidoId])).rows;
  const por = new Map(); for (const i of its) { if (!por.has(i.produto_id)) por.set(i.produto_id, []); por.get(i.produto_id).push(i); }
  for (const [pid, linhas] of por) {
    const cb = (await c.query(`select ${COMBO_SQL('p')} combo from produtos p where p.id=$1`, [pid])).rows[0]?.combo;
    if (!cb && !linhas.some(i => i.combo)) continue;
    const s = await precoVigente(c, pid);
    const Q = linhas.reduce((t, i) => t + Number(i.quantidade), 0);
    const N = cb ? Number(cb.n) : 0, X = cb ? Number(cb.preco) : 0;
    let pool = cb ? Math.floor(Q / N) * N : 0;
    const alvo = cb ? Math.floor(Q / N) * X + (Q - Math.floor(Q / N) * N) * s : null;
    const novos = linhas.map(i => { const q = Number(i.quantidade), cc = Math.min(q, pool); pool -= cc; const custo = cc * (X / (N || 1)) + (q - cc) * s; return { id: i.id, q, cc, unit: r4(custo / q) }; });
    if (cb && novos.length) {   // acerta os centavos para o total do produto fechar exatamente
      const soma = novos.reduce((t, x) => t + Math.round(x.q * x.unit * 100) / 100, 0), dif = Math.round((alvo - soma) * 100) / 100;
      const ult = [...novos].reverse().find(x => x.cc > 0); if (ult && Math.abs(dif) >= 0.005) ult.unit = r4(ult.unit + dif / ult.q);
    }
    for (const x of novos) await c.query('update pedido_itens set preco_unit=$1, combo=$2 where id=$3', [x.unit, x.cc > 0, x.id]);
  }
}
module.exports = { PRECO_PROMO, precoVigente, COMBO_SQL, reaplicarCombos };
