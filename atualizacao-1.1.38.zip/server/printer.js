// Impressão ESC/POS: térmicas de rede (porta 9100) ou impressoras instaladas no Windows (spooler, modo RAW).
const net = require('net');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');
const iconv = require('iconv-lite');

// economia: sem linhas em branco sobrando antes do corte (o comando de corte já avança o papel até a faca) e sem título gigante
function montar(texto, { titulo, corte = true, economia = false } = {}) {
  const partes = [Buffer.from([0x1b, 0x40]), Buffer.from([0x1b, 0x74, 0x03])]; // init + code page CP860 (pt)
  if (titulo && !economia) {
    partes.push(Buffer.from([0x1b, 0x61, 0x01, 0x1d, 0x21, 0x11, 0x1b, 0x45, 0x01]));
    partes.push(iconv.encode(titulo + '\n', 'cp860'));
    partes.push(Buffer.from([0x1d, 0x21, 0x00, 0x1b, 0x45, 0x00, 0x1b, 0x61, 0x00]));
  }
  const corpo = economia ? (titulo ? titulo + '\n' : '') + texto + '\n\n' : texto + '\n\n\n\n';
  partes.push(iconv.encode(corpo, 'cp860'));
  if (corte) partes.push(Buffer.from([0x1d, 0x56, 0x42, 0x00]));
  return Buffer.concat(partes);
}

// Ticket de brincadeiras: centralizado, com título grande e itens em letra mais alta (para se distinguir dos tickets de cozinha/bar)
function montarBrincadeira({ pedido, usuario, itens, colunas = 42, reimpressao = false, cancelado = false }) {
  const hora = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  const num = String(pedido.venda_numero || pedido.id).padStart(6, '0');
  const P = [Buffer.from([0x1b, 0x40]), Buffer.from([0x1b, 0x74, 0x03]), Buffer.from([0x1b, 0x61, 0x01])];   // init, CP860, centralizar
  const t = (txt, tam = 0x00, neg = false) => { P.push(Buffer.from([0x1d, 0x21, tam, 0x1b, 0x45, neg ? 1 : 0])); P.push(iconv.encode(txt + '\n', 'cp860')); P.push(Buffer.from([0x1d, 0x21, 0x00, 0x1b, 0x45, 0x00])); };
  const larg = (txt, c) => quebrar(txt, c);
  if (reimpressao) t('*** REIMPRESSAO ***');
  if (cancelado) t('*** ITEM CANCELADO ***', 0x01, true);
  t('BRINCADEIRA', 0x11, true);
  t(`Venda ${num}  ${String(usuario || '').split(' ')[0]}  ${hora}`);
  if (pedido.observacao) larg('OBS: ' + pedido.observacao, colunas).forEach(x => t(x));
  t(linha(colunas));
  for (const i of itens) {
    if (i.ficha) t('Ficha ' + i.ficha);
    const q = Number(i.quantidade), qtd = Number.isInteger(q) ? q + 'x' : q.toLocaleString('pt-BR') + 'x';
    larg(`${i.codigo ? i.codigo + ' ' : ''}${qtd} ${i.nome}`, colunas).forEach(x => t(x, 0x01));   // altura dupla: maior sem estourar a largura
    if (i.observacao) larg('> ' + i.observacao, colunas).forEach(x => t(x));
  }
  t(linha(colunas));
  P.push(iconv.encode('\n\n', 'cp860'), Buffer.from([0x1b, 0x61, 0x00]), Buffer.from([0x1d, 0x56, 0x42, 0x00]));
  return Buffer.concat(P);
}

// ---- Windows: lista as impressoras instaladas e envia bytes RAW para uma delas (PowerShell + winspool.drv)
const PS_RAW = [
  "$ErrorActionPreference = 'Stop'",
  'Add-Type -TypeDefinition @"',
  'using System; using System.Runtime.InteropServices;',
  'public class RawPrn {',
  '  [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)] public class DOCINFO { [MarshalAs(UnmanagedType.LPWStr)] public string pDocName; [MarshalAs(UnmanagedType.LPWStr)] public string pOutputFile; [MarshalAs(UnmanagedType.LPWStr)] public string pDataType; }',
  '  [DllImport("winspool.drv", EntryPoint="OpenPrinterW", SetLastError=true, CharSet=CharSet.Unicode)] public static extern bool OpenPrinter(string n, out IntPtr h, IntPtr d);',
  '  [DllImport("winspool.drv", SetLastError=true)] public static extern bool ClosePrinter(IntPtr h);',
  '  [DllImport("winspool.drv", EntryPoint="StartDocPrinterW", SetLastError=true, CharSet=CharSet.Unicode)] public static extern bool StartDocPrinter(IntPtr h, int level, [In] DOCINFO di);',
  '  [DllImport("winspool.drv", SetLastError=true)] public static extern bool EndDocPrinter(IntPtr h);',
  '  [DllImport("winspool.drv", SetLastError=true)] public static extern bool StartPagePrinter(IntPtr h);',
  '  [DllImport("winspool.drv", SetLastError=true)] public static extern bool EndPagePrinter(IntPtr h);',
  '  [DllImport("winspool.drv", SetLastError=true)] public static extern bool WritePrinter(IntPtr h, byte[] b, int n, out int w);',
  '  public static void Send(string printer, byte[] data) {',
  '    IntPtr h; if (!OpenPrinter(printer, out h, IntPtr.Zero)) throw new Exception("Nao foi possivel abrir a impressora (erro " + Marshal.GetLastWin32Error() + ")");',
  '    try {',
  '      DOCINFO di = new DOCINFO(); di.pDocName = "LoPDV"; di.pDataType = "RAW";',
  '      if (!StartDocPrinter(h, 1, di)) throw new Exception("StartDocPrinter falhou (erro " + Marshal.GetLastWin32Error() + ")");',
  '      try { StartPagePrinter(h); int w; if (!WritePrinter(h, data, data.Length, out w)) throw new Exception("WritePrinter falhou (erro " + Marshal.GetLastWin32Error() + ")"); EndPagePrinter(h); } finally { EndDocPrinter(h); }',
  '    } finally { ClosePrinter(h); }',
  '  }',
  '}',
  '"@',
  '[RawPrn]::Send($env:LOPDV_PRN, [IO.File]::ReadAllBytes($env:LOPDV_FILE))',
].join('\n');
const psb64 = s => Buffer.from(s, 'utf16le').toString('base64');
const rodarPS = (script, env = {}, timeout = 20000) => new Promise((resolve, reject) => {
  if (process.platform !== 'win32') return reject(new Error('Impressoras do Windows só funcionam quando o servidor roda no Windows.'));
  execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', psb64(script)],
    { windowsHide: true, timeout, env: { ...process.env, ...env }, maxBuffer: 4 * 1024 * 1024 },
    (err, out, errout) => (err ? reject(new Error((String(errout || '').trim().split('\n')[0] || err.message).slice(0, 300))) : resolve(String(out))));
});
const virtual = x => /pdf|xps|onenote|fax|salvar|save to|microsoft print|document writer/i.test(`${x.nome} ${x.driver}`) || /^(portprompt|file|nul)/i.test(x.porta || '');
async function listarWindows() {
  const out = await rodarPS("[Console]::OutputEncoding=[Text.Encoding]::UTF8; $p=@(Get-CimInstance Win32_Printer | Select-Object Name,DriverName,PortName,Default,WorkOffline); ConvertTo-Json -InputObject $p -Compress");
  const j = JSON.parse(out.trim() || '[]'); return (Array.isArray(j) ? j : [j]).filter(x => x && x.Name)
    .map(x => ({ nome: x.Name, driver: x.DriverName || '', porta: x.PortName || '', padrao: !!x.Default, offline: !!x.WorkOffline }))
    .map(x => ({ ...x, virtual: virtual(x) })).sort((a, b) => a.nome.localeCompare(b.nome));
}
async function enviarWindows(imp, buf) {
  if (!imp.windows_nome) throw new Error(`Impressora ${imp.nome}: escolha a impressora do Windows no cadastro.`);
  // impressora virtual (PDF/XPS/OneNote/arquivo): o Windows só "salva um arquivo em Documentos" e nada sai no papel
  try { const v = (await listarWindows()).find(x => x.nome === imp.windows_nome); if (v && virtual(v)) throw new Error(`"${imp.windows_nome}" é uma impressora VIRTUAL (salva em arquivo, não imprime no papel). Em Administração > Impressoras, escolha a impressora térmica de verdade.`); } catch (e) { if (/VIRTUAL/.test(e.message)) throw new Error(`Impressora ${imp.nome}: ${e.message}`); }
  const tmp = path.join(os.tmpdir(), 'lopdv-prn-' + process.pid + '-' + Date.now() + '.bin'); fs.writeFileSync(tmp, buf);
  try { await rodarPS(PS_RAW, { LOPDV_PRN: imp.windows_nome, LOPDV_FILE: tmp }); }
  catch (e) { throw new Error(`Impressora ${imp.nome} (Windows: ${imp.windows_nome}): ${e.message}`); }
  finally { fs.rm(tmp, () => { }); }
}

function enviar(imp, buf) {
  if (imp.conexao === 'windows') return enviarWindows(imp, buf);
  return new Promise((resolve, reject) => {
    const s = new net.Socket();
    let fim = false;
    const done = (err) => { if (fim) return; fim = true; s.destroy(); err ? reject(err) : resolve(); };
    s.setTimeout(4000, () => done(new Error('Tempo esgotado ao conectar na impressora ' + imp.ip)));
    s.on('error', e => done(new Error(`Impressora ${imp.nome} (${imp.ip}:${imp.porta || 9100}): ${e.message}`)));
    s.connect(imp.porta || 9100, imp.ip, () => s.end(buf, () => done()));
  });
}

const pad = (s, n) => String(s).padEnd(n).slice(0, n);
function linha(c = 42) { return '-'.repeat(c); }
function quebrar(txt, largura) {   // quebra por palavras (e corta só palavra maior que a linha)
  const out = []; let cur = '';
  for (let w of String(txt || '').split(/\s+/).filter(Boolean)) {
    while (w.length > largura) { if (cur) { out.push(cur); cur = ''; } out.push(w.slice(0, largura)); w = w.slice(largura); }
    if (!cur) cur = w; else if ((cur + ' ' + w).length <= largura) cur += ' ' + w; else { out.push(cur); cur = w; }
  }
  out.push(cur); return out;
}

// Ajusta um texto montado para 42 colunas a uma bobina mais estreita (ex.: 58 mm = 32 colunas):
// encolhe os espaços do meio (mantendo o valor à direita), refaz as linhas de traços e quebra o que ainda não couber.
function ajustarLargura(texto, colunas) {
  if (!colunas || colunas >= 42) return texto;
  const out = [];
  for (const raw of String(texto).split('\n')) {
    let s = raw.replace(/\s+$/, '');
    if (s.length <= colunas) { out.push(s); continue; }
    if (/^[-=_*\s]+$/.test(s)) { out.push(s.trim()[0].repeat(colunas)); continue; }
    const ind = (s.match(/^ */) || [''])[0].length;
    const m = [...s.slice(ind).matchAll(/ {2,}/g)].sort((a, b) => b[0].length - a[0].length)[0];
    if (m) { const falta = s.length - colunas, tira = Math.min(m[0].length - 1, falta); s = s.slice(0, ind + m.index) + ' '.repeat(m[0].length - tira) + s.slice(ind + m.index + m[0].length); }
    if (s.length > colunas) s = s.slice(0, ind) + s.slice(ind).replace(/ {2,}/g, ' ');
    if (s.length <= colunas) { out.push(s); continue; }
    let cur = ' '.repeat(Math.min(ind, 3));   // ainda não coube: quebra por palavras
    for (const w of s.trim().split(' ')) {
      let pal = w; while (pal.length > colunas) { if (cur.trim()) { out.push(cur.replace(/\s+$/, '')); cur = ''; } out.push(pal.slice(0, colunas)); pal = pal.slice(colunas); }
      if ((cur + (cur.trim() ? ' ' : '') + pal).length > colunas) { out.push(cur.replace(/\s+$/, '')); cur = pal; } else cur += (cur.trim() ? ' ' : '') + pal;
    }
    if (cur.trim()) out.push(cur);
  }
  return out.join('\n');
}

// Monta o texto do pedido de produção (cozinha/bar). Com economia: cabeçalho numa linha só e sem linha final de traços.
function comandaTexto({ destino, pedido, usuario, itens, colunas = 42, reimpressao = false, cancelado = false, economia = false }) {
  const hora = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  if (economia) {
    const l = []; const num = String(pedido.venda_numero || pedido.id).padStart(6, '0');
    if (reimpressao) l.push('*** REIMPRESSAO ***');
    if (cancelado) l.push('*** ITEM CANCELADO ***');
    const cab = `${destino.toUpperCase()} #${num} ${String(usuario || '').split(' ')[0]} ${hora}`;
    l.push(cab.length <= colunas ? cab : `${destino.toUpperCase()} #${num} ${hora}`);
    if (pedido.observacao) quebrar('OBS: ' + pedido.observacao, colunas).forEach(x => l.push(x));
    l.push(linha(colunas));
    for (const i of itens) {
      const q = Number(i.quantidade), qtd = Number.isInteger(q) ? q + 'x' : q.toLocaleString('pt-BR') + 'x';
      quebrar(`${i.codigo ? i.codigo + ' ' : ''}${qtd} ${i.nome}`, colunas).forEach(x => l.push(x));
      if (i.observacao) quebrar(' > ' + i.observacao, colunas).forEach(x => l.push(x));
    }
    return { titulo: '', texto: l.join('\n') };
  }
  const l = [];
  if (reimpressao) l.push('*** REIMPRESSAO ***');
  if (cancelado) l.push('*** ITEM CANCELADO ***');
  l.push(`Venda: ${String(pedido.venda_numero || pedido.id).padStart(6, '0')}`);
  l.push(`Atendente: ${usuario}   ${hora}`);
  if (pedido.observacao) quebrar('OBS VENDA: ' + pedido.observacao, colunas).forEach(x => l.push(x));
  l.push(linha(colunas));
  for (const i of itens) {
    const q = Number(i.quantidade);
    const qtd = Number.isInteger(q) ? q + 'x' : q.toLocaleString('pt-BR') + 'x';
    quebrar(`${i.codigo ? i.codigo + ' ' : ''}${qtd} ${i.nome}`, colunas).forEach(x => l.push(x));
    if (i.observacao) quebrar('   OBS: ' + i.observacao, colunas).forEach(x => l.push(x));
  }
  l.push(linha(colunas));
  return { titulo: destino.toUpperCase(), texto: l.join('\n') };
}

async function imprimirDestino(db, destino, dados) {
  let r = await db.q("select * from impressoras where (destino=$1 or destino='todos') and ativo order by (destino='todos'), id limit 1", [destino]);
  // sem impressora própria de brincadeira: o ticket separado sai na impressora do caixa
  if (!r.rowCount && destino === 'brincadeira') r = await db.q("select * from impressoras where destino='caixa' and ativo order by id limit 1");
  if (!r.rowCount) return { destino, ok: false, erro: `Nenhuma impressora ativa cadastrada para ${destino}.` };
  const imp = r.rows[0];
  try {   // acrescenta o código de cada produto no ticket
    const ids = [...new Set((dados.itens || []).map(i => i.produto_id).filter(Boolean))];
    if (ids.length) { const cs = (await db.q('select id, codigo from produtos where id = any($1)', [ids])).rows; const m = new Map(cs.map(x => [x.id, x.codigo]));
      dados = { ...dados, itens: dados.itens.map(i => ({ ...i, codigo: i.codigo || m.get(i.produto_id) || '' })) }; }
  } catch (e) { /* sem código, imprime só nome e quantidade */ }
  const { titulo, texto } = comandaTexto({ ...dados, destino, colunas: imp.colunas, economia: imp.economia !== false });
  // brincadeiras: um ticket (ficha) separado POR UNIDADE (4 unidades = 4 tickets); aviso de cancelamento sai em um só
  let bytes;
  if (destino === 'brincadeira') {
    if (dados.cancelado) bytes = montarBrincadeira({ ...dados, colunas: imp.colunas });
    else {
      const fichas = [];
      for (const i of dados.itens || []) { const n = Math.max(1, Math.round(Number(i.quantidade)) || 1); for (let k = 1; k <= n; k++) fichas.push({ ...i, quantidade: 1, ficha: n > 1 ? `${k}/${n}` : '' }); }
      bytes = Buffer.concat(fichas.map(f => montarBrincadeira({ ...dados, itens: [f], colunas: imp.colunas })));
    }
  } else bytes = montar(texto, { titulo, economia: imp.economia !== false });
  try { await enviar(imp, bytes); return { destino, ok: true }; }
  catch (e) { return { destino, ok: false, erro: e.message, texto }; }
}

async function imprimirTexto(db, destino, titulo, texto) {
  const r = await db.q("select * from impressoras where (destino=$1 or destino='todos') and ativo order by (destino='todos'), id limit 1", [destino]);
  if (!r.rowCount) return { destino, ok: false, erro: `Nenhuma impressora ativa cadastrada para ${destino}.` };
  const imp = r.rows[0];
  try { await enviar(imp, montar(ajustarLargura(texto, imp.colunas), { titulo, economia: imp.economia !== false })); return { destino, ok: true }; }
  catch (e) { return { destino, ok: false, erro: e.message }; }
}

module.exports = { ajustarLargura, listarWindows, imprimirDestino, imprimirTexto, montar, enviar, comandaTexto, linha, pad, quebrar };
