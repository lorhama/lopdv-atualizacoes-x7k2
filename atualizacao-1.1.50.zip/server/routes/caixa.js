// Caixa: abertura, sangria/suprimento, fechamento por forma de pagamento (com divergência), conferência, reabertura e alteração de forma.
const express = require('express');
const db = require('../db');
const est = require('../estoque_lib');
const prn = require('../printer');
const pdf = require('../pdf_simples');
const { auth, can, auditar, verificarAutorizacao } = require('../auth');
const { HttpError, wrap, num, r2 } = require('../util');
const r = express.Router();

const brl = n => Number(n || 0).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.');
const dh = d => (d ? new Date(d).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit', timeZone: 'America/Sao_Paulo' }) : '-');
const podeVer = (u, cx) => cx.usuario_id === u.id || can(u, 'caixa.ver_todos') || can(u, 'caixa.conferir') || can(u, 'relatorios.financeiro');

async function resumo(id) {
  const cx = (await db.q('select c.*, u.nome usuario from caixas c join usuarios u on u.id=c.usuario_id where c.id=$1', [id])).rows[0];
  if (!cx) throw new HttpError(404, 'Caixa não encontrado.');
  const formas = (await db.q(`select p.forma, coalesce(f.descricao, p.forma) descricao, coalesce(f.tipo, p.forma) tipo, sum(p.valor) total, count(distinct p.pedido_id) filter (where ped.status='fechado')::int vendas,
      coalesce(sum(p.valor) filter (where p.origem='recebimento_fiado'),0) recebido_fiado
    from pagamentos p left join formas_pagamento f on f.codigo=p.forma left join pedidos ped on ped.id=p.pedido_id where p.caixa_id=$1 group by p.forma, f.descricao, f.tipo order by p.forma`, [id])).rows;
  // contas a receber recebidas neste caixa: resumo por forma de pagamento e detalhe de cada recebimento
  const receber_por_forma = (await db.q(`select p.forma, coalesce(f.descricao, p.forma) descricao, sum(p.valor)::float total, count(*)::int n from pagamentos p left join formas_pagamento f on f.codigo=p.forma
    where p.caixa_id=$1 and p.origem='recebimento_fiado' group by p.forma, f.descricao order by f.descricao nulls last`, [id])).rows;
  const receber_detalhe = (await db.q(`select p.id, p.criado_em, coalesce(f.descricao, p.forma) forma_desc, p.valor::float valor, coalesce(c.nome,'Sem cliente') cliente, t.descricao
    from pagamentos p left join formas_pagamento f on f.codigo=p.forma left join titulos t on t.id=p.titulo_id left join clientes c on c.id=t.cliente_id
    where p.caixa_id=$1 and p.origem='recebimento_fiado' order by p.id`, [id])).rows;
  // tudo que aconteceu no caixa, especificado: cancelamentos, devoluções e fiado vendido (venda a venda)
  const numV = 'coalesce(v.numero, p.id)';
  const cancelamentos = (await db.q(`select ${numV} num, p.motivo_cancelamento motivo, coalesce(u.nome,'') por, (select coalesce(sum(i.quantidade*i.preco_unit),0) from pedido_itens i where i.pedido_id=p.id)::float valor
    from pedidos p left join vendas v on v.pedido_id=p.id left join usuarios u on u.id=p.cancelado_por where p.caixa_id=$1 and p.status='cancelado' and exists (select 1 from pedido_itens i where i.pedido_id=p.id) order by p.id`, [id])).rows;
  const devolucoes = (await db.q(`select ${numV} num, d.nome, d.quantidade::float qtd, d.valor::float valor, d.forma, d.motivo from devolucoes d join pedidos p on p.id=d.pedido_id left join vendas v on v.pedido_id=p.id where p.caixa_id=$1 order by d.id`, [id])).rows;
  const fiado_detalhe = (await db.q(`select ${numV} num, coalesce(c.nome,'Sem cliente') cliente, t.valor::float valor from titulos t join pedidos p on p.id=t.pedido_id left join vendas v on v.pedido_id=p.id left join clientes c on c.id=t.cliente_id
    where p.caixa_id=$1 and t.tipo='receber' and t.categoria='Venda fiado' and t.status<>'cancelado' order by p.id`, [id])).rows;
  const mov = (await db.q('select tipo, sum(valor) total from caixa_mov where caixa_id=$1 group by tipo', [id])).rows;
  const movimentos = (await db.q('select m.*, u.nome usuario from caixa_mov m left join usuarios u on u.id=m.usuario_id where caixa_id=$1 order by m.id', [id])).rows;
  const formasDesc = new Map((await db.q('select codigo, descricao from formas_pagamento')).rows.map(x => [x.codigo, x.descricao]));
  const v = (await db.q("select count(*)::int vendas, coalesce(sum(total),0) total, coalesce(sum(desconto),0) desconto from pedidos where caixa_id=$1 and status='fechado'", [id])).rows[0];
  const abertos = (await db.q("select count(*)::int n from pedidos where status='aberto' and usuario_id=$1 and exists (select 1 from pedido_itens i where i.pedido_id=pedidos.id and i.status<>'cancelado')", [cx.usuario_id])).rows[0].n;
  const g = t => Number(mov.find(m => m.tipo === t)?.total || 0);
  // sangria/suprimento têm forma de pagamento: só a de dinheiro mexe na gaveta; as demais abatem/somam na própria forma
  const tipoDe = new Map((await db.q('select codigo, tipo from formas_pagamento')).rows.map(x => [x.codigo, x.tipo]));
  const ehDin = f => (tipoDe.get(f || 'dinheiro') || f || 'dinheiro') === 'dinheiro';
  const somaMov = (tipo, pred) => r2(movimentos.filter(m => m.tipo === tipo && pred(m.forma || 'dinheiro')).reduce((a, m) => a + Number(m.valor), 0));
  movimentos.forEach(m => { m.forma = m.forma || 'dinheiro'; m.forma_desc = (formasDesc.get(m.forma)) || m.forma; });
  const sangrias_dinheiro = somaMov('sangria', ehDin), suprimentos_dinheiro = somaMov('suprimento', ehDin), doacoes_mov_dinheiro = somaMov('doacao', ehDin);
  const movs_por_forma = [...new Set(movimentos.map(m => m.forma))].map(f => ({ forma: f, descricao: formasDesc.get(f) || f, sangrias: somaMov('sangria', x => x === f), suprimentos: somaMov('suprimento', x => x === f), doacoes: somaMov('doacao', x => x === f) }));
  const dinheiro = formas.filter(f => f.tipo === 'dinheiro').reduce((s, f) => s + Number(f.total), 0);
  const doa = (await db.q('select destino, sum(valor)::float total, count(*)::int n from doacoes where caixa_id=$1 group by destino order by destino', [id])).rows;
  const doacoes = r2(doa.reduce((s, x) => s + x.total, 0));
  const esperado = r2(Number(cx.valor_abertura) + dinheiro + suprimentos_dinheiro + doacoes_mov_dinheiro - sangrias_dinheiro + doacoes);   // o dinheiro doado fica na gaveta até ser entregue
  const ev = (await db.q('select id, nome from eventos where caixa_id=$1', [id])).rows[0];
  const evento = ev ? { nome: ev.nome, equipe: (await db.q('select u.nome, u.ativo, p.nome funcao from evento_equipe ee join usuarios u on u.id=ee.usuario_id join perfis p on p.id=ee.perfil_id where ee.evento_id=$1 order by u.nome', [ev.id])).rows } : null;
  const ticket = v.vendas ? r2(v.total / v.vendas) : 0;
  // linhas de conferência: dinheiro (esperado na gaveta) + cada forma usada (exceto fiado)
  const inf = new Map((await db.q('select forma, informado from caixa_fechamento where caixa_id=$1', [id])).rows.map(x => [x.forma, Number(x.informado)]));
  if (!inf.size && cx.status === 'fechado' && cx.valor_informado != null) inf.set('dinheiro', Number(cx.valor_informado));
  // O troco (valor de abertura) é informado à parte: a linha Dinheiro conta só o que veio de vendas/recebimentos. Caixas fechados antes desta regra mantêm a conferência antiga.
  const abertura = r2(Number(cx.valor_abertura)), comTroco = abertura > 0 && (cx.status !== 'fechado' || inf.has('troco'));
  const linhas = (comTroco ? [{ forma: 'troco', descricao: 'Troco (valor de abertura)', tipo: 'troco', calculado: abertura }, { forma: 'dinheiro', descricao: 'Dinheiro (vendas)', tipo: 'dinheiro', calculado: r2(esperado - abertura) }]
    : [{ forma: 'dinheiro', descricao: 'Dinheiro (gaveta)', tipo: 'dinheiro', calculado: esperado }])
    .concat([...new Set([...formas.filter(f => f.tipo !== 'fiado' && f.tipo !== 'dinheiro').map(f => f.forma), ...movimentos.filter(m => !ehDin(m.forma) && (tipoDe.get(m.forma) || '') !== 'fiado').map(m => m.forma)])].map(cod => {
      const f = formas.find(x => x.forma === cod) || { descricao: formasDesc.get(cod) || cod, tipo: tipoDe.get(cod) || cod, total: 0 };
      return { forma: cod, descricao: f.descricao, tipo: f.tipo, calculado: r2(Number(f.total) + somaMov('suprimento', x => x === cod) + somaMov('doacao', x => x === cod) - somaMov('sangria', x => x === cod)) }; }));
  linhas.forEach(l => { l.informado = inf.has(l.forma) ? inf.get(l.forma) : null; l.diferenca = l.informado != null ? r2(l.informado - l.calculado) : null; });
  const fechado = cx.status === 'fechado' && linhas.some(l => l.informado != null);
  const diferenca = fechado ? r2(linhas.reduce((s, l) => s + (l.diferenca || 0), 0)) : null;
  // TOTAL DO FECHAMENTO = entradas − saídas (sem custo de produto; cancelamentos estornados ficam de fora; fiado só entra quando recebido)
  const vendasRecebidas = r2(formas.filter(f => f.tipo !== 'fiado').reduce((t, f) => t + Number(f.total) - Number(f.recebido_fiado), 0));
  const fiadoRec = r2(formas.reduce((s, f) => s + Number(f.recebido_fiado), 0));
  const entradasMov = r2(g('suprimento')), doacoesMov = somaMov('doacao', () => true), despesas = r2(g('sangria'));
  const trocoRetirado = abertura > 0 ? (inf.has('troco') ? inf.get('troco') : abertura) : 0;
  const entradasTot = r2(abertura + vendasRecebidas + fiadoRec + entradasMov + doacoesMov + doacoes);
  const saidasTot = r2(despesas + trocoRetirado);
  const fechamento = { troco_abertura: abertura, vendas: vendasRecebidas, fiado_recebido: fiadoRec, entradas_mov: entradasMov, doacoes_mov: doacoesMov, doacoes_troco: doacoes, total_entradas: entradasTot,
    despesas, troco_retirado: r2(trocoRetirado), troco_retirado_previsto: !inf.has('troco'), total_saidas: saidasTot, resultado: r2(entradasTot - saidasTot) };
  return { fechamento, caixa: cx, formas, linhas, movimentos, movs_por_forma, sangrias: g('sangria'), suprimentos: g('suprimento'), sangrias_dinheiro, suprimentos_dinheiro, doacoes_mov: somaMov('doacao', () => true), doacoes_mov_dinheiro, doacoes, doacoes_por_destino: doa, evento, vendas: v.vendas,
    total_vendido: Number(v.total), descontos: Number(v.desconto), ticket_medio: ticket, dinheiro_em_caixa_esperado: esperado,
    fiado_vendido: r2(formas.filter(f => f.tipo === 'fiado').reduce((s, f) => s + Number(f.total), 0)), fiado_recebido: r2(formas.reduce((s, f) => s + Number(f.recebido_fiado), 0)),
    cancelamentos, devolucoes, fiado_detalhe, vendas_por_forma: formas.map(f => ({ forma: f.forma, descricao: f.descricao, tipo: f.tipo, n: f.vendas, valor: r2(Number(f.total) - Number(f.recebido_fiado)) })).filter(f => f.valor || f.n),
    esperado_detalhe: { abertura, dinheiro_vendas_e_recebimentos: r2(dinheiro), entradas: suprimentos_dinheiro, doacoes_recebidas: doacoes_mov_dinheiro, doacoes_troco: doacoes, saidas: sangrias_dinheiro },
    receber_por_forma, receber_detalhe, receber_total: r2(receber_por_forma.reduce((t, x) => t + x.total, 0)),
    comandas_abertas_do_usuario: abertos, diferenca };
}

function comprovanteTexto(rs) {
  const c = rs.caixa, L = []; const lin = prn.linha(42);
  L.push(`Caixa #${c.id}  Operador: ${c.usuario}`.slice(0, 42), `Abertura:   ${dh(c.aberto_em)}`, `Fechamento: ${dh(c.fechado_em)}`, `Valor de abertura: ${brl(c.valor_abertura)}`, lin);
  const col = (t, n) => String(t).slice(0, n).padEnd(n), num = (t, n) => String(t).padStart(n);
  L.push(col('Forma', 12) + num('Sistema', 10) + num('Informado', 10) + num('Dif.', 10), lin);
  for (const l of rs.linhas) { // uma linha por forma de pagamento
    const nome = String(l.descricao || l.forma || '').replace(/\s*\(.*?\)\s*/g, ' ').trim();
    L.push(col(nome, 12) + num(brl(l.calculado), 10) + num(brl(l.informado), 10) + num((l.diferenca > 0 ? '+' : '') + brl(l.diferenca), 10));
  }
  L.push(lin);
  const tc = r2(rs.linhas.reduce((s, l) => s + l.calculado, 0)), ti = r2(rs.linhas.reduce((s, l) => s + (l.informado || 0), 0));
  L.push(`TOTAL calculado pelo sistema: ${brl(tc).padStart(10)}`, `TOTAL informado:              ${brl(ti).padStart(10)}`,
    `DIFERENCA (informado - calc.): ${((rs.diferenca > 0 ? '+' : '') + brl(rs.diferenca)).padStart(9)}`, rs.diferenca === 0 ? 'Sem divergencia.' : (rs.diferenca > 0 ? 'Sobra de caixa' : 'Falta de caixa'));
  if (c.motivo_divergencia) L.push('', 'Motivo da divergencia:', ...prn.quebrar ? prn.quebrar(c.motivo_divergencia, 42) : [c.motivo_divergencia]);
  L.push(lin, `Vendas: ${rs.vendas}  Total vendido: ${brl(rs.total_vendido)}`, ...(rs.evento ? [`Evento: ${rs.evento.nome}`] : []));
  if ((rs.movimentos || []).length) {   // cada sangria/suprimento, com a forma de pagamento e o motivo
    L.push(lin, 'MOVIMENTOS DE CAIXA (detalhe)');
    for (const m of rs.movimentos) L.push(`${dh(m.criado_em).slice(0, 15)} ${m.tipo === 'sangria' ? 'SAIDA' : m.tipo === 'doacao' ? 'DOACAO' : 'ENTRADA'} ${m.tipo === 'sangria' ? '-' : '+'}${brl(m.valor)}`, `  ${String(m.forma_desc || m.forma).slice(0, 18)}: ${String(m.motivo || '').slice(0, 22)}`);
  }
  L.push(lin, 'VENDAS POR FORMA DE PAGAMENTO');
  for (const x of rs.vendas_por_forma || []) L.push(col(String(x.descricao).replace(/\s*\(.*?\)\s*/g, ' ').trim(), 24) + num(`${x.n}x`, 6) + num(brl(x.valor), 12));
  L.push(`Descontos concedidos: ${brl(rs.descontos)}   Ticket medio: ${brl(rs.ticket_medio)}`);
  if ((rs.fiado_detalhe || []).length) { L.push(lin, 'FIADO VENDIDO (a receber)', col(`${rs.fiado_detalhe.length} venda(s) no fiado`, 26) + num(brl(rs.fiado_detalhe.reduce((t, x) => t + x.valor, 0)), 16)); }
  if ((rs.receber_detalhe || []).length) { L.push(lin, 'CONTAS A RECEBER - RECEBIMENTOS'); for (const x of rs.receber_detalhe) L.push(col(`${x.cliente}`, 24) + num(String(x.forma_desc).slice(0, 8), 8) + num(brl(x.valor), 10)); }
  if ((rs.devolucoes || []).length) { L.push(lin, 'DEVOLUCOES'); for (const x of rs.devolucoes) L.push(col(`#${String(x.num).padStart(6, '0')} ${x.nome}`, 30) + num(brl(x.valor), 12), `  ${String(x.forma || '')} ${String(x.motivo || '').slice(0, 30)}`); }
  { const F = rs.fechamento, v = (t, n) => col(t, 30) + num(brl(n), 12); L.push(lin, 'TOTAL DO FECHAMENTO', 'ENTRADAS', v('Troco de abertura', F.troco_abertura), v('Vendas recebidas', F.vendas), v('Fiado recebido', F.fiado_recebido), v('Entradas (mov. caixa)', F.entradas_mov), v('Doacoes (mov. caixa)', F.doacoes_mov), v('Doacoes (troco venda)', F.doacoes_troco), v('TOTAL ENTRADAS', F.total_entradas), 'SAIDAS', v('Despesas/sangrias', F.despesas), v('Troco retirado' + (F.troco_retirado_previsto ? ' (prev.)' : ''), F.troco_retirado), v('TOTAL SAIDAS', F.total_saidas), v('RESULTADO (entr.-saidas)', F.resultado)); }
  if ((rs.receber_por_forma || []).length) {   // contas a receber recebidas, por forma de pagamento
    L.push(lin, 'CONTAS A RECEBER RECEBIDAS', ...rs.receber_por_forma.map(x => col(String(x.descricao).replace(/\s*\(.*?\)\s*/g, ' ').trim(), 24) + num(`${x.n}x`, 6) + num(brl(x.total), 12)), col('TOTAL', 24) + num('', 6) + num(brl(rs.receber_total), 12));
  }
  L.push('', '', '________________________________', 'Responsavel pelo caixa');
  return L.join('\n');
}

// ---- Caixas abertos do usuário logado (usado ao entrar na tela de vendas / recebimento de fiado)
r.get('/abertos', auth(), wrap(async (req, res) => {
  res.json((await db.q(`select c.id, c.numero, c.aberto_em, c.valor_abertura, coalesce((select sum(total) from pedidos p where p.caixa_id=c.id and p.status='fechado'),0) vendido
    from caixas c where c.usuario_id=$1 and c.status='aberto' order by c.id`, [req.user.id])).rows);
}));

r.get('/atual', auth('caixa.acessar'), wrap(async (req, res) => {
  const cx = (await db.q("select id from caixas where usuario_id=$1 and status='aberto' order by id desc limit 1", [req.user.id])).rows[0];
  res.json(cx ? await resumo(cx.id) : null);
}));


// Produtos liberados para venda neste caixa/evento (tabela caixa_produtos). Vazio = todos os produtos vendáveis aparecem.
async function gravarCardapio(cli, caixaId, ids) {
  if (!Array.isArray(ids)) return;
  await cli.q('delete from caixa_produtos where caixa_id=$1', [caixaId]);
  const lista = [...new Set(ids.map(Number).filter(Boolean))];
  if (lista.length) await cli.q('insert into caixa_produtos(caixa_id, produto_id) select $1, id from produtos where id = any($2) on conflict do nothing', [caixaId, lista]);
}
r.get('/cardapio', auth(['caixa.acessar', 'vendas.acessar']), wrap(async (req, res) => {
  const cx = (await db.q("select id from caixas where usuario_id=$1 and status='aberto' order by id desc limit 1", [req.user.id])).rows[0];
  if (!cx) return res.json({ caixa_id: null, ids: [] });
  res.json({ caixa_id: cx.id, ids: (await db.q('select produto_id from caixa_produtos where caixa_id=$1', [cx.id])).rows.map(x => x.produto_id) });
}));
r.get('/cardapio/ultimo', auth(['caixa.acessar', 'vendas.acessar']), wrap(async (req, res) => {
  const ult = (await db.q("select c.id from caixas c where c.usuario_id=$1 and exists (select 1 from caixa_produtos cp where cp.caixa_id=c.id) order by c.id desc limit 1", [req.user.id])).rows[0];
  res.json({ ids: ult ? (await db.q('select produto_id from caixa_produtos where caixa_id=$1', [ult.id])).rows.map(x => x.produto_id) : [] });
}));
r.put('/cardapio', auth('caixa.acessar'), wrap(async (req, res) => {
  const cx = (await db.q("select id from caixas where usuario_id=$1 and status='aberto' order by id desc limit 1", [req.user.id])).rows[0];
  if (!cx) throw new HttpError(400, 'Abra o caixa primeiro.');
  // alterar os produtos do caixa exige usuário e senha de quem tem permissão
  const aut = await db.tx(c => verificarAutorizacao(c, req.body?.autorizacao, 'caixa.produtos', req.user));
  await gravarCardapio(db, cx.id, req.body?.ids || []);
  await auditar(null, req.user, 'caixa_produtos', { caixa: cx.id, qtd: (req.body?.ids || []).length, autorizado_por: aut.nome });
  res.json({ ok: true });
}));

// Colaboradores ativos e funções (perfis) para montar a equipe do evento na abertura do caixa
r.get('/equipe-opcoes', auth('caixa.acessar'), wrap(async (req, res) => {
  res.json({ usuarios: (await db.q('select u.id, u.nome, u.cargo, u.perfil_id, p.nome perfil from usuarios u left join perfis p on p.id=u.perfil_id where u.ativo order by u.nome')).rows,
    funcoes: (await db.q('select id, nome from perfis order by nome')).rows });
}));

r.post('/abrir', auth('caixa.acessar'), wrap(async (req, res) => {
  const ja = await db.q("select c.id, c.numero, c.usuario_id, u.nome from caixas c join usuarios u on u.id=c.usuario_id where c.status='aberto' order by c.id limit 1");
  if (ja.rowCount) throw new HttpError(400, ja.rows[0].usuario_id === req.user.id ? 'Você já possui um caixa aberto.' : `Já existe um caixa aberto (Caixa ${ja.rows[0].numero ?? ja.rows[0].id}, operador ${ja.rows[0].nome}). Só é permitido um caixa aberto por vez: feche-o antes de abrir outro.`);
  // evento e equipe do dia (cada pessoa com a sua função); o operador que abre entra na equipe com a função que escolher/o próprio perfil
  const nomeEv = String(req.body?.evento || '').trim();
  if (!nomeEv) throw new HttpError(400, 'Informe o nome do evento.');
  const eq = new Map(); for (const m of (Array.isArray(req.body?.equipe) ? req.body.equipe : [])) if (m && m.usuario_id && m.perfil_id) eq.set(Number(m.usuario_id), Number(m.perfil_id));
  const eu = (await db.q('select perfil_id from usuarios where id=$1', [req.user.id])).rows[0];
  if (!eq.has(req.user.id) && eu?.perfil_id) eq.set(req.user.id, eu.perfil_id);
  for (const [uid, pid] of eq) {
    if (!(await db.q('select 1 from usuarios where id=$1 and ativo', [uid])).rowCount) throw new HttpError(400, 'Há um colaborador inativo ou inexistente na equipe do evento.');
    if (!(await db.q('select 1 from perfis where id=$1', [pid])).rowCount) throw new HttpError(400, 'Função inválida na equipe do evento.');
  }
  const x = await db.q('insert into caixas(usuario_id, valor_abertura) values($1,$2) returning id', [req.user.id, r2(num(req.body?.valor_abertura))]);
  const evId = (await db.q('insert into eventos(nome, caixa_id) values($1,$2) returning id', [nomeEv.slice(0, 120), x.rows[0].id])).rows[0].id;
  for (const [uid, pid] of eq) await db.q('insert into evento_equipe(evento_id, usuario_id, perfil_id) values($1,$2,$3)', [evId, uid, pid]);
  await gravarCardapio(db, x.rows[0].id, req.body?.produtos);
  await auditar(null, req.user, 'caixa_aberto', { id: x.rows[0].id, evento: nomeEv, equipe: [...eq].map(([u, f]) => ({ usuario_id: u, perfil_id: f })) });
  res.json(await resumo(x.rows[0].id));
}));

r.post('/movimento', auth('caixa.movimentar'), wrap(async (req, res) => {
  const { tipo, valor, motivo } = req.body || {};
  if (!['sangria', 'suprimento', 'doacao'].includes(tipo)) throw new HttpError(400, 'Tipo inválido.');
  const fp = (await db.q("select codigo from formas_pagamento where codigo=$1 and ativo and tipo<>'fiado'", [(req.body || {}).forma || 'dinheiro'])).rows[0];
  if (!fp) throw new HttpError(400, 'Informe a forma de pagamento da ' + (tipo === 'sangria' ? 'saída' : tipo === 'doacao' ? 'doação' : 'entrada') + '.');
  if (num(valor) <= 0) throw new HttpError(400, 'Informe um valor maior que zero.');
  if (!motivo) throw new HttpError(400, 'Informe o motivo.');
  const cx = (await db.q("select id from caixas where usuario_id=$1 and status='aberto'", [req.user.id])).rows[0];
  if (!cx) throw new HttpError(400, 'Abra o caixa primeiro.');
  await db.q('insert into caixa_mov(caixa_id,tipo,valor,motivo,usuario_id,forma) values($1,$2,$3,$4,$5,$6)', [cx.id, tipo, r2(num(valor)), motivo, req.user.id, fp.codigo]);
  await auditar(null, req.user, 'caixa_' + tipo, { caixa: cx.id, valor, motivo, forma: fp.codigo });
  res.json(await resumo(cx.id));
}));

// ---- Fechamento: o operador informa o total de CADA forma de pagamento; divergência exige confirmação e motivo

// Insumos das produções ainda não baixadas: consumo previsto (ficha técnica × quantidade produzida) e estoque atual
async function insumosPendentes(cli) {
  return (await cli.query(`select i.id insumo_id, i.nome, i.unidade, i.estoque_atual, round(sum(pr.quantidade*r.quantidade),3) previsto
    from producoes pr join receitas r on r.produto_id=pr.produto_id join produtos i on i.id=r.insumo_id
    where pr.insumos_baixados_em is null group by i.id order by i.nome`)).rows;
}
r.get('/insumos-fechamento', auth('caixa.fechar'), wrap(async (req, res) => { res.json(await insumosPendentes(db)); }));
r.get('/:id/insumos', auth(['caixa.acessar', 'caixa.conferir', 'relatorios.financeiro']), wrap(async (req, res) => {
  res.json((await db.q('select ci.*, p.nome, p.unidade from caixa_insumos ci join produtos p on p.id=ci.insumo_id where ci.caixa_id=$1 order by p.nome', [req.params.id])).rows);
}));

r.post('/fechar', auth('caixa.fechar'), wrap(async (req, res) => {
  const cx = (await db.q("select id from caixas where usuario_id=$1 and status='aberto'", [req.user.id])).rows[0];
  if (!cx) throw new HttpError(400, 'Nenhum caixa aberto.');
  const b = req.body || {}, vals = b.valores || {};
  const rs = await resumo(cx.id);
  const falta = rs.linhas.filter(l => vals[l.forma] === undefined || vals[l.forma] === '' || vals[l.forma] === null);
  if (falta.length) throw new HttpError(400, 'Informe o valor total de: ' + falta.map(l => l.descricao).join(', ') + ' (use 0 se não houve).');
  const linhas = rs.linhas.map(l => { const informado = r2(num(vals[l.forma])); return { ...l, informado, diferenca: r2(informado - l.calculado) }; });
  if (linhas.some(l => l.informado < 0 && l.calculado >= 0)) throw new HttpError(400, 'Valores informados não podem ser negativos.');
  const diverge = linhas.some(l => Math.abs(l.diferenca) > 0.004);
  if (diverge && !b.confirmar_divergencia) throw new HttpError(409, 'Há divergência de valores entre o calculado pelo sistema e o informado.', { divergencia: true, linhas });
  const motivo = String(b.motivo || '').trim();
  if (diverge && !motivo) throw new HttpError(400, 'Informe o motivo da divergência para fechar o caixa.', { motivo_obrigatorio: true });
  const dif = r2(linhas.reduce((s, l) => s + l.diferenca, 0));
  await db.tx(async c => {
    await c.query('delete from caixa_fechamento where caixa_id=$1', [cx.id]);
    for (const l of linhas) await c.query('insert into caixa_fechamento(caixa_id, forma, informado) values($1,$2,$3)', [cx.id, l.forma, l.informado]);
    const din = linhas.find(l => l.forma === 'dinheiro');
    await c.query("update caixas set status='fechado', fechado_em=now(), valor_informado=$1, valor_esperado=$2, diferenca=$3, motivo_divergencia=$4, total_calculado=$5, total_informado=$6, conferido=false, conferido_por=null, conferido_em=null where id=$7",
      [din.informado, din.calculado, dif, diverge ? motivo : null, r2(linhas.reduce((s, l) => s + l.calculado, 0)), r2(linhas.reduce((s, l) => s + l.informado, 0)), cx.id]);
    // baixa dos insumos usados nas produções: consumo real = estoque atual − sobra contada (sem contagem, vale o previsto pela ficha técnica)
    const pend = await insumosPendentes(c), sobras = b.sobras || {};
    for (const x of pend) {
      const est0 = Number(x.estoque_atual), prev = Number(x.previsto), inf = sobras[x.insumo_id];
      const tem = inf !== undefined && inf !== null && String(inf).trim() !== '';
      const sobra = tem ? num(inf) : null;
      if (tem && (sobra < 0 || sobra > est0 + 0.0005)) throw new HttpError(400, `Sobra de ${x.nome} inválida: o estoque no sistema é ${est0} ${x.unidade}. Se você comprou mais durante o evento, lance a entrada da compra antes de fechar o caixa.`);
      const real = tem ? Math.round((est0 - sobra) * 1000) / 1000 : Math.min(prev, est0);
      if (real > 0) await est.mover(c, { produto_id: x.insumo_id, tipo: 'producao_saida', quantidade: -real, custo_unit: null, origem: 'fechamento_caixa', ref_id: cx.id, motivo: 'Consumo de insumos da produção (fechamento do caixa)', usuario_id: req.user.id });
      await c.query('insert into caixa_insumos(caixa_id,insumo_id,estoque_antes,consumo_previsto,sobra_informada,consumo_real,diferenca) values($1,$2,$3,$4,$5,$6,$7)', [cx.id, x.insumo_id, est0, prev, sobra, real, Math.round((real - prev) * 1000) / 1000]);
    }
    if (pend.length) { await c.query('update producoes set insumos_baixados_em=now(), caixa_id=coalesce(caixa_id,$1) where insumos_baixados_em is null', [cx.id]); await auditar(c, req.user, 'insumos_baixados_fechamento', { caixa: cx.id, insumos: pend.length }); }
    await auditar(c, req.user, 'caixa_fechado', { id: cx.id, diferenca: dif, divergente: diverge, motivo: diverge ? motivo : undefined, linhas: linhas.map(l => ({ forma: l.forma, calc: l.calculado, inf: l.informado })) });
  });
  const rs2 = await resumo(cx.id); const texto = comprovanteTexto(rs2);
  const insumos = (await db.q('select ci.*, p.nome, p.unidade from caixa_insumos ci join produtos p on p.id=ci.insumo_id where ci.caixa_id=$1 order by p.nome', [cx.id])).rows;
  res.json({ ...rs2, insumos, comprovante: texto, impressao: await prn.imprimirTexto(db, 'caixa', 'FECHAMENTO DE CAIXA', texto) });
}));

// ---- Conferência: lista (todos se tiver permissão)
r.get('/', auth('caixa.acessar'), wrap(async (req, res) => {
  const todos = can(req.user, 'caixa.ver_todos') || can(req.user, 'caixa.conferir');
  res.json((await db.q(`select c.*, u.nome usuario, cu.nome conferido_por_nome from caixas c join usuarios u on u.id=c.usuario_id left join usuarios cu on cu.id=c.conferido_por
    ${todos ? '' : 'where c.usuario_id=$1'} order by c.id desc limit 1000`, todos ? [] : [req.user.id])).rows);
}));

// ---- Resumo do caixa em PDF (tudo especificado: conferência, vendas, recebimentos, movimentos, cancelamentos...)
function resumoPdf(rs, empresa) {
  const d = pdf.criar(), M = d.margem, R = d.largura - M, H = d.altura; let y = M;
  const fmt = n => 'R$ ' + brl(n), dd = x => (x ? dh(x) : '-');
  const ensure = h => { if (y + h > H - 50) { d.nova(); y = M; } };
  const sec = t => { ensure(40); y += 8; d.texto(M, y + 10, t, { size: 11, bold: true }); y += 14; d.linha(M, y, R, y, { w: 0.8, cinza: 0.3 }); y += 6; };
  const par = (a, b, bold) => { ensure(15); d.texto(M, y + 9, a, { size: 9.5, bold, max: R - M - 110 }); d.texto(R, y + 9, b, { size: 9.5, bold, align: 'right' }); y += 14; };
  // tabela simples: cols = [{ t, x (0-1 da largura), a: 'l'|'r' }]
  const tab = (cols, rows, rodape) => {
    const w = R - M, X = c => M + c.x * w;
    const cab = () => { ensure(30); d.caixa(M, y, w, 15, 0.9); cols.forEach(c => d.texto(c.a === 'r' ? X(c) + c.w * w - 3 : X(c) + 3, y + 11, c.t, { size: 8.5, bold: true, align: c.a === 'r' ? 'right' : 'left' })); y += 16; };
    cab(); if (!rows.length) { d.texto(M + 3, y + 9, 'Nenhum registro.', { size: 9, cor: 0.4 }); y += 14; }
    const lin = (r, bold) => { if (y + 15 > H - 50) { d.nova(); y = M; cab(); } cols.forEach((c, i) => d.texto(c.a === 'r' ? X(c) + c.w * w - 3 : X(c) + 3, y + 10, String(r[i] ?? ''), { size: 9, bold, align: c.a === 'r' ? 'right' : 'left', max: c.w * w - 6 })); y += 14; d.linha(M, y, R, y, { w: 0.3, cinza: 0.85 }); };
    rows.forEach(r => lin(r, false)); if (rodape) lin(rodape, true);
  };
  const c = rs.caixa;
  d.texto(M, y + 14, 'RESUMO DO CAIXA Nº ' + (c.numero ?? c.id), { size: 16, bold: true }); y += 24;
  if (empresa) { d.texto(M, y + 8, empresa, { size: 10, max: R - M }); y += 14; }
  d.texto(M, y + 8, `Operador: ${c.usuario}   Abertura: ${dd(c.aberto_em)}   Fechamento: ${c.fechado_em ? dd(c.fechado_em) : 'ABERTO'}`, { size: 9.5 }); y += 14;
  if (rs.evento) { d.texto(M, y + 8, 'Evento: ' + rs.evento.nome, { size: 9.5, bold: true }); y += 14; }
  if (rs.linhas && rs.diferenca !== null) {
    sec('Conferência do fechamento');
    tab([{ t: 'Forma', x: 0, w: 0.40 }, { t: 'Calculado', x: 0.40, w: 0.20, a: 'r' }, { t: 'Informado', x: 0.60, w: 0.20, a: 'r' }, { t: 'Diferença', x: 0.80, w: 0.20, a: 'r' }],
      rs.linhas.map(l => [l.descricao, fmt(l.calculado), l.informado != null ? fmt(l.informado) : '-', l.diferenca != null ? (l.diferenca > 0 ? '+' : '') + fmt(l.diferenca) : '-']));
    par('Diferença total', (rs.diferenca > 0 ? '+' : '') + fmt(rs.diferenca), true);
    if (c.motivo_divergencia) par('Motivo da divergência', String(c.motivo_divergencia).slice(0, 70));
  }
  { const F = rs.fechamento; sec('Total do fechamento (entradas - saídas)');
    d.texto(M, y + 9, 'ENTRADAS', { size: 9.5, bold: true }); y += 14;
    par('Troco de abertura', fmt(F.troco_abertura)); par('Vendas recebidas (sem canceladas e sem fiado a receber)', fmt(F.vendas)); par('Fiado recebido neste caixa', fmt(F.fiado_recebido)); par('Entradas lançadas no movimento de caixa', fmt(F.entradas_mov)); par('Doações lançadas no movimento de caixa', fmt(F.doacoes_mov)); par('Doações do troco na venda', fmt(F.doacoes_troco)); par('TOTAL DE ENTRADAS', fmt(F.total_entradas), true);
    y += 4; d.texto(M, y + 9, 'SAÍDAS', { size: 9.5, bold: true }); y += 14;
    par('Despesas / sangrias do movimento de caixa', fmt(F.despesas)); par('Troco retirado' + (F.troco_retirado_previsto ? ' (previsto)' : ''), fmt(F.troco_retirado)); par('TOTAL DE SAÍDAS', fmt(F.total_saidas), true);
    y += 4; par('RESULTADO DO FECHAMENTO', fmt(F.resultado), true); }
  sec('Vendas'); par('Quantidade de vendas', String(rs.vendas)); par('Total vendido (líquido)', fmt(rs.total_vendido)); par('Descontos concedidos', fmt(rs.descontos)); par('Ticket médio', fmt(rs.ticket_medio));
  sec('Vendas por forma de pagamento');
  tab([{ t: 'Forma', x: 0, w: 0.6 }, { t: 'Vendas', x: 0.6, w: 0.15, a: 'r' }, { t: 'Valor', x: 0.75, w: 0.25, a: 'r' }], (rs.vendas_por_forma || []).map(x => [x.descricao, x.n, fmt(x.valor)]), ['TOTAL', '', fmt((rs.vendas_por_forma || []).reduce((a, x) => a + x.valor, 0))]);
  sec('Contas a receber recebidas neste caixa');
  tab([{ t: 'Forma', x: 0, w: 0.6 }, { t: 'Recebimentos', x: 0.6, w: 0.15, a: 'r' }, { t: 'Valor', x: 0.75, w: 0.25, a: 'r' }], (rs.receber_por_forma || []).map(x => [x.descricao, x.n, fmt(x.total)]), ['TOTAL', '', fmt(rs.receber_total || 0)]);
  if ((rs.receber_detalhe || []).length) { y += 4; tab([{ t: 'Hora', x: 0, w: 0.2 }, { t: 'Cliente', x: 0.2, w: 0.3 }, { t: 'Referente a', x: 0.5, w: 0.2 }, { t: 'Forma', x: 0.7, w: 0.15 }, { t: 'Valor', x: 0.85, w: 0.15, a: 'r' }], rs.receber_detalhe.map(x => [dd(x.criado_em), x.cliente, x.descricao || '', x.forma_desc, fmt(x.valor)])); }
  if ((rs.fiado_detalhe || []).length) { sec('Fiado vendido (a receber)'); par(`${rs.fiado_detalhe.length} venda(s) no fiado - total`, fmt(rs.fiado_detalhe.reduce((a, x) => a + x.valor, 0)), true); }
  sec('Movimentos de caixa (entradas, saídas e doações)');
  const TP = { sangria: 'Saída', suprimento: 'Entrada', doacao: 'Doação' };
  tab([{ t: 'Hora', x: 0, w: 0.17 }, { t: 'Tipo', x: 0.17, w: 0.1 }, { t: 'Forma', x: 0.27, w: 0.15 }, { t: 'Motivo', x: 0.42, w: 0.3 }, { t: 'Responsável', x: 0.72, w: 0.13 }, { t: 'Valor', x: 0.85, w: 0.15, a: 'r' }],
    (rs.movimentos || []).map(m => [dd(m.criado_em), TP[m.tipo] || m.tipo, m.forma_desc || m.forma, m.motivo || '', m.usuario || '', (m.tipo === 'sangria' ? '- ' : '+ ') + fmt(m.valor)]));
  if ((rs.movs_por_forma || []).length) { y += 4; tab([{ t: 'Por forma', x: 0, w: 0.4 }, { t: 'Saídas', x: 0.4, w: 0.2, a: 'r' }, { t: 'Entradas', x: 0.6, w: 0.2, a: 'r' }, { t: 'Doações', x: 0.8, w: 0.2, a: 'r' }], rs.movs_por_forma.map(x => [x.descricao, fmt(x.sangrias), fmt(x.suprimentos), fmt(x.doacoes)])); }
  if ((rs.devolucoes || []).length) { sec('Devoluções'); tab([{ t: 'Venda', x: 0, w: 0.12 }, { t: 'Item', x: 0.12, w: 0.33 }, { t: 'Forma', x: 0.45, w: 0.13 }, { t: 'Motivo', x: 0.58, w: 0.25 }, { t: 'Valor', x: 0.83, w: 0.17, a: 'r' }], rs.devolucoes.map(x => [String(x.num).padStart(6, '0'), x.nome, x.forma || '', x.motivo || '', fmt(x.valor)]), ['', '', '', 'TOTAL', fmt(rs.devolucoes.reduce((a, x) => a + x.valor, 0))]); }
  if ((rs.doacoes_por_destino || []).length) { sec('Doações do troco, por local (valor a entregar)'); tab([{ t: 'Local', x: 0, w: 0.6 }, { t: 'Doações', x: 0.6, w: 0.15, a: 'r' }, { t: 'Valor', x: 0.75, w: 0.25, a: 'r' }], rs.doacoes_por_destino.map(x => [x.destino, x.n, fmt(x.total)]), ['TOTAL', '', fmt(rs.doacoes)]); }
  const e = rs.esperado_detalhe || {};
  sec('Dinheiro na gaveta (conferência)');
  par('Abertura (troco)', fmt(e.abertura)); par('+ Dinheiro de vendas e recebimentos', fmt(e.dinheiro_vendas_e_recebimentos)); par('+ Entradas em dinheiro', fmt(e.entradas)); par('+ Doações recebidas em dinheiro', fmt(e.doacoes_recebidas)); par('+ Doações do troco (na gaveta)', fmt(e.doacoes_troco)); par('- Saídas / sangrias em dinheiro', fmt(e.saidas)); par('= Dinheiro esperado na gaveta', fmt(rs.dinheiro_em_caixa_esperado), true);
  if (rs.fiado_vendido || rs.fiado_recebido) { sec('Fiado'); par('Vendido em fiado (a receber)', fmt(rs.fiado_vendido)); par('Fiado recebido neste caixa', fmt(rs.fiado_recebido)); }
  return d.build('Resumo do caixa ' + (c.numero ?? c.id));
}
r.get('/:id/resumo.pdf', auth(['caixa.acessar', 'relatorios.financeiro', 'caixa.conferir']), wrap(async (req, res) => {
  const rs = await resumo(req.params.id);
  if (!podeVer(req.user, rs.caixa)) throw new HttpError(403, 'Sem permissão para ver o caixa de outro usuário.');
  const emp = ((await db.q("select valor from config where chave='empresa'")).rows[0] || {}).valor || '';
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `inline; filename="caixa-${rs.caixa.numero ?? rs.caixa.id}.pdf"`);
  res.send(resumoPdf(rs, emp));
}));

r.get('/:id', auth(['caixa.acessar', 'relatorios.financeiro', 'caixa.conferir']), wrap(async (req, res) => {
  const rs = await resumo(req.params.id);
  if (!podeVer(req.user, rs.caixa)) throw new HttpError(403, 'Sem permissão para ver o caixa de outro usuário.');
  res.json(rs);
}));

// ---- Reimprimir comprovante de fechamento
r.post('/:id/comprovante', auth(['caixa.acessar', 'caixa.conferir']), wrap(async (req, res) => {
  const rs = await resumo(req.params.id);
  if (!podeVer(req.user, rs.caixa)) throw new HttpError(403, 'Sem permissão para ver o caixa de outro usuário.');
  if (rs.caixa.status !== 'fechado') throw new HttpError(400, 'O comprovante de fechamento só existe para caixa fechado.');
  const texto = comprovanteTexto(rs);
  await auditar(null, req.user, 'caixa_comprovante_reimpresso', { id: rs.caixa.id });
  res.json({ comprovante: texto, impressao: await prn.imprimirTexto(db, 'caixa', 'FECHAMENTO DE CAIXA (2a via)', texto) });
}));

// ---- Movimentações do caixa (com filtro por forma de pagamento)
r.get('/:id/movimentacoes', auth(['caixa.acessar', 'caixa.conferir']), wrap(async (req, res) => {
  const cx = (await db.q('select * from caixas where id=$1', [req.params.id])).rows[0];
  if (!cx) throw new HttpError(404, 'Caixa não encontrado.');
  if (!podeVer(req.user, cx)) throw new HttpError(403, 'Sem permissão para ver o caixa de outro usuário.');
  const forma = req.query.forma || null;
  const rows = (await db.q(`select * from (
      select p.criado_em, case when p.origem='recebimento_fiado' then 'Recebimento de fiado' else 'Venda' end tipo, p.forma, coalesce(f.descricao, p.forma) forma_desc, p.valor,
        ped.id pedido_id, case when p.pedido_id is not null then 'Venda' end ref, null::text motivo, cli.nome cliente
      from pagamentos p left join formas_pagamento f on f.codigo=p.forma left join pedidos ped on ped.id=p.pedido_id left join titulos t on t.id=p.titulo_id
        left join clientes cli on cli.id=coalesce(t.cliente_id, ped.cliente_id) where p.caixa_id=$1
      union all
      select m.criado_em, case when m.tipo='sangria' then 'Sangria' when m.tipo='doacao' then 'Doação' else 'Suprimento' end, coalesce(m.forma,'dinheiro'), coalesce(fm.descricao,'Dinheiro'), case when m.tipo='sangria' then -m.valor else m.valor end,
        null::int, null::text, m.motivo, null::text from caixa_mov m left join formas_pagamento fm on fm.codigo=coalesce(m.forma,'dinheiro') where m.caixa_id=$1) x
    where ($2::text is null or x.forma=$2) order by x.criado_em`, [req.params.id, forma])).rows;
  res.json({ caixa: cx, movimentos: rows, total: r2(rows.reduce((s, x) => s + Number(x.valor), 0)) });
}));

// ---- Pagamentos do caixa (para alterar forma de pagamento)
r.get('/:id/pagamentos', auth('caixa.alterar_forma'), wrap(async (req, res) => {
  res.json((await db.q(`select p.id, p.criado_em, p.forma, coalesce(f.descricao,p.forma) forma_desc, coalesce(f.tipo,p.forma) tipo, p.valor, p.tef_nsu, p.origem, p.pedido_id,
      'Venda' mesa, cli.nome cliente
    from pagamentos p left join formas_pagamento f on f.codigo=p.forma left join pedidos ped on ped.id=p.pedido_id left join titulos t on t.id=p.titulo_id
      left join clientes cli on cli.id=coalesce(t.cliente_id, ped.cliente_id) where p.caixa_id=$1 order by p.id`, [req.params.id])).rows);
}));

r.post('/pagamentos/:id/forma', auth('caixa.alterar_forma'), wrap(async (req, res) => {
  const b = req.body || {}; const motivo = String(b.motivo || '').trim();
  if (!motivo) throw new HttpError(400, 'Informe o motivo da alteração.');
  await db.tx(async c => {
    const aut = await verificarAutorizacao(c, b.autorizacao, 'caixa.alterar_forma', req.user);
    const p = (await c.query(`select p.*, coalesce(f.tipo, p.forma) tipo from pagamentos p left join formas_pagamento f on f.codigo=p.forma where p.id=$1 for update of p`, [req.params.id])).rows[0];
    if (!p) throw new HttpError(404, 'Pagamento não encontrado.');
    if (p.tipo === 'fiado') throw new HttpError(400, 'Vendas em fiado não podem ter a forma de pagamento alterada.');
    if (p.tef_nsu) throw new HttpError(400, 'Pagamento feito via TEF não pode ser alterado aqui (precisa de cancelamento no TEF).');
    const nova = (await c.query('select * from formas_pagamento where codigo=$1 and ativo', [b.forma])).rows[0];
    if (!nova) throw new HttpError(400, 'Forma de pagamento inválida.');
    if (nova.tipo === 'fiado') throw new HttpError(400, 'Não é permitido alterar para Fiado.');
    if (nova.tef_ativo) throw new HttpError(400, 'Não é possível alterar para uma forma com TEF (a cobrança no cartão precisa ser feita no recebimento).');
    if (nova.codigo === p.forma) throw new HttpError(400, 'A forma escolhida é a mesma atual.');
    await c.query('update pagamentos set forma=$1, parcelas=null where id=$2', [nova.codigo, p.id]);
    const cx = (await c.query('select status from caixas where id=$1', [p.caixa_id])).rows[0];
    await auditar(c, req.user, 'caixa_forma_alterada', { pagamento: p.id, caixa: p.caixa_id, pedido: p.pedido_id, de: p.forma, para: nova.codigo, valor: Number(p.valor), motivo, autorizado_por: aut.nome, caixa_status: cx.status });
    res.locals.cx = p.caixa_id;
  });
  // caixa já fechado: atualiza o esperado em dinheiro (o informado permanece)
  const rs = await resumo(res.locals.cx);
  if (rs.caixa.status === 'fechado') {
    const din = rs.linhas.find(l => l.forma === 'dinheiro');
    await db.q('update caixas set valor_esperado=$1, diferenca=$2 where id=$3', [din.calculado, rs.diferenca, rs.caixa.id]);
  }
  res.json({ ok: true });
}));

// ---- Reabrir caixa fechado (pede usuário e senha de quem tem a permissão)
// Marca/desmarca o caixa fechado como conferido
r.post('/:id/conferido', auth('caixa.conferir'), wrap(async (req, res) => {
  const marcar = !!req.body?.conferido;
  const cx = (await db.q('select id, status from caixas where id=$1', [req.params.id])).rows[0];
  if (!cx) throw new HttpError(404, 'Caixa não encontrado.');
  if (cx.status !== 'fechado') throw new HttpError(400, 'Só é possível conferir um caixa fechado.');
  await db.tx(async c => {
    await c.query('update caixas set conferido=$1, conferido_por=$2, conferido_em=$3 where id=$4', [marcar, marcar ? req.user.id : null, marcar ? new Date() : null, cx.id]);
    await auditar(c, req.user, marcar ? 'caixa_conferido' : 'caixa_desconferido', { id: cx.id });
  });
  res.json({ ok: true, conferido: marcar });
}));

r.post('/:id/reabrir', auth('caixa.reabrir'), wrap(async (req, res) => {
  const b = req.body || {}; const motivo = String(b.motivo || '').trim();
  if (!motivo) throw new HttpError(400, 'Informe o motivo da reabertura.');
  await db.tx(async c => {
    const aut = await verificarAutorizacao(c, b.autorizacao, 'caixa.reabrir', req.user);
    const cx = (await c.query('select * from caixas where id=$1 for update', [req.params.id])).rows[0];
    if (!cx) throw new HttpError(404, 'Caixa não encontrado.');
    if (cx.status !== 'fechado') throw new HttpError(400, 'Este caixa não está fechado.');
    if ((await c.query("select 1 from caixas where status='aberto'")).rowCount)
      throw new HttpError(400, 'Já existe um caixa aberto. Só é permitido um caixa aberto por vez: feche-o antes de reabrir este.');
    await c.query('delete from caixa_fechamento where caixa_id=$1', [cx.id]);
    await c.query("update caixas set status='aberto', fechado_em=null, valor_informado=null, valor_esperado=null, diferenca=null, motivo_divergencia=null, total_calculado=null, total_informado=null, conferido=false, conferido_por=null, conferido_em=null where id=$1", [cx.id]);
    await auditar(c, req.user, 'caixa_reaberto', { id: cx.id, motivo, autorizado_por: aut.nome, fechamento_anterior: { informado: cx.valor_informado, esperado: cx.valor_esperado, diferenca: cx.diferenca } });
  });
  res.json(await resumo(req.params.id));
}));

module.exports = r;
