// Servidor do sistema: API + telas web. Os terminais da rede acessam http://IP-DO-SERVIDOR:PORTA
const express = require('express');
const path = require('path');
const os = require('os');
const cfgmod = require('./config');
const db = require('./db');
const { errorHandler, wrap, HttpError } = require('./util');
const { auth } = require('./auth');
const embutido = require('./pgembutido');
const backup = require('./backup');
const VERSAO = require('../package.json').version;
const { gerarBat } = require('./atalho');
const upd = require('./atualizador');

const estado = { pronto: false, erro: null, porta: null };
let server = null;

async function conectar() {
  const cfg = cfgmod.load();
  try { await db.init(cfg.db); await db.migrate(); estado.pronto = true; estado.erro = null; }
  catch (e) { estado.pronto = false; estado.erro = e.message; console.error('Banco indisponível:', e.message); }
  return estado.pronto;
}

function enderecos(porta) {
  const out = [];
  for (const lista of Object.values(os.networkInterfaces()))
    for (const i of lista || []) if (i.family === 'IPv4' && !i.internal) out.push(`http://${i.address}:${porta}`);
  return out;
}

function criarApp() {
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '10mb' }));
  app.use('/api', require('./maiusculas'));

  // Assistente de configuração do banco (só enquanto o banco não está pronto)
  app.get('/setup/estado', (req, res) => { const c = cfgmod.load(); res.json({ pronto: estado.pronto, erro: estado.erro, db: { ...c.db, password: undefined } }); });
  app.post('/setup/salvar', wrap(async (req, res) => {
    if (estado.pronto) throw new HttpError(403, 'O banco já está configurado.');
    const b = req.body || {};
    const cfg = cfgmod.load();
    cfg.db = { host: b.host || 'localhost', port: Number(b.port) || 5432, user: b.appUser || 'gestao', password: b.appPass || 'gestao', database: b.dbName || 'gestao' };
    try {
      if (b.adminUser) await db.ensure({ host: cfg.db.host, port: cfg.db.port, adminUser: b.adminUser, adminPass: b.adminPass || '', dbName: cfg.db.database, appUser: cfg.db.user, appPass: cfg.db.password });
    } catch (e) { throw new HttpError(400, 'Não foi possível criar o banco: ' + e.message); }
    cfgmod.save(cfg);
    if (!(await conectar())) throw new HttpError(400, 'Não foi possível conectar: ' + estado.erro);
    res.json({ ok: true });
  }));

  app.post('/local/encerrar', (req, res) => {
    const ip = req.socket.remoteAddress || '';
    if (!['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(ip)) return res.status(403).json({ erro: 'Somente no computador servidor.' });
    res.json({ ok: true }); setTimeout(encerrar, 300);
  });
  app.get('/api/saude', (req, res) => res.json({ ok: true, banco: estado.pronto, versao: VERSAO }));
  app.get('/api/atualizacao/log', auth('config.gerenciar'), wrap(async (req, res) => { res.json({ arquivo: upd.ARQ_LOG, texto: upd.lerLog(+req.query.linhas || 150) }); }));
  app.get('/api/atualizacao/status', (req, res) => res.json(upd.status(req.query.ov === '1')));
  // lista de empresas ativas (só id e nome), usada pelo instalador de atalhos dos terminais e pela barra superior
  app.get('/api/empresas-terminal', wrap(async (req, res) => { if (!estado.pronto) return res.json({ lista: [] }); res.json({ lista: (await db.q('select id, nome, em_uso from empresas where ativo order by em_uso desc, nome')).rows }); }));
  app.use('/api', (req, res, next) => (estado.pronto ? next() : res.status(503).json({ erro: 'Banco de dados não configurado.', setup: true })));
  app.get('/api/rede', auth('config.gerenciar'), (req, res) => res.json({ enderecos: enderecos(estado.porta || cfgmod.load().porta) }));
  app.use('/api', require('./routes/conta'));
  app.use('/api', require('./routes/cadastros'));
  app.use('/api', require('./routes/formas'));
  app.use('/api/estoque', require('./routes/estoque'));
  app.use('/api/patrimonio', require('./routes/patrimonio'));
  app.use('/api', require('./routes/vendas'));
  app.put('/api/backups/pasta', auth('config.gerenciar'), wrap(async (req, res) => {
    const nova = String(req.body?.pasta || '').trim(); const antiga = backup.pasta(cfgmod);
    if (nova && !path.isAbsolute(nova)) throw new HttpError(400, 'Informe o caminho completo da pasta (ex.: D:\\Backups-LoPDV).');
    backup.definirPasta(nova); let d; try { d = backup.garantir(cfgmod); } catch (e) { backup.definirPasta(await db.q("select valor from config where chave='backup_pasta'").then(r => r.rows[0]?.valor || '')); throw new HttpError(400, 'Não foi possível usar essa pasta: ' + e.message); }
    if (nova && path.resolve(d) !== path.resolve(nova)) { backup.definirPasta(antiga); throw new HttpError(400, 'Não foi possível gravar nessa pasta. Escolha outra.'); }
    const movidos = backup.mover(antiga, backup.pasta(cfgmod));
    await db.q("insert into config(chave,valor) values('backup_pasta',$1) on conflict(chave) do update set valor=excluded.valor", [nova]);
    res.json({ ok: true, pasta: backup.pasta(cfgmod), movidos });
  }));
  app.get('/api/backups', auth('config.gerenciar'), wrap(async (req, res) => { res.json({ pasta: backup.pasta(cfgmod), padrao: backup.padrao(cfgmod), pg_dump: !!backup.achar(), arquivos: backup.listar(cfgmod) }); }));
  app.post('/api/backups', auth('config.gerenciar'), wrap(async (req, res) => {
    const extra = (await db.q("select valor from config where chave='backup_pasta_extra'")).rows[0]?.valor || '';
    try { res.json(await backup.fazer(cfgmod, { tipo: 'manual', extra })); } catch (e) { throw new HttpError(500, 'Backup falhou: ' + e.message); }
  }));
  app.get('/api/versao', auth(), wrap(async (req, res) => {
    res.json({ versao: VERSAO, historico: (await db.q('select versao, aplicado_em from versoes order by id desc limit 20')).rows });
  }));
  app.get('/api/atualizacao', auth(), wrap(async (req, res) => { if (req.query.checar === '1') await upd.verificarSeVelho(db); res.json(await upd.situacao(db)); }));
  app.post('/api/atualizacao/verificar', auth('config.gerenciar'), wrap(async (req, res) => { const r = await upd.verificar(db); res.json({ ...r, ...(await upd.situacao(db)) }); }));
  app.post('/api/atualizacao/aplicar', auth('config.gerenciar'), wrap(async (req, res) => {
    try { res.json(await upd.aplicar(db, estado.porta, encerrar)); } catch (e) { throw new HttpError(400, e.message); }
  }));
  app.get('/api/novidades', auth(), wrap(async (req, res) => {
    const vista = (await db.q('select versao_vista v from usuarios where id=$1', [req.user.id])).rows[0]?.v || '';
    const todas = upd.novidades(); let lista = todas.filter(x => upd.maior(x.versao, vista) && !upd.maior(x.versao, VERSAO));
    if (!vista) lista = lista.slice(0, 1); lista = lista.slice(0, 4);
    res.json({ versao: VERSAO, mostrar: lista.length > 0 && vista !== VERSAO, versoes: lista });
  }));
  app.post('/api/novidades/visto', auth(), wrap(async (req, res) => { await db.q('update usuarios set versao_vista=$1 where id=$2', [VERSAO, req.user.id]); res.json({ ok: true }); }));
  app.post('/api/sistema/encerrar', auth('config.gerenciar'), (req, res) => { res.json({ ok: true }); setTimeout(encerrar, 300); });
  app.use('/api/caixa', require('./routes/caixa'));
  app.use('/api/fiado', require('./routes/fiado'));
  app.use('/api/fiscal', require('./routes/fiscal'));
  app.use('/api/empresa', require('./routes/empresa'));
  app.use('/api/financeiro', require('./routes/financeiro'));
  app.use('/api/relatorios', require('./routes/relatorios'));
  app.use('/api', (req, res) => res.status(404).json({ erro: 'Rota não encontrada.' }));

  app.get('/instalar', (req, res) => res.redirect('/instalar.html'));
  app.get('/instalar-terminal.bat', (req, res) => { res.set('Content-Type', 'application/octet-stream'); res.set('Content-Disposition', 'attachment; filename="Instalar-LoPDV.bat"'); res.send(gerarBat(req.headers.host)); });
  app.use(express.static(path.join(__dirname, '..', 'public')));
  app.use(errorHandler);
  return app;
}

async function start() {
  try { await embutido.iniciar(cfgmod, db); } catch (e) { console.error('PostgreSQL embutido falhou:', e.message); estado.erro = 'PostgreSQL embutido: ' + e.message; }
  const cfg = cfgmod.load();
  await conectar();
  if (estado.pronto) { try { backup.definirPasta((await db.q("select valor from config where chave='backup_pasta'")).rows[0]?.valor || ''); backup.consolidar(cfgmod); } catch (e) { console.error('Pasta de backups:', e.message); } backup.aoAbrir(cfgmod, db); }
  if (estado.pronto) setTimeout(() => { try { const st = upd.status(); require('./limpeza').limparSobras({ raiz: path.join(__dirname, '..'), data: cfgmod.DIR, ocupado: !['ocioso', 'erro'].includes(st.fase), log: upd.logar }); } catch { /* */ } }, 90000).unref();
  if (estado.pronto) { try { upd.agendar(db); } catch (e) { console.error('Agendador de atualização:', e.message); } }
  if (estado.pronto) { try { require('./sefaz').iniciarAgendador(db); } catch (e) { console.error('Agendador fiscal:', e.message); } }
  const app = criarApp();
  await new Promise((resolve, reject) => {
    server = app.listen(cfg.porta, '0.0.0.0', resolve);
    server.on('error', reject);
  });
  estado.porta = cfg.porta;
  console.log(`LoPDV rodando em http://localhost:${cfg.porta}`);
  enderecos(cfg.porta).forEach(e => console.log('  Terminais da rede:', e));
  return { port: cfg.porta, enderecos: enderecos(cfg.porta), estado };
}
let parando = false;
async function stop() {
  if (parando) return; parando = true;
  await new Promise(r => (server ? server.close(() => r()) : r()));
  if (estado.pronto) await backup.aoFechar(cfgmod, db);
  await embutido.parar();
}
// Encerra o processo depois de fazer o backup de fechamento (usado pelo botão "Encerrar" e pelo Parar-LoPDV.bat)
async function encerrar() { await stop(); if (process.versions.electron) require('electron').app.quit(); else process.exit(0); }
if (require.main === module) for (const sig of ['SIGINT', 'SIGTERM', 'SIGHUP', 'SIGBREAK']) process.on(sig, () => { encerrar(); });

module.exports = { start, stop, enderecos, estado };
if (require.main === module) start().catch(e => { console.error(e); process.exit(1); });
