// Livros e documentos da associação: controle (link do Drive, responsável, prazo) + Livro de Registro dos Bens gerado do Patrimônio.
const express = require('express');
const db = require('../db');
const { auth, auditar } = require('../auth');
const { HttpError, wrap } = require('../util');
const lib = require('../livros_lib');
const r = express.Router();

const cfg = async k => ((await db.q('select valor from config where chave=$1', [k])).rows[0] || {}).valor || '';
const ymd = d => (d ? new Date(d).toISOString().slice(0, 10) : null);
function situacao(l) {
  if (!l.link) return { cod: 'sem_link', txt: 'Sem link do Drive' };
  if (l.prazo_dias) {
    if (!l.atualizado_em) return { cod: 'atrasado', txt: 'Nunca atualizado' };
    const venc = new Date(ymd(l.atualizado_em) + 'T00:00:00Z'); venc.setUTCDate(venc.getUTCDate() + Number(l.prazo_dias));
    const hoje = new Date(new Date().toISOString().slice(0, 10) + 'T00:00:00Z');
    if (hoje > venc) return { cod: 'atrasado', txt: 'Atrasado desde ' + venc.toISOString().slice(0, 10).split('-').reverse().join('/') };
  }
  return { cod: 'ok', txt: 'Em dia' };
}

r.get('/', auth('livros.ver'), wrap(async (req, res) => {
  const livros = (await db.q('select * from livros_associacao order by ordem')).rows.map(l => ({ ...l, atualizado_em: ymd(l.atualizado_em), situacao: situacao(l) }));
  let ultimo = null; try { ultimo = JSON.parse(await cfg('livros_ultimo_envio') || 'null'); } catch { /* */ }
  const b = (await db.q(`select (select count(*) from patrimonio)::int bens, (select count(*) from emprestimos)::int emprestimos`)).rows[0];
  res.json({ livros, pasta: await cfg('livros_pasta'), ultimo_envio: ultimo, sistema: b });
}));

r.put('/pasta', auth('livros.gerenciar'), wrap(async (req, res) => {
  const pasta = String((req.body || {}).pasta || '').trim().replace(/^"+|"+$/g, '');
  await db.q("insert into config(chave,valor) values('livros_pasta',$1) on conflict(chave) do update set valor=excluded.valor", [pasta]);
  await auditar(null, req.user, 'livros_pasta', { pasta });
  res.json({ ok: true });
}));

r.put('/:codigo', auth('livros.gerenciar'), wrap(async (req, res) => {
  const b = req.body || {};
  const prazo = b.prazo_dias === '' || b.prazo_dias == null ? null : Number(b.prazo_dias);
  if (prazo !== null && (!Number.isInteger(prazo) || prazo < 1 || prazo > 3650)) throw new HttpError(400, 'O prazo de atualização deve ser um número de dias entre 1 e 3650.');
  const link = String(b.link || '').trim() || null;
  if (link && !/^https?:\/\//i.test(link)) throw new HttpError(400, 'O link do Drive deve começar com https://');
  const x = await db.q(`update livros_associacao set responsavel=$1, link=$2, prazo_dias=$3, atualizado_em=$4::date, observacao=$5 where codigo=$6 returning codigo`,
    [b.responsavel || null, link, prazo, b.atualizado_em || null, b.observacao || null, req.params.codigo]);
  if (!x.rowCount) throw new HttpError(404, 'Livro não encontrado.');
  await auditar(null, req.user, 'livros_editar', { livro: req.params.codigo });
  res.json({ ok: true });
}));

r.post('/bens/sincronizar', auth('livros.gerenciar'), wrap(async (req, res) => {
  const o = await lib.sincronizar(db);
  await auditar(null, req.user, 'livros_sincronizar', { ok: !!o.ok, erro: o.erro || null });
  res.json(o);
}));

const baixar = (tipo) => wrap(async (req, res) => {
  const m = await lib.montar(db);
  if (tipo === 'pdf') { res.setHeader('Content-Type', 'application/pdf'); res.setHeader('Content-Disposition', 'inline; filename="livro-de-registro-de-bens.pdf"'); return res.send(m.pdf); }
  res.setHeader('Content-Type', 'text/csv; charset=utf-8'); res.setHeader('Content-Disposition', `attachment; filename="livro-de-bens-${tipo}.csv"`);
  res.send(tipo === 'bens' ? m.csvBens : m.csvEmp);
});
r.get('/bens.pdf', auth('livros.ver'), baixar('pdf'));
r.get('/bens-bens.csv', auth('livros.ver'), baixar('bens'));
r.get('/bens-emprestimos.csv', auth('livros.ver'), baixar('emprestimos'));

module.exports = r;
