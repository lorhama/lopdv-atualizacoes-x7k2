// Controle de patrimônio: bens não imobilizados (nem revenda nem consumo), comprados ou doados.
const express = require('express');
const db = require('../db');
const { auth, auditar } = require('../auth');
const { HttpError, wrap, num, r2, hoje } = require('../util');
const r = express.Router();
const livros = require('../livros_lib');
// qualquer mudança no patrimônio/empréstimos atualiza o Livro de Registro dos Bens na pasta do Drive (se estiver configurada)
r.use((req, res, next) => { if (req.method !== 'GET') res.on('finish', () => { if (res.statusCode < 400) livros.agendar(db); }); next(); });

const COLS = `p.*, f.nome fornecedor, e.numero nota, u.nome usuario, em.id emprestimo_id, em.pessoa_nome emprestado_para, em.saida_em emprestado_em, em.prevista_em emprestimo_prevista, (em.prevista_em is not null and em.prevista_em < current_date) emprestimo_atrasado`;
const FROM = `from patrimonio p left join fornecedores f on f.id=p.fornecedor_id left join entradas e on e.id=p.entrada_id left join usuarios u on u.id=p.usuario_id
  left join emprestimos em on em.patrimonio_id=p.id and em.devolvido_em is null`;

r.get('/', auth('patrimonio.ver'), wrap(async (req, res) => {
  const q = req.query, w = [], a = [];
  if (q.situacao === 'ativo' || q.situacao === 'baixado') { a.push(q.situacao); w.push(`p.situacao=$${a.length}`); }
  if (q.origem === 'compra' || q.origem === 'doacao') { a.push(q.origem); w.push(`p.origem=$${a.length}`); }
  if (q.q) { a.push('%' + String(q.q).toLowerCase() + '%'); w.push(`(lower(p.descricao||' '||coalesce(p.marca,'')||' '||coalesce(p.modelo,'')||' '||coalesce(p.serie,'')||' '||coalesce(p.local,'')||' '||coalesce(p.responsavel,'')) like $${a.length} or p.numero::text like $${a.length})`); }
  res.json((await db.q(`select ${COLS} ${FROM} ${w.length ? 'where ' + w.join(' and ') : ''} order by p.numero desc limit 1000`, a)).rows);
}));

r.get('/:id(\\d+)', auth('patrimonio.ver'), wrap(async (req, res) => {
  const x = (await db.q(`select ${COLS} ${FROM} where p.id=$1`, [req.params.id])).rows[0];
  if (!x) throw new HttpError(404, 'Bem não encontrado.');
  res.json(x);
}));

const campos = b => ({
  descricao: String(b.descricao || '').trim(), marca: b.marca || null, modelo: b.modelo || null, serie: b.serie || null,
  local: b.local || null, responsavel: b.responsavel || null, observacao: b.observacao || null,
});

// bem cadastrado direto (já existente na casa, sem nota)
r.post('/', auth('patrimonio.gerenciar'), wrap(async (req, res) => {
  const b = req.body || {}, c = campos(b);
  if (!c.descricao) throw new HttpError(400, 'Informe a descrição do bem.');
  const qtd = Math.max(1, Math.floor(num(b.quantidade, 1)));
  if (qtd > 200) throw new HttpError(400, 'Máximo de 200 bens por cadastro.');
  const origem = b.origem === 'doacao' ? 'doacao' : 'compra';
  const nums = [];
  await db.tx(async cx => {
    for (let k = 0; k < qtd; k++) {
      const p = await cx.query(`insert into patrimonio(descricao,marca,modelo,serie,local,responsavel,observacao,origem,valor,data_aquisicao,fornecedor_id,usuario_id)
        values($1,$2,$3,$4,$5,$6,$7,$8,$9,coalesce($10::date,current_date),$11,$12) returning numero`,
        [c.descricao, c.marca, c.modelo, c.serie, c.local, c.responsavel, c.observacao, origem, r2(num(b.valor)), b.data_aquisicao || null, b.fornecedor_id || null, req.user.id]);
      nums.push(p.rows[0].numero);
    }
    await auditar(cx, req.user, 'patrimonio_novo', { numeros: nums, descricao: c.descricao });
  });
  res.json({ numeros: nums });
}));

r.put('/:id(\\d+)', auth('patrimonio.gerenciar'), wrap(async (req, res) => {
  const b = req.body || {}, c = campos(b);
  if (!c.descricao) throw new HttpError(400, 'Informe a descrição do bem.');
  const x = await db.q(`update patrimonio set descricao=$1,marca=$2,modelo=$3,serie=$4,local=$5,responsavel=$6,observacao=$7,valor=$8 where id=$9 returning numero`,
    [c.descricao, c.marca, c.modelo, c.serie, c.local, c.responsavel, c.observacao, r2(num(b.valor)), req.params.id]);
  if (!x.rowCount) throw new HttpError(404, 'Bem não encontrado.');
  await auditar(null, req.user, 'patrimonio_editar', { numero: x.rows[0].numero });
  res.json({ ok: true });
}));

// baixa (venda, perda, descarte, devolução...) — não apaga: fica no histórico
r.post('/:id(\\d+)/baixar', auth('patrimonio.gerenciar'), wrap(async (req, res) => {
  const b = req.body || {}, motivo = String(b.motivo || '').trim();
  if (!motivo) throw new HttpError(400, 'Informe o motivo da baixa.');
  if ((await db.q('select 1 from emprestimos where patrimonio_id=$1 and devolvido_em is null', [req.params.id])).rowCount) throw new HttpError(400, 'Este bem está emprestado. Registre a devolução antes de dar baixa.');
  const x = await db.q(`update patrimonio set situacao='baixado', baixa_em=coalesce($1::date,current_date), baixa_motivo=$2 where id=$3 and situacao='ativo' returning numero`,
    [b.data || null, motivo, req.params.id]);
  if (!x.rowCount) throw new HttpError(400, 'Bem não encontrado ou já baixado.');
  await auditar(null, req.user, 'patrimonio_baixa', { numero: x.rows[0].numero, motivo });
  res.json({ ok: true });
}));

r.post('/:id(\\d+)/reativar', auth('patrimonio.gerenciar'), wrap(async (req, res) => {
  const x = await db.q(`update patrimonio set situacao='ativo', baixa_em=null, baixa_motivo=null where id=$1 and situacao='baixado' returning numero`, [req.params.id]);
  if (!x.rowCount) throw new HttpError(400, 'Bem não encontrado ou não está baixado.');
  await auditar(null, req.user, 'patrimonio_reativar', { numero: x.rows[0].numero });
  res.json({ ok: true });
}));

// ---------------- Empréstimos de bens
const MAI = v => { const t = String(v || '').trim(); return t ? t.toUpperCase() : null; };
const EMP_SQL = `select em.*, p.numero patrimonio_numero, p.descricao patrimonio_descricao, p.marca, p.modelo, p.serie, p.local, p.valor,
    uo.nome saida_por, ud.nome devolucao_por, (em.devolvido_em is null and em.prevista_em is not null and em.prevista_em < current_date) atrasado,
    case when em.devolvido_em is null and em.prevista_em < current_date then current_date - em.prevista_em else 0 end dias_atraso
  from emprestimos em join patrimonio p on p.id=em.patrimonio_id left join usuarios uo on uo.id=em.usuario_id left join usuarios ud on ud.id=em.devolucao_usuario_id`;

r.get('/emprestimos', auth('patrimonio.ver'), wrap(async (req, res) => {
  const q = req.query, w = [], a = [];
  if (q.situacao === 'aberto') w.push('em.devolvido_em is null');
  else if (q.situacao === 'atrasado') w.push('em.devolvido_em is null and em.prevista_em < current_date');
  else if (q.situacao === 'devolvido') w.push('em.devolvido_em is not null');
  if (q.patrimonio_id && /^\d+$/.test(String(q.patrimonio_id))) { a.push(q.patrimonio_id); w.push(`em.patrimonio_id=$${a.length}`); }
  if (q.q) { a.push('%' + String(q.q).toLowerCase() + '%'); w.push(`(lower(em.pessoa_nome||' '||coalesce(em.pessoa_telefone,'')||' '||p.descricao) like $${a.length} or p.numero::text like $${a.length})`); }
  res.json((await db.q(`${EMP_SQL} ${w.length ? 'where ' + w.join(' and ') : ''} order by em.devolvido_em is not null, em.saida_em desc, em.id desc limit 1000`, a)).rows);
}));

r.post('/:id(\\d+)/emprestar', auth('patrimonio.emprestar'), wrap(async (req, res) => {
  const b = req.body || {};
  const id = await db.tx(async cx => {
    const bem = (await cx.query('select id, numero, situacao from patrimonio where id=$1 for update', [req.params.id])).rows[0];
    if (!bem) throw new HttpError(404, 'Bem não encontrado.');
    if (bem.situacao !== 'ativo') throw new HttpError(400, 'Bem baixado não pode ser emprestado.');
    if ((await cx.query('select 1 from emprestimos where patrimonio_id=$1 and devolvido_em is null', [bem.id])).rowCount) throw new HttpError(400, 'Este bem já está emprestado.');
    let nome = MAI(b.pessoa_nome), tel = String(b.pessoa_telefone || '').trim() || null, doc = String(b.pessoa_documento || '').trim() || null, cli = null;
    if (b.cliente_id) {
      const c = (await cx.query('select id, nome, telefone, documento from clientes where id=$1', [b.cliente_id])).rows[0];
      if (!c) throw new HttpError(400, 'Cliente não encontrado.');
      cli = c.id; nome = nome || c.nome; tel = tel || c.telefone || null; doc = doc || c.documento || null;
    }
    if (!nome) throw new HttpError(400, 'Escolha o cliente ou informe o nome de quem vai levar o bem.');
    const saida = b.saida_em || null, prev = b.prevista_em || null;
    if (saida && prev && prev < saida) throw new HttpError(400, 'A data prevista de devolução não pode ser antes da saída.');
    const x = await cx.query(`insert into emprestimos(patrimonio_id,cliente_id,pessoa_nome,pessoa_telefone,pessoa_documento,saida_em,prevista_em,estado_saida,observacao,usuario_id)
      values($1,$2,$3,$4,$5,coalesce($6::date,current_date),$7::date,$8,$9,$10) returning id`, [bem.id, cli, nome, tel, doc, saida, prev, MAI(b.estado_saida), MAI(b.observacao), req.user.id]);
    await auditar(cx, req.user, 'emprestimo_saida', { numero: bem.numero, para: nome });
    return x.rows[0].id;
  });
  res.json({ id });
}));

r.post('/emprestimos/:id(\\d+)/devolver', auth('patrimonio.emprestar'), wrap(async (req, res) => {
  const b = req.body || {};
  const x = await db.q(`update emprestimos set devolvido_em=coalesce($1::date,current_date), estado_devolucao=$2, observacao=coalesce($3, observacao), devolucao_usuario_id=$4
    where id=$5 and devolvido_em is null and coalesce($1::date,current_date) >= saida_em returning patrimonio_id, pessoa_nome, saida_em, devolvido_em`, [b.data || null, MAI(b.estado_devolucao), MAI(b.observacao), req.user.id, req.params.id]);
  if (!x.rowCount) throw new HttpError(400, 'Empréstimo não encontrado, já devolvido, ou a data de devolução é anterior à saída.');
  const n = (await db.q('select numero from patrimonio where id=$1', [x.rows[0].patrimonio_id])).rows[0];
  await auditar(null, req.user, 'emprestimo_devolucao', { numero: n && n.numero, de: x.rows[0].pessoa_nome });
  res.json({ ok: true });
}));

module.exports = r;
