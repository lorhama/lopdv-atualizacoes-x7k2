// Livro de Registro dos Bens: montado a partir do Patrimônio (bens + empréstimos) e gravado numa pasta do Google Drive
// (o "Google Drive para computador" sincroniza a pasta com o Drive). Também gera o PDF/CSV para baixar pela tela.
const fs = require('fs'), path = require('path');
const pdf = require('./pdf_simples');

const z = n => String(n).padStart(2, '0');
const dia = d => { if (!d) return ''; const x = new Date(d); return isNaN(x) ? String(d) : `${z(x.getUTCDate())}/${z(x.getUTCMonth() + 1)}/${x.getUTCFullYear()}`; };
const dh = d => { const x = d ? new Date(d) : new Date(); return `${z(x.getDate())}/${z(x.getMonth() + 1)}/${x.getFullYear()} ${z(x.getHours())}:${z(x.getMinutes())}`; };
const R = v => Number(v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const nPat = n => String(n).padStart(5, '0');
const csvCel = v => { const s = String(v == null ? '' : v); return /[;"\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
const csv = (cab, linhas) => '﻿' + [cab, ...linhas].map(l => l.map(csvCel).join(';')).join('\r\n') + '\r\n';
const ARQ = { pdf: 'Livro de Registro de Bens.pdf', bens: 'Livro de Registro de Bens - Bens.csv', emp: 'Livro de Registro de Bens - Emprestimos.csv' };

async function dados(db) {
  const bens = (await db.q(`select p.*, f.nome fornecedor, e.numero nota from patrimonio p left join fornecedores f on f.id=p.fornecedor_id left join entradas e on e.id=p.entrada_id order by p.numero`)).rows;
  const emp = (await db.q(`select em.*, p.numero patrimonio_numero, p.descricao patrimonio_descricao from emprestimos em join patrimonio p on p.id=em.patrimonio_id order by em.saida_em, em.id`)).rows;
  const empresa = ((await db.q("select valor from config where chave='empresa'")).rows[0] || {}).valor || '';
  return { bens, emp, empresa };
}

function csvs({ bens, emp }) {
  return {
    bens: csv(['Nº patrimônio', 'Descrição', 'Marca', 'Modelo', 'Nº de série', 'Origem', 'Data de aquisição', 'Valor (R$)', 'Nota de entrada', 'Fornecedor', 'Local', 'Responsável', 'Situação', 'Data da baixa', 'Motivo da baixa', 'Observações'],
      bens.map(b => [nPat(b.numero), b.descricao, b.marca, b.modelo, b.serie, b.origem === 'doacao' ? 'DOAÇÃO' : 'COMPRA', dia(b.data_aquisicao), R(b.valor), b.nota, b.fornecedor, b.local, b.responsavel, b.situacao === 'ativo' ? 'ATIVO' : 'BAIXADO', dia(b.baixa_em), b.baixa_motivo, b.observacao])),
    emp: csv(['Nº empréstimo', 'Nº patrimônio', 'Bem', 'Quem levou', 'Telefone', 'Documento', 'Saída', 'Devolução prevista', 'Devolvido em', 'Estado na saída', 'Estado na devolução', 'Observações'],
      emp.map(e => [e.id, nPat(e.patrimonio_numero), e.patrimonio_descricao, e.pessoa_nome, e.pessoa_telefone, e.pessoa_documento, dia(e.saida_em), dia(e.prevista_em), dia(e.devolvido_em), e.estado_saida, e.estado_devolucao, e.observacao])),
  };
}

function livroPdf({ bens, emp, empresa }) {
  const d = pdf.criar({ largura: 841.89, altura: 595.28, margem: 32 }), M = d.margem, RR = d.largura - M, H = d.altura;
  let y = M;
  const cab = tit => {
    d.texto(M, y + 4, 'LIVRO DE REGISTRO DOS BENS', { size: 15, bold: true });
    d.texto(RR, y + 4, 'Emitido em ' + dh(), { size: 9, align: 'right' }); y += 20;
    if (empresa) { d.texto(M, y, empresa, { size: 10, max: RR - M }); y += 13; }
    d.texto(M, y, tit, { size: 11, bold: true }); y += 6; d.linha(M, y, RR, y, { cinza: 0.3, w: 1 }); y += 12;
  };
  const tabela = (tit, cols, linhas, vazio) => {
    cab(tit);
    const cabecalho = () => { d.caixa(M, y - 9, RR - M, 14, 0.9); let x = M + 2; cols.forEach(c => { d.texto(c.al === 'r' ? x + c.w - 6 : x, y, c.t, { size: 8, bold: true, align: c.al === 'r' ? 'right' : 'left', max: c.w - 4 }); x += c.w; }); y += 14; };
    cabecalho();
    if (!linhas.length) d.texto(M + 2, y, vazio, { size: 9 });
    linhas.forEach(l => {
      if (y > H - 46) { d.nova(); y = M; cab(tit + ' (continuação)'); cabecalho(); }
      let x = M + 2; cols.forEach((c, i) => { d.texto(c.al === 'r' ? x + c.w - 6 : x, y, l[i], { size: 8, align: c.al === 'r' ? 'right' : 'left', max: c.w - 4 }); x += c.w; });
      y += 12; d.linha(M, y - 8, RR, y - 8, { cinza: 0.85, w: 0.3 });
    });
  };
  const W = RR - M;
  const ativos = bens.filter(b => b.situacao === 'ativo');
  tabela(`1. BENS (${bens.length} registrados, ${ativos.length} ativos, valor dos ativos R$ ${R(ativos.reduce((s, b) => s + Number(b.valor), 0))})`,
    [{ t: 'Nº', w: 36 }, { t: 'Descrição', w: 190 }, { t: 'Marca / modelo / série', w: 140 }, { t: 'Origem', w: 46 }, { t: 'Aquisição', w: 56 }, { t: 'Valor (R$)', w: 58, al: 'r' }, { t: 'Local / responsável', w: 120 }, { t: 'Situação', w: W - 646 }],
    bens.map(b => [nPat(b.numero), b.descricao, [b.marca, b.modelo, b.serie ? 's/n ' + b.serie : ''].filter(Boolean).join(' · '), b.origem === 'doacao' ? 'DOAÇÃO' : 'COMPRA', dia(b.data_aquisicao), R(b.valor), [b.local, b.responsavel].filter(Boolean).join(' · '), b.situacao === 'ativo' ? 'ATIVO' : 'BAIXADO ' + dia(b.baixa_em) + (b.baixa_motivo ? ' - ' + b.baixa_motivo : '')]),
    'Nenhum bem registrado.');
  d.nova(); y = M;
  tabela(`2. EMPRÉSTIMOS DE BENS (${emp.length} registrados, ${emp.filter(e => !e.devolvido_em).length} em aberto)`,
    [{ t: 'Nº', w: 30 }, { t: 'Bem', w: 170 }, { t: 'Quem levou', w: 130 }, { t: 'Documento / telefone', w: 100 }, { t: 'Saída', w: 52 }, { t: 'Prevista', w: 52 }, { t: 'Devolvido', w: 52 }, { t: 'Estado saída / devolução', w: W - 586 }],
    emp.map(e => [String(e.id), nPat(e.patrimonio_numero) + ' ' + e.patrimonio_descricao, e.pessoa_nome, [e.pessoa_documento, e.pessoa_telefone].filter(Boolean).join(' · '), dia(e.saida_em), dia(e.prevista_em), e.devolvido_em ? dia(e.devolvido_em) : 'EM ABERTO', [e.estado_saida, e.estado_devolucao].filter(Boolean).join(' → ')]),
    'Nenhum empréstimo registrado.');
  return d.build('LIVRO DE REGISTRO DOS BENS' + (empresa ? ' - ' + empresa : ''), true);
}

async function montar(db) { const dd = await dados(db); return { dd, pdf: livroPdf(dd), ...(() => { const c = csvs(dd); return { csvBens: c.bens, csvEmp: c.emp }; })() }; }

const gravar = (pasta, nome, conteudo) => { const alvo = path.join(pasta, nome), tmp = alvo + '.tmp'; const buf = Buffer.isBuffer(conteudo) ? conteudo : Buffer.from(conteudo, 'utf8'); fs.writeFileSync(tmp, buf); fs.renameSync(tmp, alvo); const st = fs.statSync(alvo); if (st.size !== buf.length) throw new Error(`Conferência falhou em "${nome}" (gravou ${st.size} de ${buf.length} bytes).`); return { nome, bytes: st.size }; };

// grava na pasta do Drive e confere; guarda o resultado em config('livros_ultimo_envio')
async function sincronizar(db) {
  const pasta = ((await db.q("select valor from config where chave='livros_pasta'")).rows[0] || {}).valor || '';
  const salvar = async r => { await db.q("insert into config(chave,valor) values('livros_ultimo_envio',$1) on conflict(chave) do update set valor=excluded.valor", [JSON.stringify(r)]); return r; };
  if (!pasta) return salvar({ em: new Date().toISOString(), erro: 'Nenhuma pasta do Drive escolhida.' });
  try {
    if (!fs.existsSync(pasta) || !fs.statSync(pasta).isDirectory()) throw new Error('A pasta não foi encontrada neste computador: ' + pasta + '. Confira se o Google Drive para computador está aberto e o caminho está certo.');
    const m = await montar(db);
    const arquivos = [gravar(pasta, ARQ.pdf, m.pdf), gravar(pasta, ARQ.bens, m.csvBens), gravar(pasta, ARQ.emp, m.csvEmp)];
    await db.q("update livros_associacao set atualizado_em=current_date where codigo='bens'");
    return salvar({ em: new Date().toISOString(), ok: true, pasta, bens: m.dd.bens.length, emprestimos: m.dd.emp.length, arquivos });
  } catch (e) { return salvar({ em: new Date().toISOString(), pasta, erro: e.message }); }
}

let timer = null;
// chamado depois de qualquer mudança no Patrimônio/empréstimos: espera alguns segundos (juntando várias mudanças) e atualiza o Drive
function agendar(db) { if (timer) clearTimeout(timer); timer = setTimeout(() => { timer = null; sincronizar(db).catch(() => { }); }, 5000); if (timer.unref) timer.unref(); }

module.exports = { montar, sincronizar, agendar, ARQ };
