// ---- Livros e documentos da associação: controle dos cinco livros + Livro de Registro dos Bens enviado à pasta do Drive
registrar({ id: 'livros', titulo: 'Livros da associação', grupo: 'Associação', perm: 'livros.ver', render: async el => {
  const gerir = tem('livros.gerenciar');
  let d = null;
  const baixar = async (rota, nome, abrir) => { // precisa do login: busca o arquivo e abre/baixa
    const w = abrir ? window.open('', '_blank') : null;
    try {
      const r = await fetch('/api/livros/' + rota, { headers: S.token ? { Authorization: 'Bearer ' + S.token } : {} });
      if (!r.ok) { let j = {}; try { j = await r.json(); } catch { /* */ } throw new Error(j.erro || 'Erro ' + r.status); }
      const url = URL.createObjectURL(await r.blob());
      if (abrir) { if (w) w.location = url; else window.open(url, '_blank'); } else { const a = document.createElement('a'); a.href = url; a.download = nome; document.body.appendChild(a); a.click(); a.remove(); }
    } catch (e) { if (w) w.close(); throw e; }
  };
  const corSit = c => (c === 'ok' ? 'ok' : c === 'atrasado' ? 'err' : 'warn');
  const envioHtml = () => {
    const u = d.ultimo_envio, s = d.sistema;
    if (!d.pasta) return '<p class="muted">Nenhuma pasta escolhida ainda. Informe abaixo a pasta do Google Drive neste computador para o Livro de Registro dos Bens ser atualizado sozinho.</p>';
    if (!u) return '<p class="muted">Ainda não foi enviado. Clique em "Atualizar agora".</p>';
    if (u.erro) return `<p class="erro"><b>Não foi possível atualizar o Drive</b> (${dt(u.em)}): ${esc(u.erro)}</p>`;
    const igual = u.bens === s.bens && u.emprestimos === s.emprestimos;
    return `<p>${chip('Conferido', 'ok')} Atualizado em <b>${dt(u.em)}</b>: ${u.bens} bem(ns) e ${u.emprestimos} empréstimo(s). Arquivos gravados e conferidos: ${u.arquivos.map(a => esc(a.nome)).join('; ')}.</p>` +
      (igual ? '' : `<p class="erro">Atenção: o sistema tem hoje ${s.bens} bem(ns) e ${s.emprestimos} empréstimo(s), e o último envio tinha ${u.bens} e ${u.emprestimos}. A atualização é automática poucos segundos depois de cada mudança; se continuar assim, clique em "Atualizar agora".</p>`);
  };
  const desenhar = () => {
    $('#res', el).innerHTML = `<div class="card"><h3>Livro de Registro dos Bens (automático, a partir do Patrimônio)</h3>${envioHtml()}
      <div class="row" style="align-items:flex-end">${gerir ? `<label style="flex:3">Pasta do Google Drive neste computador (ex.: G:\\Meu Drive\\Associação\\Livros)<input id="pasta" value="${esc(d.pasta)}" placeholder="Cole aqui o caminho da pasta"></label><button class="btn auto" id="psalvar">Salvar pasta</button><button class="btn primary auto" id="sinc">Atualizar agora</button>` : ''}
        <button class="btn auto" id="ver">Ver PDF</button><button class="btn auto" id="cb">Planilha de bens (CSV)</button><button class="btn auto" id="ce">Planilha de empréstimos (CSV)</button></div>
      <p class="muted" style="margin:8px 0 0">Funciona com o "Google Drive para computador" aberto: o sistema grava o livro (PDF e planilhas) na pasta e o Drive envia para a nuvem. Cada bem, baixa, empréstimo e devolução registrados no Patrimônio atualiza o livro.</p></div>
      <h3 style="margin:14px 0 6px">Controle dos livros e documentos</h3>` +
      tabela([{ l: 'Livro', f: x => `<b>${esc(x.nome)}</b><br><small class="muted">${esc(x.base_legal || '')}${x.descricao ? ' · ' + esc(x.descricao) : ''}</small>` }, { l: 'Responsável', f: x => esc(x.responsavel || '—') },
        { l: 'Drive', f: x => (x.link ? `<a href="${esc(x.link)}" target="_blank" rel="noopener">Abrir no Drive</a>` : '<span class="muted">sem link</span>') },
        { l: 'Atualização', f: x => (x.automatico ? '<small class="muted">automática</small><br>' : '') + (x.atualizado_em ? dia(x.atualizado_em) : '<span class="muted">nunca</span>') + (x.prazo_dias ? `<br><small class="muted">a cada ${x.prazo_dias} dia(s)</small>` : '') },
        { l: 'Situação', f: x => chip(x.situacao.txt, corSit(x.situacao.cod)) }, { l: 'Observações', f: x => esc(x.observacao || '') }],
      d.livros, { acoes: x => (gerir ? `<button class="btn sm" data-ed="${x.codigo}">Editar</button>` : '') });
  };
  const carregar = seguro(async () => { d = await api('/livros'); desenhar(); });
  el.innerHTML = '<div id="res"></div>';
  el.onclick = seguro(async e => {
    const t = e.target, id = t.id;
    if (id === 'ver') return baixar('bens.pdf', '', true);
    if (id === 'cb') return baixar('bens-bens.csv', 'livro-de-bens-bens.csv');
    if (id === 'ce') return baixar('bens-emprestimos.csv', 'livro-de-bens-emprestimos.csv');
    if (id === 'psalvar') { await api('/livros/pasta', { method: 'PUT', body: { pasta: $('#pasta', el).value } }); toast('Pasta salva.'); return carregar(); }
    if (id === 'sinc') { if ($('#pasta', el).value.trim() !== d.pasta) await api('/livros/pasta', { method: 'PUT', body: { pasta: $('#pasta', el).value } });
      const r = await api('/livros/bens/sincronizar', { method: 'POST', body: {} }); if (r.erro) toast(r.erro, 'erro'); else toast('Livro de Registro dos Bens atualizado no Drive.'); return carregar(); }
    if (t.dataset.ed) { const l = d.livros.find(x => x.codigo === t.dataset.ed);
      return formModal({ titulo: l.nome, tam: 'md', valores: { ...l, atualizado_em: l.atualizado_em || '' },
        campos: [{ k: 'responsavel', l: 'Responsável pelo livro', full: true }, { k: 'link', l: 'Link da pasta ou do arquivo no Google Drive (https://...)', full: true },
          { k: 'prazo_dias', l: 'Atualizar a cada quantos dias? (vazio = sem prazo)', t: 'number', step: '1' }, { k: 'atualizado_em', l: 'Última atualização', t: 'date' }, { k: 'observacao', l: 'Observações', full: true }],
        onSave: async o => { await api('/livros/' + l.codigo, { method: 'PUT', body: o }); toast('Salvo.'); carregar(); } }); }
  });
  await carregar();
} });
