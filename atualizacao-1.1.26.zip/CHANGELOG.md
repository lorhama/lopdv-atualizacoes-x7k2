# Histórico de versões — LoPDV

Formato: [versão semântica](https://semver.org/lang/pt-BR/) `MAIOR.MENOR.CORREÇÃO`.
Para lançar uma nova versão: `python3 scripts/nova-versao.py 1.0.1 "o que mudou"`.

## 1.1.26 — 15/11/2026
- Correção: Segurança: todo cancelamento (item, venda aberta, venda finalizada) agora exige motivo e usuário/senha de quem tem permissão de cancelar; fica registrado quem cancelou e quem autorizou.
- Correção: Cancelamento de venda finalizada: conferido que o estoque volta e o financeiro (caixa e fiado) é estornado; também corrigido para respeitar devoluções parciais já feitas.
- Correção: Entrada manual por foto: agora reconhece imagem/planilha simples com as colunas PRODUTO, QUANTIDADE e VALOR UNITÁRIO (antes só reconhecia nota fiscal/cupom). O que não aparecer na linha (quantidade ou valor) entra zerado para você preencher, em vez de a linha ser descartada.
- Melhoria: Balanço: ao iniciar, o sistema guarda automaticamente a foto do estoque de todos os produtos e faz um backup do banco. Se algo der errado, o botão "Desfazer" no histórico restaura o estoque que havia antes do balanço (vendas e entradas feitas depois são mantidas), com motivo e registro na auditoria. Também dá para baixar o "Estoque antes (CSV)".
- Melhoria: Cancelamento de venda já finalizada: botão "Cancelar venda" ao abrir a venda em Fechadas (exige motivo e usuário/senha de quem tem permissão de cancelar). Devolve o estoque, estorna os pagamentos no caixa, cancela o fiado e remove a doação. Só com o caixa da venda aberto; fiado já recebido e pagamento TEF exigem providência antes.
- Melhoria: Relatórios > aba "Vendas": lista as vendas finalizadas e as canceladas (quem cancelou, quem autorizou, quando e o motivo), com filtro Todas / Só finalizadas / Só canceladas, totais e CSV.
- Melhoria: Manutenção > Importar estoque: nova opção "Produtos que NÃO estão no arquivo": manter o estoque como está ou zerar (com aviso de quantos serão zerados e registro no histórico/auditoria).
- Melhoria: Devolução parcial: na venda finalizada, botão "Devolução" para devolver só alguns produtos (quantidade por produto). O estoque volta, o valor sai do caixa na forma escolhida (ou reduz o fiado) e a venda fica com itens/total reduzidos. Exige motivo e usuário/senha; aparece no relatório de vendas como "Devolvido".

## 1.1.25 — 15/11/2026
- Melhoria: Conferência (balanço): o campo de leitura agora também deixa procurar pelo nome dos produtos cadastrados (lista de sugestões que filtra enquanto você digita); ao escolher, já abre a contagem do produto.
- Melhoria: Finalizar a conferência: a opção "Zerar os não conferidos" vem marcada por padrão (os conferidos recebem a contagem e o restante fica com estoque 0); ainda dá para escolher "Manter o estoque que estava" e há confirmação antes de gravar.

## 1.1.24 — 15/11/2026
- Correção: Autorizações com usuário e senha (reabrir caixa, estoque negativo, descontos, cancelamentos etc.) agora aceitam o número do usuário, o mesmo usado para entrar no sistema; antes só aceitavam o login e davam "usuário ou senha inválidos".
- Correção: Corrigido erro no servidor ao abrir o fechamento de caixa com produção pendente ("cli.query is not a function" no registro de erros).
- Melhoria: Impressoras: cada impressora tem a largura da bobina (80 mm — cupom fiscal padrão, ou 58 mm — bobina de máquina de cartão, com 32 colunas). Pedidos da cozinha/bar, conta, fechamento de caixa e comprovantes saem na largura de cada impressora (textos mais largos são ajustados ao papel de 58 mm). Nova opção "Economizar papel" (ligada por padrão): corte sem linhas em branco sobrando e pedido de cozinha/bar compacto (cabeçalho numa linha só, sem título grande). O botão Testar imprime uma régua de colunas para conferir a largura.
- Melhoria: Configurações → Acesso dos terminais: agora destaca o endereço certo para as outras máquinas (placa Wi-Fi/cabo, ex.: 192.168.x.x) e marca como "não serve" os endereços de VPN (Radmin, Hamachi) e adaptadores virtuais (WSL, Hyper-V). O registro do servidor também indica qual usar.

## 1.1.23 — 15/11/2026
- Correção: Corrigido: depois de salvar, editar, excluir ou inativar em Usuários (Equipe), Perfis, Configurações e telas fiscais, a lista não atualizava (efeito das abas) e o cadastro parecia não ter sido salvo; agora a tela recarrega na hora.

## 1.1.22 — 15/11/2026
- Correção: Abas internas: corrigido o ✕ de fechar aba, que deixava a tela em branco e não fechava; agora fecha a aba e mostra a aba vizinha (ou o Painel, se for a última).
- Melhoria: Item genérico no caixa, escolha no bar: no cadastro do produto (ex.: "Refrigerante", "Água") há o campo "Bebidas que este item pode ser" (Coca lata, Coca Zero, Soda, Sukita, Guaraná...). O caixa vende só o item genérico com um preço; na tela Cozinha / Bar, ao marcar "Retirado", o bar informa quantas de cada bebida saíram (a soma precisa fechar com o que o caixa vendeu) e só essas bebidas baixam do estoque. O custo da venda usa o custo das bebidas escolhidas; a tela mostra o que foi entregue em "Já retirados hoje".

## 1.1.21 — 15/11/2026
- Melhoria: Visual: abas internas com mais destaque (aba ativa na cor do sistema, abas inativas em tom mais forte); e a lista de produtos nos campos de busca (entrada, ajuste de estoque, produção, relatórios etc.) deixou de ser o balão escuro do navegador: agora é uma lista clara, com cada produto separado, que filtra enquanto você digita e aceita setas + Enter. O leitor de código de barras continua funcionando como antes.

## 1.1.20 — 15/11/2026
- Melhoria: Abas internas: clique com o botão direito num item do menu abre "Abrir" / "Abrir em nova aba" (também Ctrl+clique e botão do meio); a mesma tela pode ficar aberta em mais de uma aba, tudo dentro do próprio sistema, sem abrir outra janela do navegador (que pedia usuário e senha).

## 1.1.19 — 15/11/2026
- Melhoria: Sistema multi abas: cada tela (Vendas, Acerto de estoque, Entrada de mercadoria...) abre numa aba própria, com o que você estava fazendo preservado ao trocar de aba (uma venda em andamento continua aberta). Fechar aba com ✕; até 10 abas.

## 1.1.18 — 14/11/2026
- Melhoria: Manutenção, importações de preços e de estoque: o sistema confere se cada código existe e gera um arquivo de contrapartida (CSV) com o que foi importado, o que NÃO foi importado (e o motivo) e os produtos cadastrados que não vieram no arquivo; baixa a conferência antes de gravar e o relatório final ao importar. Dois modelos: com todos os produtos cadastrados (valores atuais) e em branco. Na importação de estoque, produto sem código de barras pode ser identificado pelo código reduzido.

## 1.1.17 — 14/11/2026
- Melhoria: Confirmar cadastro e Amarrar saíram da tela de Produtos e ficam só na Entrada de mercadoria, na nova aba "Cadastros pendentes". O produto criado pela entrada já nasce com os dados da nota (origem com série/nº da nota e fornecedor, código do produto no fornecedor, código de barras do XML, custo e estoque). Na tela de Produtos você ainda pode editar os dados cadastrais.
- Melhoria: Novo módulo Manutenção (menu próprio, permissão "Módulo Manutenção"): alteração em massa de produtos (categoria, destino, preço por valor ou %, estoque mínimo, vendável, situação) e de fornecedores; importação de tabela de preços (CSV com código reduzido e preço) e importação de estoque (CSV com código de barras e quantidade, lançada como ajuste de estoque). As duas importações têm arquivo modelo para baixar e mostram uma prévia antes de gravar.

## 1.1.16 — 14/11/2026
- Correção: Tela de entrada: Enter no campo do número do usuário agora pula para o campo Senha; só o Enter na senha (ou o botão Entrar) faz o login.
- Melhoria: Menu lateral: ao abrir um grupo (ou clicar em uma tela), os outros grupos recolhem; fica aberto só o grupo em uso.
- Melhoria: Entrada por foto/PDF: se o CNPJ do fornecedor está na nota e não está cadastrado, o fornecedor é cadastrado automaticamente (você confere o nome); se a nota não traz o CNPJ do fornecedor, o sistema exige escolher um fornecedor cadastrado. O CNPJ da própria empresa nunca é tomado como fornecedor.
- Melhoria: Toda entrada (manual, XML, foto/PDF e acerto de consignação) agora registra a série e o número da nota; aparecem na entrada, no relatório de entradas (coluna e CSV), na consignação e na movimentação de estoque.

## 1.1.15 — 14/11/2026
- Correção: Entrada por foto/PDF: linhas com quantidade ou total ilegíveis (caneta, rasura) não são mais descartadas — aparecem com a quantidade em branco para você digitar. Também confere o total e a quantidade do rodapé da nota com o que foi lido e avisa quanto falta, tem o botão "＋ Incluir item não lido" e a foto é ampliada e tem a caneta azul atenuada antes da leitura.
- Melhoria: Tela de entrada: o campo Usuário não lista mais os usuários cadastrados; informe apenas o número do usuário. A lista pública de usuários foi removida do servidor (segurança).

## 1.1.14 — 14/11/2026
- Correção: Recuperar senha agora informa para qual e-mail (parcialmente oculto) o código foi enviado e explica claramente quando o usuário não existe, não tem e-mail cadastrado ou pediu código demais.
- Melhoria: Removido o botão "Buscar por chave no site da SEFAZ" da Entrada de mercadoria (Automática). Fica só "Buscar por chave (serviço pago)".

## 1.1.13 — 02/11/2026
- Melhoria: Cupom fiscal item a item: o sistema junta numa linha só os itens repetidos (mesmo código do fornecedor/da nota ou mesmo código de barras), somando a quantidade e o total (ex.: 4 linhas de 1 un viram 1 item de 4 un). Vale para XML e para foto/PDF. Na foto/PDF também lê o número do item, o código e o desconto de cada item (o desconto é abatido do custo) e há o botão "Unificar linhas marcadas" para juntar à mão o que ficou separado.
- Melhoria: Alterar o nome do produto direto nas entradas: no XML, o nome do produto novo pode ser corrigido antes de cadastrar; em produto já cadastrado há o botão "✏ alterar nome" (entrada manual, XML e foto/PDF), que muda o nome no cadastro do produto.
- Melhoria: Entrada por foto/PDF: o "Nº da nota / documento" da entrada manual vem preenchido da nota (lido da chave de acesso, ou do texto da nota; pode corrigir antes de passar). Se o CNPJ do emitente estiver nos Fornecedores, o fornecedor também é escolhido sozinho.
- Melhoria: Entrada de mercadoria (Automática): ao lado de "Buscar por chave (serviço pago)" há o botão "Buscar por chave no site da SEFAZ" (grátis). Você cola a chave, o sistema identifica estado e tipo (NF-e/NFC-e), abre o site de consulta certo e deixa a chave copiada; o código de segurança (captcha) é digitado por você. Depois, escolha o XML baixado (importa direto) ou salve a página como PDF e use a aba Foto/PDF da nota.

## 1.1.12 — 02/11/2026
- Correção: O relatório "Entradas de mercadoria" aparecia no menu "Outros"; agora fica em Relatórios. Qualquer tela nova de um grupo entra no menu do grupo certo, em vez de cair em "Outros".
- Melhoria: Patrimônio: o número do bem já era gerado automaticamente (sequencial); agora isso fica visível. O "+ Novo bem" mostra o campo "Nº do patrimônio (automático)" e os avisos (cadastro e entrada de mercadoria) mostram o número no mesmo formato da etiqueta (00001, 00002...).
- Melhoria: Entrada por foto agora também lê PDF da nota (DANFE salvo ou recebido por e-mail), sem internet, e ganhou uma aba própria "📷 Foto / PDF da nota" na Entrada de mercadoria (além do botão na entrada manual). PDF com texto é lido com mais precisão que foto; PDF escaneado (imagem) pede foto. Se a chave da nota já estiver nas Notas da SEFAZ com XML completo, o sistema avisa e oferece importar pelo XML. Atualização instala o leitor de PDF (npm install).
- Melhoria: Entrada por foto/PDF: cada item lido agora tem a escolha "Cadastrar como novo" (cadastro automático pendente, sem código sequencial) ou "🔗 Amarrar ao cadastro" (liga a um produto que já existe). Itens sem produto deixam de ser ignorados; o nome do novo produto pode ser corrigido na própria linha.

## 1.1.11 — 02/11/2026
- Correção: O aviso de nova versão aparecia duas vezes (faixa no topo e botão na barra). Agora aparece só o botão da barra superior, que abre as novidades e permite atualizar.
- Melhoria: O LoPDV não abre mais duas vezes no mesmo computador: se já houver uma janela aberta, o atalho avisa "O LoPDV já está aberto neste computador" e não abre outra. Uma segunda cópia do servidor também não inicia.
- Melhoria: Ao finalizar a venda, abre uma janela com tudo que foi feito: pagamento por forma (com NSU/autorização do cartão), troco a entregar, desconto/arredondamento, fiado lançado, pedido enviado e impresso na cozinha/bar, baixa de estoque, doação do troco e comprovante do cartão.
- Melhoria: Venda fiado imprime uma via com os débitos em aberto do cliente: valor de cada venda (a de hoje marcada), vencimentos e o total em aberto, com linha de assinatura. O resultado aparece na janela de finalização.
- Melhoria: Ao receber um fiado, imprime o comprovante de pagamento para o cliente (venda de origem, forma, valor pago, saldo restante ou quitada e total que o cliente ainda deve). Janela mostra o resultado, com botão Reimprimir.
- Melhoria: Botão "Receber fiado" na tela de vendas: abre a consulta de fiado por cliente (lista de clientes com débito, vendas em aberto com vencimento e vencidas em destaque, opção de ver quitadas), botão Itens para ver os itens de cada venda e botão Receber para dar baixa ali mesmo.
- Melhoria: Ajuste de estoque agora tem motivos cadastrados: escolha na lista (mais observação opcional) e cadastre, renomeie, inative ou exclua motivos pelo botão da própria tela. Já vêm cadastrados: ACERTO ESTOQUE, DEVOLUCAO P/FORNEC., DOACAO, PRODUTO VENCIDO, QUEBRAS, ROUBO e USO INTERNO.
- Melhoria: Nova tela Balanço geral (menu Estoque): conferência de todo o estoque com leitor de código de barras, sem acúmulo (informa o total e salva no F2) ou com acúmulo (cada leitura soma). Só um balanço em andamento por vez; lista dos balanços com a situação; ao finalizar pergunta se zera os não conferidos (com confirmação), abate do estoque o que foi vendido depois de cada contagem (caixa aberto), bloqueia entrada de mercadoria enquanto houver balanço aberto e gera relatório PDF dos conferidos e não conferidos (baixar ou imprimir).
- Melhoria: O menu lateral recolhe sozinho ao clicar em qualquer lugar fora dele (no celular, fecha). O recolhimento acontece depois do clique, para o botão clicado não sair do lugar e o clique não se perder.
- Melhoria: A importação de XML só aceita nota emitida para o CNPJ da empresa em uso (o destinatário da nota precisa ser a empresa). Nota de outro CNPJ é recusada com aviso claro.
- Melhoria: No cadastro da empresa, CNPJ/CPF, telefone e CEP ganham máscara automática enquanto digita, e os documentos são validados (dígitos verificadores) antes de salvar.
- Melhoria: Entrada manual: botão "Entrada por foto da nota". Lê a foto da nota aqui no computador, sem internet (OCR offline), mostra os itens para conferência (produto, quantidade, valor, com alerta de "conferir") e passa os marcados para a entrada. A leitura de foto pode errar: sempre conferir.
- Melhoria: Novo relatório "Entradas de mercadoria" (menu Relatórios): filtros por período, tipo (Entrada XML, Entrada consignado, manual, doação) e fornecedor; totais por tipo, opção de mostrar os itens, CSV e impressão.
- Melhoria: Todas as tabelas do sistema agora ordenam ao clicar no título da coluna (crescente/decrescente, como no Excel; reconhece números, valores em R$ e datas) e têm caixa de filtro para achar linhas por qualquer texto. A coluna de data passou a mostrar o ano.
- Melhoria: Itens da nota (XML) sem cadastro agora geram cadastro automático SUSPENSO: código provisório (AUTO-n) que não gasta o sequencial, produto não vendável, marcado como "Pendente" em Produtos até alguém confirmar (aí recebe o código sequencial) ou amarrar. Botão "Amarrar ao cadastro" na importação do XML (e em Produtos, para pendentes já lançados): liga a entrada a um produto existente, aprende o código de barras novo/código do fornecedor e descarta o cadastro automático (estoque e histórico vão para o produto existente).
- Melhoria: O cabeçalho superior (título da tela, empresa, usuário, Minha senha e Sair) fica fixo no topo: continua visível por mais que a página seja rolada para baixo.
- Melhoria: Modo noturno: chave "🌙 Noturno" na barra superior deixa o sistema escuro (tela, tabelas, janelas, avisos). A escolha fica guardada no computador e vale já na próxima abertura. Na impressão continua claro.

## 1.1.10 — 02/11/2026
- Correção: Atualização: o plano B de início do atualizador usa um método que sobrevive ao fechamento do sistema.
- Melhoria: Backups em pasta própria (padrão C:\LoPDV-Backups), que o cliente pode trocar em Configurações.
- Melhoria: Limpeza automática de sobras no computador do cliente (pacotes antigos, cópias de segurança antigas, notas e arquivos de desenvolvimento).
- Melhoria: Botões da base da tela de Vendas com tamanho padrão e nomes abreviados.

## 1.1.9 — 02/11/2026
- Correção: Atualização pela tela travava: o atualizador agora inicia de forma independente do sistema, o sistema só fecha depois que ele confirma, e qualquer erro aparece na tela e no log.
- Melhoria: A atualização mostra cada etapa do que está acontecendo e grava log com resultado (concluída ou falha); botão Ver log da atualização em Configurações.

## 1.1.8 — 02/11/2026
- Correção: Aviso de e-mail com Gmail: explica a senha de app e permite cadastrar usuário e senha.
- Melhoria: Cadastros em LETRAS MAIÚSCULAS (digitação e gravação); cadastros existentes são convertidos uma vez.
- Melhoria: Várias empresas (CNPJs): tela Empresas lista, cadastra, edita, inativa e exclui; uma fica em uso.
- Melhoria: Instalador de atalhos dos terminais pergunta qual empresa o terminal usa; a venda guarda a empresa.
- Melhoria: Mensagens de aviso aparecem no topo da tela.
- Melhoria: E-mail: seletor de provedor (Gmail, Outlook, Yahoo) com passo a passo da senha de app.

## 1.1.7 — 02/11/2026
- Correção: Sair da tela de Vendas com venda em andamento não congela mais: ao confirmar, a venda fica pendente e a tela escolhida abre.
- Correção: Ficha técnica do produto: o campo Unidade agora lista as unidades.
- Correção: Autorização por usuário e senha nunca vem preenchida.
- Melhoria: Aviso de nova versão na barra superior.
- Melhoria: Fechamento do caixa: uma linha por forma de pagamento no comprovante.
- Melhoria: Vendas e entrada de mercadoria exigem empresa cadastrada.
- Melhoria: Ao abrir o caixa, o sistema vai direto para Vendas.
- Melhoria: Lançar produção e Produtos do caixa exigem usuário e senha, com permissões próprias em Equipe → Perfis.
- Melhoria: Atualização automática mais rápida.

## 1.1.6 — 02/11/2026
- Melhoria: Número do usuário sem zeros à esquerda (tela de login, lista de usuários e vendedor na venda); digitar 1 ou 000001 continua funcionando

## 1.1.5 — 02/11/2026
- Correção: Aviso de nova versão: o sistema confere ao abrir e de hora em hora, e avisa os administradores quando a atualização automática não está configurada ou falha
- Correção: Painel de caixa: a tabela não fica mais cortada à direita
- Correção: Tela de vendas: a lista de itens não corta mais as colunas Total e Situação; produtos e barra inferior mais compactos
- Melhoria: Controle de patrimônio: bens não imobilizados recebem número de patrimônio; nova tela Patrimônio com busca, novo bem, edição, baixa, etiqueta e CSV
- Melhoria: Entrada de mercadoria (manual e automática): opção de nota de doação (por nota e por item), nota mista com revenda, doação e patrimônio; doação entra no estoque sem custo e sem conta a pagar
- Melhoria: Consignação: nota consignada entra no estoque sem conta a pagar; nova tela Consignações para devoluções e acerto com a nota final, que gera o contas a pagar do que ficou
- Melhoria: Vendas: venda pendente (ao sair com itens lançados pergunta, salva como pendente e oferece resgatar ou excluir com usuário e senha)
- Melhoria: Painel inicial com novo layout, período por cartão (padrão: hoje) e sem previsão de vendas do mês
- Melhoria: Menu lateral fixo (acompanha a rolagem só quando não cabe na tela) e telas ajustadas ao tamanho do monitor
- Melhoria: Telas de entrada renomeadas: Entrada de mercadoria (Manual) e (Automática)
- Melhoria: Empresa: guia em PDF para configurar o envio de e-mails (Gmail, Hotmail e outros)
- Melhoria: Atualização automática com endereço de atualizações já configurado e travado; o cliente não precisa informar nada

## 1.1.4 — 02/11/2026
- Correção: Receber não exige mais enviar os itens antes: ao finalizar o recebimento, os itens são enviados automaticamente para a cozinha e o bar (aparecem na tela de produção e o pedido é impresso)

## 1.1.3 — 02/11/2026
- Correção: Clientes e Fornecedores agora aparecem no menu Cadastros
- Correção: Busca de XML na SEFAZ: nunca faz duas consultas com menos de 1h00min02s entre elas (evita bloqueio); intervalo mínimo do agendamento passou a 61 minutos
- Correção: Tela de Vendas ajustada ao tamanho da tela do cliente, sem barras de rolagem desnecessárias
- Melhoria: Painel com gráficos: venda líquida, ticket médio, previsão do mês, top 10 produtos, participação por categoria, compras x vendas e contas a pagar
- Melhoria: Menu reorganizado: Caixa, Conferência de caixa e Receber fiado agora ficam no Financeiro; menu esquerdo pode ser recolhido (botão ☰)
- Melhoria: Tela de vendas: botões Movimento de caixa (entrada/saída de valores), Fechar caixa e Alterar forma de pagamento
- Melhoria: Vendas: com caixa aberto entra direto na venda; sem caixa, já pede a abertura
- Melhoria: Nº da venda só é gerado ao lançar o primeiro produto; botão Cancelar venda sempre visível
- Melhoria: Vendedor da venda editável pelo número do usuário
- Melhoria: Observação no item: produtos podem permitir observação (padrão em porções, pratos e sobremesas); o sistema pergunta ao lançar e mostra no painel de itens
- Melhoria: Doação do troco: antes de entregar o troco, pergunta se o cliente quer doar as moedinhas aos locais definidos nas configurações
- Melhoria: Abertura de caixa pede o nome do evento, a equipe e a função de cada colaborador; durante o evento cada um só acessa o que a função permite
- Melhoria: Usuários: código sequencial, login pelo número com lista de usuários ativos (a partir de 2 letras) e ativar/inativar colaborador sem perder o histórico
- Melhoria: Recuperação de senha por e-mail e novo cadastro da Empresa (e-mail padrão e SMTP)
- Melhoria: Produtos: ficha técnica com unidades (kg/g, L/ml); produto com histórico não pode ser excluído, só inativado; configuração de estoque negativo (com autorização na venda)
- Melhoria: Entrada de mercadoria: a lista mostra se a nota entrou por busca automática de XML, busca manual, serviço por chave, arquivo ou digitação manual
- Melhoria: O instalador fecha sozinho quando tudo ocorre bem

## 1.1.2 — 02/11/2026
- Melhoria: Campos sequenciais (código interno do produto) ficam travados na tela e o número é gerado pelo sistema ao gravar o cadastro
- Melhoria: Códigos de barras e códigos do fornecedor no cadastro de produto agora aparecem em tabela, com o título de cada coluna
- Melhoria: Nenhuma tela do sistema (login, autorização, troca de senha, usuários) deixa o navegador oferecer ou gravar usuário e senha; campos de senha sem preenchimento automático
- Melhoria: Comandas da cozinha e do bar passam a ser impressas somente ao receber o pagamento do cliente (enviar a comanda só libera os itens na tela da cozinha/bar)
- Melhoria: Receber: remover forma de pagamento agora é uma lixeirinha
- Melhoria: Receber: botão Desconto geral trocado por Arredondamento (modal com valor em R$, para mais ou para menos); limites máximos configuráveis em Configurações; permissão própria (ou usuário e senha de quem tem); registrado na auditoria e no pedido
- Melhoria: Venda direta: sem comanda, mesa ou identificação. A tela de Vendas abre direto numa venda nova; pedido da cozinha/bar vai e imprime ao receber; "Vendas anteriores" lista em andamento/finalizadas/canceladas; textos "comanda" trocados por "venda" no sistema
- Melhoria: Observações da venda no campo da tela Receber (grava na venda e sai impressa no pedido da cozinha/bar)
- Melhoria: Estoque só baixa depois que a venda foi paga e TODOS os itens foram entregues (retirados) na cozinha e no bar; até lá o saldo fica reservado para não vender além do estoque
- Melhoria: Na abertura do caixa (e depois, em "Produtos do caixa") escolhe-se quais produtos serão vendidos no evento; a tela de Vendas mostra só esses produtos como botões grandes com imagem, nome e valor; clicar lança na venda (sem digitar nome nem ler código de barras)
- Melhoria: Imagem do produto no cadastro (reduzida automaticamente) para aparecer no botão da tela de vendas
- Melhoria: Produção: tela Estoque → Produção lança o produto preparado (ex.: pipoca) em estoque; a venda baixa só o produto; permissão própria; histórico e Extrato do produto
- Melhoria: Lançar produção em qualquer momento: botão "Produzir" na lista de produtos, campo "Produzir agora" no cadastro do prato e botão "Lançar produção" na tela de Vendas
- Melhoria: Insumos da produção só baixam no fechamento do caixa: a tela de fechar pede a sobra de cada insumo; o sistema baixa (estoque − sobra) e mostra previsto × usado × diferença; sem contagem vale o previsto pela ficha técnica
- Melhoria: Só um caixa aberto por vez no sistema inteiro (abrir e reabrir bloqueiam se já houver outro aberto; trava também no banco)
- Melhoria: Forma de pagamento: taxa da máquina em % e taxa fixa em R$ por transação (aparece na lista).
- Melhoria: Receber: mensagem em destaque quando a venda não pode ser finalizada; o botão fica liberado e abre uma janela explicando o motivo.
- Melhoria: Integração fiscal: cadastro do certificado digital A1, agendamento (por intervalo ou diário) e botão para buscar XMLs na SEFAZ, com painel de notas pendentes de entrada e já importadas no estoque.
- Melhoria: Integração com serviço pago de busca de nota por chave de acesso (inclusive cupom de consumidor), configurável.
- Melhoria: Menu lateral em grupos suspensos (Vendas e caixa, Estoque, Cadastros, Financeiro, Relatórios, Equipe, Configurações); todos os relatórios no mesmo grupo.
- Melhoria: Atualização automática: o sistema do cliente avisa quando há versão nova, pede confirmação, fecha, atualiza (com backup e volta sozinho se falhar), reabre no login e mostra as novidades. Pacote assinado.

## 1.1.1 — 02/11/2026
- Correção: Corrigido: o sistema 1.1.0 não iniciava depois da instalação (erro ao carregar a entrada de mercadoria)
- Melhoria: Instalador/atualizador encerra tudo do sistema antes de atualizar e, se o sistema não responder, mostra as últimas linhas do servidor.log
- Melhoria: Nova tela do instalador (passo atual, barra de progresso, andamento do download e registro colorido em tempo real)
- Melhoria: Ao concluir mostra 'Sistema instalado com sucesso' ou 'Deu erro' com o caminho dos logs, e deixa fechar a janela para procurar o log

## 1.1.0 — 02/11/2026
- Melhoria: Vendas/Comandas: botões Receber fiado e Nova comanda no rodapé; tela de venda no layout de balcão (caixa, nº da venda, vendedor, cliente, busca por nome, código interno ou código de barras)
- Melhoria: Numeração sequencial própria para caixas e vendas (tabelas caixas e vendas)
- Melhoria: Painel de caixa em tabela: filtros, ordenação, conferido, menu de ações, paginação e CSV
- Melhoria: Tela Receber nova: até 3 formas de pagamento, valor recebido e troco em dinheiro, cliente com busca (3 letras) e cadastro rápido, desconto geral, totais, atalhos F2/F10/Ctrl+D
- Melhoria: Códigos de barras em tabela própria (vários por produto, cada um com fator) e código interno automático do produto; códigos do produto em cada fornecedor
- Melhoria: Entrada de mercadoria: fator (unidades por embalagem) divide o custo e multiplica o estoque; entrada manual com busca e cadastro rápido de produto; importação de XML de NF-e, NFC-e e cupom SAT ligando ao cadastro existente sem duplicar
- Melhoria: Ao finalizar a entrada abre o lançamento da despesa (parcelas, vencimento e forma de pagamento) e gera as contas a pagar; nova forma de pagamento Consignado
- Melhoria: Nova tela Ajuste de estoque (avulso), com permissão própria, registrada na tabela ajustes_estoque; novo relatório Extrato do produto
- Melhoria: Impressoras: lista as instaladas no Windows e permite o setor Todos os setores

## 1.0.3 — 02/11/2026
- Correção: Instalador/atualizador falhava no passo 4 (npm) mesmo com o npm concluido com sucesso: o codigo de saida nao era lido
- Melhoria: Botoes com o nome da funcao (Atualizar/Reparar, Desinstalar, Cancelar; Remover banco/Manter banco) no lugar de Sim/Nao
- Melhoria: Log de instalacao em um unico arquivo (pasta\logs\instalacao.log), com data e hora em cada linha, do mais antigo ao mais recente, mostrando o que deu certo e o que deu errado; saida do npm dentro dele; logs com mais de 30 dias sao apagados

## 1.0.2 — 02/11/2026
- Correção: Erro ao entrar no sistema ("(cli || db).query is not a function"): o login nao conseguia gravar o registro de auditoria
- Melhoria: Tela de login abre em janela pequena, so com o cartao arredondado
- Melhoria: Depois de entrar com usuario e senha, a janela se ajusta ao tamanho da tela do cliente
- Melhoria: Atalho dos terminais tambem abre a janela de login pequena

## 1.0.1 — 02/11/2026
- Melhoria: Instalador mostra o andamento (tempo decorrido e ultima linha do log) durante a instalacao do PostgreSQL, Node.js e bibliotecas, para nao parecer travado
- Melhoria: Log da instalacao gravado na pasta escolhida (pasta\logs), incluindo a saida do npm
- Melhoria: Se a instalacao falhar, a pasta e mantida, o log abre no Bloco de Notas e uma nova execucao continua de onde parou
- Melhoria: Download do PostgreSQL com barra de progresso

## 1.0.0 — 02/11/2026
Primeira versão.
- Vendas/comandas com envio para cozinha e bar, controle de itens retirados e bloqueio de estoque negativo (com autorização por usuário e senha).
- Caixa: abertura, sangria/suprimento, fechamento por forma de pagamento com divergência e motivo, conferência, reabertura e alteração de forma de pagamento (com senha).
- Receber fiado (exige caixa aberto), formas de pagamento cadastráveis e integração TEF por pastas (padrão SITEF/TEF_DIAL).
- Cadastros (produtos com ficha técnica, categorias, clientes, fornecedores), estoque com entrada por XML ou manual, financeiro (contas a pagar/receber) e relatórios.
- Usuários, perfis e permissões por tela e por função, com auditoria.
- Backup automático ao abrir e ao fechar (guarda 3 dias), com pasta extra opcional.
- Instalador sem `.exe` (`Instalar-LoPDV-1.0.0.bat`), instalador de atalho para terminais e instalador `.exe` (Electron) a ser gerado.
